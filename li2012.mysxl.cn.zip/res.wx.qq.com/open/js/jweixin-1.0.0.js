!(function (e, n) {
  "function" == typeof define && (define.amd || define.cmd)
    ? define(function () {
        return n(e);
      })
    : n(e, !0);
})(this, function (r, e) {
  var c, a, n, i, t, s, d, o, l, p, u, f, m, g, h, y, S, _, w, I;
  if (!r.jWeixin)
    return (
      (c = {
        config: "preVerifyJSAPI",
        onMenuShareTimeline: "menu:share:timeline",
        onMenuShareAppMessage: "menu:share:appmessage",
        onMenuShareQQ: "menu:share:qq",
        onMenuShareWeibo: "menu:share:weiboApp",
        onMenuShareQZone: "menu:share:QZone",
        previewImage: "imagePreview",
        getLocation: "geoLocation",
        openProductSpecificView: "openProductViewWithPid",
        addCard: "batchAddCard",
        openCard: "batchViewCard",
        chooseWXPay: "getBrandWCPayRequest",
      }),
      (a = (function () {
        var e,
          n = {};
        for (e in c) n[c[e]] = e;
        return n;
      })()),
      (n = r.document),
      (i = n.title),
      (t = navigator.userAgent.toLowerCase()),
      (f = navigator.platform.toLowerCase()),
      (s = !(!f.match("mac") && !f.match("win"))),
      (d = -1 != t.indexOf("wxdebugger")),
      (o = -1 != t.indexOf("micromessenger")),
      (l = -1 != t.indexOf("android")),
      (p = -1 != t.indexOf("iphone") || -1 != t.indexOf("ipad")),
      (u = (f =
        t.match(/micromessenger\/(\d+\.\d+\.\d+)/) ||
        t.match(/micromessenger\/(\d+\.\d+)/))
        ? f[1]
        : ""),
      (g = m = !1),
      (h = {
        initStartTime: b(),
        initEndTime: 0,
        preVerifyStartTime: 0,
        preVerifyEndTime: 0,
      }),
      (y = {
        version: 1,
        appId: "",
        initTime: 0,
        preVerifyTime: 0,
        networkType: "",
        preVerifyState: 1,
        systemType: p ? 1 : l ? 2 : -1,
        clientVersion: u,
        url: encodeURIComponent(location.href),
      }),
      (S = {}),
      (_ = { _completes: [] }),
      (w = { state: 0, data: {} }),
      A(function () {
        h.initEndTime = b();
      }),
      (I = {
        config: function (e) {
          x("config", (S = e));
          var o = !1 !== S.check;
          A(function () {
            if (o)
              T(
                c.config,
                { verifyJsApiList: V(S.jsApiList) },
                ((_._complete = function (e) {
                  (h.preVerifyEndTime = b()), (w.state = 1), (w.data = e);
                }),
                (_.success = function (e) {
                  y.preVerifyState = 0;
                }),
                (_.fail = function (e) {
                  _._fail ? _._fail(e) : (w.state = -1);
                }),
                (t = _._completes).push(function () {
                  0 == y.preVerifyState ||
                    s ||
                    d ||
                    S.debug ||
                    u < "6.0.2" ||
                    y.systemType < 0 ||
                    m ||
                    ((m = !0),
                    (y.appId = S.appId),
                    (y.initTime = h.initEndTime - h.initStartTime),
                    (y.preVerifyTime =
                      h.preVerifyEndTime - h.preVerifyStartTime),
                    I.getNetworkType({
                      isInnerInvoke: !0,
                      success: function (e) {
                        y.networkType = e.networkType;
                        e =
                          "http://open.weixin.qq.com/sdk/report?v=" +
                          y.version +
                          "&o=" +
                          y.preVerifyState +
                          "&s=" +
                          y.systemType +
                          "&c=" +
                          y.clientVersion +
                          "&a=" +
                          y.appId +
                          "&n=" +
                          y.networkType +
                          "&i=" +
                          y.initTime +
                          "&p=" +
                          y.preVerifyTime +
                          "&u=" +
                          y.url;
                        new Image().src = e;
                      },
                    }));
                }),
                (_.complete = function (e) {
                  for (var n = 0, i = t.length; n < i; ++n) t[n]();
                  _._completes = [];
                }),
                _)
              ),
                (h.preVerifyStartTime = b());
            else {
              w.state = 1;
              for (var e = _._completes, n = 0, i = e.length; n < i; ++n)
                e[n]();
              _._completes = [];
            }
            var t;
          }),
            S.beta &&
              !I.invoke &&
              ((I.invoke = function (e, n, i) {
                r.WeixinJSBridge && WeixinJSBridge.invoke(e, k(n), i);
              }),
              (I.on = function (e, n) {
                r.WeixinJSBridge && WeixinJSBridge.on(e, n);
              }));
        },
        ready: function (e) {
          (0 != w.state || (_._completes.push(e), !o && S.debug)) && e();
        },
        error: function (e) {
          u < "6.0.2" ||
            g ||
            ((g = !0), -1 == w.state ? e(w.data) : (_._fail = e));
        },
        checkJsApi: function (e) {
          T(
            "checkJsApi",
            { jsApiList: V(e.jsApiList) },
            ((e._complete = function (e) {
              l && (i = e.checkResult) && (e.checkResult = JSON.parse(i));
              var n,
                i = e,
                t = i.checkResult;
              for (n in t) {
                var o = a[n];
                o && ((t[o] = t[n]), delete t[n]);
              }
            }),
            e)
          );
        },
        onMenuShareTimeline: function (e) {
          v(
            c.onMenuShareTimeline,
            {
              complete: function () {
                T(
                  "shareTimeline",
                  {
                    title: e.title || i,
                    desc: e.title || i,
                    img_url: e.imgUrl || "",
                    link: e.link || location.href,
                    type: e.type || "link",
                    data_url: e.dataUrl || "",
                  },
                  e
                );
              },
            },
            e
          );
        },
        onMenuShareAppMessage: function (n) {
          v(
            c.onMenuShareAppMessage,
            {
              complete: function (e) {
                "favorite" === e.scene
                  ? T("sendAppMessage", {
                      title: n.title || i,
                      desc: n.desc || "",
                      link: n.link || location.href,
                      img_url: n.imgUrl || "",
                      type: n.type || "link",
                      data_url: n.dataUrl || "",
                    })
                  : T(
                      "sendAppMessage",
                      {
                        title: n.title || i,
                        desc: n.desc || "",
                        link: n.link || location.href,
                        img_url: n.imgUrl || "",
                        type: n.type || "link",
                        data_url: n.dataUrl || "",
                      },
                      n
                    );
              },
            },
            n
          );
        },
        onMenuShareQQ: function (e) {
          v(
            c.onMenuShareQQ,
            {
              complete: function () {
                T(
                  "shareQQ",
                  {
                    title: e.title || i,
                    desc: e.desc || "",
                    img_url: e.imgUrl || "",
                    link: e.link || location.href,
                  },
                  e
                );
              },
            },
            e
          );
        },
        onMenuShareWeibo: function (e) {
          v(
            c.onMenuShareWeibo,
            {
              complete: function () {
                T(
                  "shareWeiboApp",
                  {
                    title: e.title || i,
                    desc: e.desc || "",
                    img_url: e.imgUrl || "",
                    link: e.link || location.href,
                  },
                  e
                );
              },
            },
            e
          );
        },
        onMenuShareQZone: function (e) {
          v(
            c.onMenuShareQZone,
            {
              complete: function () {
                T(
                  "shareQZone",
                  {
                    title: e.title || i,
                    desc: e.desc || "",
                    img_url: e.imgUrl || "",
                    link: e.link || location.href,
                  },
                  e
                );
              },
            },
            e
          );
        },
        startRecord: function (e) {
          T("startRecord", {}, e);
        },
        stopRecord: function (e) {
          T("stopRecord", {}, e);
        },
        onVoiceRecordEnd: function (e) {
          v("onVoiceRecordEnd", e);
        },
        playVoice: function (e) {
          T("playVoice", { localId: e.localId }, e);
        },
        pauseVoice: function (e) {
          T("pauseVoice", { localId: e.localId }, e);
        },
        stopVoice: function (e) {
          T("stopVoice", { localId: e.localId }, e);
        },
        onVoicePlayEnd: function (e) {
          v("onVoicePlayEnd", e);
        },
        uploadVoice: function (e) {
          T(
            "uploadVoice",
            {
              localId: e.localId,
              isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1,
            },
            e
          );
        },
        downloadVoice: function (e) {
          T(
            "downloadVoice",
            {
              serverId: e.serverId,
              isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1,
            },
            e
          );
        },
        translateVoice: function (e) {
          T(
            "translateVoice",
            {
              localId: e.localId,
              isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1,
            },
            e
          );
        },
        chooseImage: function (e) {
          T(
            "chooseImage",
            {
              scene: "1|2",
              count: e.count || 9,
              sizeType: e.sizeType || ["original", "compressed"],
              sourceType: e.sourceType || ["album", "camera"],
            },
            ((e._complete = function (e) {
              if (l) {
                var n = e.localIds;
                try {
                  n && (e.localIds = JSON.parse(n));
                } catch (e) {}
              }
            }),
            e)
          );
        },
        previewImage: function (e) {
          T(c.previewImage, { current: e.current, urls: e.urls }, e);
        },
        uploadImage: function (e) {
          T(
            "uploadImage",
            {
              localId: e.localId,
              isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1,
            },
            e
          );
        },
        downloadImage: function (e) {
          T(
            "downloadImage",
            {
              serverId: e.serverId,
              isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1,
            },
            e
          );
        },
        getNetworkType: function (e) {
          T(
            "getNetworkType",
            {},
            ((e._complete = function (e) {
              var n = e,
                e = n.errMsg,
                i = ((n.errMsg = "getNetworkType:ok"), n.subtype);
              if ((delete n.subtype, i)) n.networkType = i;
              else {
                var i = e.indexOf(":"),
                  t = e.substring(i + 1);
                switch (t) {
                  case "wifi":
                  case "edge":
                  case "wwan":
                    n.networkType = t;
                    break;
                  default:
                    n.errMsg = "getNetworkType:fail";
                }
              }
            }),
            e)
          );
        },
        openLocation: function (e) {
          T(
            "openLocation",
            {
              latitude: e.latitude,
              longitude: e.longitude,
              name: e.name || "",
              address: e.address || "",
              scale: e.scale || 28,
              infoUrl: e.infoUrl || "",
            },
            e
          );
        },
        getLocation: function (e) {
          (e = e || {}),
            T(
              c.getLocation,
              { type: e.type || "wgs84" },
              ((e._complete = function (e) {
                delete e.type;
              }),
              e)
            );
        },
        hideOptionMenu: function (e) {
          T("hideOptionMenu", {}, e);
        },
        showOptionMenu: function (e) {
          T("showOptionMenu", {}, e);
        },
        closeWindow: function (e) {
          T("closeWindow", {}, (e = e || {}));
        },
        hideMenuItems: function (e) {
          T("hideMenuItems", { menuList: e.menuList }, e);
        },
        showMenuItems: function (e) {
          T("showMenuItems", { menuList: e.menuList }, e);
        },
        hideAllNonBaseMenuItem: function (e) {
          T("hideAllNonBaseMenuItem", {}, e);
        },
        showAllNonBaseMenuItem: function (e) {
          T("showAllNonBaseMenuItem", {}, e);
        },
        scanQRCode: function (e) {
          T(
            "scanQRCode",
            {
              needResult: (e = e || {}).needResult || 0,
              scanType: e.scanType || ["qrCode", "barCode"],
            },
            ((e._complete = function (e) {
              var n;
              p &&
                (n = e.resultStr) &&
                ((n = JSON.parse(n)),
                (e.resultStr = n && n.scan_code && n.scan_code.scan_result));
            }),
            e)
          );
        },
        openProductSpecificView: function (e) {
          T(
            c.openProductSpecificView,
            {
              pid: e.productId,
              view_type: e.viewType || 0,
              ext_info: e.extInfo,
            },
            e
          );
        },
        addCard: function (e) {
          for (var n = e.cardList, i = [], t = 0, o = n.length; t < o; ++t) {
            var r = n[t],
              r = { card_id: r.cardId, card_ext: r.cardExt };
            i.push(r);
          }
          T(
            c.addCard,
            { card_list: i },
            ((e._complete = function (e) {
              if ((n = e.card_list)) {
                for (var n, i = 0, t = (n = JSON.parse(n)).length; i < t; ++i) {
                  var o = n[i];
                  (o.cardId = o.card_id),
                    (o.cardExt = o.card_ext),
                    (o.isSuccess = !!o.is_succ),
                    delete o.card_id,
                    delete o.card_ext,
                    delete o.is_succ;
                }
                (e.cardList = n), delete e.card_list;
              }
            }),
            e)
          );
        },
        chooseCard: function (e) {
          T(
            "chooseCard",
            {
              app_id: S.appId,
              location_id: e.shopId || "",
              sign_type: e.signType || "SHA1",
              card_id: e.cardId || "",
              card_type: e.cardType || "",
              card_sign: e.cardSign,
              time_stamp: e.timestamp + "",
              nonce_str: e.nonceStr,
            },
            ((e._complete = function (e) {
              (e.cardList = e.choose_card_info), delete e.choose_card_info;
            }),
            e)
          );
        },
        openCard: function (e) {
          for (var n = e.cardList, i = [], t = 0, o = n.length; t < o; ++t) {
            var r = n[t],
              r = { card_id: r.cardId, code: r.code };
            i.push(r);
          }
          T(c.openCard, { card_list: i }, e);
        },
        chooseWXPay: function (e) {
          T(
            c.chooseWXPay,
            {
              timeStamp: e.timestamp + "",
              nonceStr: e.nonceStr,
              package: e.package,
              paySign: e.paySign,
              signType: e.signType || "SHA1",
            },
            e
          );
        },
      }),
      e && (r.wx = r.jWeixin = I),
      I
    );
  function T(n, e, i) {
    r.WeixinJSBridge
      ? WeixinJSBridge.invoke(n, k(e), function (e) {
          M(n, e, i);
        })
      : x(n, i);
  }
  function v(n, i, t) {
    r.WeixinJSBridge
      ? WeixinJSBridge.on(n, function (e) {
          t && t.trigger && t.trigger(e), M(n, e, i);
        })
      : x(n, t || i);
  }
  function k(e) {
    return (
      ((e = e || {}).appId = S.appId),
      (e.verifyAppId = S.appId),
      (e.verifySignType = "sha1"),
      (e.verifyTimestamp = S.timestamp + ""),
      (e.verifyNonceStr = S.nonceStr),
      (e.verifySignature = S.signature),
      e
    );
  }
  function M(e, n, i) {
    delete n.err_code, delete n.err_desc, delete n.err_detail;
    var t = n.errMsg,
      e =
        (t ||
          ((t = n.err_msg),
          delete n.err_msg,
          (t = (function (e, n) {
            var i = a[e];
            i && (e = i);
            i = "ok";
            {
              var t;
              n &&
                ((t = n.indexOf(":")),
                ("access denied" !=
                  (i = (i = (i =
                    -1 !=
                    (i =
                      -1 !=
                      (i =
                        "failed" ==
                        (i = "confirm" == (i = n.substring(t + 1)) ? "ok" : i)
                          ? "fail"
                          : i).indexOf("failed_")
                        ? i.substring(7)
                        : i).indexOf("fail_")
                      ? i.substring(5)
                      : i).replace(/_/g, " ")).toLowerCase()) &&
                  "no permission to execute" != i) ||
                  (i = "permission denied"),
                "" ==
                  (i =
                    "config" == e && "function not exist" == i ? "ok" : i)) &&
                (i = "fail");
            }
            return (n = e + ":" + i);
          })(e, t)),
          (n.errMsg = t)),
        (i = i || {})._complete && (i._complete(n), delete i._complete),
        (t = n.errMsg || ""),
        S.debug && !i.isInnerInvoke && alert(JSON.stringify(n)),
        t.indexOf(":"));
    switch (t.substring(e + 1)) {
      case "ok":
        i.success && i.success(n);
        break;
      case "cancel":
        i.cancel && i.cancel(n);
        break;
      default:
        i.fail && i.fail(n);
    }
    i.complete && i.complete(n);
  }
  function V(e) {
    if (e) {
      for (var n = 0, i = e.length; n < i; ++n) {
        var t = e[n],
          t = c[t];
        t && (e[n] = t);
      }
      return e;
    }
  }
  function x(e, n) {
    var i;
    !S.debug ||
      (n && n.isInnerInvoke) ||
      ((i = a[e]) && (e = i),
      n && n._complete && delete n._complete,
      console.log('"' + e + '",', n || ""));
  }
  function b() {
    return new Date().getTime();
  }
  function A(e) {
    o &&
      (r.WeixinJSBridge
        ? e()
        : n.addEventListener &&
          n.addEventListener("WeixinJSBridgeReady", e, !1));
  }
});
