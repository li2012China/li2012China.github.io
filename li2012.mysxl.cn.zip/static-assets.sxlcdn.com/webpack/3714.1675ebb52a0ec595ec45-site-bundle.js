/*! For license information please see 3714.1675ebb52a0ec595ec45-site-bundle.js.LICENSE.txt */
"use strict";
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [3714],
  {
    577444: function (e, t, a) {
      var l = a(501068),
        u = a(663978),
        o = a(60530)(a(60530));
      u(t, "__esModule", { value: !0 }), (t.default = void 0);
      var f = a(812077),
        i = (0, o.default)(f),
        n = a(726394),
        r = (0, o.default)(n),
        d = a(569198),
        c = (0, o.default)(d),
        p = a(351379),
        s = (0, o.default)(p),
        v = a(900214),
        y = (0, o.default)(v),
        h = a(566380),
        g = (0, o.default)(h),
        k = a(366757),
        m = (0, o.default)(k),
        _ = a(818166),
        C = (0, o.default)(_),
        D = a(183123),
        b = (0, o.default)(D);
      var P = (function (e) {
        (0, s.default)(o, e);
        var t,
          a,
          u =
            ((t = o),
            (a = (function () {
              if ("undefined" == typeof Reflect || !l) return !1;
              if (l.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    l(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                u = (0, g.default)(t);
              if (a) {
                var o = (0, g.default)(this).constructor;
                e = l(u, arguments, o);
              } else e = u.apply(this, arguments);
              return (0, y.default)(this, e);
            });
        function o() {
          return (0, r.default)(this, o), u.apply(this, arguments);
        }
        return (
          (0, c.default)(o, [
            {
              key: "render",
              value: function () {
                var e = b.default.getIsBlog()
                  ? $S.siteData.privacy_policy_text
                  : C.default.getPrivacyPolicyText();
                return (0, i.default)(
                  "pre",
                  { style: { whiteSpace: "pre-wrap" } },
                  void 0,
                  e
                );
              },
            },
          ]),
          o
        );
      })(m.default.Component);
      (t.default = P), (e.exports = t.default);
    },
    773714: function (e, t, a) {
      var l = a(353147),
        u = a(501068),
        o = a(663978),
        f = a(60530)(a(60530));
      o(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i,
        n = a(812077),
        r = (0, f.default)(n),
        d = a(726394),
        c = (0, f.default)(d),
        p = a(569198),
        s = (0, f.default)(p),
        v = a(351379),
        y = (0, f.default)(v),
        h = a(900214),
        g = (0, f.default)(h),
        k = a(566380),
        m = (0, f.default)(k),
        _ = a(366757),
        C = (0, f.default)(_),
        D = a(141655),
        b = (0, f.default)(D),
        P = a(577444),
        x = (0, f.default)(P),
        w = a(223336),
        B = (0, f.default)(w);
      var N = (function (e) {
        (0, y.default)(f, e);
        var t,
          a,
          o =
            ((t = f),
            (a = (function () {
              if ("undefined" == typeof Reflect || !u) return !1;
              if (u.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    u(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                l = (0, m.default)(t);
              if (a) {
                var o = (0, m.default)(this).constructor;
                e = u(l, arguments, o);
              } else e = l.apply(this, arguments);
              return (0, g.default)(this, e);
            });
        function f() {
          return (0, c.default)(this, f), o.apply(this, arguments);
        }
        return (
          (0, s.default)(f, [
            {
              key: "_onClickCloseDialog",
              value: function () {
                b.default.closeDialog("cookieNotification");
              },
            },
            {
              key: "componentDidMount",
              value: function () {
                "privacy-policy" === B.default.url().param("open") &&
                  b.default.openDialog("privacyPolicyDialog"),
                  (0, B.default)("body").delegate(
                    'a[href$="open=privacy-policy"]',
                    "click",
                    function () {
                      b.default.openDialog("privacyPolicyDialog");
                    }
                  );
              },
            },
            {
              key: "render",
              value: function () {
                return (0, r.default)(
                  "div",
                  {
                    id: "privacy-policy-dialog",
                    className: "s-terms-dialog s-edit-modal",
                  },
                  void 0,
                  (0, r.default)(
                    "div",
                    {
                      className: "close-button",
                      onClick: this._onClickCloseDialog,
                    },
                    void 0,
                    "×"
                  ),
                  (0, r.default)(
                    "div",
                    { className: "title-wrapper" },
                    void 0,
                    l("EditorSettings|Privacy Policy")
                  ),
                  i || (i = (0, r.default)(x.default, {}))
                );
              },
            },
          ]),
          f
        );
      })(C.default.Component);
      (t.default = N), (e.exports = t.default);
    },
  },
]);
