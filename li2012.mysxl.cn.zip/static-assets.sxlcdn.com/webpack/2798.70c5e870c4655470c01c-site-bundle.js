/*! For license information please see 2798.70c5e870c4655470c01c-site-bundle.js.LICENSE.txt */
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [2798],
  {
    952798: function (e, t, n) {
      var a = n(51580);
      n(496486),
        (e.exports = {
          internal: "s5-theme",
          displayName: "S5-theme",
          description: "Crisp and modern. Show off images & videos.",
          activated: !1,
          thumbnail: a.correctThumbnailPath(n(866951)),
          defaultFonts: {
            heading: "montserrat",
            title: "montserrat",
            body: "montserrat",
            button: "montserrat",
            navItem: "montserrat",
            navDropdown: "montserrat",
          },
          features: {
            verticalAlignRowsSection: !0,
            itemSubtitleDefaultStyle: "bold",
            backgroundColorRotate: !1,
            backgroundColorClassNames: ["s-bg-white", "s-bg-gray", "s-bg-dark"],
          },
          callbacks: {
            CustomColorsTemplate: n(433907),
            after_render: n(379388),
          },
          sections: {
            blog: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(785478),
              template: n(661532),
              thumbnail: {
                cover: a.correctThumbnailPath(n(486033)),
                template: n(99584),
              },
            },
            columns: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(400342),
              template: n(125973),
              thumbnail: {
                cover: a.correctThumbnailPath(n(991010)),
                template: n(261844),
              },
            },
            contact_form: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(637906),
              template: n(843218),
              thumbnail: {
                cover: a.correctThumbnailPath(n(808394)),
                template: n(325020),
              },
            },
            cta: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(91252),
              template: n(285192),
              thumbnail: {
                cover: a.correctThumbnailPath(n(728083)),
                template: n(734143),
              },
            },
            ecommerce: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(780847),
              template: n(355762),
              thumbnail: {
                cover: a.correctThumbnailPath(n(779865)),
                template: n(645777),
              },
            },
            gallery: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(305228),
              template: n(76430),
              thumbnail: {
                cover: a.correctThumbnailPath(n(42003)),
                template: n(810915),
              },
            },
            html: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(980190),
              template: n(4878),
              thumbnail: {
                cover: a.correctThumbnailPath(n(72643)),
                template: n(658077),
              },
            },
            icons: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(401062),
              template: n(937756),
              thumbnail: {
                cover: a.correctThumbnailPath(n(877232)),
                template: n(518503),
              },
            },
            info: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(90724),
              template: n(219329),
              thumbnail: {
                cover: a.correctThumbnailPath(n(220945)),
                template: n(489336),
              },
            },
            media: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(299111),
              template: n(658875),
              thumbnail: {
                cover: a.correctThumbnailPath(n(733381)),
                template: n(50288),
              },
            },
            navbar: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(269597),
              template: n(276085),
            },
            rows: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(537282),
              template: n(296295),
              thumbnail: {
                cover: a.correctThumbnailPath(n(896e3)),
                template: n(595950),
              },
            },
            signup_form: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(977741),
              template: n(52307),
              thumbnail: {
                cover: a.correctThumbnailPath(n(15501)),
                template: n(563657),
              },
            },
            slider: {
              proFeature: !0,
              canEditInMobileApp: !1,
              component: n(612535),
              template: n(38730),
              thumbnail: {
                cover: a.correctThumbnailPath(n(244486)),
                template: n(812938),
              },
            },
            social_feed: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(684321),
              template: n(528677),
              thumbnail: {
                cover: a.correctThumbnailPath(n(702654)),
                template: n(245855),
              },
            },
            text: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(484182),
              template: n(458582),
              thumbnail: {
                cover: a.correctThumbnailPath(n(893096)),
                template: n(667472),
              },
            },
            title: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(191333),
              template: n(595825),
              thumbnail: {
                cover: a.correctThumbnailPath(n(421630)),
                template: n(323682),
              },
            },
            block: {
              proFeature: !0,
              canEditInMobileApp: !1,
              component: n(533126),
              template: n(277139),
              thumbnail: { template: n(912955) },
            },
            blog1: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(854673),
              template: n(856230),
              thumbnail: {
                cover: a.correctThumbnailPath(n(591021)),
                template: n(347347),
              },
            },
            blog2: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(396204),
              template: n(789505),
              thumbnail: { template: n(186954) },
            },
            blog3: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(134469),
              template: n(801564),
              thumbnail: { template: n(813564) },
            },
            custom_form: {
              proFeature: !0,
              canEditInMobileApp: !0,
              component: n(612953),
              template: n(147629),
              thumbnail: { template: n(821234) },
            },
            donation: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(425192),
              template: n(829088),
              thumbnail: { template: n(919338) },
            },
            faq: {
              proFeature: !0,
              canEditInMobileApp: !0,
              component: n(583617),
              template: n(97786),
              thumbnail: { template: n(214783) },
            },
            featureListA: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(352596),
              template: n(970748),
              thumbnail: { template: n(287471) },
            },
            featureListB: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(530737),
              template: n(384533),
              thumbnail: { template: n(567837) },
            },
            featureListC: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(321479),
              template: n(19644),
              thumbnail: { template: n(343148) },
            },
            featureListD: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(984161),
              template: n(890128),
              thumbnail: { template: n(849946) },
            },
            footer: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(679669),
              template: n(475448),
            },
            gallery1: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(837947),
              template: n(568365),
              thumbnail: { template: n(293302) },
            },
            gallery2: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(321178),
              template: n(437600),
              thumbnail: { template: n(134878) },
            },
            gallery3: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(216177),
              template: n(444195),
              thumbnail: { template: n(36176) },
            },
            gallery4: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(37509),
              template: n(370631),
              thumbnail: { template: n(5246) },
            },
            gallery5: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(435685),
              template: n(411486),
              thumbnail: { template: n(90408) },
            },
            gallery6: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(939947),
              template: n(447167),
              thumbnail: { template: n(268163) },
            },
            grid: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(188717),
              template: n(765146),
              thumbnail: { template: n(57451) },
            },
            hero: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(449030),
              template: n(349906),
              thumbnail: {
                cover: a.correctThumbnailPath(n(53394)),
                template: n(821597),
              },
            },
            media1: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(114208),
              template: n(4390),
              thumbnail: { template: n(924750) },
            },
            media2: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(549212),
              template: n(718773),
              thumbnail: { template: n(642958) },
            },
            media3: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(485253),
              template: n(347072),
              thumbnail: { template: n(119775) },
            },
            portfolio: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(991485),
              template: n(441959),
              thumbnail: { template: n(282074) },
            },
            pricing: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(416534),
              template: n(283238),
              thumbnail: { template: n(763542) },
            },
            process: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(433006),
              template: n(604366),
              thumbnail: { template: n(868437) },
            },
            s6_common_section: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(96152),
              template: n(687006),
              thumbnail: { template: n(978122) },
            },
            booking: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(264096),
              template: n(322787),
              thumbnail: { template: n(201680) },
            },
            featureListE: {
              proFeature: !1,
              canEditInMobileApp: !0,
              component: n(635209),
              template: n(105073),
              thumbnail: { template: n(123418) },
            },
            new_grid: {
              proFeature: !1,
              canEditInMobileApp: !1,
              component: n(734988),
              template: n(625665),
              thumbnail: { template: n(873868) },
            },
          },
        });
    },
    540599: function (e, t, n) {
      var a = n(893379),
        i = n(558042);
      "string" == typeof (i = i.__esModule ? i.default : i) &&
        (i = [[e.id, i, ""]]);
      a(i, { insert: "head", singleton: !1 }), (e.exports = i.locals || {});
    },
    661840: function (e, t, n) {
      "use strict";
      var a = n(573126),
        i = n(841266),
        o = n(366757),
        s = n(805803),
        r = ["to", "children"];
      t.Z = function (e) {
        var t = e.to,
          n = e.children,
          l = (0, i.Z)(e, r);
        return o.createElement(s.Link, (0, a.Z)({ to: t }, l), n);
      };
    },
    987893: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          default: function () {
            return Vt;
          },
        });
      var a = n(686902),
        i = n.n(a),
        o = n(14310),
        s = n.n(o),
        r = n(834074),
        l = n.n(r),
        c = n(778914),
        d = n.n(c),
        u = n(239649),
        p = n.n(u),
        m = n(820368),
        h = n.n(m),
        v = n(663978),
        f = n.n(v),
        g = n(573126),
        b = n(844845),
        y = n(863056),
        x = n(54103),
        w = n.n(x),
        S = n(694473),
        C = n.n(S),
        k = n(394198),
        N = n.n(k),
        M = n(620116),
        E = n.n(M),
        _ = n(678580),
        Z = n.n(_),
        I = n(2991),
        P = n.n(I),
        L = n(977766),
        T = n.n(L),
        O = n(277149),
        B = n.n(O),
        D = n(729828),
        A = n.n(D),
        R =
          (n(974916),
          n(115306),
          n(66992),
          n(241539),
          n(788674),
          n(978783),
          n(333948),
          n(323123),
          n(569600),
          n(366757)),
        F = n(973935),
        H = n(45697),
        j = n(496486),
        U = n(907423),
        W = n(234584),
        V = n(818166),
        z = n(229081),
        Q = n(145546),
        G = n(156503),
        J = n(815549),
        q = n(357646),
        K = n(365940),
        Y = n(832313),
        X = n(501068),
        $ = n.n(X),
        ee = n(841266),
        te = n(468420),
        ne = n(327344),
        ae = n(505281),
        ie = n(484441),
        oe = n(103020),
        se = n(803362),
        re = n(51942),
        le = n.n(re),
        ce = n(981643),
        de = n.n(ce),
        ue = n(143393),
        pe = n(294184),
        me = n.n(pe),
        he = n(104802),
        ve = n(387937),
        fe = n(726469),
        ge = n(332578),
        be = n(879042),
        ye = n(878210),
        xe = n(183123),
        we = n(685231),
        Se = function (e) {
          var t = e.url,
            n = e.visible,
            a = e.onCancelDialog;
          return (0, y.Z)(
            we.Z,
            {
              zIndex: 2600,
              visible: n,
              onCancel: a,
              wrapClassName: "social-media-qr-code",
            },
            void 0,
            (0, y.Z)("img", { className: "qr-code", src: t })
          );
        },
        Ce = n(786483),
        ke = n(141655),
        Ne = n(723367),
        Me = n(871745),
        Ee = n(318592),
        _e = n(353147),
        Ze = ["type"];
      function Ie(e, t) {
        var n = i()(e);
        if (s()) {
          var a = s()(e);
          t &&
            (a = E()(a).call(a, function (t) {
              return l()(e, t).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      function Pe(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n,
            a = null != arguments[t] ? arguments[t] : {};
          if (t % 2)
            d()((n = Ie(Object(a), !0))).call(n, function (t) {
              (0, b.Z)(e, t, a[t]);
            });
          else if (p()) h()(e, p()(a));
          else {
            var i;
            d()((i = Ie(Object(a)))).call(i, function (t) {
              f()(e, t, l()(a, t));
            });
          }
        }
        return e;
      }
      var Le = ["a", "b", "d", "h", "i"],
        Te = "button",
        Oe = "link",
        Be = (function (e) {
          (0, ie.Z)(o, e);
          var t,
            a,
            i =
              ((t = o),
              (a = (function () {
                if ("undefined" == typeof Reflect || !$()) return !1;
                if ($().sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                  return (
                    Boolean.prototype.valueOf.call(
                      $()(Boolean, [], function () {})
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              })()),
              function () {
                var e,
                  n = (0, se.Z)(t);
                if (a) {
                  var i = (0, se.Z)(this).constructor;
                  e = $()(n, arguments, i);
                } else e = n.apply(this, arguments);
                return (0, oe.Z)(this, e);
              });
          function o(e) {
            var t;
            return (
              (0, te.Z)(this, o),
              (t = i.call(this, e)),
              (0, b.Z)((0, ae.Z)(t), "_subscribeToken", null),
              (0, b.Z)((0, ae.Z)(t), "handleShowQRCode", function (e) {
                t.setState({
                  QRCodeUrl: e,
                  showQRCode: !0,
                  canClosePopover: !1,
                });
              }),
              (0, b.Z)((0, ae.Z)(t), "handleCancelDialog", function () {
                t.setState({ showQRCode: !1, canClosePopover: !0 });
              }),
              (0, b.Z)((0, ae.Z)(t), "handleOpenPopover", function () {
                t.state.visible || t.setState({ visible: !0 });
              }),
              (0, b.Z)((0, ae.Z)(t), "handleClosePopover", function () {
                t.state.visible && t.setState({ visible: !1 });
              }),
              (0, b.Z)((0, ae.Z)(t), "handleVisibleChange", function (e) {
                t.state.canClosePopover && t.setState({ visible: e });
              }),
              (0, b.Z)((0, ae.Z)(t), "handleCanClosePopover", function (e) {
                t.setState({ canClosePopover: e });
              }),
              (0, b.Z)((0, ae.Z)(t), "handleIconShowQRCode", function (e, n) {
                var a = e,
                  i = a.url,
                  o = a.type;
                (be.sxlSocialMediaMap[o] || {}).shareType === fe.yP.QR_CODE &&
                  (n.stopPropagation(),
                  n.preventDefault(),
                  t.handleShowQRCode(i));
              }),
              (0, b.Z)((0, ae.Z)(t), "handleSaveData", function (e, t) {
                ke.updateThemeConfigValue("nav.socialMedia", ue.fromJS(e)),
                  ke.updateNavSocialMediaContactList(ue.fromJS(t));
              }),
              (0, b.Z)(
                (0, ae.Z)(t),
                "getIsHasSocialMediaContactList",
                function () {
                  var e = V.sub("s5Theme.nav.socialMediaContactList").get();
                  return null == e
                    ? void 0
                    : B()(e).call(e, function (e) {
                        return e.get("defaultValue");
                      });
                }
              ),
              (0, b.Z)(
                (0, ae.Z)(t),
                "getIsHasSocialMediaButtonList",
                function () {
                  var e;
                  return null === (e = t.getNavSocialMediaButtonList().get()) ||
                    void 0 === e
                    ? void 0
                    : B()(e).call(e, function (e) {
                        return e.get("show_button");
                      });
                }
              ),
              (0, b.Z)((0, ae.Z)(t), "_getStyle", function () {
                var e = t.props,
                  n = e.socialMediaList,
                  a = (e.navObject || {}).layout;
                return (0,
                Ee.css)("&{position:relative;display:flex;align-items:center;}.s-social-media-buttons-wrap{display:flex;align-items:center;flex-flow:row wrap;.s-social-media-button{margin:0 10px;.col.fb-counter{iframe{top:4px;}}.col.twitter-counter{iframe{display:inherit;}}}}.social-media-svg{height:16px;fill:currentColor;}", "g" === a && n.length <= 5 && "\n        margin-right: 5px;\n        .social-media-link {\n          margin-right: 10px;\n          &:first-child {\n            margin-left: 0;\n          }\n        }\n      ", "\n      ", "g" !== a && n.length <= 5 && !xe.getNewNavHeaderDesign() && "\n        .social-media-link {\n          margin: 0 15px;\n        }\n      ", "\n      ", "g" === a ? "\n        ul.s-navbar-dropdown.social-medial-ul {\n          transform: translateY(-100%);\n          margin-left: -30px !important;\n        }" : "", "\n      .dropdown-social-media\n      .s-nav-dropdown\n      .s-nav-link-container\n      .social-media-link{margin-right:5px;}.s-component-empty{width:150px;.overlay{position:relative;}.center{white-space:normal;}}", n.length > 1 && !t.getIsHasSocialMediaContactList() ? "\n        @media only screen and (min-width: 1281px) {\n        .small-screen-social-media {\n          display: none;\n        }\n      }\n      @media only screen and (max-width: 1280px) {\n        .large-screen-social-media {\n          display: none;\n        }\n        .s-nav-dropdown .social-media-link {\n          margin: 10px 10px;\n        }\n        .s-nav-link-container:not(.s-nav-dropdown) {\n          margin-right: 10px;\n          .social-media-link {\n            margin-right: 0;\n          }\n        }\n      }\n      " : "\n      .small-screen-social-media {\n          display: none;\n        }\n      ");
              }),
              (0, b.Z)((0, ae.Z)(t), "getIconLink", function (e) {
                var n,
                  a = e.type,
                  i = be.sxlSocialMediaMap[a] || {},
                  o = i.viewBox,
                  s = i.svgCode,
                  r = i.iconType;
                return (0,
                y.Z)("a", { onClick: w()((n = t.handleIconShowQRCode)).call(n, (0, ae.Z)(t), e), href: (0, ge.getSocialMedialUrl)(e.url), "aria-label": _e("SocialMedia|Social media links"), target: "_blank", className: "social-media-link" }, e.id, r !== fe.AQ.SVG ? (0, y.Z)("i", { className: e.className }) : (0, ge.renderSVGElement)({ viewBox: o, svgCode: s, classNames: "social-media-svg" }));
              }),
              (0, b.Z)((0, ae.Z)(t), "getSocialMediaIcon", function () {
                var e = t.props,
                  n = e.socialMediaList,
                  a = e.navObject;
                return 0 === n.length
                  ? null
                  : n.length > 5
                  ? (0, y.Z)(
                      "div",
                      { className: "dropdown-social-media" },
                      void 0,
                      t.getDropDownIcon()
                    )
                  : Z()(Le).call(Le, a.layout)
                  ? (0, y.Z)(
                      "div",
                      { className: "social-media-link-wrap" },
                      void 0,
                      (0, y.Z)(
                        "div",
                        { className: "large-screen-social-media" },
                        void 0,
                        P()(n).call(n, function (e) {
                          return t.getIconLink(e);
                        })
                      ),
                      (0, y.Z)(
                        "div",
                        { className: "small-screen-social-media" },
                        void 0,
                        t.getDropDownIcon()
                      )
                    )
                  : (0, y.Z)(
                      "div",
                      { className: "social-media-link-wrap" },
                      void 0,
                      P()(n).call(n, function (e) {
                        return t.getIconLink(e);
                      })
                    );
              }),
              (0, b.Z)((0, ae.Z)(t), "getDropDownIcon", function () {
                var e = t.props,
                  n = e.socialMediaList,
                  a = e.navObject,
                  i = le()([], n),
                  o = i.shift(),
                  s = "g" === (a || {}).layout ? "right" : "down";
                return (0, y.Z)(
                  ye.Z,
                  {
                    pageIndex: -1,
                    className:
                      "s-nav-link-container s-nav-dropdown s-social-media",
                    title: t.getIconLink(o),
                    sidemenuWidth: 0,
                    direction: s,
                    showDropdownBesideText: !1,
                    selected: !1,
                  },
                  void 0,
                  (0, y.Z)(
                    "ul",
                    {
                      className: "s-nav-li s-navbar-dropdown social-medial-ul",
                    },
                    void 0,
                    P()(i).call(i, function (e) {
                      return (0,
                      y.Z)("li", { className: "s-nav-li s-dropdown-item s-font-body social-medial-li" }, e.id, t.getIconLink(e));
                    })
                  )
                );
              }),
              (0, b.Z)((0, ae.Z)(t), "renderQRCode", function () {
                var e = t.state,
                  n = e.showQRCode,
                  a = e.QRCodeUrl;
                return (0,
                y.Z)(Se, { url: a, visible: n, onCancelDialog: t.handleCancelDialog });
              }),
              (0, b.Z)(
                (0, ae.Z)(t),
                "getNavSocialMediaButtonList",
                function () {
                  return V.sub("s5Theme.nav.socialMediaButtonList");
                }
              ),
              (0, b.Z)((0, ae.Z)(t), "_getSocialMediaItemArr", function (e) {
                var a,
                  i = n(857973),
                  o = t.props.socialMediaListType,
                  s = t.getNavSocialMediaButtonList(),
                  r = o,
                  l =
                    (null === (a = s.get()) || void 0 === a
                      ? void 0
                      : a.toArray()) || [],
                  c = P()(l).call(l, function (t, n) {
                    var a,
                      o = t.get("type");
                    if (
                      de()((a = ["GPlus", "Renren"])).call(a, o) > -1 ||
                      (!Me.socialMediaList[o] && "SocialMediaItem" !== o)
                    )
                      return null;
                    var l = r + o + t.get("id");
                    return R.createElement(
                      i,
                      (0, g.Z)(
                        { binding: s.sub(n), editMode: e, listType: r, key: l },
                        j.omit(t.toObject(), j.isNull)
                      )
                    );
                  });
                return E()(c).call(c, function (e) {
                  return null !== e;
                });
              }),
              (0, b.Z)(
                (0, ae.Z)(t),
                "getNavSocialMediaContactListField",
                function () {
                  var e,
                    n,
                    a = t.state._socialMediaContactList;
                  return {
                    phone:
                      (null ===
                        (e = C()(a).call(a, function (e) {
                          return (
                            e.type === be.SOCIAL_MEDIA_CONTACT_LIST_TYPE.PHONE
                          );
                        })) || void 0 === e
                        ? void 0
                        : e.defaultValue) || "",
                    email:
                      (null ===
                        (n = C()(a).call(a, function (e) {
                          return (
                            e.type === be.SOCIAL_MEDIA_CONTACT_LIST_TYPE.EMAIL
                          );
                        })) || void 0 === n
                        ? void 0
                        : n.defaultValue) || "",
                  };
                }
              ),
              (0, b.Z)((0, ae.Z)(t), "handleSyncChange", function (e) {
                var n = e.target.checked;
                t.setState({ isSyncSocialMedia: n });
              }),
              (0, b.Z)((0, ae.Z)(t), "renderPopoverContent", function () {
                var e,
                  a,
                  i,
                  o,
                  s,
                  r = n(550745),
                  l = r.Button,
                  c = r.Checkbox,
                  d = n(764469).Z,
                  u = n(749375).Z,
                  p = t.state,
                  m = p.visible,
                  h = p._socialMediaContactList,
                  v = p.isSyncSocialMedia,
                  f = t.props,
                  g = f.editSocialMediaList,
                  b = f.socialMediaListType,
                  x = b === Te,
                  S = b === Oe;
                return (0,
                y.Z)("div", { className: "s-component s-social-media s-social-media-edit" }, void 0, (0, y.Z)(Ne, { labelLeft: _e("SocialMedia|Share"), labelRight: _e("SocialMedia|Links"), checkedLeft: x, checkedRight: S, onClickLeft: w()((e = t.handleToggleTab)).call(e, (0, ae.Z)(t), Te), onClickRight: w()((a = t.handleToggleTab)).call(a, (0, ae.Z)(t), Oe) }), x && (0, y.Z)("p", { className: "note" }, void 0, _e("SocialMedia|Get shares! Let visitors like & share this site.")), x && R.createElement(R.Fragment, null, (0, y.Z)("div", { className: "s-component-editor social-media-button-editor" }, void 0, (0, y.Z)("ul", { className: "s-social-media-buttons" }, void 0, t._getSocialMediaItemArr(!0))), (0, y.Z)(u, { list: t.getNavSocialMediaContactListField(), saveSocialMediaContactList: w()((i = t.saveSocialMediaContactList)).call(i, (0, ae.Z)(t)) }), (0, y.Z)(c, { wrapperClassName: "sync-checkbox button-list-part", checked: v, onChange: t.handleSyncChange }, void 0, (0, y.Z)("span", { className: "sync-hint" }, void 0, _e("SocialMedia|Sync across header & footer"))), (0, y.Z)("div", { className: "footer" }, void 0, (0, y.Z)(l, { className: "submit", onClick: w()((o = t.handleSaveBottonList)).call(o, (0, ae.Z)(t)), size: "smaller" }, void 0, _e("Save")), (0, y.Z)(l, { className: "light-gray", size: "smaller", onClick: t.handleClosePopover }, void 0, _e("Cancel")))), S && (0, y.Z)(d, { isOpen: m, socialMediaList: g, socialMediaContactList: h, socialMediaContactListField: t.getNavSocialMediaContactListField(), saveSocialMediaContactList: w()((s = t.saveSocialMediaContactList)).call(s, (0, ae.Z)(t)), onCanClosePopover: t.handleCanClosePopover, onClosePopover: t.handleClosePopover, onShowQRCode: t.handleShowQRCode, onSaveData: t.handleSaveData }));
              }),
              (0, b.Z)((0, ae.Z)(t), "getContactListItem", function (e) {
                var t = e || {},
                  n = t.className,
                  a = t.defaultValue;
                return a
                  ? (0, y.Z)(
                      "div",
                      { className: "social-media-contact-item s-font-body" },
                      void 0,
                      (0, y.Z)(
                        "span",
                        {},
                        void 0,
                        (0, y.Z)("i", {
                          className: "social-contact-icon ".concat(n),
                        })
                      ),
                      (0, y.Z)("span", {}, void 0, a)
                    )
                  : null;
              }),
              (0, b.Z)((0, ae.Z)(t), "renderComponentContactList", function () {
                var e = t.props.socialMediaContactList;
                return (0, y.Z)(
                  "div",
                  { className: "social-media-contact-list-wrap" },
                  void 0,
                  null == e
                    ? void 0
                    : P()(e).call(e, function (e) {
                        return t.getContactListItem(e);
                      })
                );
              }),
              (0, b.Z)((0, ae.Z)(t), "renderComponentSocialMedia", function () {
                var e = t.props.socialMediaListType;
                return R.createElement(
                  R.Fragment,
                  null,
                  t.getIsHasSocialMediaContactList() &&
                    R.createElement(
                      R.Fragment,
                      null,
                      t.renderComponentContactList()
                    ),
                  e === Te
                    ? R.createElement(
                        R.Fragment,
                        null,
                        (0, y.Z)(
                          "ul",
                          { className: "s-social-media-buttons-wrap" },
                          void 0,
                          t._getSocialMediaItemArr(!1)
                        )
                      )
                    : t.getSocialMediaIcon()
                );
              }),
              (0, b.Z)((0, ae.Z)(t), "getIsHasContent", function () {
                var e = t.props,
                  n = e.socialMediaList,
                  a = e.socialMediaListType;
                return (
                  t.getIsHasSocialMediaContactList() ||
                  (a === Oe ? n.length > 0 : t.getIsHasSocialMediaButtonList())
                );
              }),
              (0, b.Z)((0, ae.Z)(t), "renderEditor", function () {}),
              (0, b.Z)((0, ae.Z)(t), "isPreviewMode", function () {
                return !1;
              }),
              (t.state = {
                visible: !1,
                canClosePopover: !0,
                showQRCode: !1,
                QRCodeUrl: "",
                _socialMediaContactList: e.socialMediaContactList || [],
                isSyncSocialMedia: !0,
              }),
              t
            );
          }
          return (
            (0, ne.Z)(o, [
              {
                key: "componentDidMount",
                value: function () {
                  var e = this;
                  Ce.Event.topics["socialMedia.showQRCode"] ||
                    (this._subscribeToken = Ce.Event.subscribe(
                      "socialMedia.showQRCode",
                      function (t, n) {
                        var a = n.url;
                        e.handleShowQRCode(a);
                      }
                    ));
                },
              },
              {
                key: "componentWillUnmount",
                value: function () {
                  Ce.Event.unsubscribe(this._subscribeToken);
                },
              },
              {
                key: "handleSaveBottonList",
                value: function () {
                  var e = this.state,
                    t = e.isSyncSocialMedia,
                    n = e._socialMediaContactList,
                    a = this.getNavSocialMediaButtonList().get();
                  (a = P()(a).call(a, function (e, t) {
                    return e.get("show_button") ? e : e.set("url", "");
                  })),
                    t
                      ? ke.updateSocialMediaShareButtonNavAndFooter(
                          a,
                          ue.fromJS(n)
                        )
                      : (ke.updateNavSocialMediaButtonList(a),
                        ke.updateNavSocialMediaContactList(ue.fromJS(n))),
                    this.handleClosePopover();
                },
              },
              {
                key: "handleToggleTab",
                value: function (e) {
                  ke.updateNavbarSocialMediaType(e);
                },
              },
              {
                key: "saveSocialMediaContactList",
                value: function () {
                  var e =
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : {},
                    t = this.state._socialMediaContactList,
                    n = P()(t).call(t, function (t) {
                      var n = t.type;
                      return Pe(
                        Pe({}, (0, ee.Z)(t, Ze)),
                        {},
                        { type: n, defaultValue: e[n] }
                      );
                    });
                  this.setState({ _socialMediaContactList: n });
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this.props.showSocialMedia,
                    t = this.getIsHasContent();
                  return e && xe.getIsNewNavLayout() && t
                    ? (0, y.Z)(
                        "div",
                        {
                          className: pe("s-nav-social-media", {
                            "has-social-media-contact-list":
                              this.getIsHasSocialMediaContactList(),
                          }),
                        },
                        void 0,
                        (0, y.Z)(
                          "div",
                          {
                            className: pe("".concat(this._getStyle()), {
                              "social-media-contact-list-wrapper":
                                this.getIsHasSocialMediaContactList(),
                            }),
                          },
                          void 0,
                          t && this.renderComponentSocialMedia(),
                          this.renderQRCode()
                        )
                      )
                    : null;
                },
              },
            ]),
            o
          );
        })(R.Component),
        De = ve(Be, function (e) {
          var t;
          return {
            navObject: (0, he.getNavObject)(e),
            editSocialMediaList: (0, he.getNavSocialMedia)(e),
            showSocialMedia: (0, he.getShowNavSocialMedia)(e),
            socialMediaList: (0, he.getShowNavSocialMediaIcon)(e),
            socialMediaButtonList: (0, he.getNavSocialMediaButtonList)(e),
            socialMediaListType: (0, he.getNavSocialMediaListType)(e) || Oe,
            socialMediaContactList:
              null === (t = (0, he.getNavSocialMediaContactList)(e)) ||
              void 0 === t
                ? void 0
                : t.toJS(),
          };
        }),
        Ae = n(792539),
        Re = n(328043),
        Fe = n(611930),
        He = n(647168),
        je = n(454350),
        Ue = n(31933),
        We = n(661840),
        Ve = n(223336),
        ze = n(859056),
        Qe = n(205223);
      var Ge,
        Je,
        qe = (function () {
          function e() {
            (0, te.Z)(this, e),
              (0, b.Z)(this, "_templateComponents", {}),
              (0, b.Z)(this, "_templateElements", {}),
              (0, b.Z)(this, "_renderData", {});
          }
          return (
            (0, ne.Z)(e, [
              {
                key: "setComponent",
                value: function (e, t) {
                  if (!this._templateComponents[e]) {
                    var n = this,
                      a = (function (t) {
                        (0, ie.Z)(s, t);
                        var a,
                          i,
                          o =
                            ((a = s),
                            (i = (function () {
                              if ("undefined" == typeof Reflect || !$())
                                return !1;
                              if ($().sham) return !1;
                              if ("function" == typeof Proxy) return !0;
                              try {
                                return (
                                  Boolean.prototype.valueOf.call(
                                    $()(Boolean, [], function () {})
                                  ),
                                  !0
                                );
                              } catch (e) {
                                return !1;
                              }
                            })()),
                            function () {
                              var e,
                                t = (0, se.Z)(a);
                              if (i) {
                                var n = (0, se.Z)(this).constructor;
                                e = $()(t, arguments, n);
                              } else e = t.apply(this, arguments);
                              return (0, oe.Z)(this, e);
                            });
                        function s() {
                          return (0, te.Z)(this, s), o.apply(this, arguments);
                        }
                        return (
                          (0, ne.Z)(s, [
                            {
                              key: "getExtraProps",
                              value: function () {
                                var e = { style: {} },
                                  t = this.props.theme.getIn([
                                    "section",
                                    "padding",
                                  ]);
                                return (
                                  this.props.sectionPaddingTop &&
                                    ((e.style.paddingTop = t),
                                    n._renderData.isFirstSection &&
                                      this.props.theme.getIn([
                                        "nav",
                                        "overlapsContent",
                                      ]) &&
                                      (e.style.paddingTop +=
                                        this.props.navHeight)),
                                  this.props.sectionPaddingBottom &&
                                    (e.style.paddingBottom = t),
                                  e
                                );
                              },
                            },
                            {
                              key: "render",
                              value: function () {
                                var t = n._templateElements[e];
                                return (
                                  "function" == typeof t &&
                                    (t = t(
                                      this.props.children,
                                      this.getExtraProps()
                                    )),
                                  t
                                );
                              },
                            },
                          ]),
                          s
                        );
                      })(R.Component),
                      i = [V.sub("s5Theme"), G.getBinding()];
                    this._templateComponents[e] = Qe(a, i, function (e) {
                      var t = (0, ze.Z)(e, 2),
                        n = t[0],
                        a = t[1];
                      return { theme: n.get(), navHeight: a.get("navHeight") };
                    });
                  }
                  this._templateElements[e] = t;
                },
              },
              {
                key: "render",
                value: function (e) {
                  var t =
                    arguments.length > 1 && void 0 !== arguments[1]
                      ? arguments[1]
                      : {};
                  this._renderData = t;
                  var n = e(this._templateComponents);
                  return n;
                },
              },
            ]),
            e
          );
        })(),
        Ke = xe.getNewNavHeaderDesign() ? "s-font-nav_dropdown" : "s-font-body",
        Ye = R.useState,
        Xe = function (e) {
          var t = e.listData,
            n = e.isMemberOnly;
          return (0, y.Z)(
            "div",
            { className: me()("s-nav-li", { selected: t.selected }) },
            void 0,
            (0, y.Z)(
              "div",
              {
                className:
                  "navbar-collapse-menu s-font-body s-nav-link-container",
              },
              void 0,
              n(t.uid)
                ? (0, y.Z)(
                    "a",
                    {
                      onClick: function () {
                        window.strkOpenMemberLoginPopup &&
                          window.strkOpenMemberLoginPopup();
                      },
                    },
                    void 0,
                    (0, y.Z)(
                      "span",
                      { className: "".concat(Ke, " s-nav-text") },
                      void 0,
                      t.title
                    )
                  )
                : (0, y.Z)(
                    "a",
                    { target: t.newTarget ? "_blank" : "_self", href: t.path },
                    void 0,
                    (0, y.Z)(
                      "span",
                      { className: "".concat(Ke, " s-nav-text") },
                      void 0,
                      t.title
                    )
                  )
            )
          );
        },
        $e = function (e) {
          var t,
            n = e.data,
            a = e.isMemberOnly,
            i = Ye(""),
            o = (0, ze.Z)(i, 2),
            s = o[0],
            r = o[1];
          return (0, y.Z)(
            "div",
            { className: "collapse-item-content" },
            void 0,
            P()((t = n.items)).call(t, function (e) {
              var t;
              return e.items
                ? (0, y.Z)(
                    "div",
                    {
                      className: me()("s-nav-li", {
                        selected: e.selected,
                        expanded: e.uid === s,
                      }),
                    },
                    e.uid,
                    (0, y.Z)(
                      "div",
                      {
                        className: "navbar-collapse-menu ".concat(Ke),
                        onClick: function () {
                          return (t = e.uid), void r(s === t ? "" : t);
                          var t;
                        },
                      },
                      void 0,
                      e.title,
                      " ",
                      Ge ||
                        (Ge = (0, y.Z)("i", {
                          className:
                            "collapse-menu-icon drop-down-icon-light fa entypo-right-open-big",
                        }))
                    ),
                    e.items &&
                      (0, y.Z)(
                        "div",
                        { className: "collapse-item-content" },
                        void 0,
                        P()((t = e.items)).call(t, function (e) {
                          return (0,
                          y.Z)(Xe, { listData: e, isMemberOnly: a }, e.uid);
                        })
                      )
                  )
                : (0, y.Z)(Xe, { listData: e, isMemberOnly: a }, e.uid);
            })
          );
        },
        et = R.useState,
        tt = xe.getNewNavHeaderDesign(),
        nt = function (e) {
          var t = e.itemData,
            n = e.isMemberOnly,
            a = et(""),
            i = (0, ze.Z)(a, 2),
            o = i[0],
            s = i[1];
          return (0, y.Z)(
            "li",
            {
              className: me()("s-nav-li", {
                selected: t.selected,
                expanded: t.uid === o,
              }),
            },
            void 0,
            (0, y.Z)(
              "div",
              {
                className: "navbar-collapse-menu ".concat(
                  tt ? "s-font-nav_item" : "s-font-body"
                ),
                onClick: function () {
                  return (e = t.uid), void s(o === e ? "" : e);
                  var e;
                },
              },
              void 0,
              t.title,
              " ",
              Je ||
                (Je = (0, y.Z)("i", {
                  className:
                    "collapse-menu-icon drop-down-icon-light fa entypo-right-open-big",
                }))
            ),
            t.items && (0, y.Z)($e, { data: t, isMemberOnly: n })
          );
        },
        at = n(884920),
        it = n(766727),
        ot = n(851172),
        st = n(43138),
        rt = n(792656),
        lt = n(611384),
        ct = n(329756),
        dt = n(979252),
        ut = (n(891763), n(91473), n(143268)),
        pt = n(595386),
        mt = ["topRadial", "drawer"],
        ht = ["topBar", "circleIcon", "topBlock"],
        vt = n(11945),
        ft = n(926941),
        gt = n.n(ft),
        bt = (0, vt.getIsEditorRtlLayout)();
      function yt(e) {
        var t = new (gt())(e);
        return t.toHsl().l > 5
          ? (0, ft.getDiffBrightnessColor)(t)
          : "rgba(255, 255, 255, 0.1)";
      }
      var xt,
        wt,
        St,
        Ct,
        kt,
        Nt,
        Mt,
        Et = R.memo(
          (0, pt.default)("div", { target: "css-t0x6sn0" })(
            "&.s-nav.navigator .s-navbar-desktop{background:",
            function (e) {
              return e.backgroundColor1;
            },
            ";&:not(.s-new-layout-g){.s-nav-social-media.has-social-media-contact-list{background-color:",
            function (e) {
              return yt(e.backgroundColor1);
            },
            ";}}&.s-new-layout-i .ant-drawer-content{background:",
            function (e) {
              return e.isTransparent ? "#fff" : e.backgroundColor1;
            },
            ";}",
            function (e) {
              var t,
                n = e.showFixedNavAlternativeVariation,
                a = e.transparentFixedNavBackgroundColor,
                i = e.fixedNavBackgroundColor;
              return (
                n &&
                T()(
                  (t =
                    "\n        &.s-navbar-desktop-fixed {\n          background: ".concat(
                      a || i,
                      ";\n          &:not(.s-new-layout-g) {\n            .s-nav-social-media.has-social-media-contact-list {\n              background-color: "
                    ))
                ).call(
                  t,
                  yt(a || i),
                  ";\n            }\n          }\n        }\n      "
                )
              );
            },
            ";& .s-nav-icons > .s-nav-li,& .s-uncollapsed-nav > .s-nav-li,& .s-nav-icons > div > .s-nav-li,& .s-common-button{font-size:",
            function (e) {
              return e.fontSize;
            },
            ";}/* navbar button is smaller */\n    & .s-common-button{padding:",
            function (e) {
              return e.isNewNavLayout ? "12px 20px" : "8px 14px";
            },
            ";}& .s-navbar-dropdown{& ul{& li{text-align:",
            function (e) {
              return e.isRtlLayout ? "right" : "left";
            },
            ";}}}& .s-nav-items-and-links .s-nav-li.s-navbar-dropdown li{&.selected > .s-nav-link-container,& > .s-nav-link-container:hover{background:",
            function (e) {
              return e.dropdownItemHighlightColor;
            },
            ";}}& .s-navbar-dropdown .social-medial-li:hover{background:",
            function (e) {
              return e.dropdownItemHighlightColor;
            },
            ";}",
            function (e) {
              var t;
              return (
                e.isTransparent &&
                "& .s-navbar-dropdown {\n          & ul {\n            border-radius: ".concat(
                  null === (t = e.buttonTheme) || void 0 === t
                    ? void 0
                    : t.borderRadiusWithoutPill,
                  "px;\n          }\n        }\n        & .s-collapsed-nav {\n          color: #2e2e2f;\n          .s-nav-dropdown-item {\n            color: inherit;\n          }\n        }\n      "
                )
              );
            },
            ";",
            function (e) {
              var t, n, a, i, o;
              return (
                !e.isTransparent &&
                T()(
                  (t = T()(
                    (n = T()(
                      (a =
                        "& .s-navbar-dropdown > ul {\n          background: ".concat(
                          e.backgroundColor1,
                          ";\n          border-bottom-right-radius: "
                        ))
                    ).call(
                      a,
                      null === (i = e.buttonTheme) || void 0 === i
                        ? void 0
                        : i.borderRadiusWithoutPill,
                      "px;\n          border-bottom-left-radius: "
                    ))
                  ).call(
                    n,
                    null === (o = e.buttonTheme) || void 0 === o
                      ? void 0
                      : o.borderRadiusWithoutPill,
                    "px;\n        }\n        "
                  ))
                ).call(
                  t,
                  e.showFixedNavAlternativeVariation &&
                    "&.s-navbar-desktop-fixed {\n            & .s-navbar-dropdown > ul {\n              background: ".concat(
                      e.fixedNavBackgroundColor,
                      ";\n            }\n          }\n        "
                    ),
                  ";\n      "
                )
              );
            },
            ";&.s-bg-light-text{",
            function (e) {
              return (
                e.isTransparent &&
                "\n          & .membership-nav-container ul li a {\n            color: rgba(0, 0, 0, 0.8) !important;\n          }\n        "
              );
            },
            ";}& .s-ecommerce-shopping-cart .fa{margin:",
            function (e) {
              return e.isRtlLayout ? "0 0 0 5px" : "0 5px 0 0";
            },
            ";}&.s-navbar-desktop-fixed{&:not(.is-not-sticky-navbar){top:0;left:",
            function (e) {
              return bt ? "initial;" : "".concat(e.sidemenuWidth, "px;");
            },
            "\n        right:",
            function (e) {
              return bt ? "".concat(e.sidemenuWidth, "px;") : "initial;";
            },
            "\n        width:",
            function (e) {
              var t = e.isPreviewMode ? e.sidemenuWidth + 30 : e.sidemenuWidth;
              return "calc(100% - ".concat(t, "px)");
            },
            ";}",
            function (e) {
              return (
                e.isTransparent &&
                "\n          ._alternative {\n            & .s-logo-image-normal {\n              display: none;\n            }\n            & .s-logo-image-alternative {\n              display: inline-block;\n            }\n\n            & .s-logo-image img {\n              max-height: 40px;\n            }\n          }\n        "
              );
            },
            "}&.s-new-layout{",
            function (e) {
              return (
                !(0, lt.$i)(e.backgroundColor1) &&
                "\n          &.has-new-layout {\n            .s-logo-image.image2 {\n              box-shadow: none;\n            }\n          }\n        "
              );
            },
            ";&.s-new-layout-e,&.s-new-layout-f,&.circleIcon{.s-nav-logo-wrapper{.s-icon-button{",
            function (e) {
              return e.isRtlLayout && "left: 0;";
            },
            ";",
            function (e) {
              return !e.isRtlLayout && "right: 0;";
            },
            ";}}&._alternative{.s-nav-logo-wrapper{.s-icon-button{",
            function (e) {
              var t = e.isRtlLayout,
                n = e.padding;
              return t && "left: ".concat(n, "px;");
            },
            ";",
            function (e) {
              var t = e.isRtlLayout,
                n = e.padding;
              return !t && "right: ".concat(n, "px;");
            },
            ";}}}}&.s-new-layout-f{.s-nav-logo-wrapper{& > .s-nav-social-media{",
            function (e) {
              var t = e.isRtlLayout,
                n = e.padding;
              return t ? "right: ".concat(n, "px") : "left: ".concat(n, "px");
            },
            ";",
            function (e) {
              return e.isRtlLayout ? "left" : "right";
            },
            ":unset;}}}&.s-new-layout-f.inline-layout{background:",
            function (e) {
              return e.backgroundColor1;
            },
            ";}&.s-new-layout-g{.s-nav-icons{.fa-search,.fa-shopping-cart,.entypo-user{margin:",
            function (e) {
              return e.isRtlLayout ? "0 0 0 10px;" : "0 10px 0 0;";
            },
            "}.fa-search{margin:",
            function (e) {
              return e.isRtlLayout ? "0 0 0 8px;" : "0 8px 0 0;";
            },
            "}> div.s-nav-li:last-child{",
            function (e) {
              return (
                "left" === e.horizontalContentAlignment &&
                "\n                left: ".concat(
                  e.padding,
                  "px;\n              "
                )
              );
            },
            "\n            ",
            function (e) {
              return (
                "right" === e.horizontalContentAlignment &&
                "\n                right: ".concat(
                  e.padding,
                  "px;\n              "
                )
              );
            },
            "\n            ",
            function (e) {
              return (
                "center" === e.horizontalContentAlignment &&
                "\n                left: calc(50% - 18px);\n              "
              );
            },
            "}}}&.s-new-layout-h,&.topBlock{.s-nav-li:not(.selected):not(:hover){.s-nav-link-container >a,.s-nav-link-container >.s-font-body,.s-nav-link-container >div:not(.nav-dropdown-popover) a,.s-nav-link-container >div:not(.nav-dropdown-popover) .s-font-body,.s-nav-icons i,.s-nav-icons span{color:",
            function (e) {
              return !e.isTransparent && e.itemColor;
            },
            ";}}}&.s-new-layout-h,&.topBlock{.s-nav-social-media{margin:",
            function (e) {
              return e.isRtlLayout ? "0 0 0 10px" : "0 10px 0 0";
            },
            "}}}",
            function (e) {
              var t, n;
              return null === (t = e.navObject) ||
                void 0 === t ||
                null === (n = t.getStyle) ||
                void 0 === n
                ? void 0
                : n.call(t, e);
            },
            ";}&.navigator .s-new-layout{&:not(.s-new-layout-g){&:not(.topBlock){.s-nav-inner-wrap{padding:",
            function (e) {
              return e.padding;
            },
            "px;}}.s-nav-inner{.s-nav-social-media.has-social-media-contact-list{padding:8px ",
            function (e) {
              return e.padding;
            },
            "px 8px;.social-media-contact-item{&:first-child{margin-left:0;}margin:0;margin-",
            function (e) {
              return e.isRtlLayout ? "right" : "left";
            },
            ":20px;}.s-social-media-button{margin:0;margin-",
            function (e) {
              return e.isRtlLayout ? "right" : "left";
            },
            ":20px;}.social-media-link{&:last-child{margin-",
            function (e) {
              return e.isRtlLayout ? "left" : "right";
            },
            ":0;}}.fb-counter{margin:0 -15px;}}}}.s-social-media-button{",
            function (e) {
              return (
                e.isRtlLayout &&
                ".linkedin-counter .IN-widget xdoor-icon {\n          margin-left: 2px!important;\n        }\n        .pinterest-counter span {\n          background-position-x: 32px;\n        }\n        "
              );
            },
            "}.social-contact-icon{margin-",
            function (e) {
              return e.isRtlLayout ? "left" : "right";
            },
            ":10px;}}& .s-navbar-mobile-header{background:",
            function (e) {
              return e.backgroundColor1;
            },
            ";",
            function (e) {
              return (
                e.showLogoImage1 &&
                "\n        padding: 5px;\n        min-height: 50px;\n      "
              );
            },
            ";}@media screen and (max-width:727px){&.s-nav.navigator .s-navbar-desktop{display:none;}}}"
          ),
          function (e, t) {
            return j.isEqual(e, t);
          }
        ),
        _t = n(353147);
      function Zt(e, t) {
        var n = i()(e);
        if (s()) {
          var a = s()(e);
          t &&
            (a = E()(a).call(a, function (t) {
              return l()(e, t).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      function It(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n,
            a = null != arguments[t] ? arguments[t] : {};
          if (t % 2)
            d()((n = Zt(Object(a), !0))).call(n, function (t) {
              (0, b.Z)(e, t, a[t]);
            });
          else if (p()) h()(e, p()(a));
          else {
            var i;
            d()((i = Zt(Object(a)))).call(i, function (t) {
              f()(e, t, l()(a, t));
            });
          }
        }
        return e;
      }
      var Pt = xe.getNewNavHeaderDesign(),
        Lt = /s-nav-border|s-nav-drop-shadow/g,
        Tt = Pt ? "s-font-nav_item" : "s-font-body",
        Ot = Pt ? "s-font-nav_dropdown" : "s-font-body";
      function Bt(e) {
        var t = null == e ? void 0 : e.get("url");
        return ut.imageHasContent(t);
      }
      function Dt(e) {
        var t,
          n,
          a =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
          i = a || "text",
          o = e[i];
        return (
          e && "function" == typeof e.get && (o = e.get(i)),
          ct.HTML_TAGS.test(o) &&
            (o =
              null ===
                (n = o =
                  null === (t = o) || void 0 === t
                    ? void 0
                    : t.replace(ct.HTML_TAGS, "")) || void 0 === n
                ? void 0
                : n.replace(ct.NBSP, "")),
          Boolean(o)
        );
      }
      var At,
        Rt,
        Ft = R.memo(
          (0, pt.default)("div", { target: "css-tqs8yw0" })(
            "position:relative;.s-navbar-desktop-normal &{& .s-logo-image-alternative{display:none;}}.s-navbar-desktop-fixed &{position:relative;& .s-logo-image-alternative{",
            function (e) {
              return (
                e.hasImage2 &&
                "\n          & > .s-logo-image.image1 {\n            /* image 1 */\n            display: none;\n          }\n        "
              );
            },
            ";",
            function (e) {
              return (
                !e.hasImage2 &&
                "\n          & > .s-logo-image.image2 {\n            /* image 2 */\n            position: absolute;\n            top: 0;\n            bottom: 0;\n            left: 0;\n            right: 0;\n\n            & .s-component-empty {\n              opacity: 0;\n            }\n            & .s-image {\n              height: 100%;\n            }\n            z-index: 200;\n          }\n        "
              );
            },
            ";}}"
          )
        ),
        Ht = R.memo(
          (0, pt.default)("div", { target: "css-tqs8yw1" })(
            "position:relative;&:hover{.s-kit-tooltip{display:block;}}.s-kit-tooltip{display:none;position:absolute;pointer-events:none;z-index:3002;visibility:visible;top:calc(50% - 18px);",
            function (e) {
              return !e.isRtlLayout && "right: -15px;";
            },
            ";",
            function (e) {
              return (
                e.isRtlLayout &&
                "\n        top: 16px;\n        right: 74px;\n      "
              );
            },
            ";transform:",
            function (e) {
              return e.isRtlLayout ? "translate(0, 0)" : "translate(100%, 0)";
            },
            ";font-size:14px;.s-kit-tooltip-arrow{top:50%;margin-top:-7px;position:absolute;width:0;height:0;border-color:transparent;border-style:solid;",
            function (e) {
              return (
                e.isRtlLayout &&
                "right: -6px;\n          transform: rotate(180deg);"
              );
            },
            ";",
            function (e) {
              return !e.isRtlLayout && "left: -6px;";
            },
            ";border-width:7px 7px 7px 0;border-right-color:#181818;}.s-kit-tooltip-inner-content{max-width:400px;padding:8px 12px;font-size:14px;color:#fff;text-align:left;white-space:nowrap;text-decoration:none;background-color:#181818;border-radius:4px;box-shadow:0 0 2px rgb(255 255 255 / 15%);border:1px solid rgba(0,0,0,0.2);word-wrap:break-word;word-break:normal;line-height:1.35;}}&:has(.s-component-editor){.s-kit-tooltip{display:none;}}"
          )
        ),
        jt = function (e) {
          var t = e.children,
            n = e.text,
            a = e.isRtlLayout;
          return (0, y.Z)(
            Ht,
            { isRtlLayout: a, className: "layout-tip-box" },
            void 0,
            t,
            (0, y.Z)(
              "div",
              { className: "s-kit-tooltip" },
              void 0,
              xt ||
                (xt = (0, y.Z)("div", { className: "s-kit-tooltip-arrow" })),
              (0, y.Z)(
                "div",
                { className: "s-kit-tooltip-inner-content" },
                void 0,
                n
              )
            )
          );
        },
        Ut = ["e", "f", "h"],
        Wt = {
          displayName: "NavbarSection",
          propTypes: {
            className: H.string,
            navbarItemData: H.oneOfType([H.object, H.array]),
            showNav: H.bool,
            isRtlLayout: H.bool,
            eagerLoad: H.bool.isRequired,
            needOpenNavBarLogoEditor: H.bool,
          },
          _subscribeToken: null,
          componentWillMount: function () {
            var e;
            (this._navDomsCache = null),
              (this.template = new qe()),
              (this.onImageLoad = j.debounce(this.onImageLoad, 100)),
              (this._onScroll = j.debounce(
                w()((e = this._onScroll)).call(e, this),
                0
              )),
              (this.debouncedUpdateNavbarMeasurement = j.debounce(
                this._updateNavbarMeasurement,
                100
              )),
              this.initFixedNavLogoData(),
              this.removeCircleIconNavSecondLogo();
            var t = (0, it.default)(function () {
              return Promise.resolve()
                .then(n.bind(n, 828706))
                .then(function (e) {
                  return e.default;
                });
            });
            At = (0, at.wrapComponentWithReduxStore)(
              xe.getIsStrikingly() ? t : je.ZP,
              He.getStore()
            );
            var a = (0, it.default)(function () {
              return Promise.resolve()
                .then(n.bind(n, 274425))
                .then(function (e) {
                  return e.default;
                });
            });
            Rt = (0, at.wrapComponentWithReduxStore)(a, He.getStore());
          },
          componentDidMount: function () {
            var e = this.props.themeProps;
            (void 0 === e ? {} : e).layout,
              this._onMountOrUpdate(),
              (this._onResize = j.throttle(this._onResize, 200)),
              Ve(window).on("resize", this._onResize),
              Ve(window).on("scroll", this._onScroll);
            var t = Ve(F.findDOMNode(this));
            t.on("click", ".s-nav-li", this.handleNavItemClick),
              C()(t).call(t, "img").on("load", this.onImageLoad),
              Ve(window).on("scroll", this.debouncedUpdateNavbarMeasurement),
              this.resetMobileNavFontSize(),
              this._navbarUpdated();
          },
          resetMobileNavFontSize: function () {
            var e;
            (st.isMobile || st.isSmallScreen) &&
              C()((e = Ve(".s-navbar-mobile-header .s-logo-title")))
                .call(e, "h1, h2, h3, h4, h5, div, p, span")
                .each(function (e, t) {
                  N()(Ve(t).css("font-size")) > 18 &&
                    Ve(t).css("font-size", "".concat(18, "px"));
                });
          },
          initFixedNavLogoData: function () {
            return null;
          },
          removeCircleIconNavSecondLogo: function () {
            return xe.getIsNewNavLayout(), null;
          },
          onImageLoad: function () {
            this._onMountOrUpdate();
          },
          componentWillUnmount: function () {
            Ve(window).off("resize", this._onResize),
              Ve(window).off("scroll", this._onScroll),
              Ve(window).off("scroll", this.debouncedUpdateNavbarMeasurement),
              U.removeChangeListener(this._pagesListListener),
              Ce.Event.unsubscribe(this._newPageFadeInToken);
          },
          componentWillReceiveProps: function (e) {},
          componentDidUpdate: function (e) {
            (this._navDomsCache = null),
              this._onMountOrUpdate(),
              this.props.themeProps.navObject !== e.themeProps.navObject &&
                Ve(window).scroll();
            var t = this.getComponentProps("button1");
            if (
              t.size &&
              t.size !== Y.BUTTON_SIZE_VALUE.FULL &&
              this.props.themeProps.name !== e.themeProps.navObject.name &&
              "left" === this.props.themeProps.name
            ) {
              var n = this.getBinding().default.toJS();
              this.updateData({
                components: It(
                  It({}, n.components),
                  {},
                  {
                    button1: It(
                      It({}, n.components.button1),
                      {},
                      { size: Y.BUTTON_SIZE_VALUE.FULL }
                    ),
                  }
                ),
              }),
                this.savePage();
            }
          },
          getShowDropdownBesideText: function () {
            return this.props.themeProps.navObject.showDropdownBesideText;
          },
          _onMountOrUpdate: function () {
            this._callNavAfterRender(),
              this._repositionFirstSectionButtons(),
              this._updateNavbarMeasurement();
          },
          _onScroll: function () {
            this.props.showNav &&
              (Pt &&
                "topBar" === this.props.themeProps.name &&
                this.toggleNavbarPosition(),
              requestAnimationFrame(this._updateFixedNav));
          },
          _onResize: function () {
            this._callNavAfterRender();
          },
          _onNavbarHover: function (e) {},
          _onRefreshNavbarHover: function () {
            var e = Ve(F.findDOMNode(this));
            C()(e)
              .call(e, ".s-navbar-desktop")
              .off("mouseenter", this._onNavbarHover)
              .off("mouseleave", this._onNavbarHover)
              .on("mouseenter", this._onNavbarHover)
              .on("mouseleave", this._onNavbarHover);
          },
          _getNavDom: function (e) {
            var t = C()(e).call(e, ".s-nav-inner"),
              n = C()(e).call(e, ".s-nav-btn"),
              a = C()(e).call(e, ".s-nav-icons"),
              i = C()(e).call(e, ".s-nav-items-and-links"),
              o = C()(e).call(e, ".s-logo"),
              s = C()(e).call(e, ".s-logo-image"),
              r = C()(i).call(i, ".s-uncollapsed-nav"),
              l = C()(i).call(i, ".s-nav-ellipsis"),
              c = C()(i).call(i, ".s-collapsed-nav"),
              d = C()(e).call(e, ".s-logo-title"),
              u = C()(e).call(e, ".s-nav-social-media"),
              p = function (e) {
                var t;
                return E()((t = e.children())).call(
                  t,
                  "li:not(.s-nav-ellipsis)"
                );
              };
            return {
              container: e,
              navInner: t,
              ellipsis: l,
              uncollapsedNavItems: p(r),
              collapsedNavItems: p(c),
              collapsedNav: c,
              uncollapsedNav: r,
              navIcons: a,
              navButton: n,
              logo: o,
              logoImage: s,
              logoTitle: d,
              navSocialMedia: u,
            };
          },
          _callNavAfterRender: function () {
            if (this.props.showNav) {
              var e = this.props.themeProps,
                t = e.navObject,
                n = e.layout,
                a = this.props.ui.showFixedNavAlternativeVariation;
              try {
                this._onScroll();
                var i = this._getNavDoms();
                t.afterRender(i, t, this.props.themeProps, {
                  showFixedNavAlternativeVariation: a,
                  isPreviewMode: this.props.isPreviewMode,
                });
                var o = 0;
                Z()(Ut).call(Ut, n) &&
                  (o = Ve(F.findDOMNode(this)).outerHeight() || 0),
                  Ve(".page-wrapper").css(
                    "min-height",
                    "calc(100vh - ".concat(o, "px)")
                  );
              } catch (e) {
                console.log(e);
              }
            }
          },
          _resetLoginOverlayPosition: function () {},
          _updateFixedNav: function () {
            var e = this.props,
              t = e.themeProps,
              n = e.themeProps.navObject,
              a = e.ui,
              i = a.showFixedNavAlternativeVariation,
              o = a.showFixedNavContainer,
              s = e.updateUI,
              r = this._getNavDoms(),
              l = r.normal.container,
              c = r.fixed.container,
              d = !1;
            n.shouldShowFixedNav && (d = n.shouldShowFixedNav(r, n));
            var u = !1;
            n.shouldShowAlternativeFixedNavVariation &&
              (u = n.shouldShowAlternativeFixedNavVariation(r, n, t));
            var p = !1;
            n.shouldHideNormalNav && (p = n.shouldHideNormalNav(r, n)),
              c.toggleClass("_show", d),
              c.toggleClass("_hide", !d),
              l.toggleClass("_hide", p),
              l.toggleClass("_show", p),
              (i === u && o === d) ||
                (s({
                  showFixedNavAlternativeVariation: u,
                  showFixedNavContainer: d,
                }),
                this.forceUpdate());
          },
          _navbarUpdated: j.debounce(function () {
            var e, t;
            null !== (e = window) &&
              void 0 !== e &&
              null !== (t = e.edit_page) &&
              void 0 !== t &&
              t.Event &&
              window.edit_page.Event.publish("Editor.navbarUpdated");
          }, 500),
          _getNavDoms: function () {
            if (this._navDomsCache) return this._navDomsCache;
            var e = Ve(F.findDOMNode(this)),
              t = {
                normal: this._getNavDom(
                  C()(e).call(
                    e,
                    ".s-navbar-desktop:not(.s-navbar-desktop-fixed)"
                  )
                ),
                fixed: this._getNavDom(
                  C()(e).call(
                    e,
                    ".s-navbar-desktop-fixed.s-navbar-desktop-fixed"
                  )
                ),
              };
            return (this._navDomsCache = t), t;
          },
          _updateSectionPaddingTop: function () {
            var e = this.props.themeProps.overlapsContent,
              t = this._getNormalNavHeight();
            Ve(".s-section:not(.s-grid-section, .s-slider-section)").css(
              "paddingTop",
              ""
            );
            var n = Ve(".s-first-visible-section .s-section");
            n.is(".s-grid-section, .s-slider-section") ||
              (e && !st.isSmallScreen()
                ? (n.css("paddingTop", t + 60),
                  Ve(".s-page-section").css("paddingTop", t + 10))
                : n.css("paddingTop", ""));
          },
          _repositionFirstSectionButtons: function () {
            this.props.themeProps.overlapsContent,
              this._getNormalNavHeight(),
              Ve(".slide.s-first-visible-section .s-section");
          },
          _updateNavbarMeasurement: function () {
            G.set("navHeight", this._getNormalNavHeight()),
              G.set("fixedNavHeight", this._getFixedNavHeight());
          },
          _getNormalNavHeight: function () {
            try {
              var e,
                t = F.findDOMNode(this);
              return C()((e = Ve(t)))
                .call(e, ".s-navbar-desktop-normal")
                .outerHeight();
            } catch (e) {
              return 0;
            }
          },
          _getFixedNavHeight: function () {
            try {
              var e,
                t = F.findDOMNode(this),
                n = C()((e = Ve(t))).call(e, ".s-navbar-desktop-fixed");
              if (0 === n.length) return 0;
              var a = n.position().top;
              if ("topRadial" === this.props.themeProps.navObject.name) {
                var i = N()(n.css("transform").split(",")[5]) || 0,
                  o = z.getData("selected");
                if (((a -= i), !n.hasClass("_show") && 0 !== o)) return 0;
              }
              return n.outerHeight() + (a < 0 ? a : 0);
            } catch (e) {
              return 0;
            }
          },
          _pagesListListener: function () {
            return this.forceUpdate();
          },
          toggleNavbarPosition: function () {
            var e,
              t = F.findDOMNode(this),
              n = C()((e = Ve(t))).call(e, ".s-navbar-desktop-fixed"),
              a = Ve(window).scrollTop();
            n &&
              (a <= 0
                ? n.addClass("navbar-sticky")
                : n.removeClass("navbar-sticky"));
          },
          handleNavItemClick: function (e) {
            var t = Ve(e.target);
            if (t.is(".s-nav-link-container")) {
              var n = t.children().first();
              n.is("a") && n[0].click();
            }
          },
          _getTimestampForLinks: function () {
            return new Date().getTime();
          },
          reduxUI: {
            state: {
              visibleDrawer: !1,
              showFixedNavAlternativeVariation: !1,
              showFixedNavContainer: !1,
              showAddTextButton: null,
            },
          },
          bindings: function () {
            return [V.getBinding(), Q.getBinding(), V.sub("submenu")];
          },
          mapStateToProps: function (e) {
            var t = (0, he.getNavIsTransparent)(e),
              n = (0, he.getNavHighlightObj)(e),
              a = V.isInStorePage,
              i = V.isInBlogCategoryPage,
              o = V.isInPortfolioCategoriesPage,
              s = xe.getIsBlog()
                ? dt.getBinding().get("content.header.backgroundImage")
                : V.getCurrentPageBinding().get(
                    "sections.0.components.background1"
                  );
            (a() || i() || o()) && (s = null);
            var r = rt.getNavTextColor(s),
              l = t ? rt.getTransparentFixedBackgroundColor(s) : "",
              c = t ? r : (0, ot.getNavTextColor)(e),
              d = (0, ot.getNavThemeProps)(e);
            return {
              themeProps: d,
              navTextColor: c,
              transparentFixedNavBackgroundColor: l,
              fixedNavTextColor: (0, ot.getFixedNavTextColor)(e),
              fixedNavTextColorBySticky: (0, ot.getNavTextColorBySticky)(
                l || d.fixedNavBackgroundColor
              )(e),
              submenu: V.getBinding().get().getIn(["submenu", "list"]),
              showNav: V.getShowNav(),
              showMobileNav: V.getShowMobileMenu(),
              hasEcommerceSection: V.hasSection("ecommerce"),
              navIsTransparent: t,
              navHighlightObj: n,
            };
          },
          getSectionHash: function (e) {
            return z.getSectionHashByIndex(e);
          },
          _getNavItemProps: function (e) {
            return e.showNav && e.name.length
              ? {}
              : { style: { display: "none" } };
          },
          _switchPage: function (e, t) {
            switch (W.getSiteMode()) {
              case "editor":
                return t.preventDefault(), J.replace(e.path);
              case "preview":
                return t.preventDefault(), J.push(e.path);
            }
          },
          _isMemberOnly: function (e) {
            if ("show" === W.getSiteMode()) {
              var t = z.getNavById(e);
              if (t && t.isMemberOnly && !get("authenticationToken")) return !0;
            }
            return !1;
          },
          _openDrawer: function () {
            this.props.updateUI({ visibleDrawer: !0 });
          },
          _closeDrawer: function () {
            this.props.updateUI({ visibleDrawer: !1 });
          },
          _getNavItemsAndLinksEntries: function (e) {
            var t,
              n,
              a,
              i = this,
              o = [],
              s = this.props,
              r = s.isRtlLayout,
              l = (s.themeProps || {}).layout;
            this.props.isMultiPage ||
              (o = P()((a = this.props.navbarItemData)).call(a, function (t) {
                var n,
                  a,
                  o = t.isCategoryMenu,
                  s = t.selected,
                  r = t.title,
                  l = t.sectionIndex;
                return o
                  ? (0, y.Z)(
                      "li",
                      {
                        className: me()(
                          "s-nav-li s-navbar-dropdown is-category-menu",
                          { selected: s }
                        ),
                      },
                      "s-nav-link-".concat(r),
                      n || (n = (0, y.Z)(Ae.Z, { itemData: t, selected: s }))
                    )
                  : R.createElement(
                      "li",
                      (0, g.Z)({}, i._getNavItemProps(t), {
                        key: T()((a = "s-dropdown-".concat(e, "-"))).call(a, l),
                        className: "s-nav-li",
                      }),
                      (0, y.Z)(
                        "div",
                        { className: "s-nav-link-container" },
                        void 0,
                        (0, y.Z)(
                          "a",
                          {
                            className: "".concat(Tt, " s-nav-text"),
                            href: i.getSectionHash(l),
                          },
                          void 0,
                          (0, y.Z)("span", {}, void 0, t.name)
                        )
                      )
                    );
              }));
            var c,
              d = [];
            this.props.isMultiPage &&
              (d = P()((c = this.props.navbarItemData)).call(
                c,
                function (t, n) {
                  var a = t.isCategoryMenu,
                    o = t.selected,
                    s = t.title;
                  if (a)
                    return (0, y.Z)(
                      "li",
                      {
                        className: me()(
                          "s-nav-li s-navbar-dropdown is-category-menu",
                          { selected: o }
                        ),
                      },
                      "s-nav-link-".concat(s),
                      (0, y.Z)(
                        Ae.Z,
                        {
                          itemData: t,
                          selected: o,
                          isRtlLayout: r,
                          title: s,
                          pageIndex: n,
                          isInDropdown: e,
                          themeProps: i.props.themeProps,
                        },
                        t.uid
                      )
                    );
                  if (t.items) {
                    var c;
                    if ("i" === l)
                      return (0, y.Z)(
                        nt,
                        { itemData: t, isMemberOnly: i._isMemberOnly },
                        t.uid
                      );
                    var d = "down";
                    return (
                      (e ||
                        "vertical" ===
                          i.props.themeProps.navObject.orientation) &&
                        (d = "right"),
                      (0, y.Z)(
                        ye.Z,
                        {
                          className: "s-nav-li",
                          direction: d,
                          isRtlLayout: r,
                          title: t.title,
                          selected: t.selected,
                          pageIndex: n,
                          isInDropdown: e,
                          themeProps: i.props.themeProps,
                          itemData: t,
                          sidemenuWidth: i.props.themeProps.sidemenuWidth,
                          showDropdownBesideText: i.getShowDropdownBesideText(),
                        },
                        t.uid,
                        (0, y.Z)(
                          "ul",
                          {
                            className: me()("s-nav-li", {
                              selected: t.selected,
                            }),
                          },
                          void 0,
                          P()((c = t.items)).call(c, function (e, n) {
                            return (0, y.Z)(
                              "li",
                              {
                                className: me()("s-nav-li", {
                                  selected: e.selected,
                                }),
                              },
                              "nav-li-".concat(n),
                              (0, y.Z)(
                                "div",
                                { className: "s-nav-link-container" },
                                void 0,
                                i._isMemberOnly(t.uid)
                                  ? (0, y.Z)(
                                      "a",
                                      {
                                        onClick: function () {
                                          window.strkOpenMemberLoginPopup &&
                                            window.strkOpenMemberLoginPopup();
                                        },
                                      },
                                      void 0,
                                      (0, y.Z)(
                                        "span",
                                        {
                                          className: "".concat(
                                            Ot,
                                            " s-nav-text"
                                          ),
                                        },
                                        void 0,
                                        e.title
                                      )
                                    )
                                  : (0, y.Z)(
                                      "a",
                                      {
                                        target: e.newTarget
                                          ? "_blank"
                                          : "_self",
                                        href: e.path,
                                      },
                                      void 0,
                                      (0, y.Z)(
                                        "span",
                                        {
                                          className: "".concat(
                                            Ot,
                                            " s-nav-text"
                                          ),
                                        },
                                        void 0,
                                        e.title
                                      )
                                    )
                              )
                            );
                          })
                        )
                      )
                    );
                  }
                  return (0, y.Z)(
                    "li",
                    { className: me()("s-nav-li", { selected: t.selected }) },
                    "s-nav-link-".concat(n),
                    (0, y.Z)(
                      "div",
                      { className: "s-nav-link-container" },
                      void 0,
                      i._isMemberOnly(t.uid)
                        ? (0, y.Z)(
                            "a",
                            {
                              onClick: function () {
                                window.strkOpenMemberLoginPopup &&
                                  window.strkOpenMemberLoginPopup();
                              },
                            },
                            void 0,
                            (0, y.Z)(
                              "span",
                              { className: "".concat(Ot, " s-nav-text") },
                              void 0,
                              t.title
                            )
                          )
                        : (0, y.Z)(
                            "a",
                            {
                              target: t.newTarget ? "_blank" : "_self",
                              href: t.path,
                            },
                            void 0,
                            (0, y.Z)(
                              "span",
                              { className: "".concat(Tt, " s-nav-text") },
                              void 0,
                              t.title
                            )
                          )
                    )
                  );
                }
              ));
            var u = P()((t = this.props.submenu.toArray())).call(
              t,
              function (e, t) {
                return R.createElement(
                  Ue,
                  (0, g.Z)(
                    {
                      liClassName: "s-nav-li",
                      updateTimeStamp: i._getTimestampForLinks(),
                      key: "external-link-".concat(t),
                    },
                    e.getIn(["components", "link"]).toObject()
                  )
                );
              }
            );
            return T()((n = T()(o).call(o, d))).call(n, u);
          },
          _getLogoImage: function (e) {
            var t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              n = this.props,
              a = n.isRtlLayout,
              i = n.needOpenNavBarLogoEditor,
              o = n.themeProps,
              s = n.ui,
              r = s.showFixedNavAlternativeVariation,
              l = s.showFixedNavContainer,
              c = ("topRadial" === o.name || o.name, "image".concat(e)),
              d = (xe.getIsNewNavLayout(), this.getDefaultBinding());
            if (
              ("3" !== e || d.get("components.".concat(c)) || (c = "image1"),
              this.sbHasContent(c))
            ) {
              var u,
                p,
                m = this.getReduxComponentProps(c),
                h =
                  (ut.imageHasContent(
                    null === (u = this.getComponentProps(c)) || void 0 === u
                      ? void 0
                      : u.url
                  ),
                  "3" === e && !1),
                v = !1,
                f = h || v ? jt : R.Fragment,
                b =
                  (null === (p = this.getComponentProps("text1")) ||
                    void 0 === p ||
                    p.value,
                  {});
              v
                ? (b = {
                    isRtlLayout: a,
                    text: _t("Editor|Upload your logo or generate a new logo"),
                  })
                : h &&
                  (b = {
                    isRtlLayout: a,
                    text: _t("Editor|Upload alternate logo for sticky nav"),
                  }),
                Z()(mt).call(mt, null == o ? void 0 : o.name);
              var x = {};
              return (0, y.Z)(
                "div",
                {
                  className: me()("s-logo-image", "image".concat(e), {
                    editor: this.isEditMode(),
                    "rtl-layout": a,
                    transparent: !this.sbHasContent(c),
                    noImage: !Bt(m.dataProps) && "2" === e,
                  }),
                },
                m.dataProps.get("url"),
                R.createElement(
                  f,
                  b,
                  R.createElement(
                    Re,
                    (0, g.Z)(
                      {
                        isSelfOpening: i,
                        inNavbar: !0,
                        isEditorAiLogo: xe.getIsEditorAiLogo(),
                        size: "small",
                        needTrim: "true",
                        clsSize: !0,
                        onlyShowEdit: !0,
                        emptyMessage: _t("Editor|Add Logo"),
                        useType: "float",
                        isSiteLogo: !0,
                      },
                      x,
                      m,
                      t,
                      {
                        disableAiMode: !0,
                        onLoadEditorCallback: this._navbarUpdated,
                        onImageUploaded: this.onImageUploaded,
                      }
                    )
                  )
                )
              );
            }
            return null;
          },
          _isPreviewMode: function () {
            return !1;
          },
          _resetCicleIcon: function () {
            ke.updateThemeConfigValue("nav.keptOldLayout", !1);
          },
          _changeLogoImage: function (e) {
            xe.getIsNewNavLayout() &&
              ((0, lt.Q)(this.getDefaultBinding(), ["image3", "image1"], e),
              this.savePage());
          },
          getIsShowSocialMediaContactList: function () {
            var e = xe.getIsNewNavLayout(),
              t = V.sub("s5Theme.nav.socialMediaContactList").get();
            return (
              (null == t
                ? void 0
                : B()(t).call(t, function (e) {
                    return e.get("defaultValue");
                  })) && e
            );
          },
          getThemeConfigValue: function () {
            var e = this.props,
              t = e.navHighlightObj,
              n = e.themeProps || {},
              a = n.border,
              i = n.itemColor,
              o = t || {},
              s = {
                borderColor: (a || {}).borderColor,
                textColor: o.textColor,
                blockTextColor: o.blockTextColor,
                blockBackgroundColor: o.blockBackgroundColor,
                itemColor: i,
              },
              r = {};
            for (var l in s) r["--".concat(l)] = s[l];
            return r;
          },
          onText2Blur: function () {
            Ve(".s-nav-inner>.s-left-nav-scroll-container").css(
              "overflow",
              "auto"
            );
          },
          onText2Focus: function () {
            Ve(".s-nav-inner>.s-left-nav-scroll-container").css(
              "overflow",
              "visible"
            );
          },
          onAiLogoClick: function (e, t) {
            var n,
              a = Ve(t).parents(".s-navbar-desktop-fixed").length;
            Ve(
              T()(
                (n = ".s-navbar-desktop-".concat(a ? "fixed" : "normal", " ."))
              ).call(
                n,
                e,
                " .ai-media-eidtor-container .ai-media-navbar-editor"
              )
            ).trigger("click"),
              Ve(".editor-ai-logo-toolbar").addClass("s-kit-tooltip-hidden");
          },
          onAiTitleClick: function () {
            var e = this.props,
              t = e.themeProps,
              n = e.ui,
              a = n.showFixedNavAlternativeVariation,
              i = n.showFixedNavContainer,
              o = "topRadial" === t.name || "topBlock" === t.name ? i : a;
            this.props.updateUI({ showAddTextButton: !1 });
            var s =
              o || Z()(ht).call(ht, t.name)
                ? ".s-navbar-desktop-fixed"
                : ".s-navbar-desktop-normal";
            Ve(
              "".concat(Z()(mt).call(mt, t.name) ? "" : s, " .s-logo-title")
            ).show(),
              Ve(
                "".concat(s, " .s-logo-title .s-draft-editor-wrapper")
              ).trigger("click"),
              Ve(".editor-ai-logo-toolbar").addClass("s-kit-tooltip-hidden");
          },
          onImageUploaded: function () {
            this.template = new qe();
          },
          render: function () {
            var e,
              t = this.props,
              n = t.isPreviewMode,
              a = t.showNav,
              i = t.showMobileNav,
              o = t.themeProps,
              s = t.navTextColor,
              r = t.isRtlLayout,
              l = t.fixedNavTextColor,
              c = t.navIsTransparent,
              d = t.fixedNavTextColorBySticky,
              u = t.hasEcommerceSection,
              p = t.transparentFixedNavBackgroundColor,
              m = t.ui,
              h = m.showFixedNavAlternativeVariation,
              v = m.showFixedNavContainer,
              f = (m.visibleDrawer, m.showAddTextButton, xe.getIsBlog()),
              b = xe.getIsNewNavLayout(),
              x = o.layout,
              S = o.keptOldLayout,
              C = o.isSticky,
              k = o.name,
              N = o.isTransparent,
              M = o.itemSpacing,
              E = void 0 === M ? "normal" : M,
              _ = o.border,
              I = o.highlight,
              P = o.dropShadow,
              L = o.navObject,
              O = (o.backgroundColor1, L.enabledNavOptions),
              B = void 0 === O ? [] : O,
              D = this.getThemeConfigValue(),
              F = b ? "s-new-layout ".concat(k) : "";
            F += b && !S ? " s-new-layout-".concat(x) : "";
            var H = [];
            if (Pt) {
              if (
                (Z()(B).call(B, "itemSpacing") &&
                  H.push("s-nav-spacing-".concat(E)),
                Z()(B).call(B, "border") && !N && null != _ && _.enable)
              ) {
                var j,
                  U = _.position,
                  W = _.thickness;
                H.push(T()((j = "s-nav-border-".concat(U, "-"))).call(j, W));
              }
              if (Z()(B).call(B, "highlight") && I) {
                var V = I.type,
                  z = I.blockShape,
                  Q = [V];
                "block" === V && Q.push(z),
                  H.push("s-nav-highlight-".concat(Q.join("-")));
              }
              Z()(B).call(B, "dropShadow") &&
                P &&
                H.push("s-nav-drop-shadow-".concat(P)),
                (0, lt.nf)(o, B) && H.push("s-nav-sticky-drop-shadow-default");
            }
            F += " ".concat(H.join(" "));
            var G,
              J = "topRadial" === k || "topBlock" === k ? v : h,
              Y = this.sbHasContent("image1", { showOnly: !1 }),
              X = b && J && N && C && "topRadial" !== k ? "3" : "1";
            this.template.setComponent(
              "LogoImage1",
              this._getLogoImage(X, { changeCallback: this._changeLogoImage })
            ),
              this.template.setComponent(
                "LogoImage2",
                this._getLogoImage("2", {
                  removeCallback: this._resetCicleIcon,
                })
              ),
              (G = (0, y.Z)(
                Ft,
                { hasImage2: this.sbHasContent("image2", { showOnly: !1 }) },
                void 0,
                (0, y.Z)(
                  "div",
                  { className: "s-logo-image-normal" },
                  void 0,
                  this._getLogoImage(X, {
                    changeCallback: this._changeLogoImage,
                  })
                ),
                (0, y.Z)(
                  "div",
                  { className: "s-logo-image-alternative" },
                  void 0,
                  this._getLogoImage(X, {
                    changeCallback: this._changeLogoImage,
                  }),
                  this._getLogoImage("2", {
                    emptyTooltip: _t(
                      "Editor|You can upload an alternate logo for the white background"
                    ),
                    uploadActionName: _t("Editor|Upload alternate logo"),
                  })
                )
              )),
              this.template.setComponent("LogoImage", G);
            var $ = null;
            this.sbHasContent("text1") &&
              ($ = (0, y.Z)(
                "div",
                { className: "s-logo-title" },
                void 0,
                R.createElement(
                  q,
                  (0, g.Z)(
                    {
                      emptyMessage: _t("Editor|Add title"),
                      textType: "title",
                      defaultStyle: "bold",
                      onlyNormalToolbar: !0,
                      inputCallback: this._navbarUpdated,
                    },
                    this.getComponentProps("text1")
                  )
                )
              )),
              this.template.setComponent("LogoTitle", $);
            var ee,
              te,
              ne = null;
            this.sbHasContent("text2") &&
              (ne = (0, y.Z)(
                "div",
                { className: "s-logo-subtitle" },
                void 0,
                R.createElement(
                  q,
                  (0, g.Z)(
                    {
                      emptyMessage: _t("Editor|Add subtitle"),
                      textType: "title",
                      defaultStyle: "bold",
                      onlyNormalToolbar: !0,
                      onblur: w()((ee = this.onText2Blur)).call(ee, this),
                      onfocus: w()((te = this.onText2Focus)).call(te, this),
                    },
                    this.getComponentProps("text2")
                  )
                )
              )),
              this.template.setComponent("LogoSubtitle", ne);
            var ae = this.getIsShowSocialMediaContactList()
                ? null
                : wt || (wt = (0, y.Z)(De, {})),
              ie = this.getIsShowSocialMediaContactList()
                ? St || (St = (0, y.Z)(De, {}))
                : null;
            this.template.setComponent("NavSocialMedia", ae),
              this.template.setComponent("NavSocialMediaHasContactList", ie);
            var oe = null,
              se = this.getComponentProps("button1"),
              re = Dt(se),
              le = null;
            try {
              le = this.getComponentProps("background1");
            } catch (e) {
              console.log(e);
            }
            if (se && re) {
              var ce,
                de = se.url;
              f &&
                A()(de).call(de, "#") &&
                (se = It(
                  It({}, se),
                  {},
                  {
                    url: T()((ce = "".concat(window.location.host, "/"))).call(
                      ce,
                      de
                    ),
                  }
                )),
                (oe = (0, y.Z)(
                  "div",
                  { className: "s-nav-link-container s-nav-btn" },
                  void 0,
                  R.createElement(
                    K,
                    (0, g.Z)({}, le, se, {
                      needCeiling: !0,
                      isNavBtn: !0,
                      navLayout: x,
                    })
                  )
                ));
            }
            this.template.setComponent("NavButton", oe);
            var ue = (0, y.Z)(
                ye.Z,
                {
                  direction: "down",
                  isEllipsis: !0,
                  className: "s-nav-li s-nav-ellipsis hidden",
                  title: "… ",
                  selected: !1,
                  pageIndex: 1e3,
                  isRtlLayout: r,
                  sidemenuWidth: o.sidemenuWidth,
                  showDropdownBesideText: this.getShowDropdownBesideText(),
                },
                "ellipsis",
                (0, y.Z)(
                  "ul",
                  { className: "s-collapsed-nav" },
                  void 0,
                  this._getNavItemsAndLinksEntries(!0)
                )
              ),
              pe = (0, y.Z)(
                "div",
                { className: "s-nav-items-and-links" },
                void 0,
                (0, y.Z)(
                  "ul",
                  { className: "s-uncollapsed-nav" },
                  void 0,
                  T()((e = this._getNavItemsAndLinksEntries(!1))).call(e, ue)
                )
              );
            this.template.setComponent("NavItemsAndLinks", pe);
            var he = b && "left" === k,
              ve = [];
            if (this.props.enableSiteSearch) {
              var fe = (0, y.Z)(
                "li",
                {
                  className: me()("s-nav-li -nav-item site-search", {
                    selected: this.props.selectSiteSearchTab,
                  }),
                  onClick: this.props.onClickSiteSearch,
                },
                "site-search",
                (0, y.Z)(
                  "div",
                  { className: "s-nav-link-container" },
                  void 0,
                  (0, y.Z)(
                    We.Z,
                    {
                      className: "s-font-body",
                      to: this.props.siteSearchUrl,
                      "aria-label": _t("SiteSearch|Search"),
                    },
                    void 0,
                    (0, y.Z)(
                      "span",
                      { className: "s-font-body" },
                      void 0,
                      Ct ||
                        (Ct = (0, y.Z)("span", { className: "fa fa-search" })),
                      he &&
                        (0, y.Z)(
                          "span",
                          { className: "nav-icon-text" },
                          void 0,
                          _t("SiteSearch|Search")
                        )
                    )
                  )
                )
              );
              ve.push(fe);
            }
            if (u) {
              var ge = (0, y.Z)(
                "li",
                { className: "s-nav-li hidden" },
                "shopping-cart",
                (0, y.Z)(Fe, { type: "nav", showIconText: he })
              );
              ve.push(ge);
            }
            var be,
              we = kt || (kt = (0, y.Z)(At, {}, "membership"));
            if ((ve.push(we), "g" === x)) {
              var Se =
                Nt ||
                (Nt = (0, y.Z)(
                  "div",
                  { className: "s-nav-g-footer" },
                  void 0,
                  (0, y.Z)(De, {}, "socialMedia"),
                  (0, y.Z)(Rt, {}, "langSwitcher")
                ));
              this.template.setComponent("MultiLangAndSocialMedia", Se);
            } else be = Mt || (Mt = (0, y.Z)(Rt, {}, "langSwitcher"));
            ve.push(be),
              this.template.setComponent(
                "NavIcons",
                (0, y.Z)(
                  "ul",
                  { className: "s-nav-icons s-nav-items-and-links" },
                  void 0,
                  ve
                )
              ),
              this.template.setComponent("NavContentContainer", function (e) {
                return (0,
                y.Z)("div", { className: "s-nav-inner nav-item-loaded" }, void 0, e);
              });
            var Ce,
              ke = o.name,
              Ne = o.navObject.templateFunction;
            if (b) {
              Ne = o.navObject.newLayoutTemplateFunction || Ne;
              var Me = o.navObject.newLayoutFixedTemplateFunction;
              Ce = Me && this.template.render(Me);
            }
            var Ee = !1;
            this.sbHasContent("image2") &&
              (Ee = Bt(this.getReduxComponentProps("image2").dataProps));
            var _e = !1;
            this.sbHasContent("text1") &&
              (_e = Dt(
                this.getReduxComponentProps("text1").dataProps,
                "value"
              ));
            var Ze = this.template.render(Ne),
              Ie = "light" === s && this.props.selectSiteSearchTab ? "dark" : s;
            return (
              C && h && (Ie = c ? d : l),
              R.createElement(
                Et,
                (0, g.Z)({ key: ke }, o, {
                  isRtlLayout: r,
                  navbarItemData: this.props.navbarItemData,
                  transparentFixedNavBackgroundColor: p,
                  isNewNavLayout: b,
                  showLogoImage1: this.sbHasContent("image1"),
                  hasLogoImage1: Y,
                  navButtonProps: this.getComponentProps("button1"),
                  showFixedNavAlternativeVariation: h,
                  className: me()("s-nav navigator", { _alternative: h }),
                  style: It({}, D),
                  isPreviewMode: n,
                }),
                a &&
                  (0, y.Z)(
                    "div",
                    {
                      className: me()(
                        "s-navbar-desktop",
                        "s-navbar-desktop-normal",
                        "s-bg-".concat(s, "-text"),
                        F,
                        {
                          "strikingly-fixed":
                            "vertical" === o.navObject.orientation,
                          "has-new-layout": b,
                          "not-in-sticky": b && !C && J,
                          "is-not-sticky-navbar": !C,
                          "has-image2": Ee,
                          "has-button": re,
                          "has-title": _e,
                          "in-editor": !1,
                          "s-nav-transparent-desktop": c,
                        }
                      ),
                    },
                    void 0,
                    Ze
                  ),
                a &&
                  (0, y.Z)(
                    "div",
                    {
                      className: me()(
                        "s-navbar-desktop",
                        "s-navbar-desktop-fixed",
                        "strikingly-fixed",
                        "s-bg-".concat(Ie, "-text"),
                        F,
                        {
                          _alternative: h,
                          _alternativeNavBackgroundColorIsDifferentFromNormal:
                            o.backgroundColor1 !== o.fixedNavBackgroundColor,
                          "has-new-layout": b,
                          "not-in-sticky": b && !C && J,
                          "is-not-sticky-navbar": !C,
                          "has-image2": Ee,
                          "has-button": re,
                          "has-title": _e,
                          "inline-layout": !C,
                          "in-editor": !1,
                          "s-nav-transparent-desktop": c,
                          "s-new-dashbaord-fixed-navbar": !1,
                        }
                      ),
                    },
                    void 0,
                    Ce || Ze
                  ),
                "i" === x &&
                  (0, y.Z)("div", {
                    id: "layout-drawer-wrap",
                    className: me()(
                      "s-navbar-desktop",
                      "layout-drawer-wrap",
                      "s-bg-".concat(Ie, "-text"),
                      F.replace(Lt, ""),
                      { "in-editor": !1, "is-preview": this._isPreviewMode() }
                    ),
                  }),
                i &&
                  this.template.render(function (e) {
                    var t = e.LogoTitle,
                      n = e.LogoImage1;
                    return (0,
                    y.Z)("div", { className: "s-navbar-mobile-header" }, void 0, Y ? (0, y.Z)(n, {}) : (0, y.Z)(t, {}));
                  })
              )
            );
          },
        },
        Vt = Wt;
    },
    891763: function (e, t, n) {
      "use strict";
      n(863056), n(366757), n(234584), n(183123), n(353147);
    },
    91473: function (e, t, n) {
      "use strict";
      n(863056), n(366757), n(234584), n(594488);
    },
    749375: function (e, t, n) {
      "use strict";
      var a,
        i,
        o = n(501068),
        s = n.n(o),
        r = n(863056),
        l = n(468420),
        c = n(327344),
        d = n(505281),
        u = n(484441),
        p = n(103020),
        m = n(803362),
        h = n(844845),
        v = n(366757),
        f = n(990369),
        g = n(353147);
      var b = (function (e) {
        (0, u.Z)(v, e);
        var t,
          n,
          o =
            ((t = v),
            (n = (function () {
              if ("undefined" == typeof Reflect || !s()) return !1;
              if (s().sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    s()(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                a = (0, m.Z)(t);
              if (n) {
                var i = (0, m.Z)(this).constructor;
                e = s()(a, arguments, i);
              } else e = a.apply(this, arguments);
              return (0, p.Z)(this, e);
            });
        function v(e) {
          var t, n, a;
          return (
            (0, l.Z)(this, v),
            (a = o.call(this, e)),
            (0, h.Z)((0, d.Z)(a), "handlePhoneChange", function (e) {
              a.setState({ phoneValue: e.target.value });
            }),
            (0, h.Z)((0, d.Z)(a), "handleEmailChange", function (e) {
              a.setState({ emailValue: e.target.value });
            }),
            (0, h.Z)((0, d.Z)(a), "hanbleBlurInput", function () {
              var e = a.state,
                t = e.phoneValue,
                n = e.emailValue;
              a.props.saveSocialMediaContactList({
                SocialMediaPhone: t,
                SocialMediaEmail: n,
              });
            }),
            (a.state = {
              phoneValue:
                (null === (t = e.list) || void 0 === t ? void 0 : t.phone) ||
                "",
              emailValue:
                (null === (n = e.list) || void 0 === n ? void 0 : n.email) ||
                "",
            }),
            a
          );
        }
        return (
          (0, c.Z)(v, [
            {
              key: "render",
              value: function () {
                var e = this.state,
                  t = e.phoneValue,
                  n = e.emailValue;
                return (0, r.Z)(
                  "div",
                  { className: "social-media-contact-container" },
                  void 0,
                  (0, r.Z)(
                    "div",
                    { className: "social-media-contact-list" },
                    void 0,
                    a || (a = (0, r.Z)("i", { className: "fas fa-phone-alt" })),
                    (0, r.Z)(f.Z, {
                      value: t,
                      onChange: this.handlePhoneChange,
                      onBlur: this.hanbleBlurInput,
                      placeholder: g("SocialMedia|Enter your phone number"),
                    })
                  ),
                  (0, r.Z)(
                    "div",
                    { className: "social-media-contact-list" },
                    void 0,
                    i || (i = (0, r.Z)("i", { className: "fas fa-envelope" })),
                    (0, r.Z)(f.Z, {
                      value: n,
                      onChange: this.handleEmailChange,
                      onBlur: this.hanbleBlurInput,
                      placeholder: g("SocialMedia|Enter your email address"),
                    })
                  )
                );
              },
            },
          ]),
          v
        );
      })(v.PureComponent);
      t.Z = b;
    },
    764469: function (e, t, n) {
      "use strict";
      n.d(t, {
        Z: function () {
          return de;
        },
      });
      var a,
        i,
        o,
        s,
        r,
        l,
        c,
        d = n(501068),
        u = n.n(d),
        p = n(863056),
        m = n(468420),
        h = n(327344),
        v = n(505281),
        f = n(484441),
        g = n(103020),
        b = n(803362),
        y = n(844845),
        x = n(51942),
        w = n.n(x),
        S = n(492762),
        C = n.n(S),
        k = n(62462),
        N = n.n(k),
        M = n(2991),
        E = n.n(M),
        _ = n(620116),
        Z = n.n(_),
        I = n(25843),
        P = n.n(I),
        L = n(410062),
        T = n.n(L),
        O = n(20455),
        B = n.n(O),
        D = n(366757),
        A = n(143393),
        R = n(15091),
        F = n(294184),
        H = n.n(F),
        j = n(684474),
        U = n(234584),
        W = n(183123),
        V = n(387937),
        z = n(171725),
        Q = n(622587),
        G = n(601765),
        J = n(726469),
        q = n(879042),
        K = n(332578),
        Y = n(144726),
        X = n(948736),
        $ = n(786483),
        ee = n(353147);
      var te = (0, R.W6)(function () {
          return (
            a ||
            (a = (0, p.Z)(
              "span",
              { className: "drag-field" },
              void 0,
              (0, p.Z)("i", { className: "fa fa-bars", "aria-hidden": "true" })
            ))
          );
        }),
        ne = (function (e) {
          (0, f.Z)(d, e);
          var t,
            n,
            a =
              ((t = d),
              (n = (function () {
                if ("undefined" == typeof Reflect || !u()) return !1;
                if (u().sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                  return (
                    Boolean.prototype.valueOf.call(
                      u()(Boolean, [], function () {})
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              })()),
              function () {
                var e,
                  a = (0, b.Z)(t);
                if (n) {
                  var i = (0, b.Z)(this).constructor;
                  e = u()(a, arguments, i);
                } else e = a.apply(this, arguments);
                return (0, g.Z)(this, e);
              });
          function d(e) {
            var t;
            return (
              (0, m.Z)(this, d),
              (t = a.call(this, e)),
              (0, y.Z)((0, v.Z)(t), "_subscribeToken", null),
              (0, y.Z)((0, v.Z)(t), "handleClickEdit", function () {
                t.setState({ isEditing: !0 }, function () {
                  t.refs.smLink && t.refs.smLink.focus();
                });
              }),
              (0, y.Z)((0, v.Z)(t), "handleInputKeyDown", function (e) {
                13 === e.keyCode && t.handleUpdateSocialMedia(e);
              }),
              (0, y.Z)((0, v.Z)(t), "handleRemoveSocialMedia", function () {
                var e = t.props,
                  n = e.socialMedia;
                (0, e.onRemoveItem)(n.id);
              }),
              (0, y.Z)((0, v.Z)(t), "handleUpdateSocialMedia", function (e) {
                e.stopPropagation();
                var n = t.props,
                  a = n.socialMedia,
                  i = n.updateSocialMediaLink,
                  o = n.isEmpty,
                  s = n.onChangeValidate,
                  r = t.refs.smLink.value;
                t.setState({ isEditing: !1 }), i(r, a, o);
                var l = a.type,
                  c = q.sxlSocialMediaMap[l] || {},
                  d = c.validateUrl;
                c.shareType === J.yP.URL &&
                  s &&
                  (r && d && !d.test(r)
                    ? (t.setState({ isError: !0 }), s(l, !1))
                    : (t.setState({ isError: !1 }), s(l, !0)));
              }),
              (0, y.Z)((0, v.Z)(t), "cbUpdateQRCodeUrl", function (e) {
                var n = t.props,
                  a = n.socialMedia;
                (0, n.updateSocialMediaLink)((0, Y.createImage)(e).getUrl(), a);
              }),
              (0, y.Z)((0, v.Z)(t), "canCloseAssetDialog", function () {
                var e =
                    !(arguments.length > 0 && void 0 !== arguments[0]) ||
                    arguments[0],
                  n = t.props.onCanClosePopover;
                n && n(e);
              }),
              (0, y.Z)((0, v.Z)(t), "handleUpdateRQCode", function () {
                t.canCloseAssetDialog(!1),
                  X.pick({
                    dialogType: "image",
                    listenedActions: ["select"],
                    iconLibComponents: "background",
                    from: "socialMedia.nav",
                    isPrivate: !0,
                    initialTabIdx: 0,
                    handlers: {
                      itemUploaded: t.cbUpdateQRCodeUrl,
                      itemSelected: t.cbUpdateQRCodeUrl,
                    },
                  });
              }),
              (0, y.Z)((0, v.Z)(t), "handleShowQRCode", function () {
                var e = t.props.socialMedia.url,
                  n = t.props.onShowQRCode;
                n && n(e);
              }),
              (0, y.Z)((0, v.Z)(t), "handleRemoveQRCode", function () {
                var e = t.props,
                  n = e.socialMedia;
                (0, e.updateSocialMediaLink)("", n);
              }),
              (0, y.Z)((0, v.Z)(t), "renderInputComponent", function () {
                var e,
                  n = t.props.socialMedia,
                  a = n.url,
                  o = t.state.isEditing,
                  s = H()("sm-link", { "hint-link": !a }),
                  r = n.type;
                e = (q.sxlSocialMediaMap[r] || {}).placeholderUrl;
                var l = a || ee("SocialMedia|e.g. %{URL}", { URL: e });
                return (0,
                p.Z)("span", { className: "item-cell sm-name", onClick: t.handleClickEdit }, void 0, o && D.createElement("input", { ref: "smLink", type: "text", className: "sm-link-input", defaultValue: a, onKeyDown: t.handleInputKeyDown, onBlur: t.handleUpdateSocialMedia }), !o && (0, p.Z)("span", { className: "sm-link-wrapper" }, void 0, (0, p.Z)("span", { className: s }, void 0, l), a && (i || (i = (0, p.Z)(G.Z, { className: "edit-icon", type: "fas fa-pencil-alt" })))));
              }),
              (0, y.Z)((0, v.Z)(t), "renderUpdateImageComponent", function () {
                return t.props.socialMedia.url
                  ? (0, p.Z)(
                      D.Fragment,
                      {},
                      void 0,
                      (0, p.Z)(
                        "span",
                        {
                          className: "show-image",
                          onClick: t.handleShowQRCode,
                        },
                        void 0,
                        s || (s = (0, p.Z)(G.Z, { type: "fas fa-search" })),
                        (0, p.Z)("span", {}, void 0, ee("SocialMedia|View"))
                      ),
                      (0, p.Z)(
                        "span",
                        {
                          className: "delete-image",
                          onClick: t.handleRemoveQRCode,
                        },
                        void 0,
                        r || (r = (0, p.Z)(G.Z, { type: "entypo-cancel" })),
                        (0, p.Z)(
                          "span",
                          {},
                          void 0,
                          ee("SocialMedia|Delete image")
                        )
                      )
                    )
                  : (0, p.Z)(
                      "span",
                      {
                        className: "update-image",
                        onClick: t.handleUpdateRQCode,
                      },
                      void 0,
                      o || (o = (0, p.Z)(G.Z, { type: "entypo-upload" })),
                      (0, p.Z)(
                        "span",
                        {},
                        void 0,
                        ee("SocialMedia|Update image")
                      )
                    );
              }),
              (0, y.Z)((0, v.Z)(t), "renderStrikinglyItem", function () {
                var e = t.props.isEmpty;
                return (0,
                p.Z)("li", { className: "sm-item-container" }, void 0, l || (l = (0, p.Z)(te, {})), t.getStrikinglySocialMediaIcon(), t.renderInputComponent(), !e && (0, p.Z)(G.Z, { onClick: t.handleRemoveSocialMedia, className: "delete-icon", type: "fas fa-trash" }));
              }),
              (0, y.Z)(
                (0, v.Z)(t),
                "getStrikinglySocialMediaIcon",
                function () {
                  var e = t.props.socialMedia,
                    n = e.className,
                    a = e.type,
                    i = (q.strikinglySocialMediaMap[a] || {}).iconType,
                    o = void 0 === i ? J.JO.FONT : i,
                    s = H()(n, "social-media-icon");
                  if (o === J.JO.SVG) {
                    var r = q.strikinglySocialMediaMap[a] || {},
                      l = r.viewBox,
                      c = r.svgCode;
                    return (0, K.renderSVGElement)({
                      viewBox: l,
                      svgCode: c,
                      classNames: "social-media-svg",
                    });
                  }
                  return (0, p.Z)(G.Z, { className: s });
                }
              ),
              (0, y.Z)((0, v.Z)(t), "renderSxlItem", function () {
                var e = t.props.socialMedia,
                  n = t.state.isError,
                  a = e.type,
                  i = q.sxlSocialMediaMap[a].text,
                  o = H()("sm-item-container sxl-item", { error: n });
                return (0,
                p.Z)("li", { className: o }, void 0, c || (c = (0, p.Z)(te, {})), t.getSxlSocialMediaIcon(), (0, p.Z)("span", { className: "item-title" }, void 0, ee(i)), t.getSxlSocialMediaContent());
              }),
              (0, y.Z)((0, v.Z)(t), "getSxlSocialMediaContent", function () {
                var e = t.state.isError,
                  n = t.props.socialMedia.type;
                return q.sxlSocialMediaMap[n].shareType === J.yP.URL
                  ? (0, p.Z)(
                      "span",
                      { className: "content-wrapper" },
                      void 0,
                      t.renderInputComponent(),
                      e &&
                        (0, p.Z)(
                          "span",
                          { className: "error-hint" },
                          void 0,
                          ee("SocialMedia|Please enter a valid %{type} URL.", {
                            type: n,
                          })
                        )
                    )
                  : (0, p.Z)(
                      "span",
                      { className: "content-wrapper" },
                      void 0,
                      (0, p.Z)(
                        "span",
                        { className: "item-cell" },
                        void 0,
                        t.renderUpdateImageComponent()
                      )
                    );
              }),
              (0, y.Z)((0, v.Z)(t), "getSxlSocialMediaIcon", function () {
                var e = t.props.socialMedia,
                  n = e.className,
                  a = e.type,
                  i = q.sxlSocialMediaMap[a].iconType,
                  o = H()(n, "social-media-icon");
                if (i === J.AQ.FONT) return (0, p.Z)(G.Z, { className: o });
                var s = q.sxlSocialMediaMap[a],
                  r = s.viewBox,
                  l = s.svgCode;
                return (0,
                K.renderSVGElement)({ viewBox: r, svgCode: l, classNames: "social-media-svg" });
              }),
              (t.state = { isEditing: !1, isError: !1 }),
              t
            );
          }
          return (
            (0, h.Z)(d, [
              {
                key: "componentDidMount",
                value: function () {
                  this.refs.smLink && this.refs.smLink.focus(),
                    (this._subscribeToken = $.Event.subscribe(
                      "Editor.CloseModal",
                      this.canCloseAssetDialog
                    ));
                },
              },
              {
                key: "componentWillUnmount",
                value: function () {
                  $.Event.unsubscribe(this._subscribeToken);
                },
              },
              {
                key: "render",
                value: function () {
                  return this.renderSxlItem();
                },
              },
            ]),
            d
          );
        })(D.Component),
        ae = (0, R.W8)(ne),
        ie = ne,
        oe = (0, R.JN)(function (e) {
          var t = e.list,
            n = e.onRemoveItem,
            a = e.onShowQRCode,
            i = e.updateSocialMediaLink,
            o = e.onCanClosePopover,
            s = e.onChangeValidate;
          return (0, p.Z)(
            "ul",
            { className: "setting-link-content" },
            void 0,
            E()(t).call(t, function (e, t) {
              return (0,
              p.Z)(ae, { index: t, socialMedia: e, onShowQRCode: a, onRemoveItem: n, updateSocialMediaLink: i, onCanClosePopover: o, onChangeValidate: s }, e.id);
            })
          );
        }),
        se = n(749375),
        re = n(141655),
        le = (n(540599), n(353147));
      var ce = (function (e) {
          (0, f.Z)(i, e);
          var t,
            n,
            a =
              ((t = i),
              (n = (function () {
                if ("undefined" == typeof Reflect || !u()) return !1;
                if (u().sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                  return (
                    Boolean.prototype.valueOf.call(
                      u()(Boolean, [], function () {})
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              })()),
              function () {
                var e,
                  a = (0, b.Z)(t);
                if (n) {
                  var i = (0, b.Z)(this).constructor;
                  e = u()(a, arguments, i);
                } else e = a.apply(this, arguments);
                return (0, g.Z)(this, e);
              });
          function i(e) {
            var t;
            return (
              (0, m.Z)(this, i),
              (t = a.call(this, e)),
              (0, y.Z)((0, v.Z)(t), "handleChangeValidate", function (e, n) {
                var a = t.state.validateSocialMedia,
                  i = w()({}, a, { type: n });
                t.setState({ validateSocialMedia: i });
              }),
              (0, y.Z)((0, v.Z)(t), "getEmptySocialMediaConfig", function () {
                return {
                  socialMedia: (0, K.getDefaultSocialMediaItem)(),
                  updateSocialMediaLink: t.updateSocialMediaLink,
                  isEmpty: !0,
                };
              }),
              (0, y.Z)((0, v.Z)(t), "handleSortEnd", function (e) {
                var n = e.oldIndex,
                  a = e.newIndex;
                t.setState(function (e) {
                  var t = e.socialMediaItems;
                  return { socialMediaItems: (0, R.Rp)(t, n, a) };
                });
              }),
              (0, y.Z)((0, v.Z)(t), "handleDeleteSocialMedia", function (e) {
                var n = t.state.socialMediaItems;
                C()(n).call(
                  n,
                  N()(n).call(n, function (t) {
                    return t.id === e;
                  }),
                  1
                ),
                  t.setState({ socialMediaItems: n });
              }),
              (0, y.Z)((0, v.Z)(t), "handleAddSocialMediaItem", function () {
                var e = t.state.socialMediaItems,
                  n = (0, K.getDefaultSocialMediaItem)();
                e.push(n), t.setState({ socialMediaItems: e });
              }),
              (0, y.Z)((0, v.Z)(t), "updateSocialMediaLink", function (e, n) {
                var a =
                  arguments.length > 2 &&
                  void 0 !== arguments[2] &&
                  arguments[2];
                if (a)
                  return (
                    (n.className = (0, K.getSocialMedialIcon)(e.toLowerCase())),
                    (n.url = e),
                    t.setState({ socialMediaItems: [n] })
                  );
                var i = t.state.socialMediaItems,
                  o = E()(i).call(i, function (t) {
                    return t.id !== n.id || (t.url = e), t;
                  });
                return t.setState({ socialMediaItems: o });
              }),
              (0, y.Z)((0, v.Z)(t), "filterSaveData", function () {
                var e = t.state.socialMediaItems;
                return (
                  Z()(e).call(e, function (e) {
                    var t;
                    return P()((t = e.url)).call(t);
                  }),
                  E()(e).call(e, function (e) {
                    var t;
                    return (
                      (e.show_button = Boolean(P()((t = e.url)).call(t))), e
                    );
                  })
                );
              }),
              (0, y.Z)((0, v.Z)(t), "handleSave", function () {
                var e = t.props,
                  n = e.onClosePopover,
                  a = e.onSaveData,
                  i = t.props.socialMediaContactList,
                  o = t.state.isSyncSocialMedia;
                t.getIsShowSocialMediaContactList() || (i = []);
                var s,
                  r = t.state.validateSocialMedia;
                if (
                  T()((s = B()(r))).call(s, function (e) {
                    return e;
                  })
                ) {
                  var l = t.filterSaveData();
                  o
                    ? re.updateSocialMediaNavAndFooter(A.fromJS(l), A.fromJS(i))
                    : a(l, i),
                    n();
                }
              }),
              (0, y.Z)((0, v.Z)(t), "handleSyncChange", function (e) {
                var n = e.target.checked;
                t.setState({ isSyncSocialMedia: n });
              }),
              (0, y.Z)(
                (0, v.Z)(t),
                "getIsShowSocialMediaContactList",
                function () {
                  return "s5-theme" === U.getThemeName() && !W.getIsBlog();
                }
              ),
              (t.state = {
                socialMediaItems: e.socialMediaList || [],
                validateSocialMedia: q.sxlValidateSocialMedia,
                isSyncSocialMedia: !0,
              }),
              t
            );
          }
          return (
            (0, h.Z)(i, [
              {
                key: "componentWillReceiveProps",
                value: function (e) {
                  e.isOpen &&
                    !this.props.isOpen &&
                    this.setState({
                      socialMediaItems: e.socialMediaList || [],
                    });
                },
              },
              {
                key: "isPreviewMode",
                value: function () {
                  return this.props.isPreviewMode;
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this.state,
                    t = e.socialMediaItems,
                    n = e.isSyncSocialMedia,
                    a = this.props,
                    i = a.hideTitle,
                    o = a.isSaving,
                    s = a.onClosePopover,
                    r = a.onCanClosePopover,
                    l = a.onShowQRCode,
                    c = a.socialMediaContactListField,
                    d = a.saveSocialMediaContactList,
                    u = 0 === t.length,
                    m = t.length < 5;
                  return (0, p.Z)(
                    "div",
                    { className: "s-social-media-edit" },
                    void 0,
                    !i &&
                      (0, p.Z)(
                        D.Fragment,
                        {},
                        void 0,
                        (0, p.Z)(
                          "p",
                          { className: "note" },
                          void 0,
                          le(
                            "SocialMedia|Enter your social media profile links."
                          ),
                          !1
                        )
                      ),
                    (0, p.Z)(
                      "div",
                      {},
                      void 0,
                      !u &&
                        (0, p.Z)(oe, {
                          useDragHandle: !0,
                          list: t,
                          onSortEnd: this.handleSortEnd,
                          lockToContainerEdges: !0,
                          onShowQRCode: l,
                          onChangeValidate: this.handleChangeValidate,
                          onCanClosePopover: r,
                          onRemoveItem: this.handleDeleteSocialMedia,
                          updateSocialMediaLink: this.updateSocialMediaLink,
                          helperClass: H()(
                            "social-media__style__stylizedHelper",
                            { "ai-mode": this.isPreviewMode() }
                          ),
                        }),
                      u && D.createElement(ie, this.getEmptySocialMediaConfig())
                    ),
                    m &&
                      (0, p.Z)(
                        "div",
                        {
                          className: "add-btn",
                          onClick: this.handleAddSocialMediaItem,
                        },
                        void 0,
                        "+ ",
                        le("SocialMedia|Add New Link")
                      ),
                    this.getIsShowSocialMediaContactList() &&
                      (0, p.Z)(se.Z, {
                        list: c,
                        saveSocialMediaContactList: d,
                      }),
                    (0, p.Z)(
                      "div",
                      { className: "footer" },
                      void 0,
                      (0, p.Z)(
                        z.Z,
                        {
                          loading: o,
                          className: "submit",
                          onClick: this.handleSave,
                          size: "smaller",
                        },
                        void 0,
                        le("Save")
                      ),
                      (0, p.Z)(
                        z.Z,
                        {
                          className: "light-gray",
                          onClick: s,
                          size: "smaller",
                        },
                        void 0,
                        le("Cancel")
                      ),
                      (0, p.Z)(
                        Q.Z,
                        {
                          wrapperClassName: "sync-checkbox",
                          checked: n,
                          onChange: this.handleSyncChange,
                        },
                        void 0,
                        (0, p.Z)(
                          "span",
                          { className: "sync-hint" },
                          void 0,
                          le("SocialMedia|Sync across header & footer")
                        )
                      )
                    )
                  );
                },
              },
            ]),
            i
          );
        })(D.Component),
        de = V(ce, function () {
          return { isSaving: j.isSaving() };
        });
    },
    332578: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          getDefaultSocialMediaItem: function () {
            return u;
          },
          getSocialMedialIcon: function () {
            return p;
          },
          getSocialMedialUrl: function () {
            return m;
          },
          renderSVGElement: function () {
            return h;
          },
          migrateNewSocialMediaData: function () {
            return v;
          },
        });
      var a = n(863056),
        i = n(277149),
        o = n.n(i),
        s = n(2991),
        r = n.n(s),
        l = (n(620116), n(25843), n(678580), n(366757), n(879042)),
        c = n(828125),
        d = n(329756),
        u = function () {
          return {
            id: (0, c.Bu)(),
            url: "",
            className: "fas fa-link",
            type: "SocialMediaItem",
            show_button: !0,
          };
        },
        p = function (e) {
          for (var t in l.SOCIAL_MEDIA_CONFIG) {
            var n,
              a = l.SOCIAL_MEDIA_CONFIG[t];
            if (
              o()((n = a.validateUrl)).call(n, function (t) {
                return t.test(e);
              })
            )
              return a.className;
          }
          return "fas fa-link";
        },
        m = function (e) {
          return d.RegexConstants.HAS_HTTP.test(e)
            ? e
            : /^\/\//.test(e)
            ? "https:".concat(e)
            : "https://".concat(e);
        },
        h = function (e) {
          var t = e.viewBox,
            n = e.svgCode,
            i = e.classNames;
          return (0, a.Z)("svg", {
            className: i,
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: t,
            dangerouslySetInnerHTML: { __html: n },
          });
        },
        v = function (e) {
          return e.length !== l.defaultSxlSocialMediaList.length
            ? l.defaultSxlSocialMediaList
            : r()(e).call(e, function (e) {
                return (
                  l.sxlSocialMediaMap[e.type].className &&
                    (e.className = l.sxlSocialMediaMap[e.type].className),
                  e.id || (e.id = (0, c.Bu)()),
                  e
                );
              });
        };
    },
    661532: function (e, t, n) {
      "use strict";
      var a = n(366757),
        i = n(496486),
        o = (n(357646), n(436173)),
        s = n(990264),
        r = (n(659370), n(389005), n(845939)),
        l = n(716505),
        c = (n(467338), n(718711));
      n(711827),
        n(3325),
        (e.exports = function () {
          function e(e, t) {
            var n = i.assign({}, e, t);
            return (
              e.hasOwnProperty("style") &&
                (n.style = i.defaults(n.style, e.style)),
              e.hasOwnProperty("className") &&
                t.hasOwnProperty("className") &&
                (n.className = t.className + " " + e.className),
              n
            );
          }
          return a.createElement(
            l,
            e(
              {
                className:
                  "s-blog-section s-section " +
                  this._getPaddingClass() +
                  " " +
                  this._getIsNewMobileLayoutClass(),
              },
              this.getThemeFeature("disableBackgrounds")
                ? {}
                : this.getBackgroundProps("background1")
            ),
            a.createElement(c, this._getWaypointProps()),
            null,
            !this.getThemeFeature("disableBackgrounds") &&
              this.hasBackgroundVideo("background1")
              ? a.createElement(
                  o,
                  i.assign(
                    {},
                    { key: "2302" },
                    this.getBackgroundProps("background1")
                  )
                )
              : null,
            a.createElement(
              "div",
              { className: "container" },
              a.createElement(
                "div",
                { className: "columns no-float sixteen" },
                a.createElement(r, {
                  section: this,
                  binding: this.getDefaultBinding(),
                  inSectionSelector: this.props.inSectionSelector,
                })
              ),
              a.createElement(
                "div",
                { className: this.sbUniformTextAlignment("text1 text2") },
                a.createElement(
                  s,
                  e(
                    {
                      className: "WaypointLazy",
                      layoutSetting: this._getLayoutSettings(),
                      sectionId: this._getSectionId(),
                      inSectionSelector: this.props.inSectionSelector,
                      templateDummyData: this.props.templateDummyData,
                      isPreviewMode: this.isPreviewMode(),
                    },
                    this.getComponentProps("blog1")
                  )
                )
              )
            )
          );
        });
    },
    843218: function (e, t, n) {
      "use strict";
      var a = n(353147),
        i = n(366757),
        o = n(496486),
        s = (n(357646), n(659370)),
        r = n(389005),
        l = n(436173),
        c = n(21053),
        d = n(845939),
        u = n(716505),
        p = (n(183123), n(828765)),
        m = n(281750),
        h = n(410730),
        v = n(3325);
      e.exports = function () {
        function e(e) {
          var t = this.getComponentProps("contactInfo1");
          return i.createElement(
            "div",
            {
              className:
                "s-contact-section-columns s-three-columns " +
                this.sbUniformTextAlignment("text1 text2"),
            },
            i.createElement(
              "div",
              { className: "s-contact-info-column" },
              i.createElement(
                m,
                o.assign({}, { onDelete: this._hideContactInfo }, t)
              )
            ),
            i.createElement(
              "div",
              { className: "s-google-maps-column" },
              i.createElement(
                p,
                o.assign(
                  {},
                  { onDelete: this._hideMap, fixHeight: this._fixMapHeight },
                  t
                )
              )
            ),
            i.createElement(
              "div",
              { className: "s-email-column" },
              i.createElement(
                c,
                o.assign(
                  {},
                  {
                    sessionId: this._getSectionId(),
                    onToggleField: this._fixMapHeight,
                    fieldType: "overlay_label_field",
                  },
                  this.getComponentProps("email1")
                )
              )
            )
          );
        }
        function t(e) {
          var t = this.getComponentProps("contactInfo1");
          return i.createElement(
            "div",
            {
              className:
                "s-contact-section-columns s-two-columns " +
                this.sbUniformTextAlignment("text1 text2"),
            },
            i.createElement(
              "div",
              { className: "s-google-maps-column" },
              i.createElement(
                p,
                o.assign(
                  {},
                  { onDelete: this._hideMap, fixHeight: this._fixMapHeight },
                  t
                )
              )
            ),
            i.createElement(
              "div",
              { className: "s-email-column" },
              i.createElement(
                c,
                o.assign(
                  {},
                  {
                    sessionId: this._getSectionId(),
                    onToggleField: this._fixMapHeight,
                    fieldType: "overlay_label_field",
                  },
                  this.getComponentProps("email1")
                )
              )
            )
          );
        }
        function n(e) {
          var t = this.getComponentProps("contactInfo1");
          return i.createElement(
            "div",
            {
              className:
                "s-contact-section-columns s-three-columns " +
                this.sbUniformTextAlignment("text1 text2"),
            },
            i.createElement(
              "div",
              { className: "s-contact-info-column" },
              i.createElement(
                m,
                o.assign({}, { onDelete: this._hideContactInfo }, t)
              )
            ),
            i.createElement(
              "div",
              { className: "s-google-maps-column" },
              i.createElement(
                p,
                o.assign(
                  {},
                  { onDelete: this._hideMap, fixHeight: this._fixMapHeight },
                  t
                )
              )
            ),
            i.createElement(
              "div",
              { className: "s-email-column" },
              i.createElement(
                c,
                o.assign(
                  {},
                  {
                    sessionId: this._getSectionId(),
                    onToggleField: this._fixMapHeight,
                    fieldType: "overlay_label_field",
                  },
                  this.getComponentProps("email1")
                )
              )
            )
          );
        }
        function f(e) {
          var t = this.getComponentProps("contactInfo1");
          return i.createElement(
            "div",
            {
              className:
                "s-contact-section-columns s-two-columns " +
                this.sbUniformTextAlignment("text1 text2"),
            },
            !e.get("show_info") ||
              (!this.isEditMode() && this._isContactInfoEmpty(t))
              ? null
              : i.createElement(
                  "div",
                  { className: "s-contact-info-column", key: "6329" },
                  i.createElement(
                    m,
                    o.assign({}, { onDelete: this._hideContactInfo }, t)
                  )
                ),
            e.get("show_map")
              ? i.createElement(
                  "div",
                  { className: "s-google-maps-column", key: "6578" },
                  i.createElement(
                    p,
                    o.assign(
                      {},
                      {
                        sessionId: this._getSectionId(),
                        onDelete: this._hideMap,
                        fixHeight: this._fixMapHeight,
                      },
                      this.getComponentProps("contactInfo1")
                    )
                  )
                )
              : null,
            i.createElement(
              "div",
              { className: "s-email-column" },
              i.createElement(
                c,
                o.assign(
                  {},
                  {
                    sessionId: this._getSectionId(),
                    onToggleField: this._fixMapHeight,
                    fieldType: "overlay_label_field",
                  },
                  this.getComponentProps("email1")
                )
              )
            )
          );
        }
        return i.createElement(
          u,
          ((g = {
            className: "s-contact-section s-section " + this._getPaddingClass(),
          }),
          (b = this.getThemeFeature("disableBackgrounds")
            ? {}
            : this.getBackgroundProps("background1")),
          (y = o.assign({}, g, b)),
          g.hasOwnProperty("style") && (y.style = o.defaults(y.style, g.style)),
          g.hasOwnProperty("className") &&
            b.hasOwnProperty("className") &&
            (y.className = b.className + " " + g.className),
          y),
          this.isEditMode() && !this.props.inSectionSelector
            ? i.createElement(
                "div",
                { className: "s-section-editor-wrapper", key: "1168" },
                i.createElement(
                  v,
                  {
                    renderAIEditor: this._renderAIEditor,
                    isPreviewMode: this.isPreviewMode(),
                  },
                  this.getThemeFeature("disableBackgrounds")
                    ? null
                    : i.createElement(
                        s,
                        o.assign(
                          {},
                          { key: "BackgroundEditor" },
                          this.getComponentProps("background1")
                        )
                      ),
                  i.createElement(
                    h,
                    o.assign(
                      {},
                      {
                        key: "LayoutSelector",
                        hiddenAiMobile: !0,
                        layoutOptions: this._getLayoutOptions(),
                        updateLayout: this._updateLayout,
                        updatePadding: this._updatePadding,
                      },
                      this._getLayoutProps()
                    )
                  ),
                  i.createElement(r.default, {
                    key: "HideOrShowSection",
                    sectionBinding: this.getDefaultBinding(),
                    sectionIndex: this.props.index,
                  })
                )
              )
            : null,
          this.getThemeFeature("disableBackgrounds") ||
            !this.hasBackgroundVideo("background1") ||
            this.props.inSectionSelector
            ? null
            : i.createElement(
                l,
                o.assign(
                  {},
                  { key: "1944" },
                  this.getBackgroundProps("background1")
                )
              ),
          function () {
            var s = this.generateComponentBindingIfMissing([
              "slideSettings",
              "display_settings",
            ]);
            return i.createElement(
              "div",
              {
                className:
                  "container " + (this.isPreviewMode() ? "ai-mode" : ""),
              },
              s.get("show_map") || s.get("show_info")
                ? null
                : i.createElement(
                    "div",
                    {
                      className:
                        "columns " +
                        (this.getThemeFeature("narrowContactForm")
                          ? "twelve offset-two"
                          : "sixteen"),
                      key: "2330",
                    },
                    i.createElement(d, {
                      section: this,
                      binding: this.getDefaultBinding(),
                    }),
                    i.createElement(
                      "div",
                      {
                        className:
                          "s-email-form-container " +
                          this.sbUniformTextAlignment("text1 text2"),
                      },
                      i.createElement(
                        c,
                        o.assign(
                          {},
                          {
                            sessionId: this._getSectionId(),
                            onToggleField: this._fixMapHeight,
                            fieldType: "overlay_label_field",
                          },
                          this.getComponentProps("email1")
                        )
                      )
                    )
                  ),
              this.isEditMode() && s.get("show_map") && s.get("show_info")
                ? i.createElement(
                    "div",
                    { className: "columns sixteen", key: "2924" },
                    i.createElement(d, {
                      section: this,
                      binding: this.getDefaultBinding(),
                    }),
                    e.apply(this, [s])
                  )
                : null,
              !this.isEditMode() &&
                s.get("show_map") &&
                s.get("show_info") &&
                this._isContactInfoEmpty(this.getComponentProps("contactInfo1"))
                ? i.createElement(
                    "div",
                    { className: "columns sixteen", key: "3902" },
                    i.createElement(d, {
                      section: this,
                      binding: this.getDefaultBinding(),
                    }),
                    t.apply(this, [s])
                  )
                : null,
              !this.isEditMode() &&
                s.get("show_map") &&
                s.get("show_info") &&
                !this._isContactInfoEmpty(
                  this.getComponentProps("contactInfo1")
                )
                ? i.createElement(
                    "div",
                    { className: "columns sixteen", key: "4804" },
                    i.createElement(d, {
                      section: this,
                      binding: this.getDefaultBinding(),
                    }),
                    n.apply(this, [s])
                  )
                : null,
              (!s.get("show_map") && s.get("show_info")) ||
                (s.get("show_map") && !s.get("show_info"))
                ? i.createElement(
                    "div",
                    { className: "columns sixteen", key: "5852" },
                    i.createElement(d, {
                      section: this,
                      binding: this.getDefaultBinding(),
                    }),
                    f.apply(this, [s])
                  )
                : null,
              !this.isEditMode() || (s.get("show_map") && s.get("show_info"))
                ? null
                : i.createElement(
                    "div",
                    { className: "s-black-button-container", key: "7090" },
                    s.get("show_map") || this.props.inSectionSelector
                      ? null
                      : i.createElement(
                          "div",
                          {
                            className: "s-small-black-button",
                            onClick: this._showMap,
                            key: "7255",
                          },
                          a("Editor|Add Map")
                        ),
                    s.get("show_info") || this.props.inSectionSelector
                      ? null
                      : i.createElement(
                          "div",
                          {
                            className: "s-small-black-button",
                            onClick: this._showContactInfo,
                            key: "7426",
                          },
                          a("Editor|Add Contact Info")
                        )
                  )
            );
          }.apply(this, [])
        );
        var g, b, y;
      };
    },
    355762: function (e, t, n) {
      "use strict";
      var a = n(366757),
        i = n(496486),
        o = (n(357646), n(184635), n(845939)),
        s = (n(755802), n(183123), n(332347)),
        r = n(659370),
        l = n(389005),
        c = n(658840),
        d = n(990415),
        u = n(716505),
        p = n(436173),
        m = n(3325);
      e.exports = function () {
        return a.createElement(
          u,
          ((e = {
            className: "s-section s-store-section " + this._getPaddingClass(),
          }),
          (t = this.getThemeFeature("disableBackgrounds")
            ? {}
            : this.getBackgroundProps("background1", null, !0)),
          (n = i.assign({}, e, t)),
          e.hasOwnProperty("style") && (n.style = i.defaults(n.style, e.style)),
          e.hasOwnProperty("className") &&
            t.hasOwnProperty("className") &&
            (n.className = t.className + " " + e.className),
          n),
          this.isEditMode() && !this.props.inSectionSelector
            ? a.createElement(
                "div",
                { className: "s-section-editor-wrapper", key: "1366" },
                a.createElement(
                  m,
                  {
                    renderAIEditor: this._renderAIEditor,
                    isPreviewMode: this.isPreviewMode(),
                  },
                  this.getThemeFeature("disableBackgrounds")
                    ? null
                    : a.createElement(
                        r,
                        i.assign(
                          {},
                          { key: "BackgroundEditor", wasMinimal: !0 },
                          this.getComponentProps("background1")
                        )
                      ),
                  this._showLayoutButton()
                    ? a.createElement(
                        s,
                        i.assign(
                          {},
                          {
                            key: "LayoutSelector",
                            hiddenAiMobile: !0,
                            layoutOptions: this._getLayoutOptions(),
                            isEcommerce: !0,
                            updateLayout: this._updateLayout,
                            updatePadding: this._updatePadding,
                            category:
                              this.getComponentProps("ecommerce1").category,
                          },
                          this._getLayoutProps()
                        )
                      )
                    : null,
                  a.createElement(
                    c,
                    i.assign(
                      {},
                      { key: "CategorySelector" },
                      this.getComponentProps("ecommerce1")
                    )
                  ),
                  a.createElement(l.default, {
                    key: "HideOrShowSection",
                    sectionBinding: this.getDefaultBinding(),
                    sectionIndex: this.props.index,
                  })
                )
              )
            : null,
          !this.getThemeFeature("disableBackgrounds") &&
            this.hasBackgroundVideo("background1")
            ? a.createElement(
                p,
                i.assign(
                  {},
                  { key: "2370" },
                  this.getBackgroundProps("background1")
                )
              )
            : null,
          a.createElement(
            "div",
            { className: "container" },
            a.createElement(
              "div",
              { className: "columns sixteen" },
              a.createElement(o, {
                section: this,
                binding: this.getDefaultBinding(),
                inSectionSelector: this.props.inSectionSelector,
              })
            ),
            a.createElement(
              "div",
              { className: "s-ecommerce-container" },
              a.createElement(
                d,
                i.assign(
                  {},
                  {
                    sbClass: this.sbUniformTextAlignment("text1 text2"),
                    sectionId: this._getSectionId(),
                    inSectionSelector: this.props.inSectionSelector,
                    templateDummyData: this.props.templateDummyData,
                    isPreviewMode: this.isPreviewMode(),
                    key: "2787",
                  },
                  this.getComponentProps("ecommerce1")
                )
              ),
              null
            )
          )
        );
        var e, t, n;
      };
    },
    76430: function (e, t, n) {
      "use strict";
      var a = n(366757),
        i = n(496486),
        o = (n(357646), n(659370), n(389005), n(436173)),
        s = n(16863),
        r = n(980244),
        l = n(845939),
        c = (n(647851), n(716505));
      n(3325),
        (e.exports = function () {
          return a.createElement(
            c,
            ((e = {
              className:
                "s-gallery-section s-section " + this._getPaddingClass(),
            }),
            (t = this.getThemeFeature("disableBackgrounds")
              ? {}
              : this.getBackgroundProps("background1", null, !0)),
            (n = i.assign({}, e, t)),
            e.hasOwnProperty("style") &&
              (n.style = i.defaults(n.style, e.style)),
            e.hasOwnProperty("className") &&
              t.hasOwnProperty("className") &&
              (n.className = t.className + " " + e.className),
            n),
            null,
            this.getThemeFeature("disableBackgrounds") ||
              !this.hasBackgroundVideo("background1") ||
              this.props.inSectionSelector
              ? null
              : a.createElement(
                  o,
                  i.assign(
                    {},
                    { key: "1876" },
                    this.getBackgroundProps("background1")
                  )
                ),
            "fullWidth" != this._getLayoutKey()
              ? a.createElement(
                  "div",
                  { className: "container", key: "2074" },
                  a.createElement(
                    "div",
                    { className: "columns sixteen" },
                    a.createElement(l, {
                      section: this,
                      binding: this.getDefaultBinding(),
                    })
                  ),
                  a.createElement(
                    "div",
                    {
                      className: "columns sixteen",
                      style: { transition: "none" },
                    },
                    "vertical" != this._getLayoutKey()
                      ? a.createElement(
                          s,
                          i.assign(
                            {},
                            {
                              layout: this._getLayoutKey(),
                              isArranging: this.isState("editor"),
                              toggleEditor: this.toggleEditor,
                              inSectionSelector: this.props.inSectionSelector,
                              isPreviewMode: this.isPreviewMode(),
                              key: "2339",
                            },
                            this.getComponentProps("gallery1")
                          )
                        )
                      : null,
                    "vertical" == this._getLayoutKey()
                      ? a.createElement(
                          r,
                          i.assign(
                            {},
                            {
                              layout: this._getLayoutKey(),
                              isArranging: this.isState("editor"),
                              toggleEditor: this.toggleEditor,
                              inSectionSelector: this.props.inSectionSelector,
                              isPreviewMode: this.isPreviewMode(),
                              key: "2658",
                            },
                            this.getComponentProps("gallery1")
                          )
                        )
                      : null
                  )
                )
              : null,
            "fullWidth" == this._getLayoutKey()
              ? a.createElement(
                  "div",
                  { className: "full-width-gallery", key: "3009" },
                  a.createElement(
                    "div",
                    { className: "container" },
                    a.createElement(
                      "div",
                      { className: "columns sixteen" },
                      a.createElement(l, {
                        section: this,
                        binding: this.getDefaultBinding(),
                      })
                    )
                  ),
                  a.createElement(
                    s,
                    i.assign(
                      {},
                      {
                        layout: this._getLayoutKey(),
                        isArranging: this.isState("editor"),
                        toggleEditor: this.toggleEditor,
                        inSectionSelector: this.props.inSectionSelector,
                        isPreviewMode: this.isPreviewMode(),
                      },
                      this.getComponentProps("gallery1")
                    )
                  )
                )
              : null
          );
          var e, t, n;
        });
    },
    38730: function (e, t, n) {
      "use strict";
      var a = n(366757),
        i = n(496486),
        o = (n(357646), n(787066)),
        s = (n(365940), n(659370)),
        r = (n(389005), n(436173)),
        l = n(845939),
        c = n(716505),
        d = n(485456),
        u = (n(3325), n(316056));
      e.exports = function () {
        function e(e, t, n, o, r) {
          var l = this._renderSliderLayoutBtn;
          return a.createElement(
            "div",
            { className: "s-section-editor-wrapper", key: "2031" },
            e
              ? null
              : a.createElement(
                  s,
                  i.assign(
                    {},
                    { key: "BackgroundEditor", allowColors: !1 },
                    this.getComponentProps("background1", t.sub(o))
                  )
                ),
            e
              ? a.createElement(
                  u,
                  i.assign(
                    {},
                    {
                      warnningInfo: this._imageRatioWarnning(o),
                      setStateFunc: this.setStateFunc,
                      key: "2403",
                    },
                    this.getComponentProps("background1", t.sub(o))
                  )
                )
              : null,
            e
              ? null
              : a.createElement(l, { index: o, sliderLayout: r, key: "2629" }),
            null
          );
        }
        function t(e, t, n, s, r) {
          var c = this._sbHasMediaContent(s);
          return a.createElement(
            "div",
            { className: "inner" },
            "noForeground" !== r
              ? a.createElement(
                  "div",
                  {
                    className:
                      "container s-rva " +
                      r +
                      " " +
                      this.getVerticalAlignmentClassName(r),
                    key: "3272",
                  },
                  this._showMediaWrapper(r)
                    ? a.createElement(
                        "div",
                        {
                          className:
                            "columns eight media-outer s-rva-media " +
                            r +
                            " " +
                            i
                              .transform(
                                {
                                  "offset-four": !this._sbAnyHasContent(
                                    s,
                                    "text1 text2 button1"
                                  ),
                                },
                                function (e, t, n) {
                                  t && e.push(n);
                                },
                                []
                              )
                              .join(" "),
                          key: "3430",
                        },
                        a.createElement(
                          "div",
                          { className: "media-wrapper" },
                          a.createElement(
                            o,
                            i.assign(
                              {},
                              {
                                enableWidth: "true",
                                size: "medium",
                                iconLibComponents: "background",
                              },
                              this.getReduxComponentProps("media1", t.sub(s))
                            )
                          )
                        )
                      )
                    : null,
                  this._sbAnyHasContent(s, "text1 text2 button1")
                    ? a.createElement(
                        "div",
                        {
                          className:
                            "columns s-rva-text slider-desc valign " +
                            r +
                            " " +
                            i
                              .transform(
                                {
                                  eight: c,
                                  "fourteen offset-one":
                                    ("noImage" == r || !c) &&
                                    this.getThemeFeature("narrowMedia"),
                                  sixteen: !(
                                    ("noImage" != r && c) ||
                                    this.getThemeFeature("narrowMedia")
                                  ),
                                },
                                function (e, t, n) {
                                  t && e.push(n);
                                },
                                []
                              )
                              .join(" "),
                          key: "3896",
                        },
                        a.createElement(
                          "div",
                          {
                            className: i
                              .transform(
                                { "half-offset-right": "right" == r && c },
                                function (e, t, n) {
                                  t && e.push(n);
                                },
                                []
                              )
                              .join(" "),
                          },
                          a.createElement(l, {
                            section: this,
                            binding: this.getDefaultBinding(),
                            parentBinding: t.sub(s),
                            contentCheck: "button1",
                            inSectionSelector: this.props.inSectionSelector,
                          }),
                          a.createElement(
                            "div",
                            {
                              className: this.sbUniformTextAlignment(
                                "text1 text2",
                                { parentBinding: t.sub(s) }
                              ),
                            },
                            "\n                ",
                            this._rendertBtn(s, t),
                            "\n              "
                          )
                        )
                      )
                    : null
                )
              : null
          );
        }
        function n(n, o, s, l) {
          var d,
            u,
            p,
            m = this._getSliderLayout(l);
          return a.createElement(
            c,
            ((d = { className: "item " + m, key: l, isFullContent: n }),
            (u = this.getSliderBackgroundProps("background1", o.sub(l), m)),
            (p = i.assign({}, d, u)),
            d.hasOwnProperty("style") &&
              (p.style = i.defaults(p.style, d.style)),
            d.hasOwnProperty("className") &&
              u.hasOwnProperty("className") &&
              (p.className = u.className + " " + d.className),
            p),
            !this.isEditMode() ||
              this.props.inSectionSelector ||
              this.isEnableAiEditor()
              ? null
              : e.apply(this, [n, o, s, l, m]),
            !this.hasBackgroundVideo("background1", o.sub(l)) ||
              this.props.inSectionSelector ||
              this.isPreviewMode()
              ? null
              : a.createElement(
                  r,
                  i.assign(
                    {},
                    { key: "2928" },
                    this.getBackgroundProps("background1", o.sub(l))
                  )
                ),
            t.apply(this, [n, o, s, l, m])
          );
        }
        function p(e, t, a, i, o) {
          return n.apply(this, [e, t, a, i]);
        }
        function m(e) {
          var t = this.getRepeatableBinding("slider1");
          return a.createElement.apply(this, [
            d,
            i.assign(
              {},
              {
                fullscreen: this.getThemeFeature("fullscreenSlider"),
                fullscreenSliderOnlyFirstSection: this.getThemeFeature(
                  "fullscreenSliderOnlyFirstSection"
                ),
                index: this.props.index,
                isOnlyOneSection: this.props.isOnlyOneSection,
                getSliderLayouts: this._getSliderLayoutArr,
                isBanner: e,
                imgEditorState: this.state.imgEditorState,
                inSectionSelector: this.props.inSectionSelector,
                aiModePros: this._getChildComponentAiProps(),
              },
              this.getComponentProps("slider1")
            ),
            i.map(t.get().toArray(), p.bind(this, e, t)),
          ]);
        }
        return function () {
          var e = this._isBannerSection();
          return a.createElement(
            "div",
            {
              className:
                "s-section s-slider-section " +
                i
                  .transform(
                    {
                      "s-banner-section": e,
                      "s-slider-section-s5": this.isS5FirstSection(),
                    },
                    function (e, t, n) {
                      t && e.push(n);
                    },
                    []
                  )
                  .join(" "),
              style: this.getSectionStyle(),
            },
            m.apply(this, [e])
          );
        }.apply(this, []);
      };
    },
    276085: function (e, t, n) {
      "use strict";
      var a = n(366757);
      n(496486),
        (e.exports = function () {
          return a.createElement("div", {}, "\n  unused template\n");
        });
    },
    323682: function (e, t, n) {
      "use strict";
      var a = n(353147),
        i = n(366757);
      n(496486),
        (e.exports = function () {
          return i.createElement(
            "div",
            { className: "no-bg s-section-thumb s-title-thumb" },
            i.createElement(
              "div",
              { className: "p100" },
              i.createElement(
                "div",
                { className: "title-media" },
                i.createElement("img", {
                  src: this.props.content.components.media1.image.url,
                })
              ),
              i.createElement("div", {
                className: "title",
                dangerouslySetInnerHTML: {
                  __html: a(
                    "Sections|" + this.props.content.components.text1.value
                  ),
                },
              }),
              i.createElement("div", {
                className: "subtitle",
                dangerouslySetInnerHTML: {
                  __html: a(
                    "Sections|" + this.props.content.components.text2.value
                  ),
                },
              })
            )
          );
        });
    },
    723367: function (e, t, n) {
      "use strict";
      var a = n(353147),
        i = n(501068),
        o = n(663978),
        s = n(60530)(n(60530));
      o(t, "__esModule", { value: !0 }), (t.default = void 0);
      var r = n(812077),
        l = (0, s.default)(r),
        c = n(726394),
        d = (0, s.default)(c),
        u = n(569198),
        p = (0, s.default)(u),
        m = n(351379),
        h = (0, s.default)(m),
        v = n(900214),
        f = (0, s.default)(v),
        g = n(566380),
        b = (0, s.default)(g),
        y = n(366757),
        x = (0, s.default)(y),
        w = n(45697);
      (0, s.default)(w);
      var S = (function (e) {
        (0, h.default)(s, e);
        var t,
          n,
          o =
            ((t = s),
            (n = (function () {
              if ("undefined" == typeof Reflect || !i) return !1;
              if (i.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    i(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                a = (0, b.default)(t);
              if (n) {
                var o = (0, b.default)(this).constructor;
                e = i(a, arguments, o);
              } else e = a.apply(this, arguments);
              return (0, f.default)(this, e);
            });
        function s() {
          return (0, d.default)(this, s), o.apply(this, arguments);
        }
        return (
          (0, p.default)(s, [
            {
              key: "render",
              value: function () {
                var e = this.props,
                  t = e.labelLeft,
                  n = e.labelRight,
                  i = e.checkedLeft,
                  o = e.checkedRight,
                  s = e.onClickLeft,
                  r = e.onClickRight;
                return (0, l.default)(
                  "div",
                  { className: "s-binary-switcher" },
                  void 0,
                  (0, l.default)(
                    "div",
                    { className: "capsule" },
                    void 0,
                    (0, l.default)(
                      "div",
                      {
                        className: "option".concat(i ? " selected" : ""),
                        onClick: s,
                      },
                      void 0,
                      a(t)
                    ),
                    (0, l.default)(
                      "div",
                      {
                        className: "option".concat(o ? " selected" : ""),
                        onClick: r,
                      },
                      void 0,
                      a(n)
                    )
                  )
                );
              },
            },
          ]),
          s
        );
      })(x.default.Component);
      (t.default = S), (e.exports = t.default);
    },
    809641: function (e, t, n) {
      "use strict";
      var a = n(663978),
        i = n(60530)(n(60530));
      a(t, "__esModule", { value: !0 });
      var o,
        s = n(143393),
        r = (0, i.default)(s),
        l = n(717187),
        c = n(223336),
        d = (0, i.default)(c),
        u = n(496486),
        p = (0, i.default)(u),
        m = n(14991),
        h = (0, i.default)(m),
        v = p.default.assign({}, l.EventEmitter.prototype, {
          getBinding: function () {
            return o.binding;
          },
          getData: function () {
            return this.getBinding().toJS();
          },
          getDataByName: function (e) {
            return this.getBinding().sub(e).toJS();
          },
          hasTitle: function () {
            var e = this.getData().header.title.value.toLowerCase(),
              t = (0, d.default)("<div>").html(e).text();
            return "add a title" !== t && "add a blog post title" !== t;
          },
          getTitle: function () {
            var e = this.getData().header.title.value;
            return (0, d.default)("<div>").html(e).text();
          },
          init: function (e) {
            o = new h.default(e);
          },
          hydrate: function (e) {
            o.binding.set(r.default.fromJS(e));
          },
        });
      (t.default = v), (e.exports = t.default);
    },
    979252: function (e, t, n) {
      "use strict";
      var a = n(223765),
        i = n(752424),
        o = n(663978),
        s = n(834074),
        r = n(60530)(n(60530));
      o(t, "__esModule", { value: !0 });
      var l,
        c,
        d = n(176965),
        u = (0, r.default)(d),
        p = n(143393),
        m = (0, r.default)(p),
        h = n(717187),
        v = n(809641),
        f = (0, r.default)(v),
        g = n(835065),
        b = (0, r.default)(g),
        y = n(125485),
        x = (0, r.default)(y),
        w = n(381947),
        S = (0, r.default)(w),
        C = n(234584),
        k = (0, r.default)(C),
        N = n(818166),
        M = (0, r.default)(N),
        E = n(156503),
        _ = (0, r.default)(E),
        Z = n(229081),
        I = (0, r.default)(Z),
        P = n(266004),
        L = (0, r.default)(P),
        T = n(389087),
        O = (0, r.default)(T),
        B = n(604990),
        D = (0, r.default)(B),
        A = (n(884920), V(n(647168))),
        R = V(n(398193)),
        F = n(443673),
        H = (0, r.default)(F),
        j = n(496486),
        U = (0, r.default)(j);
      function W(e) {
        if ("function" != typeof i) return null;
        var t = new i(),
          n = new i();
        return (W = function (e) {
          return e ? n : t;
        })(e);
      }
      function V(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" !== a(e) && "function" != typeof e))
          return { default: e };
        var n = W(t);
        if (n && n.has(e)) return n.get(e);
        var i = {},
          r = o && s;
        for (var l in e)
          if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
            var c = r ? s(e, l) : null;
            c && (c.get || c.set) ? o(i, l, c) : (i[l] = e[l]);
          }
        return (i.default = e), n && n.set(e, i), i;
      }
      var z = function () {
          R.setPageDataBinding(c),
            A.initStore({ pageDataReducer: R.default }),
            (0, H.default)(A.getStore(), c);
        },
        Q = U.default.assign({}, h.EventEmitter.prototype, {
          init: function (e) {
            var t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              a =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : {},
              i = m.default.fromJS(
                e || {
                  blogPostMeta: {},
                  content: {},
                  pageMeta: {},
                  pageData: {},
                  navigator: {},
                  settings: {},
                  fonts: {},
                }
              ),
              o = (l = u.default.createContext({
                initialState: i,
                options: { renderOnce: t.isServer },
              })).getBinding();
            (c = o),
              f.default.init(o.sub("content")),
              k.default.init(o.sub("pageMeta")),
              M.default.init(o.sub("pageData")),
              _.default.init(o.sub("elementMeasurements"), o.get("pageData")),
              I.default.init(o.sub("navigator")),
              L.default.init(o.sub("_ecommerce")),
              O.default.init(o.sub("_portfolio")),
              b.default.init(o.sub("blogPostMeta"));
            var s = n(107056),
              r = n(183123);
            s.config("cloud_name", r.getCloudinaryCloudName());
            var d = a.features,
              p = a.fonts_v2;
            return (
              x.default.init(c.sub("fonts")),
              x.default.hydrate(null, e.pageMeta, p),
              S.default.init(o.sub("features")),
              S.default.hydrate(d),
              z(),
              a.blogCategoryCollection &&
                D.default.hydrate({
                  blogCategoryCollectionFromSSR: a.blogCategoryCollection,
                }),
              a.ecommerceProductCollection &&
                L.default.hydrate({
                  ecommerceProductOrderList: a.ecommerceProductOrderList || {},
                  ecommerceProductCollection:
                    a.ecommerceProductCollection || {},
                  ecommerceCategoryCollection:
                    a.ecommerceCategoryCollection || {},
                }),
              a.portfolioCategoryCollection &&
                O.default.hydrate({
                  portfolioCategoryCollection:
                    a.portfolioCategoryCollection || {},
                }),
              l
            );
          },
          hydrate: function (e, t) {
            var n = e.blogPostMeta,
              a = e.content,
              i = e.pageMeta,
              o = e.pageData,
              s = e.settings,
              r = t.features,
              l = t.fonts_v2;
            c.set("settings", m.default.fromJS(s)),
              f.default.hydrate(a),
              b.default.hydrate(n),
              k.default.hydrate(i),
              M.default.hydrate(o),
              x.default.init(c.sub("fonts")),
              x.default.hydrate(null, i, l),
              S.default.init(c.sub("features")),
              S.default.hydrate(r),
              z();
          },
          getBinding: function () {
            return c;
          },
          getBlogSettings: function () {
            return this.getBinding().sub("settings");
          },
        });
      (t.default = Q), (e.exports = t.default);
    },
    400342: function (e, t, n) {
      "use strict";
      n(663978)(t, "__esModule", { value: !0 }),
        (t.default = n(196771)),
        (e.exports = t.default);
    },
    305228: function (e, t, n) {
      "use strict";
      var a = n(353147),
        i =
          (n(686902),
          n(14310),
          n(620116),
          n(834074),
          n(778914),
          n(239649),
          n(820368),
          n(663978)),
        o = n(60530)(n(60530));
      i(t, "__esModule", { value: !0 });
      var s = n(487672),
        r = ((0, o.default)(s), n(43138)),
        l = (0, o.default)(r),
        c = n(792695),
        d = (0, o.default)(c);
      (t.default = {
        mixins: [d.default],
        displayName: "GallerySection",
        _getLayoutOptions: function () {
          return [
            { name: "normal", key: "normal" },
            { name: "full width", key: "fullWidth" },
            { name: "vertical", key: "vertical" },
          ];
        },
        _isSmallScreen: function () {
          return l.default.isSmallScreen();
        },
        isPreviewMode: function () {
          return !1;
        },
        _renderAIEditor: function () {
          return !1;
        },
        render: function () {
          return (
            a("Editor|Gallery"),
            a("Sections|Gallery (Legacy)"),
            a("Editor|Image and video thumbnails that open in a full view."),
            this.getTemplate().apply(this)
          );
        },
      }),
        (e.exports = t.default);
    },
    537282: function (e, t, n) {
      "use strict";
      n(663978)(t, "__esModule", { value: !0 }),
        (t.default = n(196771)),
        (e.exports = t.default);
    },
    433907: function (e, t, n) {
      "use strict";
      var a = n(663978),
        i = n(60530)(n(60530));
      a(t, "__esModule", { value: !0 });
      var o = n(977766),
        s = (0, i.default)(o),
        r = n(926941),
        l = (0, i.default)(r),
        c = n(297079),
        d = (0, i.default)(c);
      function u(e, t) {
        var n,
          a,
          i,
          o,
          r,
          l,
          c,
          p = u.getCustomColors(e, t),
          m = p.primary,
          h = p.secondary,
          v = (p.primaryHex, p.primary09Hex, p.primary11Hex, p.secondaryLight);
        return (0, s.default)(
          (n = (0, s.default)(
            (a = (0, s.default)(
              (i = (0, s.default)(
                (o = (0, s.default)(
                  (r = (0, s.default)(
                    (l = (0, s.default)(
                      (c = "".concat(
                        d.default.generate({
                          overlay: h.mult(0.5).fade(0.35),
                          socialLinks: m.fade(0.5),
                          ecommerceGroup: {
                            main: m,
                            mobileBg: h.lumaCorrection(-0.6).lighten(0.8),
                          },
                          donationGroup: { main: m },
                          themeColorGroup: { main: m },
                        }),
                        "\n.s-custom-colors .navigator .nav-container .nav ul li a:hover,\n.s-custom-colors .navigator .nav-container .nav ul li a.selected {\n  background: "
                      ))
                    ).call(
                      c,
                      v,
                      ";\n}\n.s-custom-colors .navigator .nav-container .nav ul.items li,\n.s-custom-colors .navigator .nav-container .nav ul.items,\n.s-custom-colors .navigator {\n  border-color: "
                    ))
                  ).call(
                    l,
                    h.lumaCorrection(-0.6).lighten(0.7).toHex(),
                    ";\n}\n\n.s-custom-colors .dummy-shadow {\n  box-shadow: "
                  ))
                ).call(
                  r,
                  h.lumaCorrection(-0.6).lighten(0.8).toHex(),
                  " 0 0 10px 0 inset;\n}\n.navbar-drawer.strikingly-drawer ul#nav-drawer-list {\n  border-right: 1px solid "
                ))
              ).call(
                o,
                v,
                ";\n}\n.navbar-drawer.strikingly-drawer ul#nav-drawer-list li a.selected {\n  background: "
              ))
            ).call(i, v, ";\n  box-shadow: 5px 0 0 0 "))
          ).call(
            a,
            h.lumaCorrection(-0.6).lighten(0.7).toHex(),
            " inset;\n}\n.navbar-drawer.strikingly-drawer ul#nav-drawer-list li {\n  a:not(.social-media-link):not(.mobile-nav-button .s-common-button), .s-mobile-nav-dropdown-item, .s-mobile-membership-login-nav-item, .s-mobile-multi-lang, .s-mobile-nav-btn {\n    border-bottom: 1px solid "
          ))
        ).call(n, h.lumaCorrection(-0.6).lighten(0.7).toHex(), ";\n  }\n}");
      }
      (u.getCustomColors = function (e, t) {
        var n = new l.default(e).lumaCorrection(0.6),
          a = null;
        a = t ? new l.default(t).lumaCorrection() : n;
        var i = n.toHex(),
          o = n.mult(0.95).toHex(),
          s = n.mult(1.05).toHex(),
          r = a.lumaCorrection(-0.6).lighten(0.9).toHex();
        return {
          primary: n,
          secondary: a,
          primaryHex: i,
          primary09Hex: o,
          primary11Hex: s,
          secondaryLight: r,
        };
      }),
        (t.default = u),
        (e.exports = t.default);
    },
    379388: function (e, t, n) {
      "use strict";
      var a = n(663978),
        i = n(60530)(n(60530));
      a(t, "__esModule", { value: !0 });
      var o = n(223336),
        s = (0, i.default)(o),
        r = n(786483),
        l = (0, i.default)(r),
        c = n(792656),
        d = (0, i.default)(c),
        u = n(43138),
        p = (0, i.default)(u),
        m = function () {
          var e = (0, s.default)(
            ".page-wrapper .slide:not(.s-hidden-section) .s-section:visible"
          );
          d.default.collapsePaddingAdjacentSection(e);
        },
        h = function () {
          p.default.isIE11() &&
            (0, s.default)(".s-first-visible-section .s-section").each(
              function () {
                var e = (0, s.default)(this);
                e.css("height", ""),
                  e.css("height", "".concat(e.height(), "px"));
              }
            );
        };
      (t.default = function () {
        m(),
          h(),
          l.default.Event.subscribe("Editor.SideMenu.Opened", function () {
            return (0, s.default)(window).resize();
          }),
          l.default.Event.subscribe("Editor.SideMenu.Closed", function () {
            return (0, s.default)(window).resize();
          }),
          l.default.Event.subscribe("Page.beforeNewOneFadeIn", m),
          l.default.Event.subscribe("Section.onLoad", m),
          l.default.Event.subscribe("Section.changed", m),
          l.default.Event.subscribe("Section.changed", h);
      }),
        (e.exports = t.default);
    },
    269597: function (e, t, n) {
      "use strict";
      var a = n(663978),
        i = n(60530)(n(60530));
      a(t, "__esModule", { value: !0 });
      var o = n(987893),
        s = (0, i.default)(o);
      (t.default = s.default), (e.exports = t.default);
    },
    558042: function (e, t, n) {
      (t = n(923645)(!1)).push([
        e.id,
        ".s-component.s-social-media .s-component-editor.social-media-button-editor {\n  border: none;\n  padding: 0;\n}\n.s-component.s-social-media .s-component-editor.social-media-button-editor .s-social-media-buttons .social-media-button .link-icon {\n  font-family: open_sans, Open Sans, sans-serif;\n}\n.s-social-media-edit {\n  width: 440px;\n  color: #E2E4E7;\n}\n.s-social-media-edit .title {\n  font-size: 20px;\n  font-weight: bold;\n  text-transform: uppercase;\n  font-family: 'brandon-grotesque', 'brandon', martel-sans, sans-serif;\n}\n.s-social-media-edit .note {\n  margin: 10px 0;\n  line-height: 1.5;\n  font-size: 12px;\n  font-family: open_sans, Open Sans, sans-serif;\n}\n.s-social-media-edit button.s-kit-btn {\n  margin: 0;\n}\n.s-social-media-edit .add-btn {\n  margin-top: 1px;\n  width: 100%;\n  height: 36px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 2px;\n  background-color: #474B56;\n  text-transform: uppercase;\n  font-weight: bold;\n  font-family: 'brandon-grotesque', 'brandon', martel-sans, sans-serif;\n  cursor: pointer;\n}\n.s-social-media-edit .add-btn:hover {\n  background-color: #5c6676;\n}\n.s-social-media-edit .sync-checkbox.button-list-part {\n  margin-top: 20px;\n}\n.s-social-media-edit .sync-checkbox .sync-hint {\n  color: #E2E4E7;\n  font-size: 12px;\n}\n.s-social-media-edit .footer {\n  margin-top: 20px;\n}\n.s-social-media-edit .footer .submit {\n  margin-right: 10px;\n}\n.s-social-media-edit .footer .s-kit-btn:last-of-type {\n  margin-right: 10px;\n}\n.s-social-media-edit .footer .sync-checkbox {\n  display: inline-block;\n}\n.s-social-media-edit .social-media-contact-container {\n  margin-top: 20px;\n}\n.s-social-media-edit .social-media-contact-list {\n  padding: 10px;\n  margin-bottom: 1px;\n  box-sizing: border-box;\n  border-radius: 2px;\n  font-size: 12px;\n}\n.s-social-media-edit .social-media-contact-list,\n.s-social-media-edit .social-media-contact-list input {\n  color: #E2E4E7;\n  background: #474B56;\n  border: none;\n  outline: none;\n  line-height: 15px;\n  font-size: 12px;\n  min-height: unset;\n}\n.s-social-media-edit .social-media-contact-list input {\n  outline: none;\n  border: none;\n  box-shadow: none;\n  padding: 0px 10px;\n}\n.s-social-media-edit .social-media-contact-list input::-webkit-input-placeholder {\n  color: #8D949C;\n}\n.sm-item-container {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  background: #474B56;\n  padding: 10px;\n  margin-bottom: 1px;\n  color: #E2E4E7;\n  box-sizing: border-box;\n  border-radius: 2px;\n  font-size: 12px;\n}\n.sm-item-container.sxl-item {\n  justify-content: flex-start;\n}\n.sm-item-container.error {\n  padding-bottom: 25px;\n}\n.sm-item-container .s-kit-icon {\n  color: #E2E4E7;\n}\n.sm-item-container .drag-field {\n  padding-left: 5px;\n  cursor: move;\n}\n.sm-item-container i.social-media-icon {\n  margin: 0 10px;\n  font-size: 16px;\n}\n.sm-item-container .social-media-svg {\n  height: 16px;\n  margin: 0 10px;\n  fill: currentColor;\n}\n.sm-item-container .item-title {\n  margin-right: 10px;\n}\n.sm-item-container .content-wrapper {\n  flex: 1;\n  position: relative;\n  display: inline-block;\n}\n.sm-item-container .item-cell {\n  width: 100%;\n  overflow: hidden;\n  display: inline-block;\n}\n.sm-item-container .item-cell .sm-link-input {\n  width: 100%;\n  border: none;\n  outline: none;\n  line-height: 15px;\n  color: #E2E4E7;\n  background-color: transparent;\n}\n.sm-item-container .item-cell .sm-link {\n  height: 15px;\n  max-width: 92%;\n  line-height: 15px;\n  display: inline-block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  vertical-align: bottom;\n  scrollbar-width: none;\n  /* Firefox */\n  -ms-overflow-style: none;\n  /* IE 10+ */\n}\n.sm-item-container .item-cell .sm-link::-webkit-scrollbar {\n  display: none;\n  /* Chrome Safari */\n}\n.sm-item-container .item-cell .sm-link.hint-link {\n  color: #8D949C;\n}\n.sm-item-container .item-cell .update-image,\n.sm-item-container .item-cell .show-image,\n.sm-item-container .item-cell .delete-image {\n  cursor: pointer;\n  display: inline-block;\n  border-bottom: 1px solid #E2E4E7;\n}\n.sm-item-container .item-cell .show-image {\n  margin-right: 10px;\n}\n.sm-item-container .item-cell .edit-icon {\n  margin-left: 10px;\n  vertical-align: top;\n}\n.sm-item-container .delete-icon {\n  cursor: pointer;\n  margin-left: 10px;\n}\n.sm-item-container .error-hint {\n  top: 20px;\n  left: 0;\n  position: absolute;\n  white-space: nowrap;\n  color: #E64751;\n}\n.social-media__style__stylizedHelper {\n  box-shadow: 0 5px 5px -5px rgba(0, 0, 0, 0.2), 0 -5px 5px -5px rgba(0, 0, 0, 0.2);\n  z-index: 3200;\n  font-family: open_sans, Open Sans, sans-serif;\n}\n",
        "",
      ]),
        (e.exports = t);
    },
    486033: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/blog/thumbnail/cover.png";
    },
    991010: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/columns/thumbnail/cover.png";
    },
    808394: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/contact_form/thumbnail/cover.png";
    },
    728083: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/cta/thumbnail/cover.png";
    },
    779865: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/ecommerce/thumbnail/cover.png";
    },
    42003: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/gallery/thumbnail/cover.png";
    },
    72643: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/html/thumbnail/cover.png";
    },
    877232: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/icons/thumbnail/cover.png";
    },
    220945: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/info/thumbnail/cover.png";
    },
    733381: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/media/thumbnail/cover.png";
    },
    896e3: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/rows/thumbnail/cover.png";
    },
    15501: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/signup_form/thumbnail/cover.png";
    },
    244486: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/slider/thumbnail/cover.jpg";
    },
    702654: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/social_feed/thumbnail/cover.jpg";
    },
    893096: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/text/thumbnail/cover.png";
    },
    421630: function (e, t, n) {
      e.exports =
        n.p +
        "../../../../public/images/v4/s5-theme/sections/title/thumbnail/cover.png";
    },
    866951: function (e, t, n) {
      e.exports = n.p + "../../../../public/images/v4/s5-theme/thumbnail.jpg";
    },
    171349: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = (function () {
          function e(e, t) {
            for (var n = 0; n < t.length; n++) {
              var a = t[n];
              (a.enumerable = a.enumerable || !1),
                (a.configurable = !0),
                "value" in a && (a.writable = !0),
                Object.defineProperty(e, a.key, a);
            }
          }
          return function (t, n, a) {
            return n && e(t.prototype, n), a && e(t, a), t;
          };
        })(),
        i = n(496486),
        o = (function () {
          function e() {
            !(function (e, t) {
              if (!(e instanceof t))
                throw new TypeError("Cannot call a class as a function");
            })(this, e),
              (this.refs = {});
          }
          return (
            a(e, [
              {
                key: "add",
                value: function (e, t) {
                  this.refs[e] || (this.refs[e] = []), this.refs[e].push(t);
                },
              },
              {
                key: "remove",
                value: function (e, t) {
                  var n = this.getIndex(e, t);
                  -1 !== n && this.refs[e].splice(n, 1);
                },
              },
              {
                key: "getActive",
                value: function () {
                  var e = this;
                  return (0, i.find)(
                    this.refs[this.active.collection],
                    function (t) {
                      return t.node.sortableInfo.index == e.active.index;
                    }
                  );
                },
              },
              {
                key: "getIndex",
                value: function (e, t) {
                  return this.refs[e].indexOf(t);
                },
              },
              {
                key: "getOrderedRefs",
                value: function () {
                  var e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : this.active.collection;
                  return (0, i.sortBy)(this.refs[e], function (e) {
                    return e.node.sortableInfo.index;
                  });
                },
              },
            ]),
            e
          );
        })();
      t.default = o;
    },
    846538: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a =
          Object.assign ||
          function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var a in n)
                Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
            }
            return e;
          },
        i = function (e, t) {
          if (Array.isArray(e)) return e;
          if (Symbol.iterator in Object(e))
            return (function (e, t) {
              var n = [],
                a = !0,
                i = !1,
                o = void 0;
              try {
                for (
                  var s, r = e[Symbol.iterator]();
                  !(a = (s = r.next()).done) &&
                  (n.push(s.value), !t || n.length !== t);
                  a = !0
                );
              } catch (e) {
                (i = !0), (o = e);
              } finally {
                try {
                  !a && r.return && r.return();
                } finally {
                  if (i) throw o;
                }
              }
              return n;
            })(e, t);
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance"
          );
        },
        o = (function () {
          function e(e, t) {
            for (var n = 0; n < t.length; n++) {
              var a = t[n];
              (a.enumerable = a.enumerable || !1),
                (a.configurable = !0),
                "value" in a && (a.writable = !0),
                Object.defineProperty(e, a.key, a);
            }
          }
          return function (t, n, a) {
            return n && e(t.prototype, n), a && e(t, a), t;
          };
        })();
      t.default = function (e) {
        var t,
          n,
          p =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : { withRef: !1 };
        return (
          (n = t =
            (function (t) {
              function n(e) {
                h(this, n);
                var t = v(
                  this,
                  (n.__proto__ || Object.getPrototypeOf(n)).call(this, e)
                );
                return (
                  (t.handleStart = function (e) {
                    var n = t.props,
                      a = n.distance,
                      i = n.shouldCancelStart;
                    if (2 === e.button || i(e)) return !1;
                    (t._touched = !0),
                      (t._pos = { x: e.clientX, y: e.clientY });
                    var o = (0, d.closest)(e.target, function (e) {
                      return null != e.sortableInfo;
                    });
                    if (o && o.sortableInfo && !t.state.sorting) {
                      var s = t.props.useDragHandle,
                        r = o.sortableInfo,
                        l = r.index,
                        c = r.collection;
                      if (
                        s &&
                        !(0, d.closest)(e.target, function (e) {
                          return null != e.sortableHandle;
                        })
                      )
                        return;
                      (t.manager.active = { index: l, collection: c }),
                        a ||
                          (t.pressTimer = setTimeout(function () {
                            return t.handlePress(e);
                          }, t.props.pressDelay));
                    }
                  }),
                  (t.handleMove = function (e) {
                    var n = t.props.distance;
                    if (!t.state.sorting && t._touched) {
                      t._delta = {
                        x: t._pos.x - e.clientX,
                        y: t._pos.y - e.clientY,
                      };
                      var a = Math.abs(t._delta.x) + Math.abs(t._delta.y);
                      n ? a >= n && t.handlePress(e) : t.cancel();
                    }
                  }),
                  (t.handleEnd = function () {
                    var e = t.props.distance;
                    (t._touched = !1), e || t.cancel();
                  }),
                  (t.cancel = function () {
                    t.state.sorting ||
                      (clearTimeout(t.pressTimer), (t.manager.active = null));
                  }),
                  (t.handlePress = function (e) {
                    var n = t.manager.getActive();
                    if (n) {
                      var a = t.props,
                        i = a.axis,
                        o = a.onSortStart,
                        s = a.helperClass,
                        r = a.hideSortableGhost,
                        l = a.useWindowAsScrollContainer,
                        c = n.node,
                        u = n.collection,
                        p = c.sortableInfo.index,
                        h = (0, d.getElementMargin)(c),
                        v = t.container.getBoundingClientRect();
                      (t.node = c),
                        (t.margin = h),
                        (t.width = c.offsetWidth),
                        (t.height = c.offsetHeight),
                        (t.dimension = "x" === i ? t.width : t.height),
                        (t.marginOffset = {
                          x: t.margin.left + t.margin.right,
                          y: Math.max(t.margin.top, t.margin.bottom),
                        }),
                        (t.boundingClientRect = c.getBoundingClientRect()),
                        (t.index = p),
                        (t.newIndex = p);
                      var f,
                        g = (t.edge = "x" === i ? "Left" : "Top");
                      (t.offsetEdge = t.getEdgeOffset(g, c)),
                        (t.initialOffset = t.getOffset(e)),
                        (t.initialScroll = t.scrollContainer["scroll" + g]),
                        (t.helper = t.document.body.appendChild(
                          c.cloneNode(!0)
                        )),
                        (t.helper.style.position = "fixed"),
                        (t.helper.style.top =
                          t.boundingClientRect.top - h.top + "px"),
                        (t.helper.style.left =
                          t.boundingClientRect.left - h.left + "px"),
                        (t.helper.style.width = t.width + "px"),
                        (t.helper.style.boxSizing = "border-box"),
                        r &&
                          ((t.sortableGhost = c),
                          (c.style.visibility = "hidden")),
                        "x" === i
                          ? ((t.minTranslate =
                              (l ? 0 : v.left) -
                              t.boundingClientRect.left -
                              t.width / 2),
                            (t.maxTranslate =
                              (l
                                ? t.contentWindow.innerWidth
                                : v.left + v.width) -
                              t.boundingClientRect.left -
                              t.width / 2))
                          : ((t.minTranslate =
                              (l ? 0 : v.top) -
                              t.boundingClientRect.top -
                              t.height / 2),
                            (t.maxTranslate =
                              (l
                                ? t.contentWindow.innerHeight
                                : v.top + v.height) -
                              t.boundingClientRect.top -
                              t.height / 2)),
                        s &&
                          (f = t.helper.classList).add.apply(
                            f,
                            m(s.split(" "))
                          ),
                        (t.listenerNode = e.touches ? c : t.contentWindow),
                        d.events.move.forEach(function (e) {
                          return t.listenerNode.addEventListener(
                            e,
                            t.handleSortMove,
                            !1
                          );
                        }),
                        d.events.end.forEach(function (e) {
                          return t.listenerNode.addEventListener(
                            e,
                            t.handleSortEnd,
                            !1
                          );
                        }),
                        t.setState({ sorting: !0, sortingIndex: p }),
                        o && o({ node: c, index: p, collection: u }, e);
                    }
                  }),
                  (t.handleSortMove = function (e) {
                    var n = t.props.onSortMove;
                    e.preventDefault(),
                      t.updatePosition(e),
                      t.animateNodes(),
                      t.autoscroll(),
                      n && n(e);
                  }),
                  (t.handleSortEnd = function (e) {
                    var n = t.props,
                      a = n.hideSortableGhost,
                      i = n.onSortEnd,
                      o = t.manager.active.collection;
                    t.listenerNode &&
                      (d.events.move.forEach(function (e) {
                        return t.listenerNode.removeEventListener(
                          e,
                          t.handleSortMove
                        );
                      }),
                      d.events.end.forEach(function (e) {
                        return t.listenerNode.removeEventListener(
                          e,
                          t.handleSortEnd
                        );
                      })),
                      t.helper.parentNode.removeChild(t.helper),
                      a &&
                        t.sortableGhost &&
                        (t.sortableGhost.style.visibility = "");
                    for (
                      var s = t.manager.refs[o], r = 0, l = s.length;
                      r < l;
                      r++
                    ) {
                      var c = s[r],
                        u = c.node;
                      (c.edgeOffset = null),
                        (u.style[d.vendorPrefix + "Transform"] = ""),
                        (u.style[d.vendorPrefix + "TransitionDuration"] = "");
                    }
                    "function" == typeof i &&
                      i(
                        {
                          oldIndex: t.index,
                          newIndex: t.newIndex,
                          collection: o,
                        },
                        e
                      ),
                      clearInterval(t.autoscrollInterval),
                      (t.autoscrollInterval = null),
                      (t.manager.active = null),
                      t.setState({ sorting: !1, sortingIndex: null }),
                      (t._touched = !1);
                  }),
                  (t.autoscroll = function () {
                    var e = t.translate,
                      n = 0,
                      a = 1;
                    e >= t.maxTranslate - t.dimension / 2
                      ? ((n = 1),
                        (a =
                          10 *
                          Math.abs(
                            (t.maxTranslate - t.dimension / 2 - e) / t.dimension
                          )))
                      : e <= t.minTranslate + t.dimension / 2 &&
                        ((n = -1),
                        (a =
                          10 *
                          Math.abs(
                            (e - t.dimension / 2 - t.minTranslate) / t.dimension
                          ))),
                      t.autoscrollInterval &&
                        (clearTimeout(t.autoscrollInterval),
                        (t.autoscrollInterval = null),
                        (t.isAutoScrolling = !1)),
                      0 !== n &&
                        (t.autoscrollInterval = setInterval(function () {
                          t.isAutoScrolling = !0;
                          var e = 1 * a * n;
                          (t.scrollContainer["scroll" + t.edge] += e),
                            (t.translate += e),
                            t.animateNodes();
                        }, 5));
                  }),
                  (t.manager = new c.default()),
                  (t.events = {
                    start: t.handleStart,
                    move: t.handleMove,
                    end: t.handleEnd,
                  }),
                  (0, u.default)(
                    !(e.distance && e.pressDelay),
                    "Attempted to set both `pressDelay` and `distance` on SortableContainer, you may only use one or the other, not both at the same time."
                  ),
                  (t.state = {}),
                  t
                );
              }
              return (
                f(n, t),
                o(n, [
                  {
                    key: "getChildContext",
                    value: function () {
                      return { manager: this.manager };
                    },
                  },
                  {
                    key: "componentDidMount",
                    value: function () {
                      var e = this,
                        t = this.props,
                        n = t.contentWindow,
                        a = t.getContainer,
                        i = t.useWindowAsScrollContainer;
                      (this.container =
                        "function" == typeof a
                          ? a(this.getWrappedInstance())
                          : l.default.findDOMNode(this)),
                        (this.document =
                          this.container.ownerDocument || document),
                        (this.scrollContainer = i
                          ? this.document.body
                          : this.container),
                        (this.contentWindow = "function" == typeof n ? n() : n);
                      var o = function (t) {
                        d.events[t].forEach(function (n) {
                          return e.container.addEventListener(
                            n,
                            e.events[t],
                            !1
                          );
                        });
                      };
                      for (var s in this.events) o(s);
                    },
                  },
                  {
                    key: "componentWillUnmount",
                    value: function () {
                      var e = this,
                        t = function (t) {
                          d.events[t].forEach(function (n) {
                            return e.container.removeEventListener(
                              n,
                              e.events[t]
                            );
                          });
                        };
                      for (var n in this.events) t(n);
                    },
                  },
                  {
                    key: "getEdgeOffset",
                    value: function (e, t) {
                      var n =
                        arguments.length > 2 && void 0 !== arguments[2]
                          ? arguments[2]
                          : 0;
                      if (t)
                        return t.parentNode !== this.container
                          ? this.getEdgeOffset(
                              e,
                              t.parentNode,
                              n + t["offset" + e]
                            )
                          : t["offset" + e] + n;
                    },
                  },
                  {
                    key: "getOffset",
                    value: function (e) {
                      return {
                        x: e.touches ? e.touches[0].clientX : e.clientX,
                        y: e.touches ? e.touches[0].clientY : e.clientY,
                      };
                    },
                  },
                  {
                    key: "getLockPixelOffsets",
                    value: function () {
                      var e = this.props.lockOffset;
                      Array.isArray(e) || (e = [e, e]),
                        (0, u.default)(
                          2 === e.length,
                          "lockOffset prop of SortableContainer should be a single value or an array of exactly two values. Given %s",
                          e
                        );
                      var t = i(e, 2),
                        n = t[0],
                        a = t[1];
                      return [
                        this.getLockPixelOffset(n),
                        this.getLockPixelOffset(a),
                      ];
                    },
                  },
                  {
                    key: "getLockPixelOffset",
                    value: function (e) {
                      var t = e,
                        n = "px";
                      if ("string" == typeof e) {
                        var a = /^[+-]?\d*(?:\.\d*)?(px|%)$/.exec(e);
                        (0, u.default)(
                          null !== a,
                          'lockOffset value should be a number or a string of a number followed by "px" or "%". Given %s',
                          e
                        ),
                          (t = parseFloat(e)),
                          (n = a[1]);
                      }
                      return (
                        (0, u.default)(
                          isFinite(t),
                          "lockOffset value should be a finite. Given %s",
                          e
                        ),
                        "%" === n && (t = (t * this.dimension) / 100),
                        t
                      );
                    },
                  },
                  {
                    key: "updatePosition",
                    value: function (e) {
                      var t = this.props,
                        n = t.axis,
                        a = t.lockAxis,
                        o = t.lockToContainerEdges,
                        s = this.getOffset(e),
                        r = {
                          x: s.x - this.initialOffset.x,
                          y: s.y - this.initialOffset.y,
                        };
                      if (((this.translate = r[n]), o)) {
                        var l = this.getLockPixelOffsets(),
                          c = i(l, 2),
                          u = c[0],
                          p = c[1],
                          m = this.dimension / 2 - u,
                          h = this.dimension / 2 - p;
                        r[n] = (0, d.limit)(
                          this.minTranslate + m,
                          this.maxTranslate - h,
                          r[n]
                        );
                      }
                      switch (a) {
                        case "x":
                          r.y = 0;
                          break;
                        case "y":
                          r.x = 0;
                      }
                      this.helper.style[d.vendorPrefix + "Transform"] =
                        "translate3d(" + r.x + "px," + r.y + "px, 0)";
                    },
                  },
                  {
                    key: "animateNodes",
                    value: function () {
                      var e = this.props,
                        t = e.axis,
                        n = e.transitionDuration,
                        a = e.hideSortableGhost,
                        i = this.manager.getOrderedRefs(),
                        o =
                          this.scrollContainer["scroll" + this.edge] -
                          this.initialScroll,
                        s = this.offsetEdge + this.translate + o;
                      this.newIndex = null;
                      for (var r = 0, l = i.length; r < l; r++) {
                        var c = i[r],
                          u = c.node,
                          p = c.edgeOffset,
                          m = u.sortableInfo.index,
                          h = "x" === t ? u.offsetWidth : u.offsetHeight,
                          v = this.dimension > h ? h / 2 : this.dimension / 2,
                          f = 0,
                          g = 0,
                          b = 0;
                        null == p &&
                          (i[r].edgeOffset = p =
                            this.getEdgeOffset(this.edge, u)),
                          m !== this.index
                            ? (n &&
                                (u.style[
                                  d.vendorPrefix + "TransitionDuration"
                                ] = n + "ms"),
                              m > this.index && s + v >= p
                                ? ((f = -(
                                    this.dimension + this.marginOffset[t]
                                  )),
                                  (this.newIndex = m))
                                : m < this.index &&
                                  s <= p + v &&
                                  ((f = this.dimension + this.marginOffset[t]),
                                  null == this.newIndex && (this.newIndex = m)),
                              "x" === t ? (g = f) : (b = f),
                              (u.style[d.vendorPrefix + "Transform"] =
                                "translate3d(" + g + "px," + b + "px,0)"))
                            : a &&
                              ((this.sortableGhost = u),
                              (u.style.visibility = "hidden"));
                      }
                      null == this.newIndex && (this.newIndex = this.index);
                    },
                  },
                  {
                    key: "getWrappedInstance",
                    value: function () {
                      return (
                        (0, u.default)(
                          p.withRef,
                          "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableContainer() call"
                        ),
                        this.refs.wrappedInstance
                      );
                    },
                  },
                  {
                    key: "render",
                    value: function () {
                      var t = p.withRef ? "wrappedInstance" : null;
                      return r.default.createElement(
                        e,
                        a({ ref: t }, this.props, this.state)
                      );
                    },
                  },
                ]),
                n
              );
            })(s.Component)),
          (t.displayName = e.displayName
            ? "SortableList(" + e.displayName + ")"
            : "SortableList"),
          (t.WrappedComponent = e),
          (t.defaultProps = {
            axis: "y",
            transitionDuration: 300,
            pressDelay: 0,
            distance: 0,
            useWindowAsScrollContainer: !1,
            hideSortableGhost: !0,
            contentWindow: "undefined" != typeof window ? window : null,
            shouldCancelStart: function (e) {
              if (
                -1 !==
                ["input", "textarea", "select", "option"].indexOf(
                  e.target.tagName.toLowerCase()
                )
              )
                return !0;
            },
            lockToContainerEdges: !1,
            lockOffset: "50%",
          }),
          (t.propTypes = {
            axis: s.PropTypes.oneOf(["x", "y"]),
            distance: s.PropTypes.number,
            lockAxis: s.PropTypes.string,
            helperClass: s.PropTypes.string,
            transitionDuration: s.PropTypes.number,
            contentWindow: s.PropTypes.any,
            onSortStart: s.PropTypes.func,
            onSortMove: s.PropTypes.func,
            onSortEnd: s.PropTypes.func,
            shouldCancelStart: s.PropTypes.func,
            pressDelay: s.PropTypes.number,
            useDragHandle: s.PropTypes.bool,
            useWindowAsScrollContainer: s.PropTypes.bool,
            hideSortableGhost: s.PropTypes.bool,
            lockToContainerEdges: s.PropTypes.bool,
            lockOffset: s.PropTypes.oneOfType([
              s.PropTypes.number,
              s.PropTypes.string,
              s.PropTypes.arrayOf(
                s.PropTypes.oneOfType([s.PropTypes.number, s.PropTypes.string])
              ),
            ]),
            getContainer: s.PropTypes.func,
          }),
          (t.childContextTypes = { manager: s.PropTypes.object.isRequired }),
          n
        );
      };
      var s = n(366757),
        r = p(s),
        l = p(n(973935)),
        c = p(n(171349)),
        d = n(35315),
        u = p(n(441143));
      function p(e) {
        return e && e.__esModule ? e : { default: e };
      }
      function m(e) {
        if (Array.isArray(e)) {
          for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
          return n;
        }
        return Array.from(e);
      }
      function h(e, t) {
        if (!(e instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      function v(e, t) {
        if (!e)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
      }
      function f(e, t) {
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function, not " +
              typeof t
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
          t &&
            (Object.setPrototypeOf
              ? Object.setPrototypeOf(e, t)
              : (e.__proto__ = t));
      }
    },
    287082: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a =
          Object.assign ||
          function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var a in n)
                Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
            }
            return e;
          },
        i = (function () {
          function e(e, t) {
            for (var n = 0; n < t.length; n++) {
              var a = t[n];
              (a.enumerable = a.enumerable || !1),
                (a.configurable = !0),
                "value" in a && (a.writable = !0),
                Object.defineProperty(e, a.key, a);
            }
          }
          return function (t, n, a) {
            return n && e(t.prototype, n), a && e(t, a), t;
          };
        })();
      t.default = function (e) {
        var t,
          n,
          c =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : { withRef: !1 };
        return (
          (n = t =
            (function (t) {
              function n() {
                return (
                  d(this, n),
                  u(
                    this,
                    (n.__proto__ || Object.getPrototypeOf(n)).apply(
                      this,
                      arguments
                    )
                  )
                );
              }
              return (
                p(n, t),
                i(n, [
                  {
                    key: "componentDidMount",
                    value: function () {
                      var e = this.props,
                        t = e.collection,
                        n = e.disabled,
                        a = e.index;
                      n || this.setDraggable(t, a);
                    },
                  },
                  {
                    key: "componentWillReceiveProps",
                    value: function (e) {
                      if (
                        (this.props.index !== e.index &&
                          this.node &&
                          (this.node.sortableInfo.index = e.index),
                        this.props.disabled !== e.disabled)
                      ) {
                        var t = e.collection,
                          n = e.disabled,
                          a = e.index;
                        n ? this.removeDraggable(t) : this.setDraggable(t, a);
                      } else
                        this.props.collection !== e.collection &&
                          (this.removeDraggable(this.props.collection),
                          this.setDraggable(e.collection, e.index));
                    },
                  },
                  {
                    key: "componentWillUnmount",
                    value: function () {
                      var e = this.props,
                        t = e.collection;
                      e.disabled || this.removeDraggable(t);
                    },
                  },
                  {
                    key: "setDraggable",
                    value: function (e, t) {
                      var n = (this.node = (0, r.findDOMNode)(this));
                      (n.sortableInfo = { index: t, collection: e }),
                        (this.ref = { node: n }),
                        this.context.manager.add(e, this.ref);
                    },
                  },
                  {
                    key: "removeDraggable",
                    value: function (e) {
                      this.context.manager.remove(e, this.ref);
                    },
                  },
                  {
                    key: "getWrappedInstance",
                    value: function () {
                      return (
                        (0, l.default)(
                          c.withRef,
                          "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableElement() call"
                        ),
                        this.refs.wrappedInstance
                      );
                    },
                  },
                  {
                    key: "render",
                    value: function () {
                      var t = c.withRef ? "wrappedInstance" : null;
                      return s.default.createElement(
                        e,
                        a({ ref: t }, this.props)
                      );
                    },
                  },
                ]),
                n
              );
            })(o.Component)),
          (t.displayName = e.displayName
            ? "SortableElement(" + e.displayName + ")"
            : "SortableElement"),
          (t.WrappedComponent = e),
          (t.contextTypes = { manager: o.PropTypes.object.isRequired }),
          (t.propTypes = {
            index: o.PropTypes.number.isRequired,
            collection: o.PropTypes.oneOfType([
              o.PropTypes.number,
              o.PropTypes.string,
            ]),
            disabled: o.PropTypes.bool,
          }),
          (t.defaultProps = { collection: 0 }),
          n
        );
      };
      var o = n(366757),
        s = c(o),
        r = n(973935),
        l = c(n(441143));
      function c(e) {
        return e && e.__esModule ? e : { default: e };
      }
      function d(e, t) {
        if (!(e instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      function u(e, t) {
        if (!e)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
      }
      function p(e, t) {
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function, not " +
              typeof t
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
          t &&
            (Object.setPrototypeOf
              ? Object.setPrototypeOf(e, t)
              : (e.__proto__ = t));
      }
    },
    114610: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a =
          Object.assign ||
          function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var a in n)
                Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
            }
            return e;
          },
        i = (function () {
          function e(e, t) {
            for (var n = 0; n < t.length; n++) {
              var a = t[n];
              (a.enumerable = a.enumerable || !1),
                (a.configurable = !0),
                "value" in a && (a.writable = !0),
                Object.defineProperty(e, a.key, a);
            }
          }
          return function (t, n, a) {
            return n && e(t.prototype, n), a && e(t, a), t;
          };
        })();
      t.default = function (e) {
        var t,
          n,
          c =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : { withRef: !1 };
        return (
          (n = t =
            (function (t) {
              function n() {
                return (
                  d(this, n),
                  u(
                    this,
                    (n.__proto__ || Object.getPrototypeOf(n)).apply(
                      this,
                      arguments
                    )
                  )
                );
              }
              return (
                p(n, t),
                i(n, [
                  {
                    key: "componentDidMount",
                    value: function () {
                      (0, r.findDOMNode)(this).sortableHandle = !0;
                    },
                  },
                  {
                    key: "getWrappedInstance",
                    value: function () {
                      return (
                        (0, l.default)(
                          c.withRef,
                          "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableHandle() call"
                        ),
                        this.refs.wrappedInstance
                      );
                    },
                  },
                  {
                    key: "render",
                    value: function () {
                      var t = c.withRef ? "wrappedInstance" : null;
                      return s.default.createElement(
                        e,
                        a({ ref: t }, this.props)
                      );
                    },
                  },
                ]),
                n
              );
            })(o.Component)),
          (t.displayName = e.displayName
            ? "SortableHandle(" + e.displayName + ")"
            : "SortableHandle"),
          (t.WrappedComponent = e),
          n
        );
      };
      var o = n(366757),
        s = c(o),
        r = n(973935),
        l = c(n(441143));
      function c(e) {
        return e && e.__esModule ? e : { default: e };
      }
      function d(e, t) {
        if (!(e instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      function u(e, t) {
        if (!e)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
      }
      function p(e, t) {
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function, not " +
              typeof t
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
          t &&
            (Object.setPrototypeOf
              ? Object.setPrototypeOf(e, t)
              : (e.__proto__ = t));
      }
    },
    15091: function (e, t, n) {
      "use strict";
      t.Rp = t.W6 = t.W8 = t.JN = void 0;
      var a = n(35315);
      Object.defineProperty(t, "Rp", {
        enumerable: !0,
        get: function () {
          return a.arrayMove;
        },
      });
      var i = r(n(846538)),
        o = r(n(287082)),
        s = r(n(114610));
      function r(e) {
        return e && e.__esModule ? e : { default: e };
      }
      (t.JN = i.default), (t.W8 = o.default), (t.W6 = s.default);
    },
    35315: function (e, t) {
      "use strict";
      function n(e) {
        return "px" === e.substr(-2) ? parseFloat(e) : 0;
      }
      Object.defineProperty(t, "__esModule", { value: !0 }),
        (t.arrayMove = function (e, t, n) {
          var a = e.slice(0);
          if (n >= a.length)
            for (var i = n - a.length; 1 + i--; ) a.push(void 0);
          return a.splice(n, 0, a.splice(t, 1)[0]), a;
        }),
        (t.closest = function (e, t) {
          for (; e; ) {
            if (t(e)) return e;
            e = e.parentNode;
          }
        }),
        (t.limit = function (e, t, n) {
          return n < e ? e : n > t ? t : n;
        }),
        (t.getElementMargin = function (e) {
          var t = window.getComputedStyle(e);
          return {
            top: n(t.marginTop),
            right: n(t.marginRight),
            bottom: n(t.marginBottom),
            left: n(t.marginLeft),
          };
        }),
        (t.events = {
          start: ["touchstart", "mousedown"],
          move: ["touchmove", "mousemove"],
          end: ["touchend", "touchcancel", "mouseup"],
        }),
        (t.vendorPrefix = (function () {
          if ("undefined" == typeof window || "undefined" == typeof document)
            return "";
          var e = window.getComputedStyle(document.documentElement, ""),
            t = (Array.prototype.slice
              .call(e)
              .join("")
              .match(/-(moz|webkit|ms)-/) ||
              ("" === e.OLink && ["", "o"]))[1];
          return "ms" === t
            ? "ms"
            : t && t.length
            ? t[0].toUpperCase() + t.substr(1)
            : "";
        })());
    },
  },
]);
