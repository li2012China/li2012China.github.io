/*! For license information please see 8477.c6bf407abafe83f2584e-site-bundle.js.LICENSE.txt */
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [8477],
  {
    709841: function (e, t, a) {
      "use strict";
      a.r(t),
        a.d(t, {
          default: function () {
            return y;
          },
        });
      var n,
        o,
        i = a(859056),
        r = a(863056),
        l = (a(241539), a(788674), a(974916), a(115306), a(977766)),
        s = a.n(l),
        c = a(25843),
        d = a.n(c),
        u = a(366757),
        f = a(881701),
        p = a(965239),
        m = a(468420),
        h = a(327344),
        g = (function () {
          function e(t) {
            (0, m.Z)(this, e), (this.conf = t);
          }
          return (
            (0, h.Z)(e, [
              {
                key: "fbLoginPopup",
                value: function (e) {
                  var t;
                  if (window.FB)
                    return null === (t = window.FB) || void 0 === t
                      ? void 0
                      : t.login(
                          function (t) {
                            t.authResponse
                              ? e.success && e.success(t)
                              : e.fail && e.fail(t);
                          },
                          { scope: this.conf.FACEBOOK_PERMS }
                        );
                },
              },
              {
                key: "loadFacebook",
                value: function () {
                  var e, t;
                  if (window.FB)
                    return null === (e = window.FB) || void 0 === e
                      ? void 0
                      : e.init({
                          appId: this.conf.FACEBOOK_APP_ID,
                          channelUrl: s()(
                            (t = "".concat(window.location.protocol, "//"))
                          ).call(t, window.location.host, "/fb/channel.html"),
                          status: !1,
                          cookie: !0,
                          xfbml: !0,
                          oauth: !0,
                          version: "v3.2",
                        });
                },
              },
            ]),
            e
          );
        })(),
        v = a(353147),
        _ = u.useState,
        b = u.useEffect,
        w = u.useCallback,
        E = function (e) {
          var t = e.errorText;
          return t
            ? (0, r.Z)(
                "div",
                { className: "pop-toast" },
                void 0,
                n || (n = (0, r.Z)("i", {})),
                (0, r.Z)("p", {}, void 0, (0, r.Z)("strong", {}, void 0, t))
              )
            : null;
        },
        y = function (e) {
          var t,
            a = e.layoutClass,
            n = e.domId,
            l = _(null),
            c = (0, i.Z)(l, 2),
            u = c[0],
            m = c[1],
            h = _(!1),
            y = (0, i.Z)(h, 2),
            k = y[0],
            C = y[1],
            I = _(!1),
            x = (0, i.Z)(I, 2),
            A = x[0],
            S = x[1],
            O = _(""),
            T = (0, i.Z)(O, 2),
            N = T[0],
            L = T[1],
            P = _(""),
            D = (0, i.Z)(P, 2),
            G = D[0],
            M = D[1],
            R = _(""),
            Z = (0, i.Z)(R, 2),
            F = Z[0],
            B = Z[1],
            H = _(""),
            U = (0, i.Z)(H, 2),
            $ = U[0],
            z = U[1];
          b(function () {
            var e = document.createElement("script");
            if (
              ((e.type = "text/javascript"),
              (e.src = "https://connect.facebook.com/en_US/all.js"),
              (e.onload = function () {
                C(!0);
              }),
              document.head.appendChild(e),
              $S.conf)
            ) {
              var t = new g($S.conf);
              m(t);
            }
          }, []),
            b(
              function () {
                if (k && u)
                  try {
                    u.loadFacebook(), S(!0);
                  } catch (e) {
                    console.log(e);
                  }
              },
              [k, u]
            );
          var j = w(
              function () {
                u && A && u.fbLoginPopup();
              },
              [u, A]
            ),
            K = w(
              function (e) {
                var t = e.target.value;
                L(t);
              },
              [N]
            ),
            Y = w(
              function (e) {
                var t = e.target.value;
                M(t);
              },
              [G]
            ),
            W = w(
              function (e) {
                var t = e.target.value;
                B(t);
              },
              [F]
            ),
            Q = s()(
              (t = "".concat(
                (0, f.css)(
                  "width:100%;display:flex;justify-content:center;.new-user-form .form-wrapper{display:inline-block;padding:12px;padding-bottom:5px;border-radius:6px;position:relative;}&.form-dark_center,&.form-dark_left,&.form-dark_right,&.form-small_dark_center,&.form-small_dark_left,&.form-small_dark_right{.new-user-form .form-wrapper{margin-bottom:10px;background:#0000004d;}}&.form-dark_left,&.form-light_left,&.form-small_dark_left,&.form-small_light_left{justify-content:flex-start;}&.form-dark_right,&.form-light_right,&.form-small_dark_right,&.form-small_light_right{justify-content:flex-end;}.new-user-form .col{display:inline-block;zoom:1;vertical-align:middle;width:200px;margin:0 5px 7px 0;position:relative;}&.form-small_dark_center,&.form-small_dark_left,&.form-small_dark_right,&.form-small_light_center,&.form-small_light_left,&.form-small_light_right{.form-wrapper{width:calc(100% - 24px);}.new-user-form{width:324px;.col{margin-bottom:10px;}.row.email-signup{display:flex;flex-direction:column;.col,.col.short{width:auto;margin-right:0;}}.row.terms-and-fb{display:flex;flex-direction:column;.terms{margin-top:10px;}}}}&.form-small_dark_left,&.form-small_light_left{.row.terms-and-fb{text-align:left;}}&.form-small_dark_right,&.form-small_light_right{.row.terms-and-fb{text-align:right;}}.new-user-form .row{margin-bottom:0px;}@media only screen and (max-width:550px){justify-content:center !important;.form-wrapper{width:calc(100% - 24px);}.new-user-form{width:324px;.col{margin-bottom:10px;}.row.email-signup{display:flex;flex-direction:column;.col,.col.short{width:auto;margin-right:0;}}.row.terms-and-fb{display:flex;flex-direction:column;.terms{margin-top:10px;}}}}&.form-small_light_center,&.form-small_light_left,&.form-small_light_right,&.form-light_center,&.form-light_left,&.form-light_right{.form-wrapper{width:100%;padding:0;}}.btn{background:#8aac18;border:1px solid #769214;border-radius:4px;font-family:'brandon-grotesque','brandon',martel-sans,sans-serif;text-transform:uppercase;font-weight:700;font-size:18px;text-shadow:0 1px rgb(0 0 0 / 20%);color:#fff;cursor:pointer;position:relative;padding:10px 20px;transition:all 0.15s;}.new-user-form .col .field input{border:0;border-radius:4px;font-size:18px;font-weight:600;color:#444;padding:11px 10px;width:90%;width:calc(100% - 20px);box-shadow:inset 0 1px 4px rgb(0 0 0 / 15%);outline:none;}.new-user-form .col.submit .submit.btn,.new-user-form .col.submit .submit.s-btn{outline:0;text-shadow:none;border-radius:4px;background-image:none;box-shadow:0 1px 1px rgb(0 0 0 / 20%);border-top-color:#fff6;background:#96bd13;white-space:normal;border:0;padding:10px 25px;}.new-user-form .col.submit .submit.btn:hover,.new-user-form .col.submit .submit.s-btn:hover{background:#a5d015;border-color:#8fb312;}.new-user-form .facebook-login-container a.btn{display:inline-block;zoom:1;vertical-align:middle;font-size:12px;background:#688bd4;border:0;padding:6px 12px;margin-left:5px;text-shadow:0 1px rgb(0 0 0 / 20%);position:relative;white-space:nowrap;color:#fff;}.new-user-form .facebook-login-container a.btn:hover{background:#6f94e2;}.new-user-form .col.short{width:140px;}.new-user-form .col.submit{width:auto;position:relative;}.new-user-form .terms,.new-user-form .or{font-size:12px;line-height:1.25;opacity:0.5;}.terms-and-fb{display:block;.terms{float:left;}.facebook-login-container{float:right;}}.pop-toast{width:fit-content;position:fixed;padding:10px 15px;text-align:center;top:95px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.5);border-radius:20px;z-index:10000;i{display:inline-block;width:16px;height:16px;vertical-align:middle;background:url(\"data:image/svg+xml,%3Csvg class='icon' width='200' height='200' viewBox='0 0 1024 1024' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill='%23f3f3f3' d='M873.439 960.4H152.591c-48.34 0-87.174-19.097-106.568-52.405-19.399-33.308-17.039-76.816 6.499-119.331L416.23 131.772C439.905 88.947 475.11 64.4 512.775 64.4c37.67 0 72.84 24.517 96.581 67.304l364.09 657.027c23.532 42.516 25.966 85.992 6.531 119.296-19.363 33.307-58.229 52.373-106.538 52.373zM512.812 133.356c-11.976 0-25.693 11.964-36.813 31.998L112.291 822.313c-11.396 20.618-14.063 39.138-7.256 50.821 6.813 11.654 24.155 18.347 47.557 18.347H873.44c23.439 0 40.75-6.656 47.558-18.347 6.771-11.653 4.14-30.166-7.287-50.785L549.626 165.354c-11.088-20.034-24.875-31.998-36.814-31.998zm.205 515.978c-18.883 0-34.21-15.414-34.21-34.479v-310.31c0-19.033 15.327-34.48 34.21-34.48 18.886 0 34.213 15.447 34.213 34.48v310.309c-.001 19.066-15.328 34.48-34.213 34.48zm-.246 168.537c29.441 0 53.309-24.096 53.309-53.819s-23.867-53.819-53.309-53.819-53.308 24.096-53.308 53.819 23.867 53.819 53.308 53.819z'/%3E%3C/svg%3E\") center center / 100% no-repeat;}p{display:inline-block;font-size:14px;line-height:14px;color:rgb(240,240,240);vertical-align:middle;margin:0px 0px 0px 10px;}"
                ),
                " form-"
              ))
            ).call(t, a),
            V = w(
              function () {
                return d()(N).call(N) && d()(G).call(G)
                  ? !!d()(F).call(F) || (z(v("password can't be empty")), !1)
                  : (z(v("Email and firstname required.")), !1);
              },
              [$, N, G, F]
            ),
            q = w(
              function () {
                if (V()) {
                  z("");
                  var e = new FormData();
                  e.append("utf8", "✓"),
                    e.append("user[profile_attributes][first_name]", N),
                    e.append("user[email]", G),
                    e.append("user[password]", F),
                    e.append("commit", "Get Started. It's free!"),
                    fetch("/s/users", { method: "POST", body: e })
                      .then(p.parseJSON)
                      .then(function (e) {
                        if ("error" === e.status) {
                          var t,
                            a = (
                              (null === (t = e.message.i18n) || void 0 === t
                                ? void 0
                                : t.message) || ""
                            ).replace(/(<strong>|<\/strong>)/g, "");
                          z(a);
                        } else {
                          var n;
                          location.href = s()(
                            (n = "".concat(location.origin))
                          ).call(n, e.to || "/s");
                        }
                      })
                      .catch(function (e) {
                        console.log(e);
                      });
                }
              },
              [$, N, G, F]
            );
          return (0, r.Z)(
            "div",
            { className: Q, id: "signup-form-".concat(n) },
            void 0,
            (0, r.Z)(
              "div",
              { className: "simple_form form new-user-form s-font-body" },
              void 0,
              (0, r.Z)(
                "div",
                { className: "form-wrapper" },
                void 0,
                (0, r.Z)(
                  "div",
                  { className: "row email-signup" },
                  void 0,
                  (0, r.Z)(
                    "div",
                    { className: "col short" },
                    void 0,
                    (0, r.Z)(
                      "div",
                      { className: "field" },
                      void 0,
                      (0, r.Z)("input", {
                        autoComplete: "off",
                        placeholder: v("First Name"),
                        value: N,
                        onChange: K,
                        type: "text",
                        name: "user[profile_attributes][first_name]",
                        id: "user_profile_attributes_first_name",
                      })
                    )
                  ),
                  (0, r.Z)(
                    "div",
                    { className: "col" },
                    void 0,
                    (0, r.Z)(
                      "div",
                      { className: "field" },
                      void 0,
                      (0, r.Z)("input", {
                        autoComplete: "off",
                        placeholder: v("Email"),
                        value: G,
                        onChange: Y,
                        type: "text",
                        name: "user[email]",
                        id: "user_email",
                      })
                    )
                  ),
                  (0, r.Z)(
                    "div",
                    { className: "col" },
                    void 0,
                    (0, r.Z)(
                      "div",
                      { className: "field" },
                      void 0,
                      (0, r.Z)("input", {
                        autoComplete: "off",
                        value: F,
                        onChange: W,
                        placeholder: v("Create Password"),
                        type: "password",
                        name: "user[password]",
                        id: "user_password",
                      })
                    )
                  ),
                  (0, r.Z)(
                    "div",
                    { className: "col short submit" },
                    void 0,
                    (0, r.Z)(
                      "div",
                      { className: "submit btn sign-up-button", onClick: q },
                      void 0,
                      v("Get Started. It's free!")
                    )
                  )
                )
              ),
              (0, r.Z)(
                "div",
                { className: "row terms-and-fb" },
                void 0,
                (0, r.Z)(
                  "div",
                  { className: "facebook-login-container" },
                  void 0,
                  (0, r.Z)("span", { className: "or" }, void 0, v("OR")),
                  (0, r.Z)(
                    "a",
                    {
                      className: "facebook-login tiny fb-blue btn",
                      href: "javascript:void(0);",
                      onClick: j,
                    },
                    void 0,
                    v("Sign up with Facebook")
                  ),
                  o || (o = (0, r.Z)("br", {}))
                ),
                (0, r.Z)(
                  "div",
                  { className: "terms" },
                  void 0,
                  v(
                    "By continuing, you agree to Strikingly's %{var1} and %{var2}.",
                    {
                      var1: (0, r.Z)(
                        "a",
                        {
                          href: "http://support.strikingly.com/hc/en-us/articles/214364828",
                          target: "_blank",
                        },
                        void 0,
                        v("Landing|Terms of Service")
                      ),
                      var2: (0, r.Z)(
                        "a",
                        {
                          href: "http://support.strikingly.com/hc/en-us/articles/214364818",
                          target: "_blank",
                        },
                        void 0,
                        v("Landing|Privacy Policy")
                      ),
                    }
                  )
                )
              ),
              (0, r.Z)(E, { errorText: $ })
            )
          );
        };
    },
    441568: function (e, t, a) {
      "use strict";
      var n = a(353147),
        o = a(366757);
      a(496486),
        (e.exports = function () {
          return o.createElement(
            "div",
            { className: "s-component s-html-component" },
            this.isEditMode()
              ? o.createElement(
                  "div",
                  { className: "s-component-editor-wrapper", key: "61" },
                  this.isAdminMode()
                    ? o.createElement(
                        "div",
                        { className: "admin-only clearfix", key: "132" },
                        o.createElement(
                          "div",
                          {
                            className: "fa fa-refresh",
                            style: { cursor: "pointer" },
                            onClick: this._recreateComponent,
                          },
                          o.createElement(
                            "span",
                            {},
                            "ID: ",
                            this.dtProps.id,
                            " -"
                          ),
                          o.createElement(
                            "span",
                            {},
                            "Admin: recreate component"
                          )
                        )
                      )
                    : null,
                  o.createElement(
                    "div",
                    {
                      className: "s-component-overlay",
                      onClick: this._onClickEditor,
                    },
                    o.createElement(
                      "div",
                      { className: "center" },
                      o.createElement("span", {}, n("Edit"))
                    )
                  ),
                  this._hasContent() && this.state && this.state.showIframe
                    ? o.createElement(
                        "div",
                        { className: "s-component-content", key: "572" },
                        o.createElement("iframe", {
                          src:
                            "/s/html_editor/" +
                            this.dtProps.id +
                            "?q=" +
                            this._iframeSrcQ(),
                          width: "100%",
                          style: { border: "none" },
                        })
                      )
                    : null,
                  this._hasContent()
                    ? null
                    : o.createElement(
                        "div",
                        { className: "s-component-content", key: "823" },
                        o.createElement(
                          "div",
                          { className: "s-app-store-placeholder" },
                          o.createElement(
                            "p",
                            { className: "descr" },
                            n("Click to explore the App Store")
                          ),
                          o.createElement(
                            "div",
                            { className: "placeholder-background" },
                            o.createElement("i", {
                              className: "bg-icon fa fa-code",
                            }),
                            o.createElement("i", {
                              className: "bg-icon fa fa-headphones",
                            }),
                            o.createElement("i", {
                              className: "bg-icon fa fa-shopping-cart",
                            }),
                            o.createElement("i", {
                              className: "bg-icon fa fa-bar-chart-o",
                            }),
                            o.createElement("i", {
                              className: "bg-icon fa fa-cutlery",
                            }),
                            o.createElement("i", {
                              className: "bg-icon fa fa-group",
                            }),
                            o.createElement("i", {
                              className: "bg-icon fa fa-map-marker",
                            }),
                            o.createElement("i", {
                              className: "bg-icon fa fa-camera",
                            })
                          )
                        )
                      )
                )
              : null,
            this.isEditMode()
              ? null
              : o.createElement(
                  "div",
                  { className: "s-component-content-wrapper", key: "1492" },
                  this._isSpecialComponent()
                    ? o.createElement(
                        "div",
                        { className: "s-component-content", key: "1565" },
                        "\n      ",
                        this._renderSpecialComponent(),
                        "\n    "
                      )
                    : null,
                  !this._isSpecialComponent() && this._renderAsIframe()
                    ? o.createElement(
                        "div",
                        { className: "s-component-content", key: "1694" },
                        this._isOldEditorPreview()
                          ? null
                          : o.createElement("iframe", {
                              src:
                                "/show_iframe_component/" +
                                this.dtProps.id +
                                this._getIframeParams(),
                              width: "100%",
                              style: { border: "none" },
                              key: "1825",
                            }),
                        this._isOldEditorPreview()
                          ? o.createElement("iframe", {
                              src:
                                this._getPublicUrl() +
                                "/show_iframe_component/" +
                                this.dtProps.id +
                                this._getIframeParams(),
                              width: "100%",
                              style: { border: "none" },
                              key: "1996",
                            })
                          : null
                      )
                    : null,
                  this._isSpecialComponent() || this._renderAsIframe()
                    ? null
                    : o.createElement(
                        "div",
                        {
                          className: "s-component-content s-font-body",
                          key: "2198",
                        },
                        o.createElement("div", { ref: "htmlInject" })
                      )
                )
          );
        });
    },
    878477: function (e, t, a) {
      "use strict";
      var n = a(353147),
        o = a(663978),
        i = a(60530)(a(60530));
      o(t, "__esModule", { value: !0 });
      var r = a(418777),
        l = (0, i.default)(r),
        s = a(812077),
        c = (0, i.default)(s);
      a(974916), a(864765), a(804723), a(115306);
      var d = a(703649),
        u = (0, i.default)(d),
        f = a(933032),
        p = (0, i.default)(f),
        m = a(729828),
        h = (0, i.default)(m),
        g = a(678580),
        v = (0, i.default)(g),
        _ = a(694473),
        b = (0, i.default)(_),
        w = a(54103),
        E = (0, i.default)(w),
        y = a(51942),
        k = (0, i.default)(y),
        C = a(981643),
        I = (0, i.default)(C),
        x = a(366757),
        A = ((0, i.default)(x), a(45697)),
        S = (0, i.default)(A),
        O = a(183123),
        T = (0, i.default)(O),
        N = a(709841),
        L = (0, i.default)(N);
      function P(e, t, a) {
        if (e.length > 0) {
          var n = !1,
            o = function () {
              n
                ? console.error("done function called after timeout")
                : (clearTimeout(i),
                  (n = !0),
                  P((0, u.default)(e).call(e, 1), t, a));
            },
            i = (0, p.default)(o, t);
          a(e[0], o);
        }
      }
      var D = a(973935),
        G = a(496486),
        M = a(223336),
        R = a(399069),
        Z = (a(234584), a(141655)),
        F = (a(708285), a(230139)),
        B = a(315321),
        H = (a(904614), a(743050)),
        U = a(443198),
        $ = a(497640),
        z = a(441568),
        j = {
          data: {
            id: S.default.oneOfType([S.default.string, S.default.number]),
            value: B.html,
            render_as_iframe: S.default.bool,
            selected_app_name: S.default.string,
            app_list: S.default.string,
            binding: S.default.object,
          },
        },
        K = R.createPageComponent({
          displayName: "HtmlComponent",
          mixins: [F("editor")],
          bobcatPropTypes: j,
          getBobcatDefaultProps: function () {
            return { data: { render_as_iframe: !1, app_list: "{}" } };
          },
          componentWillMount: function () {
            this.initMeta({ iframeSrcQ: 0, canceled: !1 });
          },
          componentDidMount: function () {
            var e = this;
            H.startTimer(),
              this._injectHtml(),
              this._resizeIFrame(),
              this._isTypeForm() &&
                $().then(function (t) {
                  var a = (t || {}).Fancybox;
                  e._initTypeForm(a);
                });
          },
          componentDidUpdate: function (e) {},
          componentWillUnmount: function () {
            this.props.isBlog &&
              window.Ecwid &&
              (window.Ecwid.destroy(), (window.Ecwid = null));
          },
          _isPreviewMode: function () {
            return !1;
          },
          _isOldEditorPreview: function () {
            return T.default.getIsPreview();
          },
          _isSpecialComponent: function () {
            var e;
            return (0, h.default)((e = this.dtProps.value)).call(
              e,
              "strikingly_custom"
            );
          },
          _getIframeParams: function () {
            var e,
              t,
              a,
              n =
                (null === (e = window) || void 0 === e ? void 0 : e.location) ||
                {},
              o = n.search,
              i = void 0 === o ? "" : o,
              r = n.href,
              l = void 0 === r ? "" : r;
            return (0, v.default)(i).call(i, "ho_review=true")
              ? "?source=ho_review"
              : (0, v.default)(l).call(l, "/preview?") ||
                (0, v.default)(l).call(l, "preview=true")
              ? "?source=site_preview"
              : !0 ===
                  (null === (t = $S) || void 0 === t ? void 0 : t.live_site) ||
                !0 === (null === (a = $S) || void 0 === a ? void 0 : a.liveBlog)
              ? "?source=live_site"
              : "";
          },
          _renderSpecialComponent: function () {
            var e = this.dtProps.value.match(/(.+)\((.+)\)/);
            if (!e) return null;
            var t = (0, l.default)(e, 3),
              a = (t[0], t[1]),
              n = t[2];
            if ("strikingly_custom_landing_signup" === a) {
              var o = {};
              try {
                o = JSON.parse(n);
              } catch (e) {
                console.error(e);
              }
              return (0, c.default)(L.default, {
                layoutClass: o.layout,
                domId: o.id,
              });
            }
            return null;
          },
          _initTypeForm: function (e) {
            var t,
              a = (0, b.default)((t = M(D.findDOMNode(this)))).call(
                t,
                ".type-form-popup"
              ),
              n = "button-component",
              o = (0, b.default)(a).call(a, ".type-form-button").eq(0);
            if (e) {
              var i = o.attr("data-iframe-content"),
                r = M(i).eq(0).attr("src");
              o.attr("href", r),
                o.attr("data-fancybox", "type-form-fancybox"),
                o.attr("data-type", "iframe"),
                (0, E.default)(e).call(e, ["data-fancybox=type-form-fancybox"]);
            }
            var l = (0, b.default)(a)
              .call(a, ".type-form-button")
              .css("background");
            (0, b.default)(a).call(a, ".type-form-button").removeClass(n),
              l ===
                (0, b.default)(a)
                  .call(a, ".type-form-button")
                  .css("background") && a.addClass("type-form-button-style"),
              (0, b.default)(a).call(a, ".type-form-button").addClass(n);
          },
          _applyTypeformScrollTopHack: function () {
            var e = M(window).scrollTop(),
              t = null;
            $B.TH.isMobile() ||
              ((t = function () {
                var t = M(window).scrollTop();
                Math.abs(t - e) > 200 ? M(window).scrollTop(e) : (e = t);
              }),
              M(window).on("scroll", t),
              (0, p.default)(function () {
                M(window).off("scroll", t);
              }, 15e3));
          },
          _isTypeForm: function () {
            return "TypeFormApp" === this.props.selected_app_name;
          },
          _hasId: function (e) {
            return "number" == typeof e;
          },
          _getId: function () {
            var e,
              t,
              a,
              o = this,
              i =
                null === (e = window.parent) ||
                void 0 === e ||
                null === (t = e.document) ||
                void 0 === t
                  ? void 0
                  : t.getElementById("blog-post-editor-iframe"),
              r =
                null === (a = M(i)) || void 0 === a ? void 0 : a.data("postId"),
              l = (0, k.default)({}, { blogPostId: r, component: {} });
            return (
              this._setCanceled(!1),
              Z["createComponent".concat(this.props.isBlog ? "InBlog" : "")]({
                data: l,
                success: function (e) {
                  return (
                    o.updateData({ id: e.data.component.id }),
                    window.edit_page.Event.publish(
                      "Blog.Post.HtmlComponent.Save"
                    ),
                    o.savePage()
                  );
                },
                error: function (e) {
                  return window.confirm(
                    n(
                      "Uh oh! There's been an error creating this HTML component. Try again?"
                    )
                  )
                    ? o._getId()
                    : o._setCanceled(!0);
                },
              })
            );
          },
          _resizeIFrame: function () {
            var e,
              t = (0, b.default)((e = M(D.findDOMNode(this)))).call(
                e,
                "iframe"
              );
            if (t.length) return H.resizeIFrames(t);
          },
          _injectHtml: function () {
            if (this.dtProps.render_as_iframe);
            else
              try {
                var e,
                  t = D.findDOMNode(this.refs.htmlInject);
                (t.innerHTML = this._rawHtml()),
                  P(
                    (0, b.default)((e = M(t))).call(e, "script"),
                    4e3,
                    function (e, t) {
                      if (
                        !e.src ||
                        !/^$|\/(?:java|ecma)script/i.test(e.type || "")
                      )
                        return (
                          M.globalEval(
                            e.textContent.replace(
                              /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
                              ""
                            )
                          ),
                          t()
                        );
                      M.getScript(e.src).done(t);
                    }
                  );
              } catch (e) {
                return (
                  U.log("Html section script error: ".concat(e)),
                  M(D.findDOMNode(this.refs.htmlInject)).append(
                    "Script error: ".concat(e)
                  )
                );
              }
          },
          _hasContent: function () {
            return this.dtProps.value.length > 0;
          },
          _renderAsIframe: function () {
            return this.dtProps.render_as_iframe;
          },
          _rawHtml: function () {
            return G.unescape(this.dtProps.value || "");
          },
          _onClickEditor: function () {
            return null;
          },
          _saveComponent: function (e) {},
          _iframeSrcQ: function () {
            return this.getMeta("iframeSrcQ");
          },
          _reloadIframe: function () {
            return this.updateMeta({
              iframeSrcQ: this.getMeta("iframeSrcQ") + 1,
            });
          },
          _recreateComponent: function () {
            if (
              window.confirm(
                "Recreating will delete any existing component! Make sure you understand what this does"
              )
            )
              return (
                this.updateData({ render_as_iframe: !1, app_list: "{}" }),
                this._getId()
              );
          },
          _showIframe: function () {},
          _getPublicUrl: function () {
            var e, t, a, n, o, i;
            return null !== (e = $S) &&
              void 0 !== e &&
              null !== (t = e.stores) &&
              void 0 !== t &&
              null !== (a = t.pageMeta) &&
              void 0 !== a &&
              a.public_url
              ? (null === (n = $S) ||
                void 0 === n ||
                null === (o = n.stores) ||
                void 0 === o ||
                null === (i = o.pageMeta) ||
                void 0 === i
                  ? void 0
                  : i.public_url
                ).replace(/^https?:/, "")
              : "";
          },
          render: function () {
            if (
              T.default.getIsPreview() &&
              "HtmlApp" === this.props.selected_app_name &&
              !this.props.isBlog
            ) {
              var e = (window.location || {}).search,
                t = void 0 === e ? "" : e;
              if (-1 !== (0, I.default)(t).call(t, "without_custom_code=true"))
                return null;
            }
            return this._getCanceled()
              ? (0, c.default)(
                  "div",
                  {
                    className: "s-common-status",
                    style: { cursor: "pointer" },
                    onClick: this._getId,
                  },
                  void 0,
                  n("Click here to create HTML component again.")
                )
              : this._hasId(this.props.id)
              ? z.apply(this)
              : null;
          },
        });
      (t.default = K), (e.exports = t.default);
    },
    708285: function (e, t, a) {
      "use strict";
      var n = a(663978),
        o = a(60530)(a(60530));
      n(t, "__esModule", { value: !0 });
      var i = a(726394),
        r = (0, o.default)(i),
        l = a(569198),
        s = (0, o.default)(l),
        c = a(359340),
        d = (0, o.default)(c),
        u = a(680523),
        f = (0, o.default)(u),
        p = a(921806),
        m = (0, o.default)(p),
        h = (function () {
          function e() {
            (0, r.default)(this, e), (this.baseUrl = "/s/components/");
          }
          return (
            (0, s.default)(e, [
              {
                key: "update",
                value: function (e, t, a) {
                  var n = { component: { value: (0, d.default)(t) } };
                  return (
                    t.isBlog && (n.blogPostId = t.blogPostId),
                    new m.default({
                      url: f.default.COMPONENTS.UPDATE(e),
                      type: "PUT",
                      data: n,
                      success: function (e) {
                        return console.info("ComponentDataUtils: success.", e);
                      },
                      complete: function () {
                        return "function" == typeof a ? a() : void 0;
                      },
                    }).run()
                  );
                },
              },
              {
                key: "destroy",
                value: function (e) {
                  return new m.default({
                    url: "/s/components/".concat(e),
                    type: "DELETE",
                  }).run();
                },
              },
            ]),
            e
          );
        })();
      (t.default = new h()), (e.exports = t.default);
    },
    743050: function (e, t, a) {
      "use strict";
      var n = a(663978),
        o = a(60530)(a(60530));
      n(t, "__esModule", { value: !0 });
      var i = a(694473),
        r = (0, o.default)(i),
        l = a(678580),
        s = (0, o.default)(l),
        c = a(931581),
        d = (0, o.default)(c),
        u = a(933032),
        f = (0, o.default)(u),
        p = a(394198),
        m = (0, o.default)(p),
        h = a(778914),
        g = (0, o.default)(h),
        v = a(223336),
        _ = (0, o.default)(v),
        b = a(496486),
        w = (0, o.default)(b),
        E = [],
        y = null,
        k = !1;
      function C(e, t) {
        var a = { lastHeight: e.height(), $el: e, callback: t };
        E.push(a);
      }
      function I(e, t, a) {
        var n = [];
        function o() {
          (0, r.default)(e).call(e, "iframe").length &&
            (0, r.default)(e)
              .call(e, "iframe")
              .each(function () {
                (0, s.default)(w.default).call(w.default, n, this) ||
                  (n.push(this), t && t((0, _.default)(this)));
              });
        }
        o();
        var i = (0, d.default)(o, 200);
        (0, f.default)(function () {
          clearInterval(i), a && a();
        }, 1e4);
      }
      function x(e) {
        var t = 0;
        return (
          e.children().each(function () {
            "none" === (0, _.default)(this).css("display") ||
              (0, s.default)(w.default).call(
                w.default,
                ["fixed", "absolute"],
                (0, _.default)(this).css("position")
              ) ||
              (t += (0, _.default)(this).outerHeight());
          }),
          t
        );
      }
      function A() {
        (0, g.default)(E).call(E, function (e) {
          var t = 0;
          try {
            var a, n;
            t = (0, r.default)((a = e.$el.contents())).call(a, "body").length
              ? x((0, r.default)((n = e.$el.contents())).call(n, "body"))
              : x(e.$el);
          } catch (a) {
            t = e.$el.height();
          }
          e.lastHeight !== t &&
            (e.callback && e.callback(t - e.lastHeight), (e.lastHeight = t));
        });
      }
      (t.default = {
        resizeIFrames: function e(t) {
          function a(e) {
            var t;
            try {
              var a;
              (0, r.default)((a = e.contents())).call(a, "body");
            } catch (e) {
              return;
            }
            var n = (0, r.default)((t = e.contents())).call(t, "body"),
              o = (0, m.default)(n.css("margin-top"), 10) || 0,
              i = (0, m.default)(n.css("margin-bottom"), 10) || 0,
              l = x(n) + o + i;
            l <= 50 ||
              (e.height(l),
              null !== window.edit_page &&
                window.edit_page.Event.publish("Iframe.Resized"));
          }
          function n(e) {
            if (e.attr("src")) {
              a(e), (0, _.default)(window).resize();
              try {
                C(e.contents(), function () {
                  a(e), (0, _.default)(window).resize();
                });
              } catch (e) {}
            }
          }
          t.each(function () {
            var t = (0, _.default)(this);
            if (t.attr("src")) {
              try {
                var o = t[0].contentWindow.innerHeight;
                o >= 50 && (t.height(o), n(t));
              } catch (e) {
                if (!_.default.browser.msie) return;
              }
              t[0].onload = function () {
                var o;
                try {
                  t.contents();
                } catch (e) {
                  return;
                }
                t.contents().length &&
                  (n(t),
                  I(
                    (0, r.default)((o = t.contents())).call(o, "html"),
                    function (t) {
                      n(t), e(t);
                    },
                    function () {
                      a(t);
                    }
                  ));
              };
            }
          });
        },
        detectHeightChange: C,
        detectIFrameCreated: I,
        startTimer: function () {
          k ||
            ((y = (0, d.default)(A, 200)),
            (0, f.default)(function () {
              0 === E.length && clearInterval(y);
            }, 6e4),
            (k = !0));
        },
        inIframe: function () {
          try {
            return window.self !== window.top;
          } catch (e) {
            return !0;
          }
        },
      }),
        (e.exports = t.default);
    },
    904614: function (e, t, a) {
      "use strict";
      var n = a(663978),
        o = a(60530)(a(60530));
      n(t, "__esModule", { value: !0 });
      var i = a(726394),
        r = (0, o.default)(i),
        l = a(569198),
        s = (0, o.default)(l),
        c = a(694473),
        d = (0, o.default)(c),
        u = a(223336),
        f = (0, o.default)(u),
        p = a(154920),
        m = (0, o.default)(p),
        h = a(607947),
        g = (0, o.default)(h),
        v = a(241093),
        _ = (0, o.default)(v),
        b = a(786483),
        w = (0, o.default)(b),
        E = a(234584),
        y = (0, o.default)(E),
        k = a(183123),
        C = (0, o.default)(k),
        I = {},
        x = {},
        A = (function () {
          function e(t, a, n) {
            var o,
              i = this;
            (0, r.default)(this, e),
              (this.originalData = t),
              (this.doneCallback = a),
              (this.cancelCallback = n),
              (this.eventCenter = w.default.Event),
              (this.$dialog = (0, f.default)(_.default.APP_STORE_DIALOG)),
              (this.iframe = (0, d.default)((o = this.$dialog)).call(
                o,
                "#app-store-iframe"
              )),
              this.iframe.attr("src") &&
                this.init(this.doneCallback, this.cancelCallback),
              this.iframe.on("load", function () {
                return i.init(i.doneCallback, i.cancelCallback);
              }),
              (this.iframeLoadedToken = this.eventCenter.subscribe(
                "AppStore.iframeLoaded",
                function () {
                  i.init(i.doneCallback, i.cancelCallback);
                }
              )),
              this.open();
          }
          return (
            (0, s.default)(e, [
              {
                key: "init",
                value: function (e, t) {
                  var a = this;
                  (this.doneCallback = e),
                    (this.cancelCallback = t),
                    (this.eventCenter = w.default.Event),
                    (this.saveAndCloseToken = this.eventCenter.subscribe(
                      "AppStore.saveAndClose",
                      function (e, t) {
                        return (
                          m.default.track("Save App - App Store - Editor v1", {
                            app_name: t.selected_app_name,
                          }),
                          a.doneCallback(t)
                        );
                      }
                    )),
                    (this.discardAndCloseToken = this.eventCenter.subscribe(
                      "AppStore.discardAndClose",
                      function (e, t) {
                        return a.cancelCallback();
                      }
                    )),
                    (this.clickAppItemToken = this.eventCenter.subscribe(
                      "AppStore.clickAppItem",
                      function (e, t) {
                        var a = y.default.canUseCustomCode(),
                          n = y.default.getIsProForSxlAndStrk();
                        if (C.default.getIsSxl() && "HtmlApp" === t && n && !a)
                          return y.default.getIsBlog()
                            ? x.openDomainCheckDialog()
                            : I.openDomainCheckDialog();
                      }
                    )),
                    this.eventCenter.publish(
                      "AppStore.dialogCreated",
                      this.originalData
                    );
                },
              },
              {
                key: "closeEvents",
                value: function () {
                  this.eventCenter.unsubscribe(this.saveAndCloseToken),
                    this.eventCenter.unsubscribe(this.discardAndCloseToken),
                    this.eventCenter.unsubscribe(this.clickAppItemToken),
                    this.eventCenter.unsubscribe(this.iframeLoadedToken),
                    this.eventCenter.publish("AppStore.dialogClosed");
                },
              },
              {
                key: "open",
                value: function () {
                  var e = this;
                  g.default.ui.openCloseModal(this.$dialog, {
                    closeCallback: function () {
                      e.closeEvents();
                    },
                  });
                },
              },
              {
                key: "close",
                value: function () {
                  g.default.ui.closeModal(this.$dialog), this.closeEvents();
                },
              },
            ]),
            e
          );
        })();
      (t.default = A), (e.exports = t.default);
    },
    241093: function (e, t, a) {
      "use strict";
      var n = a(663978),
        o = a(60530)(a(60530));
      n(t, "__esModule", { value: !0 });
      var i = a(977766),
        r = (0, o.default)(i),
        l = a(694473),
        s = (0, o.default)(l),
        c = a(666419),
        d = (0, o.default)(c),
        u = 1,
        f = {
          SLIDES: "ul.slides > li.slide",
          AI_MODE_SLIDES: "ul.slides > .section-item-wrapper > li.slide",
          PAGE_DATA_SCOPE: "page",
          EDITPAGE_DATA_SCOPE: "editpage",
          NAVIGATOR: "#strikingly-navigation-menu",
          FOOTER: "#strikingly-footer",
          FOOTER_LOGO_EDITOR: "#edit-logo-footer",
          EDITOR_OVERLAY: ".edit-overlay",
          EDITOR: ".editor",
          CONTENT: ".content",
          PAGE_SETTING_DIALOG: "#page-settings-dialog",
          NEW_PAGE_MESSAGE_DIALOG: "#new-page-message-dialog",
          NEW_SECTION_DIALOG: "#new-section-dialog",
          ASSET_LIB_DIALOG: "#asset-lib-dialog",
          FILE_LIB_DIALOG: "#file-lib-dialog",
          APP_STORE_DIALOG: "#app-store-dialog",
          DOMAIN_CHECK_DIALOG: "#domain-check-dialog",
          SERVICE_EDIT_DIALOG: "#service-edit-dialog",
          TRAFFIC_GUIDE_DIALOG: "#traffic-guide-dialog",
          PAYPAL_POPUP: ".strikingly-paypal-popup",
          RECURLY_POPUP: ".strikingly-recurly-popup-wrap",
          wechat_invite_popup: ".strikingly-wechat-invite-popup-wrap",
          SHARE_DIALOG: "#sharing-options-dialog",
          CATEGORY_DIALOG: "#category-dialog",
          PUBLISH_DIALOG: "#publish-dialog-new",
          UNPUBLISH_SITES_DIALOG: "#unpublish-sites-dialog",
          SAVED_DIALOG: "#saved-dialog",
          COLLABORATION_WARNING_DIALOG: "#collaboration-warning-dialog",
          LINKEDIN_THEME_CHANGE_DIALOG: "#linkedin-change-theme-dialog",
          LOCKED_WARNING_DIALOG: "#locked-warning-dialog",
          FEEDBACK_DIALOG: "#feedback-dialog",
          FEEDBACK_DIALOG_STEP1: ".step-1",
          FEEDBACK_DIALOG_STEP2: ".step-2",
          DIALOG_INACTIVE_CLASS: "inactive",
          FACEBOOK_ROOT: "#fb-root",
          FONT_SELECTOR: "select.fontselector",
          VARIATION_SELECTOR: "select.variationselector",
          PRESET_SELECTOR: "select.s-preset-selector-input",
          STRIKINGLY_LOGO: "#strikingly-footer-logo",
          SETTINGS: {
            FORM: ".strikingly-settings-form",
            DOMAIN_FORM: ".strikingly-custom-domain-form",
            PUBLISH: {
              FB_SHARE: "#publish-fb-button",
              PUBLIC_URL: "#publish-public-url",
            },
            COLLABORATORS_CONTAINER: "#collaborators-container",
          },
          SLIDE: function (e) {
            var t;
            return (0, r.default)(
              (t = "".concat(f.SLIDES, ":nth-child("))
            ).call(t, e, ")");
          },
          IMAGE_TITLE: function (e) {
            return (0, s.default)(e).call(e, "img").attr("title") || "";
          },
          IMAGE_DESCRIPTION: function (e) {
            return (
              (0, s.default)(e).call(e, "img").attr("data-description") || ""
            );
          },
          GALLERY: function (e) {
            for (
              var t = 0,
                a = (0, d.default)(
                  (0, s.default)((n = e.parent())).call(n, "a.item")
                );
              t < a.length;
              t++
            ) {
              var n,
                o = a[t];
              $(o).attr("data-fancybox", "gallery_".concat(u));
            }
            return $("a.item[data-fancybox=gallery_".concat(u++, "]"));
          },
          GALLERY_IMAGES: function (e) {
            return (0, s.default)(e).call(e, "a.item");
          },
          GALLERY_IMAGES_EDITOR: function (e) {
            return (0, s.default)(e).call(e, ".gallery-editor-image");
          },
        };
      (t.default = f), (e.exports = t.default);
    },
    497640: function (e, t, a) {
      e.exports = function () {
        return new Promise(function (e) {
          a.e(1626)
            .then(
              function (t) {
                e(a(791626));
              }.bind(null, a)
            )
            .catch(a.oe);
        });
      };
    },
  },
]);
