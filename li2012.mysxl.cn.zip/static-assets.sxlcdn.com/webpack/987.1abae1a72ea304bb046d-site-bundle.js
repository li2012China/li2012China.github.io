/*! For license information please see 987.1abae1a72ea304bb046d-site-bundle.js.LICENSE.txt */
"use strict";
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [987],
  {
    549556: function (t, e, n) {
      n.r(e),
        n.d(e, {
          default: function () {
            return o;
          },
        });
      var a = n(468420),
        i = n(844845),
        o = function t() {
          (0, a.Z)(this, t);
        };
      (0, i.Z)(o, "EDIT_CLICK_MESSAGE", "EDIT_CLICK_MESSAGE"),
        (0, i.Z)(o, "GALLERY_ADD_IMAGE_MESSAGE", "GALLERY_ADD_IMAGE_MESSAGE"),
        (0, i.Z)(o, "GALLERY_ITEM_CLICK_MESSAGE", "GALLERY_ITEM_CLICK_MESSAGE"),
        (0, i.Z)(
          o,
          "INITITAL_SECTION_LIST_MESSAGE",
          "INITITAL_SECTION_LIST_MESSAGE"
        ),
        (0, i.Z)(o, "AVAILABLE_SECTION_MESSAGE", "AVAILABLE_SECTION_MESSAGE"),
        (0, i.Z)(o, "SECTIONS_UPDATE_MESSAGE", "SECTIONS_UPDATE_MESSAGE"),
        (0, i.Z)(o, "BACKGROUND_CLICK_MESSAGE", "BACKGROUND_CLICK_MESSAGE"),
        (0, i.Z)(
          o,
          "CLICK_ADD_BACKGROUND_MESSAGE",
          "CLICK_ADD_BACKGROUND_MESSAGE"
        ),
        (0, i.Z)(o, "UPDATE_NAVIGATOR", "UPDATE_NAVIGATOR"),
        (0, i.Z)(o, "PAGE_LOADED", "PAGE_LOADED"),
        (0, i.Z)(o, "WEB_EDITOR_LOCK", "WEB_EDITOR_LOCK"),
        (0, i.Z)(o, "WEB_EDITOR_UNLOCK", "WEB_EDITOR_UNLOCK"),
        (0, i.Z)(o, "JUMP_TO_DASHBOARD", "JUMP_TO_DASHBOARD"),
        (0, i.Z)(o, "SAVE_STATUS_CHANGED", "SAVE_STATUS_CHANGED"),
        (0, i.Z)(o, "SESSION_TIMEOUT_REDIRECT", "SESSION_TIMEOUT_REDIRECT"),
        (0, i.Z)(o, "UPDATE_EDITOR_UNDO_REDO", "UPDATE_EDITOR_UNDO_REDO"),
        (0, i.Z)(o, "EXIT_EDITOR", "EXIT_EDITOR"),
        (0, i.Z)(o, "OPEN_SECTION_ITEM_MENU", "OPEN_SECTION_ITEM_MENU"),
        (0, i.Z)(
          o,
          "OPEN_EXTERNAL_LINK_ITEM_MENU",
          "OPEN_EXTERNAL_LINK_ITEM_MENU"
        ),
        (0, i.Z)(
          o,
          "OPEN_MULTIPLE_PAGE_EXTERNAL_LINK_ITEM_MENU",
          "OPEN_MULTIPLE_PAGE_EXTERNAL_LINK_ITEM_MENU"
        ),
        (0, i.Z)(o, "OPEN_PAGE_ITEM_MENU", "OPEN_PAGE_ITEM_MENU"),
        (0, i.Z)(o, "OPEN_DROPDOWN_ITEM_MENU", "OPEN_DROPDOWN_ITEM_MENU"),
        (0, i.Z)(
          o,
          "INITIALIZE_NATIVE_EDITOR_DATA",
          "INITIALIZE_NATIVE_EDITOR_DATA"
        ),
        (0, i.Z)(o, "SWITCH_PAGE_START", "SWITCH_PAGE_START"),
        (0, i.Z)(o, "SWITCH_PAGE_END", "SWITCH_PAGE_END"),
        (0, i.Z)(o, "OPEN_AUDIENCE_DETAIL", "OPEN_AUDIENCE_DETAIL"),
        (0, i.Z)(o, "BLOG_IS_SAVING", "BLOG_IS_SAVING"),
        (0, i.Z)(o, "BLOG_IS_SAVED", "BLOG_IS_SAVED"),
        (0, i.Z)(o, "BLOG_CLICK_PREVIEW", "BLOG_CLICK_PREVIEW"),
        (0, i.Z)(o, "BLOG_CLICK_SETTINGS", "BLOG_CLICK_SETTINGS"),
        (0, i.Z)(o, "BLOG_CLICK_PUBLISH", "BLOG_CLICK_PUBLISH"),
        (0, i.Z)(o, "BLOG_CLICK_EXIT", "BLOG_CLICK_EXIT"),
        (0, i.Z)(o, "BLOG_CLICK_CANCEL_SCHEDULE", "BLOG_CLICK_CANCEL_SCHEDULE"),
        (0, i.Z)(o, "BLOG_SAVE_CONTENT", "BLOG_SAVE_CONTENT"),
        (0, i.Z)(o, "BLOG_CLICK_EDITOR_SECTION", "BLOG_CLICK_EDITOR_SECTION");
    },
    861704: function (t, e, n) {
      n.r(e),
        n.d(e, {
          addMetaId: function () {
            return r;
          },
        });
      var a = n(175892),
        i = n(496486),
        o = n(468811),
        r = function (t) {
          return (
            (0, a.traverseObj)(
              t,
              function (t) {
                (i.isUndefined(t.id) || i.isNull(t.id)) &&
                  (t.id = "f_" + o.v4());
              },
              function (t) {
                return i.isString(t.type);
              }
            ),
            t
          );
        };
    },
    175892: function (t, e, n) {
      n.r(e),
        n.d(e, {
          traverseObj: function () {
            return d;
          },
          isArrayContain: function () {
            return c;
          },
        });
      var a = n(778914),
        i = n.n(a),
        o = n(277149),
        r = n.n(o),
        l = n(678580),
        s = n.n(l),
        u = n(496486),
        d = function t(e, n, a) {
          (a =
            a ||
            function (t) {
              return t == t;
            }),
            u.isArray(e)
              ? i()(u).call(u, e, function (e) {
                  t(e, n, a);
                })
              : u.isPlainObject(e) &&
                (a(e) && n(e),
                i()(u).call(u, e, function (e) {
                  t(e, n, a);
                }));
        },
        c = function () {
          var t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : [],
            e =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : [];
          return r()(u).call(u, t, function (t) {
            return !!s()(e).call(e, t);
          });
        };
    },
    31484: function (t, e, n) {
      n.d(e, {
        XO: function () {
          return l;
        },
        qX: function () {
          return s;
        },
        Yc: function () {
          return u;
        },
      });
      var a = n(977766),
        i = n.n(a),
        o = n(183123);
      function r(t, e) {
        var n;
        return i()(
          (n =
            "\n    & .s-nav-items-and-links .s-nav-li {\n      &.selected,\n      &:hover {\n        & > .s-nav-link-container > a {\n          outline: none;\n          ".concat(
              "color" === t &&
                "\n            color: ".concat(
                  e.highlightColor,
                  ";\n          "
                ),
              ";\n          "
            ))
        ).call(
          n,
          "underline" === t &&
            "\n            border-width: 0;\n            border-style: solid;\n            border-bottom-width: 1px;\n            border-bottom-color: inherit;\n          ",
          ";\n        }\n      }\n      &.s-navbar-dropdown {\n        &.s-nav-li,\n        &.s-nav-li.selected,\n        &.s-nav-li:hover {\n          & .s-nav-li > .s-nav-link-container > a {\n            /* don't apply the highlight logic from above inside dropdowns */\n            color: inherit;\n            border-bottom-color: transparent;\n          }\n        }\n      }\n    }\n  "
        );
      }
      function l(t) {
        var e, n;
        if (o.getNewNavHeaderDesign()) return "";
        var a = t.navSelectedItemDefaultHighlightBehaviors;
        return i()(
          (e = i()(
            (n = "&.s-navbar-desktop-normal {\n      ".concat(
              r(a.normal, t),
              ";\n    }\n    &.s-navbar-desktop-fixed:not(._alternative) {\n      "
            ))
          ).call(
            n,
            r(a.fixed, t),
            ";\n    }\n    &.s-navbar-desktop-fixed._alternative {\n      "
          ))
        ).call(e, r(a.fixedAlternative, t), ";\n    }\n  ");
      }
      function s(t) {
        return "& .s-nav-items-and-links .s-nav-li {\n      &.selected,\n      &:hover,\n      &.s-navbar-dropdown ul,\n      &:not(.s-navbar-dropdown):hover a {\n        & a:not(.s-navbar-dropdown) {\n          color: ".concat(
          t.navHighlightColor,
          "\n          opacity: 1;\n        }\n      }\n    }\n  "
        );
      }
      function u(t) {
        var e;
        return i()(
          (e =
            "\n    & .s-nav-items-and-links .s-nav-li:not(.login-container) {\n      &.selected,\n      &:hover,\n      &.s-navbar-dropdown:hover ul,\n      &.selected.s-navbar-dropdown ul {\n        background: ".concat(
              t.navHighlightColor,
              ";\n        & a:not(.s-navbar-dropdown), .s-nav-dropdown-item {\n          color: "
            ))
        ).call(e, t.navHighlightTextColor, ";\n        }\n      }\n    }\n  ");
      }
    },
    611384: function (t, e, n) {
      n.d(e, {
        Eg: function () {
          return f;
        },
        Gx: function () {
          return g;
        },
        es: function () {
          return p;
        },
        f3: function () {
          return h;
        },
        MP: function () {
          return v;
        },
        Re: function () {
          return m;
        },
        Q: function () {
          return b;
        },
        p9: function () {
          return C;
        },
        $i: function () {
          return y;
        },
        nf: function () {
          return S;
        },
      });
      var a = n(778914),
        i = n.n(a),
        o = n(703649),
        r = n.n(o),
        l = n(678580),
        s = n.n(l),
        u = n(223336),
        d = n(468811),
        c = n(143393);
      function f(t) {
        return (
          t.overlapsContent &&
          "\n      position: absolute;\n      left: 0;\n      z-index: 201;\n      width: 100%;\n      // Navigation can't cover the current page content, so need to navigate the actual height\n      &.s-navbar-desktop-normal {\n        .s-product-page-content &,\n        .s-booking-page-content &,\n        .s-item-page-content & {\n          position: static;\n        }\n      }\n    "
        );
      }
      function g(t) {
        return "\n    box-sizing: border-box;\n    & {\n      .s-nav-inner, .s-nav-inner-wrap {\n        margin: auto;\n      }\n    }\n  ";
      }
      function p() {
        return "\n    & .s-nav-items-and-links,\n    .s-nav-items-and-links > ul,\n    .s-nav-icons,\n    .s-nav-icons li,\n    .s-nav-btn,\n    .s-nav-btn > *:not(style) {\n      display: inline;\n    }\n  ";
      }
      function h(t) {
        var e,
          n,
          a,
          i,
          o = t.items,
          r = t.containerSizes,
          l = t.navOrientation,
          s = t.spaceForEllipsis,
          d = void 0 === s ? 0 : s,
          c = 0,
          f = 0,
          g = [],
          p = 0;
        function h() {
          g.push(p), (c = 0), (p = 0), f++;
        }
        function v() {
          return h(), { total: e, perContainer: g };
        }
        for (e = 0; e < o.length; e++) {
          c +=
            (void 0,
            (a = void 0),
            (i = void 0),
            (n = { horizontal: "outerWidth", vertical: "outerHeight" }[l]),
            (i = (a = u(o[e]))[n](!0)),
            a.is(":visible") || (i = 0),
            i);
          var m = f === r.length - 1,
            b = r[f] - (m ? d : 0);
          if (c >= b) {
            if (m) return v();
            e--, h();
          } else p++;
        }
        return v();
      }
      function v(t, e, n, a) {
        var o = n ? [t.fixed] : [t.normal, t.fixed];
        i()(o).call(o, function (t) {
          var n = t.container,
            i = t.ellipsis,
            o = t.navInner,
            l = t.uncollapsedNav,
            s = t.uncollapsedNavItems,
            d = t.collapsedNavItems;
          n.addClass("_maximize-nav-item-space"),
            s.removeClass("hidden"),
            d.removeClass("hidden"),
            i.addClass("hidden");
          var c = (a || l.width()) - 60;
          "centered" === e.topContentWidth &&
            (c = u(n).outerWidth() - (u(o).outerWidth() - u(l).outerWidth()));
          var f = h({
            items: s,
            containerSizes: [c],
            navOrientation: e.orientation,
            spaceForEllipsis: i.outerWidth(),
          });
          r()(s).call(s, f.total).addClass("hidden"),
            f.total < s.length &&
              (r()(d).call(d, 0, f.total).addClass("hidden"),
              i.removeClass("hidden")),
            n.removeClass("_maximize-nav-item-space");
        });
      }
      function m(t, e) {
        var n = e ? [t.fixed] : [t.normal, t.fixed];
        i()(n).call(n, function (t) {
          var e = t.ellipsis,
            n = t.uncollapsedNavItems,
            a = t.collapsedNavItems;
          n.removeClass("hidden"),
            a.removeClass("hidden"),
            e.addClass("hidden");
        });
      }
      function b(t, e, n) {
        if (n && "function" == typeof n.toJS) {
          var a = t;
          i()(e).call(e, function (t) {
            (function (t, e) {
              var n = t.get("components.".concat(e, ".url"));
              return !n || "/images/icons/transparent.png" === n;
            })(a, t) &&
              (a = (function (t, e, n) {
                if (!n || "function" != typeof n.toJS) return t;
                var a = c.fromJS(
                  _.assign({}, null == n ? void 0 : n.toJS(), { id: d.v4() })
                );
                return t.sub(["components", e]).set(a);
              })(a, t, n));
          });
        }
      }
      function C(t, e) {
        t.sub(["components", e, "url"]).set("");
      }
      function y(t) {
        return (
          !t ||
          "" === t ||
          "#fff" === t ||
          "#ffffff" === t ||
          "white" === t ||
          "transparent" === t ||
          "rgba(0, 0, 0, 0)" === t
        );
      }
      function S(t, e) {
        var n = t || {},
          a = n.isSticky,
          i = n.dropShadow,
          o = n.isTransparent,
          r = n.backgroundColor1,
          l = (n.border || {}).enable,
          u = o || !(null != e && s()(e).call(e, "border")) || !l;
        return a && "no" === i && u && y(r);
      }
    },
    727505: function (t, e, n) {
      n.r(e),
        n.d(e, {
          DISABLED_TRANSPARENT_LAYOUTS: function () {
            return B;
          },
          NAV_COLORS_KEYS: function () {
            return w;
          },
          NAV_LAYOUT_KEYS: function () {
            return r;
          },
          NAV_LOGO_MAX_HEIGHT: function () {
            return D;
          },
          getNavByLayout: function () {
            return I;
          },
          getNavByName: function () {
            return k;
          },
          layouts: function () {
            return T;
          },
          layoutsMap: function () {
            return P;
          },
          navs: function () {
            return E;
          },
        });
      var a,
        i,
        o,
        r,
        l = n(844845),
        s = n(2991),
        u = n.n(s),
        d = n(694473),
        c = n.n(d),
        f = n(468420),
        g = n(327344),
        p = n(778914),
        h = n.n(p),
        v = n(686902),
        m = n.n(v),
        b = n(678580),
        _ = n.n(b),
        C = n(353147),
        y = (function () {
          function t(e) {
            var n,
              a = this;
            (0, f.Z)(this, t),
              (0, l.Z)(this, "name", void 0),
              (0, l.Z)(this, "layout", void 0),
              (0, l.Z)(this, "label", void 0),
              (0, l.Z)(this, "i18nDisplayName", void 0),
              (0, l.Z)(this, "_nameForPoGenerator", void 0),
              (0, l.Z)(this, "orientation", void 0),
              (0, l.Z)(this, "getPageWrapperStyle", void 0),
              (0, l.Z)(this, "getStyle", void 0),
              (0, l.Z)(this, "templateFunction", void 0),
              (0, l.Z)(this, "enabledNavOptions", void 0),
              (0, l.Z)(this, "afterRender", void 0),
              (0, l.Z)(this, "shouldShowFixedNav", void 0),
              (0, l.Z)(this, "shouldHideNormalNav", void 0),
              (0, l.Z)(this, "shouldShowAlternativeFixedNavVariation", void 0),
              (0, l.Z)(this, "nullHighlightColorMeansUnderline", void 0),
              (0, l.Z)(this, "getDropdownBackgroundColor", void 0),
              (0, l.Z)(this, "showDropdownBesideText", void 0),
              h()((n = m()(e))).call(n, function (t) {
                return (a[t] = e[t]);
              });
          }
          return (
            (0, g.Z)(t, [
              {
                key: "displayName",
                get: function () {
                  return C(this.i18nDisplayName);
                },
              },
              {
                key: "supportsSettingKey",
                value: function (t) {
                  var e;
                  return (
                    "name" === t ||
                    "layout" === t ||
                    "colors" === t ||
                    "fontSize" === t ||
                    "showSocialMedia" === t ||
                    _()((e = this.enabledNavOptions)).call(e, t)
                  );
                },
              },
              {
                key: "supportsNavbarTranslucency",
                value: function () {
                  return (
                    "vertical" !== this.orientation &&
                    "topCenter" !== this.name &&
                    "circleIcon" !== this.name
                  );
                },
              },
            ]),
            t
          );
        })(),
        S = n(496486),
        x = n(589499);
      !(function (t) {
        (t.A = "a"),
          (t.B = "b"),
          (t.C = "c"),
          (t.D = "d"),
          (t.E = "e"),
          (t.F = "f"),
          (t.G = "g"),
          (t.H = "h"),
          (t.I = "i");
      })(r || (r = {}));
      var w,
        E = u()(
          (a = [
            n(974545).Z,
            n(856621).Z,
            n(586640).Z,
            n(930729).Z,
            n(784308).Z,
            n(91334).Z,
            n(654667).Z,
          ])
        ).call(a, function (t) {
          return new y(t);
        }),
        P =
          ((i = {}),
          (0, l.Z)(i, r.A, "topBar"),
          (0, l.Z)(i, r.B, "topBar"),
          (0, l.Z)(i, r.C, "topBar"),
          (0, l.Z)(i, r.D, "topRadial"),
          (0, l.Z)(i, r.E, "topCenter"),
          (0, l.Z)(i, r.F, "circleIcon"),
          (0, l.Z)(i, r.G, "left"),
          (0, l.Z)(i, r.H, "topBlock"),
          (0, l.Z)(i, r.I, "drawer"),
          i),
        N =
          ((o = {}),
          (0, l.Z)(o, r.A, {
            name: "topBar",
            isTransparent: !0,
            presetColorName: "transparent",
            topContentWidth: "full",
            itemSpacing: "compact",
            dropShadow: "no",
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
            highlight: {
              type: "underline",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.B, {
            name: "topBar",
            isTransparent: !0,
            presetColorName: "transparent",
            topContentWidth: "full",
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
            highlight: {
              type: "underline",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.C, {
            name: "topBar",
            isTransparent: !0,
            presetColorName: "transparent",
            topContentWidth: "full",
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
            highlight: {
              type: "underline",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.D, {
            name: "topRadial",
            isTransparent: !0,
            presetColorName: "transparent",
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
            highlight: {
              type: "underline",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.E, {
            name: "topCenter",
            isTransparent: !1,
            presetColorName: "whiteMinimal",
            backgroundColor1: "#fff",
            itemColor: "#000",
            highlightColor: null,
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
            highlight: {
              type: "underline",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.F, {
            name: "circleIcon",
            isTransparent: !1,
            presetColorName: "whiteMinimal",
            backgroundColor1: "#fff",
            itemColor: "#000",
            highlightColor: null,
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
            highlight: {
              type: "underline",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.G, {
            name: "left",
            isTransparent: !1,
            presetColorName: "whiteMinimal",
            backgroundColor1: "#fff",
            itemColor: "#000",
            highlightColor: null,
            topContentWidth: "medium",
            padding: "medium",
            fontSize: "medium",
            horizontalContentAlignment: "left",
            verticalContentAlignment: "top",
            isSticky: !0,
            highlight: {
              type: "color",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.H, {
            name: "topBlock",
            isTransparent: !1,
            presetColorName: "whiteMinimal",
            backgroundColor1: "#fff",
            itemColor: "#000",
            highlightColor: null,
            topContentWidth: "full",
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
            highlight: {
              type: "underline",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
          }),
          (0, l.Z)(o, r.I, {
            name: "drawer",
            isTransparent: !0,
            presetColorName: "transparent",
            backgroundColor1: "#fff",
            itemColor: "#000",
            highlightColor: null,
            highlight: {
              type: "color",
              textColor: null,
              blockTextColor: null,
              blockBackgroundColor: null,
              blockShape: "pill",
            },
            topContentWidth: "full",
            itemSpacing: "compact",
            dropShadow: "no",
            padding: "medium",
            fontSize: "medium",
            isSticky: !0,
          }),
          o),
        T = S.map(P, function (t, e) {
          return new y(
            S.assign(
              {},
              c()(E).call(E, function (e) {
                return e.name === t;
              }),
              { layout: e },
              {
                label: "".concat("string" == typeof e && e.toUpperCase()),
                thumbnail: (0, x.cdnAssetPath)(
                  "/images/editor2/nav/icon-".concat(e, ".svg")
                ),
              },
              { defaultSettings: N[e] }
            )
          );
        });
      function k(t) {
        return S.find(E, { name: t });
      }
      function I(t) {
        return S.find(T, { layout: t });
      }
      !(function (t) {
        (t.BackgroundColor = "backgroundColor1"),
          (t.ItemColor = "itemColor"),
          (t.HighlightColor = "highlightColor"),
          (t.IsTransparent = "isTransparent");
      })(w || (w = {}));
      var B = [r.E, r.F, r.G, r.H],
        D = {
          topBar: 60,
          topRadial: 50,
          topCenter: 150,
          circleIcon: 100,
          left: null,
          topBlock: 46,
        };
    },
    784308: function (t, e, n) {
      var a = n(863056),
        i = n(977766),
        o = n.n(i),
        r = n(933032),
        l = n.n(r),
        s = (n(366757), n(611384)),
        u = n(31484),
        d = n(223336),
        c = n(183123),
        f = n(353147),
        g = { small: 20, medium: 30, large: 40 },
        p = [
          "colors",
          "padding",
          "backgroundColor1",
          "isSticky",
          "itemSpacing",
          "dropShadow",
          "highlight",
        ];
      e.Z = {
        name: "circleIcon",
        i18nDisplayName: "Editor|Circle Icon",
        _nameForPoGenerator: function () {
          return f("Editor|Circle Icon");
        },
        orientation: "horizontal",
        getStyle: function (t) {
          var e,
            n,
            a,
            i,
            r,
            l,
            d,
            f,
            h,
            v,
            m,
            b,
            _,
            C,
            y,
            S,
            x,
            w,
            E = Math.max(t.padding, 20),
            P =
              g[
                (null == t || null === (e = t.navTheme) || void 0 === e
                  ? void 0
                  : e.padding) || "medium"
              ],
            N = !c.getNewNavHeaderDesign() || (0, s.nf)(t, p);
          return o()(
            (n = o()(
              (a = o()(
                (i = o()(
                  (r = o()(
                    (l = o()(
                      (d = o()(
                        (f = o()(
                          (h = o()(
                            (v = o()(
                              (m = o()(
                                (b = o()(
                                  (_ = o()(
                                    (C = o()(
                                      (y = o()(
                                        (S = o()(
                                          (x = o()(
                                            (w = "\n      ".concat(
                                              "\n          & .s-nav-logo-wrapper .s-icon-button {\n            display: inline-block;\n            .login-container {\n              display: inline-block;\n            }\n          }\n        ",
                                              "\n      &._alternative {\n        padding-bottom: "
                                            ))
                                          ).call(
                                            w,
                                            20,
                                            "px;\n        box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n        &.not-in-sticky {\n          box-shadow: none;\n        }\n      }\n      text-align: center;\n\n      & .s-logo-image {\n        margin-bottom: 15px;\n      }\n\n      &.has-new-layout {\n        .noImage {\n          display: none;\n          box-shadow: none;\n        }\n        &:hover {\n          .noImage {\n            display: block;\n          }\n        }\n      }\n\n      &.s-new-layout.circleIcon.s-new-layout-f:not(.has-button)\n        .s-nav-social-media:not(.has-social-media-contact-list) {\n        padding-top: 0;\n      }\n\n      & .s-logo-title {\n        margin-bottom: 15px;\n      }\n      & ul.s-uncollapsed-nav > li {\n        display: inline-block;\n        padding: 5px 10px;\n      }\n      & ul.s-collapsed-nav > li {\n        display: block;\n      }\n      & .s-button {\n        display: inline-block;\n      }\n\n      & ul li._compact {\n        padding-left: 4px;\n        padding-right: 4px;\n      }\n\n      & .s-logo-image img {\n        max-height: 100px;\n      }\n\n      & .s-logo-image-2-container-inner {\n        position: relative;\n        margin: auto;\n        width: 54px;\n        & > * {\n          position: absolute;\n          top: "
                                          ))
                                        ).call(
                                          x,
                                          E - 25,
                                          "px;\n\n          left: 0;\n          z-index: -2;\n          padding: 5px;\n          background: "
                                        ))
                                      ).call(
                                        S,
                                        t.backgroundColor1,
                                        ";\n          box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n          height: 40px;\n          width: 40px;\n          border-radius: 100px;\n          &:before {\n            content: '';\n            background: "
                                      ))
                                    ).call(
                                      y,
                                      t.backgroundColor1,
                                      ";\n            top: -5px;\n            left: -8px;\n            width: 65px;\n            display: block;\n            position: absolute;\n            z-index: -1;\n            height: 30px;\n          }\n        }\n      }\n      &._alternative {\n        & .s-logo-image-2-container-inner > * {\n          top: "
                                    ))
                                  ).call(
                                    C,
                                    -5,
                                    "px;\n        }\n        & .s-logo-title {\n          visibility: hidden;\n        }\n      }\n\n      &.s-navbar-desktop-normal .s-nav-inner {\n        opacity: 0;\n      }\n\n      &.s-navbar-desktop-fixed {\n        transition: top 0.3s, padding-bottom 0.3s;\n        .s-icon-button .s-nav-btn .s-common-button {\n          max-width: 300px;\n          overflow: hidden;\n          text-overflow: ellipsis;\n        }\n        "
                                  ))
                                ).call(
                                  _,
                                  N &&
                                    "\n          &._alternative {\n            box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n          }\n        ",
                                  "\n        &._alternative .s-nav-inner {\n          position: relative;\n\n          /* keep alignment with button and logos. */\n          .s-nav-top-center-item-container {\n            margin-top: 10px;\n            margin-bottom: -10px;\n          }\n\n          .s-nav-logo-wrapper {\n            position: unset;\n            .s-icon-button,\n            .s-nav-social-media {\n              bottom: "
                                ))
                              ).call(
                                b,
                                E,
                                "px;\n              position: absolute;\n            }\n            .s-nav-social-media {\n              padding-bottom: 5px;\n            }\n            .s-icon-button {\n              height: unset;\n            }\n          }\n        }\n        &._alternative.has-button .s-nav-inner .s-nav-logo-wrapper {\n          .s-icon-button {\n            bottom: "
                              ))
                            ).call(m, E - 6, "px;\n            right: "))
                          ).call(
                            v,
                            P,
                            "px;\n          }\n          .s-nav-social-media-empty {\n            padding-bottom: 0px;\n          }\n        }\n      }\n      &.circleIcon .s-nav-inner {\n        .s-nav-social-media.has-social-media-contact-list {\n          padding: 8px "
                          ))
                        ).call(
                          h,
                          P,
                          "px 8px;\n        }\n        .s-nav-inner-wrap {\n          padding: "
                        ))
                      ).call(f, P, "px;\n          padding-bottom: "))
                    ).call(d, E, "px;\n        }\n      }\n\n      "))
                  ).call(l, (0, u.XO)(t), ";\n      "))
                ).call(r, (0, u.qX)(t), ";\n      "))
              ).call(i, (0, s.Eg)(t), ";\n      "))
            ).call(a, (0, s.Gx)(t), ";\n      "))
          ).call(n, (0, s.es)(), ";\n    ");
        },
        templateFunction: function (t) {
          var e = t.LogoImage1,
            n = t.LogoImage2,
            i = t.LogoTitle,
            o = t.NavItemsAndLinks,
            r = t.NavIcons,
            l = t.NavButton,
            s = t.NavContentContainer;
          return (0, a.Z)(
            s,
            {},
            void 0,
            (0, a.Z)(
              "div",
              { className: "s-logo" },
              void 0,
              (0, a.Z)(e, {}),
              (0, a.Z)("div", {}, void 0, (0, a.Z)(i, {}))
            ),
            (0, a.Z)(
              "div",
              { className: "s-nav-top-center-item-container" },
              void 0,
              (0, a.Z)(o, {}),
              (0, a.Z)(r, {}),
              (0, a.Z)(l, {})
            ),
            (0, a.Z)(
              "div",
              { className: "s-logo-image-2-container" },
              void 0,
              (0, a.Z)(
                "div",
                { className: "s-logo-image-2-container-inner" },
                void 0,
                (0, a.Z)(n, {})
              )
            )
          );
        },
        newLayoutTemplateFunction: function (t) {
          var e = t.LogoImage1,
            n = t.LogoImage2,
            i = t.LogoTitle,
            o = t.NavItemsAndLinks,
            r = t.NavIcons,
            l = t.NavButton,
            s = t.NavContentContainer,
            u = t.NavSocialMedia,
            d = t.NavSocialMediaHasContactList;
          return (0, a.Z)(
            s,
            {},
            void 0,
            (0, a.Z)(d, {}),
            (0, a.Z)(
              "div",
              { className: "s-nav-inner-wrap" },
              void 0,
              (0, a.Z)(
                "div",
                { className: "s-nav-logo-wrapper" },
                void 0,
                (0, a.Z)(u, {}),
                (0, a.Z)(
                  "div",
                  { className: "s-logo" },
                  void 0,
                  (0, a.Z)(e, {}),
                  (0, a.Z)("div", {}, void 0, (0, a.Z)(i, {}))
                ),
                (0, a.Z)(
                  "div",
                  { className: "s-icon-button" },
                  void 0,
                  (0, a.Z)(r, {}),
                  (0, a.Z)(l, {})
                )
              ),
              (0, a.Z)(
                "div",
                { className: "s-nav-top-center-item-container" },
                void 0,
                (0, a.Z)(o, {})
              ),
              (0, a.Z)(
                "div",
                { className: "s-logo-image-2-container" },
                void 0,
                (0, a.Z)(
                  "div",
                  { className: "s-logo-image-2-container-inner" },
                  void 0,
                  (0, a.Z)(n, {})
                )
              )
            )
          );
        },
        enabledNavOptions: p,
        estimateNavHeight: function (t) {
          return 60 + 2 * t.padding + 100;
        },
        shouldShowFixedNav: function (t, e) {
          return !0;
        },
        shouldShowAlternativeFixedNavVariation: function (t, e, n) {
          var a = t.normal,
            i = (a.container, a.logoImage),
            o = a.logoTitle,
            r = (n.padding || 0) + (i.height() || 0) + (o.height() || 0) + 20;
          return d(window).scrollTop() > r;
        },
        collapseNav: function (t, e) {
          var n = ".s-navbar-desktop-fixed",
            a =
              d(
                "".concat(n, " .s-nav-logo-wrapper .s-nav-social-media")
              ).outerWidth() || 0,
            i =
              d(
                "".concat(n, " .s-nav-logo-wrapper .s-icon-button")
              ).outerWidth() || 0,
            o = (d("".concat(n)).outerWidth() || 0) - 2 * Math.max(i, a);
          (0, s.MP)(t, e, !0, o);
        },
        afterRender: function (t, e, n, a) {
          var i = t.fixed.container;
          if (n.isSticky)
            if (a.showFixedNavAlternativeVariation) {
              var o,
                r =
                  null ===
                    (o = d(t.normal.uncollapsedNav[0])
                      .parent()
                      .parent()
                      .offset()) || void 0 === o
                    ? void 0
                    : o.top;
              null != a && a.isPreviewMode && (r -= 30),
                i.css("top", "".concat(-r, "px")),
                this.collapseNav(t, e);
            } else {
              var u = null != a && a.isPreviewMode ? 30 : 0;
              i.css("top", u),
                (0, s.Re)(t, !0),
                l()(function () {
                  i.css("transition", "");
                });
            }
        },
      };
    },
    654667: function (t, e, n) {
      n.d(e, {
        Z: function () {
          return f;
        },
      });
      var a = n(863056),
        i = n(366757),
        o = n(859056),
        r =
          (n(66992),
          n(241539),
          n(788674),
          n(978783),
          n(333948),
          (0, n(766727).default)(
            function () {
              return Promise.all([
                n.e(2635),
                n.e(5306),
                n.e(7271),
                n.e(9623),
                n.e(9873),
                n.e(375),
                n.e(6130),
                n.e(351),
                n.e(6237),
                n.e(1725),
                n.e(6338),
                n.e(8401),
                n.e(9128),
                n.e(1318),
                n.e(6148),
              ])
                .then(n.bind(n, 550745))
                .then(function (t) {
                  return t.Drawer;
                });
            },
            { ssr: !1 }
          )),
        l = function (t) {
          var e = t.children,
            n = t.navItemsComp,
            l = i.useState(!1),
            s = (0, o.Z)(l, 2),
            u = s[0],
            d = s[1];
          return i.createElement(
            i.Fragment,
            null,
            (0, a.Z)(
              "div",
              { className: "s-nav-inner-wrap" },
              void 0,
              (0, a.Z)(
                "div",
                { className: "s-nav-menu-btn" },
                void 0,
                (0, a.Z)("i", {
                  className: "s-nav-menu-btn-icon fas fa-bars",
                  onClick: function () {
                    return d(!0);
                  },
                })
              ),
              n
            ),
            (0, a.Z)(
              r,
              {
                className: "s-ant-drawer-container",
                zIndex: 210,
                width: "auto",
                visible: u,
                placement: "left",
                onClose: function () {
                  return d(!1);
                },
                getContainer: "#layout-drawer-wrap",
              },
              void 0,
              e
            )
          );
        },
        s = n(183123),
        u = n(156503),
        d = n.n(u),
        c = n(353147),
        f = {
          name: "drawer",
          i18nDisplayName: "Editor|Left Sidebar",
          _nameForPoGenerator: function () {
            return c("Editor|Left Sidebar");
          },
          orientation: "horizontal",
          nullHighlightColorMeansUnderline: !0,
          showDropdownBesideText: !0,
          getStyle: function (t) {
            return "";
          },
          templateFunction: function (t) {
            var e = t.LogoTitle,
              n = t.LogoImage,
              o = t.NavItemsAndLinks,
              r = t.NavIcons,
              s = t.NavSocialMedia,
              u = t.NavSocialMediaHasContactList,
              d = t.NavButton,
              c = t.NavContentContainer;
            return i.createElement(
              i.Fragment,
              null,
              (0, a.Z)(
                c,
                {},
                void 0,
                (0, a.Z)(u, {}),
                (0, a.Z)(
                  l,
                  {
                    navItemsComp: i.createElement(
                      i.Fragment,
                      null,
                      (0, a.Z)(
                        "div",
                        { className: "s-title-wrap" },
                        void 0,
                        (0, a.Z)(n, {}),
                        (0, a.Z)(e, {})
                      ),
                      (0, a.Z)(
                        "div",
                        { className: "s-drawer-nav-right" },
                        void 0,
                        (0, a.Z)(r, {}),
                        (0, a.Z)(s, {}),
                        (0, a.Z)(d, {})
                      )
                    ),
                  },
                  void 0,
                  (0, a.Z)(
                    "div",
                    { className: "nav-items-and-links-wrap" },
                    void 0,
                    (0, a.Z)(o, {})
                  )
                )
              )
            );
          },
          enabledNavOptions: [
            "colors",
            "padding",
            "backgroundColor1",
            "isTransparent",
            "highlightColor",
            "isSticky",
            "itemSpacing",
            "dropShadow",
            "highlight",
            "border",
          ],
          shouldShowFixedNav: function (t, e) {
            var n = $(".s-first-visible-section");
            return (
              s.getIsBlog() && (n = $(".s-blog-header")),
              0 !== n.length &&
                $(window).scrollTop() >=
                  $(window).height() - d().get("navHeight")
            );
          },
          shouldShowAlternativeFixedNavVariation: function (t, e, n) {
            var a = t.normal,
              i = a.logoImage,
              o = a.logoTitle,
              r = (n.padding || 0) + (i.height() || 0) + (o.height() || 0) + 20;
            return $(window).scrollTop() > r;
          },
          afterRender: function (t, e) {},
        };
    },
    586640: function (t, e, n) {
      n.d(e, {
        Z: function () {
          return u;
        },
      });
      var a = n(863056),
        i = n(977766),
        o = n.n(i);
      function r(t, e) {
        var n,
          a,
          i,
          r,
          l,
          s,
          u,
          d,
          c = e.sidemenuWidth;
        return o()(
          (n = o()(
            (a = o()(
              (i = o()(
                (r = o()(
                  (l = o()(
                    (s = o()(
                      (u = o()(
                        (d = "\n    @media screen and (min-width: ".concat(
                          1200 + c,
                          "px) {\n      "
                        ))
                      ).call(
                        d,
                        t(e.sidebarWidth.wideDesktopPercentage),
                        ";\n    }\n    @media screen and (min-width: "
                      ))
                    ).call(u, 900 + c, "px) and (max-width: "))
                  ).call(s, 1199 + c, "px) {\n      "))
                ).call(
                  l,
                  t(e.sidebarWidth.narrowDesktopPercentage),
                  ";\n    }\n    @media screen and (max-width: "
                ))
              ).call(r, 899 + c, "px) {\n      "))
            ).call(
              i,
              t(e.sidebarWidth.tabletPercentage),
              ";\n    }\n    @media screen and (max-width: "
            ))
          ).call(a, 727 + c, "px) {\n      "))
        ).call(n, t(0), ";\n    }\n  ");
      }
      n(366757);
      var l = n(31484),
        s = n(353147),
        u = {
          name: "left",
          i18nDisplayName: "Editor|Left Sidebar",
          _nameForPoGenerator: function () {
            return s("Editor|Left Sidebar");
          },
          orientation: "vertical",
          nullHighlightColorMeansUnderline: !0,
          showDropdownBesideText: !0,
          getPageWrapperStyle: function (t) {
            return (function (t) {
              var e;
              return o()(
                (e =
                  "\n    & .page-wrapper,\n    & .s-footer-section,\n    & .s-footer-logo-wrapper {\n      float: ".concat(
                    t.isRtlLayout ? "left" : "right",
                    ";\n    }\n    @media (min-width: 728px) {\n      & .s-footer-logo-wrapper .s-footer-logo {\n        margin-left: auto;\n        margin-right: auto;\n      }\n    }\n\n    "
                  ))
              ).call(
                e,
                r(function (e) {
                  var n, a;
                  return o()(
                    (n = o()(
                      (a =
                        "\n        & .page-wrapper,\n        & .s-footer-section,\n        & .s-footer-logo-wrapper {\n          width: ".concat(
                          100 - e,
                          "%;\n          width: calc(\n            "
                        ))
                    ).call(a, 100 - e, "% - "))
                  ).call(
                    n,
                    t.isPreviewMode ? (e / 100) * 30 : 0,
                    "px\n          );\n        }\n      "
                  );
                }, t),
                "\n  "
              );
            })(t);
          },
          getStyle: function (t) {
            var e, n, a, i, s, u, d, c, f, g, p, h, v, m;
            return o()(
              (e = o()(
                (n = o()(
                  (a = o()(
                    (i = o()(
                      (s = o()(
                        (u = o()(
                          (d = o()(
                            (c = o()(
                              (f = o()(
                                (g = o()(
                                  (p = o()(
                                    (h =
                                      "\n    display: flex;\n    align-items: ".concat(
                                        "middle" === t.verticalContentAlignment
                                          ? "center"
                                          : "flex-start",
                                        ";\n    position: fixed;\n    padding: "
                                      ))
                                  ).call(h, t.padding, "px;\n    "))
                                ).call(
                                  p,
                                  "small" === t.navTheme.sidebarWidth &&
                                    o()(
                                      (v =
                                        "\n      @media screen and (max-width: ".concat(
                                          1400 + t.sidemenuWidth,
                                          "px) {\n        padding: "
                                        ))
                                    ).call(
                                      v,
                                      t.padding / 2,
                                      "px;\n      }\n    "
                                    ),
                                  ";\n    "
                                ))
                              ).call(
                                g,
                                "medium" === t.navTheme.sidebarWidth &&
                                  o()(
                                    (m =
                                      "\n      @media screen and (max-width: ".concat(
                                        1e3 + t.sidemenuWidth,
                                        "px) {\n        padding: "
                                      ))
                                  ).call(
                                    m,
                                    t.padding / 2,
                                    "px;\n      }\n    "
                                  ),
                                ";\n    z-index: 210;\n    height: 100%;\n    "
                              ))
                            ).call(
                              f,
                              (function (t) {
                                return r(function (e) {
                                  var n;
                                  return o()(
                                    (n =
                                      "\n      width: calc(\n        ".concat(
                                        e,
                                        "% - "
                                      ))
                                  ).call(
                                    n,
                                    t.sidemenuWidth * (e / 100),
                                    "px\n      );\n    "
                                  );
                                }, t);
                              })(t),
                              ";\n    box-shadow: 1px 0 rgba(0, 0, 0, 0.12);\n    box-sizing: border-box;\n    text-align: "
                            ))
                          ).call(
                            c,
                            t.isRtlLayout
                              ? "right"
                              : t.horizontalContentAlignment,
                            ";\n\n    & .s-common-button {\n      padding: 16px 24px;\n    }\n    & .s-nav-btn {\n      margin: 30px 0 0 0;\n\n      .s-font-button {\n        word-break: break-word;\n        white-space: break-spaces;\n      }\n    }\n    & .s-logo-subtitle {\n      max-width: 100%;\n      margin-top: 10px;\n      margin-right: 10px;\n      padding-bottom: 8px;\n      min-width: 80px; /* Important in editor, otherwise has line break with placeholder text */\n      "
                          ))
                        ).call(
                          d,
                          "right" === t.horizontalContentAlignment &&
                            "\n        margin-right: 0px;\n      ",
                          ";\n    }\n    & .s-nav {\n      display: flex;\n      flex-direction: column;\n      height: 100%;\n    }\n    & .s-nav-items-and-links > ul li,\n    & .s-nav-icons > li {\n      display: block;\n      margin: "
                        ))
                      ).call(
                        u,
                        { large: 15, medium: 10, small: 5 }[
                          t.navTheme.fontSize
                        ],
                        "px\n        0;\n      & .s-nav-link-container {\n        padding-right: 5px;\n      }\n      .s-navbar-dropdown {\n        & .s-nav-li {\n          padding: 0px;\n        }\n      }\n    }\n\n    & .s-nav-items-and-links > ul li {\n      &:first-child {\n        margin-top: 0;\n      }\n      &:last-child {\n        margin-bottom: 0;\n      }\n    }\n\n    & .s-nav-items-and-links .s-nav-li {\n      padding-bottom: 0;\n    }\n    & .s-nav-li {\n      word-wrap: break-word;\n      line-height: 1.5em;\n    }\n\n    & .s-nav-inner {\n      width: 100%;\n      display: flex;\n      flex-direction: column;\n      max-height: 100%;\n    }\n\n    & .s-nav-icons {\n      display: block;\n      & .s-nav-li {\n        "
                      ))
                    ).call(
                      s,
                      "left" === t.horizontalContentAlignment &&
                        !t.isRtlLayout &&
                        "\n          margin-right: 10px;\n          margin-left: 0px;\n        ",
                      ";\n        "
                    ))
                  ).call(
                    i,
                    "right" === t.horizontalContentAlignment &&
                      "\n          margin-right: 0px;\n          margin-left: 10px;\n        ",
                    ";\n        "
                  ))
                ).call(
                  a,
                  "center" === t.horizontalContentAlignment &&
                    "\n          margin-right: 0px;\n          margin-left: 0px;\n        ",
                  ";\n      }\n    }\n\n    & .s-navbar-dropdown ul {\n      padding: 0 5px;\n    }\n\n    & .s-nav-items-and-links {\n      flex-shrink: 1;\n      overflow-y: hidden;\n    }\n\n    & .s-logo-image {\n      margin-bottom: 0;\n    }\n\n    & .s-logo-image img {\n      max-height: 200px;\n    }\n\n    & .s-logo-title {\n      max-width: 100%;\n      margin-top: 10px;\n      font-size: 150%;\n    }\n\n    & .s-logo {\n      margin-bottom: 30px;\n    }\n\n    & .s-navbar-desktop {\n      height: 100%;\n    }\n\n    &.s-navbar-desktop-fixed {\n      display: none;\n    }\n\n    & .s-nav-link-container {\n      display: block;\n    }\n\n    & .s-left-nav-scroll-container {\n      overflow: auto;\n      /* Subtitle is a richtext field with an extra outer border,\n           need to prevent that border from getting cut off */\n      padding: 0 8px;\n      margin-right: -8px;\n      margin-left: -8px;\n    }\n\n    @media screen and (max-width: "
                ))
              ).call(
                n,
                900 + t.sidemenuWidth,
                "px) {\n      /* there's not much horizontal space, so reduce font size a bit */\n      & .s-nav-inner {\n        font-size: 80%;\n      }\n    }\n\n    &.s-new-layout.s-new-layout-g .s-nav-g-footer .social-media-contact-list-wrapper .s-social-media-buttons-wrap {\n      flex-direction: column;\n      align-items: flex-start;\n      .s-social-media-button {\n        margin: 10px 0 0 0;\n        &:first-of-type {\n          margin-top: 0;\n        }\n        .fb-counter {\n          margin-left: -10px;\n          margin-bottom: -5px;\n        }\n      }\n    }\n\n    "
              ))
            ).call(e, (0, l.XO)(t), "\n  ");
          },
          templateFunction: function (t) {
            var e = t.LogoImage,
              n = t.LogoTitle,
              i = t.NavItemsAndLinks,
              o = t.NavIcons,
              r = t.NavButton,
              l = t.NavContentContainer,
              s = t.LogoSubtitle,
              u = t.MultiLangAndSocialMedia;
            return (0, a.Z)(
              l,
              {},
              void 0,
              (0, a.Z)(
                "div",
                { className: "s-logo" },
                void 0,
                (0, a.Z)("div", {}, void 0, (0, a.Z)(e, {})),
                (0, a.Z)("div", {}, void 0, (0, a.Z)(n, {}))
              ),
              (0, a.Z)(
                "div",
                { className: "s-left-nav-scroll-container" },
                void 0,
                (0, a.Z)(i, {}),
                (0, a.Z)(o, {}),
                (0, a.Z)(s, {})
              ),
              (0, a.Z)(
                "div",
                { style: { marginBottom: 20 } },
                void 0,
                (0, a.Z)(r, {})
              ),
              (0, a.Z)(u, {})
            );
          },
          enabledNavOptions: [
            "colors",
            "padding",
            "sidebarWidth",
            "backgroundColor1",
            "verticalContentAlignment",
            "horizontalContentAlignment",
            "highlightColor",
            "highlight",
          ],
          afterRender: function (t, e) {},
        };
    },
    974545: function (t, e, n) {
      var a = n(844845),
        i = n(386302),
        o = n(863056),
        r = n(977766),
        l = n.n(r),
        s = n(2991),
        u = n.n(s),
        d = n(51942),
        c = n.n(d),
        f = n(981643),
        g = n.n(f),
        p = (n(366757), n(611384)),
        h = n(183123),
        v = n(31484),
        m = n(234584),
        b = n(353147),
        _ =
          "&.rtl-layout .s-component-overlay {\n  margin-left: 0;\n  margin-right: -8px;\n}",
        C = ["c"],
        y = [
          "colors",
          "padding",
          "backgroundColor1",
          "topContentWidth",
          "isTransparent",
          "highlightColor",
          "isSticky",
          "itemSpacing",
          "dropShadow",
          "highlight",
          "border",
        ];
      e.Z = {
        name: "topBar",
        i18nDisplayName: "Editor|Top Bar",
        _nameForPoGenerator: function () {
          return b("Editor|Top Bar");
        },
        orientation: "horizontal",
        nullHighlightColorMeansUnderline: !0,
        getStyle: function (t) {
          var e,
            n,
            a,
            i,
            o,
            r,
            s,
            u,
            d,
            c,
            f,
            g,
            m,
            b,
            C,
            S,
            x,
            w = h.getNewNavHeaderDesign(),
            E = !w || (0, p.nf)(t, y);
          return l()(
            (e = l()(
              (n = l()(
                (a = l()(
                  (i = l()(
                    (o = l()(
                      (r = l()(
                        (s = l()(
                          (u = l()(
                            (d = l()(
                              (c = l()(
                                (f = l()(
                                  (g = l()(
                                    (m = l()(
                                      (b = l()(
                                        (C = l()(
                                          (S = l()(
                                            (x = "\n    ".concat(
                                              "centered" ===
                                                t.topContentWidth &&
                                                "\n      text-align: center;\n    ",
                                              ";\n    & .s-nav-items-and-links {\n      flex-grow: 1;\n      text-align: right;\n    }\n    & .s-nav-items-and-links li {\n      & a, .s-nav-dropdown-item, .login-nav-item {\n        font-weight: bold;\n      }\n      display: inline-block;\n    }\n    & .s-navbar-dropdown li {\n      display: block;\n    }\n    &.topBar .s-nav-inner {\n      .s-nav-social-media.has-social-media-contact-list {\n        margin: 0 auto;\n        "
                                            ))
                                          ).call(
                                            x,
                                            "section" === t.topContentWidth &&
                                              "\n          padding: 8px calc((100% - ".concat(
                                                t.sectionContentWidth.normal,
                                                ") / 2);\n        "
                                              ),
                                            ";\n        "
                                          ))
                                        ).call(
                                          S,
                                          "centered" === t.topContentWidth &&
                                            "\n          justify-content: center;\n        ",
                                          ";\n        .social-media-contact-list-wrapper {\n          margin-right: 0;\n        }\n      }\n      .s-nav-inner-wrap {\n        display: flex;\n        position: relative;\n        align-items: center;\n        padding-"
                                        ))
                                      ).call(
                                        C,
                                        t.isRtlLayout ? "left" : "right",
                                        ": "
                                      ))
                                    ).call(b, t.padding - 10, "px;\n        "))
                                  ).call(
                                    m,
                                    "section" === t.topContentWidth &&
                                      "max-width: ".concat(
                                        t.sectionContentWidth.normal,
                                        ";"
                                      ),
                                    ";\n        "
                                  ))
                                ).call(
                                  g,
                                  "centered" === t.topContentWidth &&
                                    "display: inline-flex;",
                                  ";\n      }\n    }\n    & .s-logo-title {\n      font-size: 120%;\n      margin-left: 10px;\n      margin-right: 10px;\n      "
                                ))
                              ).call(
                                f,
                                _,
                                "\n    }\n    & .s-logo .s-image {\n      max-width: 240px;\n    }\n    & .s-nav-btn {\n      margin: 0 10px;\n    }\n    & .s-logo-image {\n      margin: "
                              ))
                            ).call(
                              c,
                              t.isRtlLayout ? "0 0 0 10px" : "0 10px 0 0",
                              ";\n      "
                            ))
                          ).call(
                            d,
                            _,
                            "\n    }\n    & .s-logo-image img {\n      max-height: 60px;\n    }\n    & .s-common-button {\n      padding: 12px 20px;\n    }\n\n    &.s-new-layout-c:not(.in-editor) {\n      .s-logo-title {\n        min-width: auto;\n      }\n      &:not(.has-button) {\n        .s-nav-btn {\n          display: none;\n          width: 0;\n        }\n      }\n      &:not(.has-title) {\n        .s-logo-title {\n          display: none;\n          width: 0;\n        }\n      }\n    }\n\n    /*\n        We never want to show the normal nav since topBar nav is always fixed.\n        However, if the nav isn't translucent/transparent (overlaps the conent)\n        then the space behind the fixed nav would normally be white.\n\n        The height of the fixed nav animates, and at times it is smaller\n        than the space taken up by the invisible normal nav. This leads to a\n        white area being visible when you scroll backt to the top of the page.\n\n        To fix that we show the background color of the normal nav to hide the\n        white background. We don't want that if the nav is translucent,\n        since then the normal nav would be visible behind the fixed nav.\n      */\n    "
                          ))
                        ).call(
                          u,
                          t.overlapsContent &&
                            "\n      &.s-navbar-desktop-normal {\n        visibility: hidden;\n        opacity: 0;\n      }\n    ",
                          ";\n    "
                        ))
                      ).call(
                        s,
                        !t.overlapsContent &&
                          "\n      &.s-navbar-desktop-normal .s-nav-inner {\n        visibility: hidden;\n        opacity: 0;\n      }\n    ",
                        ";\n\n    &.s-navbar-desktop-fixed {\n      @media screen and (min-width: 728px) {\n        display: block;\n      }\n      "
                      ))
                    ).call(
                      r,
                      !w &&
                        "\n        &:not(.inline-layout) {\n          transition: margin-top 0.25s;\n        }\n        ",
                      ";\n      "
                    ))
                  ).call(
                    o,
                    E &&
                      "\n        &._alternative {\n          box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n        }\n      ",
                    "\n      & .s-logo-image-1 {\n        display: inline-block;\n      }\n      & .s-logo-image-2 {\n        display: none;\n      }\n    }\n    "
                  ))
                ).call(
                  i,
                  !w &&
                    "\n      & .s-nav-items-and-links li.s-nav-li > .s-nav-link-container {\n        padding: 5px 10px;\n      }\n    ",
                  "\n    "
                ))
              ).call(a, (0, v.XO)(t), ";\n    "))
            ).call(n, (0, p.Eg)(t), ";\n    "))
          ).call(e, (0, p.Gx)(t), ";\n  ");
        },
        templateFunction: function (t) {
          var e = t.LogoImage,
            n = t.LogoTitle,
            a = t.NavItemsAndLinks,
            i = t.NavIcons,
            r = t.NavSocialMedia,
            l = t.NavSocialMediaHasContactList,
            s = t.NavButton,
            u = t.NavContentContainer;
          return (0, o.Z)(
            u,
            {},
            void 0,
            (0, o.Z)(l, {}),
            (0, o.Z)(
              "div",
              { className: "s-nav-inner-wrap" },
              void 0,
              (0, o.Z)("div", { className: "s-logo" }, void 0, (0, o.Z)(e, {})),
              (0, o.Z)(n, {}),
              (0, o.Z)(a, {}),
              (0, o.Z)(
                "div",
                { className: "s-icons" },
                void 0,
                (0, o.Z)(i, {}),
                (0, o.Z)(r, {})
              ),
              (0, o.Z)(s, {})
            )
          );
        },
        enabledNavOptions: y,
        shouldShowFixedNav: function (t, e) {
          return !0;
        },
        shouldShowAlternativeFixedNavVariation: function (t, e, n) {
          return $(window).scrollTop() > 0;
        },
        _centerNavItems: function (t, e) {
          var n,
            o = e.padding,
            r = ".s-navbar-desktop-fixed .s-nav-inner .s-nav-inner-wrap",
            l = $("".concat(r)),
            s = l.width() || 0,
            d = $("".concat(r, " > .s-icons")),
            c = $("".concat(r, " > .s-nav-btn")),
            f = $("".concat(r, " > .s-nav-items-and-links")),
            g = $("".concat(r, " > .s-logo")),
            p = $("".concat(r, " > .s-logo-title")),
            h = $("".concat(r, " .s-logo")).outerWidth() || 0,
            v = $("".concat(r, " .s-logo-title")).outerWidth() || 0,
            b = d.outerWidth() || 0,
            _ = c.outerWidth() || 0,
            C = 0;
          $(
            "".concat(
              r,
              " > .s-nav-items-and-links .s-uncollapsed-nav > .s-nav-li:not(.hidden)"
            )
          ).each(function (t, e) {
            C += $(e).outerWidth();
          });
          var y = $(
              "".concat(
                r,
                " > .s-nav-items-and-links .s-uncollapsed-nav > .s-nav-li.hidden:not(.s-nav-ellipsis)"
              )
            ).length,
            S =
              (null === (n = $("".concat(r, " > div"))) || void 0 === n
                ? void 0
                : u()(n)
                    .call(n, function (t, e) {
                      return $(e).height() || 0;
                    })
                    .get()) || [],
            x = Math.max.apply(Math, (0, i.Z)(S)) || 0,
            w = (s - h - v - b - _ - C) / 2,
            E = s / 4,
            P = m.getIsRtlLayout() ? "left" : "right",
            N = o - 10;
          w > E && y <= 0
            ? (x && l.css("min-height", x),
              g.css({ "z-index": 92 }),
              p.css({ "z-index": 91 }),
              f.css({ position: "absolute", width: "100%" }),
              d.css((0, a.Z)({ position: "absolute" }, P, _ ? _ + o : _ + N)),
              c.css((0, a.Z)({ position: "absolute" }, P, N)))
            : this.resetNavItems();
        },
        resetNavItems: function () {
          var t = ".s-navbar-desktop-fixed .s-nav-inner .s-nav-inner-wrap",
            e = $("".concat(t)),
            n = $("".concat(t, " > .s-icons")),
            i = $("".concat(t, " > .s-nav-btn")),
            o = $("".concat(t, " > .s-nav-items-and-links")),
            r = $("".concat(t, " > .s-logo")),
            l = $("".concat(t, " > .s-logo-title")),
            s = m.getIsRtlLayout() ? "left" : "right";
          r.css({ "z-index": 91 }),
            l.css({ "z-index": 90 }),
            e.css("min-height", "unset"),
            o.css("position", "relative"),
            n.css((0, a.Z)({ position: "relative" }, s, "unset")),
            i.css((0, a.Z)({ position: "relative" }, s, "unset"));
        },
        afterRender: function (t, e, n) {
          var a = n.topContentWidth,
            i = void 0 === a ? "" : a;
          (0, p.MP)(t, c()(e, { topContentWidth: i }));
          var o = e.layout;
          -1 !== g()(C).call(C, o)
            ? this._centerNavItems(e, n)
            : this.resetNavItems();
        },
      };
    },
    91334: function (t, e, n) {
      var a,
        i = n(863056),
        o = n(977766),
        r = n.n(o),
        l = n(678580),
        s = n.n(l),
        u = n(51942),
        d = n.n(u),
        c = (n(366757), n(223336)),
        f = n(611384),
        g = n(31484),
        p = n(183123),
        h = n(156503),
        v = n.n(h),
        m = n(734274),
        b = n(353147),
        _ = [
          "border",
          "colors",
          "padding",
          "backgroundColor1",
          "highlightColor",
          "topContentWidth",
          "isSticky",
          "dropShadow",
        ];
      e.Z = {
        name: "topBlock",
        i18nDisplayName: "Editor|Top Block",
        _nameForPoGenerator: function () {
          return b("Editor|Top Block");
        },
        orientation: "horizontal",
        getStyle: function (t) {
          var e,
            n,
            a,
            i,
            o,
            l,
            u,
            d,
            c,
            h,
            v,
            b,
            C,
            y,
            S,
            x,
            w,
            E,
            P,
            N,
            T,
            k,
            I,
            B,
            D,
            A = m.NAV_ITEM_HORIZONTA_PADDING[t.navTheme.padding],
            M = m.NAV_ITEM_VERTICAL_PADDING[t.navTheme.padding],
            O = 2 * M + (t.fontSizePercentage / 100) * 16,
            L = !p.getNewNavHeaderDesign() || (0, f.nf)(t, _);
          return r()(
            (e = r()(
              (n = r()(
                (a = r()(
                  (i = r()(
                    (o = r()(
                      (l = r()(
                        (u = r()(
                          (d = r()(
                            (c = r()(
                              (h = r()(
                                (v = r()(
                                  (b = r()(
                                    (C = r()(
                                      (y = r()(
                                        (S = r()(
                                          (x = r()(
                                            (w = r()(
                                              (E = r()(
                                                (P = r()(
                                                  (N = r()(
                                                    (T = r()(
                                                      (k = r()(
                                                        (I =
                                                          "\n      padding: 0;\n      box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n      ".concat(
                                                            "centered" ===
                                                              t.topContentWidth &&
                                                              "text-align: center;\n      ",
                                                            ";\n      & .s-nav-items-and-links li {\n        display: inline-block;\n        margin: 0;\n      }\n      & .s-uncollapsed-nav > .s-nav-li > .s-nav-link-container,\n      & .s-nav-icons .s-nav-li > .s-nav-link-container,\n      &\n        "
                                                          ))
                                                      ).call(
                                                        I,
                                                        "solid" === t.buttonFill
                                                          ? ".s-nav-btn .s-common-button"
                                                          : ".__",
                                                        " {\n        /* .__, moving the & inside the string didn't work with emotion */\n        padding: "
                                                      ))
                                                    ).call(k, M, "px "))
                                                  ).call(
                                                    T,
                                                    A,
                                                    "px;\n      }\n      .s-nav-btn {\n        margin-"
                                                  ))
                                                ).call(
                                                  N,
                                                  t.isRtlLayout
                                                    ? "left"
                                                    : "right",
                                                  ": "
                                                ))
                                              ).call(
                                                P,
                                                A,
                                                "px;\n      }\n      & .s-nav-icons .s-nav-li {\n        margin: 0;\n      }\n      & .s-navbar-dropdown li {\n        display: block;\n      }\n      & .s-navbar-dropdown > ul {\n        border-radius: 0;\n      }\n      & .s-nav-inner .s-nav-inner-wrap {\n        justify-content: center;\n      }\n      &.s-bg-dark-text .s-navbar-dropdown._down > ul {\n        border-top: 1px solid rgba(0, 0, 0, 0.2);\n      }\n      &.s-bg-light-text .s-navbar-dropdown._down > ul {\n        border-top: 1px solid rgba(255, 255, 255, 0.2);\n      }\n\n      & .s-nav-inner {\n        .s-nav-social-media:not(.has-social-media-contact-list) {\n          .social-media-link {\n            margin: 0 7px;\n          }\n        }\n        .s-nav-social-media.has-social-media-contact-list {\n          margin: 0 auto;\n          "
                                              ))
                                            ).call(
                                              E,
                                              "section" === t.topContentWidth &&
                                                "\n            padding: 8px calc((100% - ".concat(
                                                  t.sectionContentWidth.normal,
                                                  ") / 2);\n          "
                                                ),
                                              ";\n          "
                                            ))
                                          ).call(
                                            w,
                                            "centered" === t.topContentWidth &&
                                              "\n            justify-content: center;\n          ",
                                            ";\n        }\n        .s-nav-inner-wrap {\n          display: flex;\n          align-items: center;\n          padding-"
                                          ))
                                        ).call(
                                          x,
                                          t.isRtlLayout ? "left" : "right",
                                          ": "
                                        ))
                                      ).call(
                                        S,
                                        t.padding - A,
                                        "px;\n          "
                                      ))
                                    ).call(
                                      y,
                                      "section" === t.topContentWidth &&
                                        "max-width: ".concat(
                                          t.sectionContentWidth.normal,
                                          ";"
                                        ),
                                      "\n          "
                                    ))
                                  ).call(
                                    C,
                                    "centered" === t.topContentWidth &&
                                      "\n            display: inline-flex;\n          ",
                                    ";\n        }\n      }\n      & .s-logo-title {\n        font-size: 120%;\n        margin-left: "
                                  ))
                                ).call(b, A, "px;\n        margin-right: "))
                              ).call(
                                v,
                                A,
                                "px;\n        flex-shrink: 0;\n        white-space: nowrap;\n        > div {\n          display: inline-block;\n        }\n      }\n      & .s-topBlock-spacer {\n        "
                              ))
                            ).call(
                              h,
                              s()((B = ["section", "full"])).call(
                                B,
                                t.topContentWidth
                              ) && "\n          flex-grow: 1;\n        ",
                              ";\n      }\n      & .s-logo {\n        max-width: 200px;\n        /* The logo placeholder in the editor is too tall, which causes\n           whitespace above and below nav items if there's no logo and the\n           nav padding is small */\n        "
                            ))
                          ).call(
                            c,
                            !t.hasLogoImage1 &&
                              "small" === t.navTheme.padding &&
                              "\n          margin-top: -5px;\n          margin-bottom: 0px;\n        ",
                            ";\n      }\n      & .s-logo-image img {\n        max-height: "
                          ))
                        ).call(
                          d,
                          O,
                          "px;\n      }\n      & .s-common-button {\n        padding: 12px 20px;\n        box-shadow: none;\n        box-sizing: border-box;\n        "
                        ))
                      ).call(
                        u,
                        "solid" === t.buttonFill &&
                          "\n          border-radius: 0;\n        ",
                        ";\n        "
                      ))
                    ).call(
                      l,
                      "ghost" === t.buttonFill &&
                        r()(
                          (D = "\n          padding: ".concat(M / 2, "px "))
                        ).call(
                          D,
                          A / 2,
                          "px;\n          margin-right: 10px;\n        "
                        ),
                      ";\n      }\n\n      "
                    ))
                  ).call(
                    o,
                    "solid" === t.buttonFill &&
                      "\n        & .s-common-button {\n          height: ".concat(
                        O,
                        "px;\n          display: flex;\n          align-items: center;\n        }\n      "
                      ),
                    ";\n\n      & .s-nav-icons > .s-nav-li,\n      & .s-uncollapsed-nav > .s-nav-li,\n      & .s-nav-ellipsis {\n        box-sizing: border-box;\n      }\n\n      &.s-navbar-desktop-normal {\n        visibility: hidden;\n        opacity: 0;\n      }\n\n      &.s-navbar-desktop-fixed {\n        @media screen and (min-width: 728px) {\n          display: block;\n        }\n        &:not(.inline-layout) {\n          transition: all 0.25s;\n        }\n        "
                  ))
                ).call(
                  i,
                  L &&
                    "&._show {\n            box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n          }",
                  "\n\n        & .s-logo-image-1 {\n          display: inline-block;\n        }\n        & .s-logo-image-2 {\n          display: none;\n        }\n      }\n\n      "
                ))
              ).call(a, (0, g.Yc)(t), ";\n      "))
            ).call(n, (0, f.Eg)(t), ";\n      "))
          ).call(e, (0, f.Gx)(t), ";\n    ");
        },
        templateFunction: function (t) {
          var e = t.LogoImage,
            n = t.LogoTitle,
            o = t.NavItemsAndLinks,
            r = t.NavIcons,
            l = t.NavButton,
            s = t.NavSocialMedia,
            u = t.NavContentContainer,
            d = t.NavSocialMediaHasContactList;
          return (0, i.Z)(
            u,
            {},
            void 0,
            (0, i.Z)(d, {}),
            (0, i.Z)(
              "div",
              { className: "s-nav-inner-wrap" },
              void 0,
              (0, i.Z)("div", { className: "s-logo" }, void 0, (0, i.Z)(e, {})),
              (0, i.Z)(n, {}),
              a || (a = (0, i.Z)("div", { className: "s-topBlock-spacer" })),
              (0, i.Z)(o, {}),
              (0, i.Z)(r, {}),
              (0, i.Z)(s, {}),
              (0, i.Z)(l, {})
            )
          );
        },
        enabledNavOptions: _,
        getDropdownBackgroundColor: function (t, e) {
          return e;
        },
        shouldShowFixedNav: function (t, e) {
          var n = c(".s-first-visible-section");
          return (
            p.getIsBlog() && (n = c(".s-blog-header")),
            0 !== n.length &&
              c(window).scrollTop() >= c(window).height() - v().get("navHeight")
          );
        },
        shouldShowAlternativeFixedNavVariation: function (t, e, n) {
          return c(window).scrollTop() > 0;
        },
        afterRender: function (t, e, n, a) {
          var i = t.fixed.container,
            o = n.topContentWidth,
            r = void 0 === o ? "" : o,
            l = n.isSticky;
          (0, f.MP)(t, d()(e, { topContentWidth: r }));
          var s = 0;
          a.showFixedNavAlternativeVariation ||
            (s = null != a && a.isPreviewMode && l ? 30 : 0),
            i.css("top", s);
        },
      };
    },
    856621: function (t, e, n) {
      var a = n(863056),
        i = n(977766),
        o = n.n(i),
        r = n(694473),
        l = n.n(r),
        s = (n(366757), n(611384)),
        u = n(183123),
        d = n(31484),
        c = n(353147),
        f =
          "&.rtl-layout .s-component-overlay {\n  margin-left: 0;\n  margin-right: -8px;\n}",
        g = { extra: 45, large: 30, medium: 20, small: 10 },
        p = [
          "colors",
          "padding",
          "backgroundColor1",
          "topContentWidth",
          "highlightColor",
          "isSticky",
          "itemSpacing",
          "border",
          "dropShadow",
          "highlight",
        ];
      e.Z = {
        name: "topCenter",
        i18nDisplayName: "Editor|Top Center",
        _nameForPoGenerator: function () {
          return c("Editor|Top Center");
        },
        orientation: "horizontal",
        nullHighlightColorMeansUnderline: !0,
        getStyle: function (t) {
          var e,
            n,
            a,
            i,
            r,
            l,
            c,
            h,
            v,
            m,
            b,
            _,
            C,
            y,
            S,
            x = g[t.navTheme.padding],
            w = !u.getNewNavHeaderDesign() || (0, s.nf)(t, p);
          return o()(
            (e = o()(
              (n = o()(
                (a = o()(
                  (i = o()(
                    (r = o()(
                      (l = o()(
                        (c = o()(
                          (h = o()(
                            (v = o()(
                              (m = o()(
                                (b = o()(
                                  (_ = o()(
                                    (C = o()(
                                      (y = o()(
                                        (S =
                                          "\n      text-align: center;\n      & .s-nav-items-and-links {\n        ".concat(
                                            "\n            &.s-nav-icons {\n              display: flex;\n            }\n            & .s-nav-logo-wrapper .s-icon-button {\n              display: flex;\n              height: unset;\n              align-items: center;\n            }\n          ",
                                            "\n        margin-left: -10px;\n      }\n      & .s-logo-image {\n        margin-bottom: 15px;\n      }\n      & .s-logo-title {\n        margin-bottom: 15px;\n      }\n      & ul.s-uncollapsed-nav > li {\n        display: inline-block;\n        padding: 5px 10px;\n      }\n      & ul li._compact {\n        padding-left: 4px;\n        padding-right: 4px;\n      }\n      & .s-button {\n        display: inline-block;\n      }\n\n      & .s-logo-image img {\n        max-height: 150px;\n      }\n\n      &.s-navbar-desktop-normal .s-nav-inner {\n        opacity: 1;\n\n        &._hide {\n          opacity: 0;\n        }\n      }\n\n      &.s-navbar-desktop-fixed {\n        opacity: 0;\n        pointer-events: none;\n        transition: top 0.5s, opacity .25s ease-out;\n        & .s-nav-inner {\n          .s-nav-social-media.has-social-media-contact-list {\n            padding: 8px "
                                          ))
                                      ).call(
                                        S,
                                        x,
                                        "px 8px;\n            margin: 0 auto;\n            "
                                      ))
                                    ).call(
                                      y,
                                      "section" === t.topContentWidth &&
                                        "\n              padding: 8px calc((100% - ".concat(
                                          t.sectionContentWidth.normal,
                                          ") / 2);\n            "
                                        ),
                                      ";\n            "
                                    ))
                                  ).call(
                                    C,
                                    "centered" === t.topContentWidth &&
                                      "\n              justify-content: center;\n            ",
                                    ";\n          }\n          .s-nav-inner-wrap {\n            display: flex;\n            align-items: center;\n            padding: "
                                  ))
                                ).call(_, x, "px;\n            "))
                              ).call(
                                b,
                                "section" === t.topContentWidth &&
                                  "max-width: ".concat(
                                    t.sectionContentWidth.normal,
                                    ";"
                                  ),
                                "\n            "
                              ))
                            ).call(
                              m,
                              "centered" === t.topContentWidth &&
                                "\n                display: inline-flex;\n              ",
                              ";\n            & .s-logo-title {\n              font-size: 120%;\n              margin-left: 10px;\n              margin-right: 10px;\n              margin-bottom: 0;\n              "
                            ))
                          ).call(
                            v,
                            f,
                            "\n            }\n            & .s-logo {\n              max-width: 200px;\n            }\n            & .s-logo-image {\n              margin: "
                          ))
                        ).call(
                          h,
                          t.isRtlLayout ? "0 0 0 10px" : "0 10px 0 0",
                          ";\n              "
                        ))
                      ).call(
                        c,
                        f,
                        "\n            }\n            & .s-logo-image img {\n              max-height: 60px;\n            }\n            & .s-nav-btn {\n              margin: "
                      ))
                    ).call(
                      l,
                      t.isRtlLayout ? "0 10px 0 0" : "0 0 0 10px",
                      ";\n            }\n            & .s-common-button {\n              padding: 12px 20px;\n            }\n            & .s-nav-items-and-links {\n              flex-grow: 1;\n              text-align: left;\n              margin-left: unset;\n              .s-uncollapsed-nav {\n                display: block;\n                & li {\n                  display: inline-block;\n                  &.hidden {\n                    display: none;\n                  }\n                }\n              }\n              .s-collapsed-nav > li {\n                display: block;\n              }\n            }\n            & .s-navbar-dropdown li {\n              display: block;\n            }\n          }\n        }\n\n        &._show {\n          top: 0;\n          opacity: 1;\n          pointer-events: all;\n        }\n\n        &._hide {\n          top: -300px\n          opacity: 0;\n        }\n        &._alternative {\n          &._alternativeNavBackgroundColorIsDifferentFromNormal {\n            &._show {\n              /* if translucent nav changes to white we want to animate that */\n              transition: opacity 0.3s;\n            }\n          }\n        }\n        "
                    ))
                  ).call(
                    r,
                    w &&
                      "&._alternative {\n            box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n          }",
                    "\n      }\n\n      "
                  ))
                ).call(i, (0, d.XO)(t), ";\n      "))
              ).call(a, (0, s.Eg)(t), ";\n      "))
            ).call(n, (0, s.Gx)(t), ";\n      "))
          ).call(e, (0, s.es)(), ";\n    ");
        },
        templateFunction: function (t) {
          var e = t.LogoImage,
            n = t.LogoTitle,
            i = t.NavItemsAndLinks,
            o = t.NavIcons,
            r = t.NavButton,
            l = t.NavContentContainer;
          return (0, a.Z)(
            l,
            {},
            void 0,
            (0, a.Z)(
              "div",
              { className: "s-logo" },
              void 0,
              (0, a.Z)(e, {}),
              (0, a.Z)("div", {}, void 0, (0, a.Z)(n, {}))
            ),
            (0, a.Z)(
              "div",
              { className: "s-nav-top-center-item-container" },
              void 0,
              (0, a.Z)(i, {}),
              (0, a.Z)(o, {}),
              (0, a.Z)(r, {})
            )
          );
        },
        newLayoutTemplateFunction: function (t) {
          var e = t.LogoImage,
            n = t.LogoTitle,
            i = t.NavItemsAndLinks,
            o = t.NavIcons,
            r = t.NavSocialMedia,
            l = t.NavSocialMediaHasContactList,
            s = t.NavButton,
            u = t.NavContentContainer;
          return (0, a.Z)(
            u,
            {},
            void 0,
            (0, a.Z)(l, {}),
            (0, a.Z)(
              "div",
              { className: "s-nav-inner-wrap" },
              void 0,
              (0, a.Z)(
                "div",
                { className: "s-nav-logo-wrapper" },
                void 0,
                (0, a.Z)(
                  "div",
                  { className: "s-logo" },
                  void 0,
                  (0, a.Z)(e, {}),
                  (0, a.Z)("div", {}, void 0, (0, a.Z)(n, {}))
                ),
                (0, a.Z)(
                  "div",
                  { className: "s-icon-button" },
                  void 0,
                  (0, a.Z)(o, {}),
                  (0, a.Z)(s, {})
                )
              ),
              (0, a.Z)(
                "div",
                { className: "s-nav-top-center-item-container" },
                void 0,
                (0, a.Z)(i, {}),
                (0, a.Z)(r, {})
              )
            )
          );
        },
        newLayoutFixedTemplateFunction: function (t) {
          var e = t.LogoImage,
            n = t.LogoTitle,
            i = t.NavItemsAndLinks,
            o = t.NavIcons,
            r = t.NavSocialMedia,
            l = t.NavSocialMediaHasContactList,
            s = t.NavButton,
            u = t.NavContentContainer;
          return (0, a.Z)(
            u,
            {},
            void 0,
            (0, a.Z)(l, {}),
            (0, a.Z)(
              "div",
              { className: "s-nav-inner-wrap" },
              void 0,
              (0, a.Z)("div", { className: "s-logo" }, void 0, (0, a.Z)(e, {})),
              (0, a.Z)(n, {}),
              (0, a.Z)(i, {}),
              (0, a.Z)(
                "div",
                { className: "s-icons" },
                void 0,
                (0, a.Z)(o, {}),
                (0, a.Z)(r, {})
              ),
              (0, a.Z)(s, {})
            )
          );
        },
        enabledNavOptions: p,
        estimateNavHeight: function (t) {
          return 60 + 2 * t.padding + 130;
        },
        shouldShowFixedNav: function (t, e) {
          var n = t.normal.container,
            a =
              (t.fixed.container,
              l()(n).call(n, ".s-nav-top-center-item-container"));
          return $(window).scrollTop() > a.offset().top - 10;
        },
        shouldHideNormalNav: function (t, e) {
          return e.shouldShowFixedNav(t, e);
        },
        shouldShowAlternativeFixedNavVariation: function (t, e) {
          var n = t.normal.container,
            a = t.fixed.container;
          return $(window).scrollTop() + a.outerHeight() > n.outerHeight();
        },
        afterRender: function (t, e) {
          (0, s.MP)(t, e, !0);
        },
      };
    },
    930729: function (t, e, n) {
      var a = n(863056),
        i = n(977766),
        o = n.n(i),
        r = n(694473),
        l = n.n(r),
        s = n(703649),
        u = n.n(s),
        d = (n(366757), n(223336)),
        c = n(611384),
        f = n(31484),
        g = n(183123),
        p = n(156503),
        h = n.n(p),
        v = n(353147),
        m = [
          "colors",
          "padding",
          "backgroundColor1",
          "isTransparent",
          "highlightColor",
          "border",
          "isSticky",
          "itemSpacing",
          "dropShadow",
          "highlight",
        ];
      e.Z = {
        name: "topRadial",
        i18nDisplayName: "Editor|Top Radial",
        _nameForPoGenerator: function () {
          return v("Editor|Top Radial");
        },
        orientation: "horizontal",
        nullHighlightColorMeansUnderline: !0,
        getStyle: function (t) {
          var e,
            n,
            a,
            i,
            r = !g.getNewNavHeaderDesign() || (0, c.nf)(t, m);
          return o()(
            (e = o()(
              (n = o()(
                (a = o()(
                  (i =
                    "\n    text-align: center;\n    & .s-logo-title {\n      margin-top: 10px;\n    }\n    & ul {\n      text-align: left;\n    }\n    & .s-nav-btn {\n      white-space: nowrap;\n    }\n    & ul.s-uncollapsed-nav,\n    & .s-nav-items-and-links {\n      display: inline;\n      .s-nav-link-container .fa-search {\n        margin-left: 10px;\n      }\n    }\n    & ul.s-uncollapsed-nav > li {\n      display: inline-block;\n      padding: 5px 10px;\n    }\n    & ul.s-collapsed-nav > li {\n      display: block;\n      &.hidden {\n        display: none;\n      }\n    }\n\n    & .s-logo {\n      display: inline-block;\n      max-width: 200px;\n    }\n\n    & ul li._compact {\n      padding-left: 4px;\n      padding-right: 4px;\n    }\n\n    & .s-nav-inner {\n      position: relative;\n    }\n\n    & .s-nav-icons {\n      & .s-nav-li {\n        display: inline-block;\n      }\n    }\n\n    & .s-topRadial-items-container {\n      display: flex;\n      align-items: center;\n      justify-content: center;\n    }\n\n    & .s-topRadial-nav-left,\n    & .s-topRadial-nav-right {\n      width: 40%;\n      display: inline-block;\n    }\n    & .s-topRadial-nav-left {\n      text-align: right;\n      margin-right: 20px;\n    }\n    & .s-topRadial-nav-right {\n      text-align: left;\n      margin-left: 20px;\n    }\n\n    & .s-nav-icons,\n    & .s-nav-btn {\n      display: inline-block;\n    }\n\n    & .s-logo-image img {\n      max-height: 50px;\n    }\n\n    /* Show plain non-radial nav until client-side JS is loaded  */\n    .s-entrance-mask & {\n      & .s-logo {\n        display: none;\n      }\n    }\n\n    &.s-navbar-desktop-fixed {\n      padding: 10px;\n      &:not(.inline-layout) {\n        transition: transform 0.75s;\n        &._show {\n          transform: translateY(0px);\n        }\n      }\n      /* Matches sleek behavior, but should be navHeight instead of hardcoded 250px */\n      transform: translateY(-250px);\n      & .s-logo-title {\n        display: none;\n      }\n      ".concat(
                      r &&
                        "\n        &._alternative {\n          box-shadow: 0 1px rgba(0, 0, 0, 0.12);\n        }\n      ",
                      "\n    }\n\n    "
                    ))
                ).call(i, (0, c.Eg)(t), ";\n    "))
              ).call(a, (0, c.Gx)(t), ";\n    "))
            ).call(n, (0, f.XO)(t), ";\n\n    "))
          ).call(e, !1, "\n  ");
        },
        templateFunction: function (t) {
          var e = t.LogoImage,
            n = t.LogoTitle,
            i = t.NavItemsAndLinks,
            o = t.NavIcons,
            r = t.NavSocialMedia,
            l = t.NavSocialMediaHasContactList,
            s = t.NavButton,
            u = t.NavContentContainer;
          return (0, a.Z)(
            u,
            {},
            void 0,
            (0, a.Z)(l, {}),
            (0, a.Z)(
              "div",
              { className: "s-topRadial-items-container s-nav-inner-wrap" },
              void 0,
              (0, a.Z)(
                "div",
                { className: "s-topRadial-nav-left" },
                void 0,
                (0, a.Z)(i, {})
              ),
              (0, a.Z)(
                "div",
                { className: "s-logo" },
                void 0,
                (0, a.Z)(e, {}),
                (0, a.Z)(n, {})
              ),
              (0, a.Z)(
                "div",
                { className: "s-topRadial-nav-right" },
                void 0,
                (0, a.Z)(i, {}),
                (0, a.Z)(o, {}),
                (0, a.Z)(r, {}),
                (0, a.Z)(s, {})
              )
            )
          );
        },
        enabledNavOptions: m,
        shouldShowFixedNav: function (t, e) {
          var n = d(".s-first-visible-section");
          return (
            g.getIsBlog() && (n = d(".s-blog-header")),
            0 !== n.length &&
              d(window).scrollTop() >= d(window).height() - h().get("navHeight")
          );
        },
        shouldShowAlternativeFixedNavVariation: function () {
          return !0;
        },
        afterRender: function (t, e) {
          function n(t) {
            var n = t.container,
              a = t.navButton,
              i = t.navIcons,
              o = t.navSocialMedia,
              r = t.uncollapsedNavItems;
            if (!(l()(n).call(n, ".big-button-editor").length > 0)) {
              ((n.hasClass("s-navbar-desktop-normal") &&
                !l()(n).call(n, ".image1").length) ||
                (n.hasClass("s-navbar-desktop-fixed") &&
                  !l()(n).call(n, ".image1").length &&
                  !l()(n).call(n, ".image2").length)) &&
                (l()(n).call(n, ".s-topRadial-nav-left").css("margin-right", 0),
                l()(n).call(n, ".s-topRadial-nav-right").css("margin-left", 0));
              var s = l()(n).call(
                  n,
                  ".s-topRadial-nav-left .s-uncollapsed-nav > li"
                ),
                f = l()(n).call(
                  n,
                  ".s-topRadial-nav-right .s-uncollapsed-nav > li"
                ),
                g = l()(n).call(n, ".s-topRadial-nav-right .s-nav-ellipsis"),
                p = l()(n).call(
                  n,
                  ".s-topRadial-nav-right .s-collapsed-nav > li"
                );
              r.removeClass("hidden"),
                p.removeClass("hidden"),
                g.addClass("hidden"),
                i.outerWidth(!0),
                a.outerWidth(!0);
              var h =
                  (i.outerWidth(!0) || 0) +
                  (a.outerWidth(!0) || 0) +
                  (o.outerWidth(!0) || 0) +
                  20,
                v = (0, c.f3)({
                  items: s,
                  containerSizes: [
                    l()(n).call(n, ".s-topRadial-nav-left").width(),
                    l()(n).call(n, ".s-topRadial-nav-right").width() - h,
                  ],
                  navOrientation: e.orientation,
                  spaceForEllipsis: g.outerWidth(),
                });
              if (v.total < s.length) {
                var m = v.perContainer;
                u()(s).call(s, m[0]).addClass("hidden"),
                  u()(f).call(f, 0, m[0]).addClass("hidden"),
                  u()(f)
                    .call(f, m[0] + m[1])
                    .addClass("hidden"),
                  g.removeClass("hidden"),
                  u()(p).call(p, 0, v.total).addClass("hidden");
              } else {
                var b = 0;
                s.each(function (t, e) {
                  d(e).hasClass("hidden") || (b += d(e).outerWidth(!0));
                });
                var _ = (b + h) / 2,
                  C = 0,
                  y = null;
                s.each(function (t, e) {
                  var n = d(e).outerWidth(!0);
                  if ((C += n) >= _) return (y = t), C - _ > n / 2 && y--, !1;
                }),
                  null === y && (y = s.length - 1),
                  u()(s)
                    .call(s, y + 1)
                    .addClass("hidden"),
                  u()(f)
                    .call(f, 0, y + 1)
                    .addClass("hidden");
              }
            }
          }
          n(t.normal), n(t.fixed);
        },
      };
    },
    734274: function (t, e, n) {
      n.r(e),
        n.d(e, {
          NAV_SPACING_CONFIG: function () {
            return a;
          },
          NAV_ITEM_HORIZONTA_PADDING: function () {
            return i;
          },
          NAV_ITEM_VERTICAL_PADDING: function () {
            return o;
          },
        });
      var a = { compact: 7, normal: 10, large: 15 },
        i = { small: 8, medium: 12, large: 16, extra: 24 },
        o = { small: 10, medium: 15, large: 22, extra: 33 };
    },
    360941: function (t, e, n) {
      n.r(e),
        (e.default = [
          "s5Theme",
          "navFont",
          "titleFont",
          "logoFont",
          "bodyFont",
          "buttonFont",
          "headingFont",
          "bodyFontWeight",
        ]);
    },
    835416: function (t, e, n) {
      n.r(e),
        n.d(e, {
          default: function () {
            return o;
          },
        });
      var a = n(496486),
        i = ["sleek", "pitch_new", "bright", "onyx_new"];
      function o(t) {
        var e = { page_scroll: "none" };
        return (
          a.includes(i, t) && (e.page_scroll = "slide_in"),
          (e.image_link_hover = "none"),
          (e.background = "perspective" === t ? "parallax" : "none"),
          e
        );
      }
    },
    884920: function (t, e, n) {
      n.r(e),
        n.d(e, {
          wrapComponentWithReduxStore: function () {
            return h;
          },
          wrapReducerWithBinding: function () {
            return v;
          },
          getReduxComponentProps: function () {
            return m;
          },
          setGlobalStore: function () {
            return b;
          },
          getGlobalStore: function () {
            return _;
          },
        });
      var a,
        i = n(501068),
        o = n.n(i),
        r = n(863056),
        l = n(468420),
        s = n(327344),
        u = n(484441),
        d = n(103020),
        c = n(803362),
        f = n(366757),
        g = n(50533),
        p = n(124218);
      function h(t, e) {
        var n,
          a = (function (a) {
            (0, u.Z)(h, a);
            var i,
              f,
              p =
                ((i = h),
                (f = (function () {
                  if ("undefined" == typeof Reflect || !o()) return !1;
                  if (o().sham) return !1;
                  if ("function" == typeof Proxy) return !0;
                  try {
                    return (
                      Boolean.prototype.valueOf.call(
                        o()(Boolean, [], function () {})
                      ),
                      !0
                    );
                  } catch (t) {
                    return !1;
                  }
                })()),
                function () {
                  var t,
                    e = (0, c.Z)(i);
                  if (f) {
                    var n = (0, c.Z)(this).constructor;
                    t = o()(e, arguments, n);
                  } else t = e.apply(this, arguments);
                  return (0, d.Z)(this, t);
                });
            function h() {
              return (0, l.Z)(this, h), p.apply(this, arguments);
            }
            return (
              (0, s.Z)(h, [
                {
                  key: "render",
                  value: function () {
                    return (
                      n ||
                      (n = (0, r.Z)(
                        g.Provider,
                        { store: e },
                        void 0,
                        (0, r.Z)(t, {})
                      ))
                    );
                  },
                },
              ]),
              h
            );
          })(f.Component);
        return a;
      }
      function v(t, e) {
        var n = e.get();
        return function () {
          var a =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : n,
            i = arguments.length > 1 ? arguments[1] : void 0,
            o = t(a, i);
          return e.set("", o), o;
        };
      }
      function m(t) {
        var e = t.get("type");
        return { path: t._path, dataProps: p[e] ? p[e](t.get()) : t.get() };
      }
      function b(t) {
        a = t;
      }
      function _() {
        return a;
      }
    },
    828125: function (t, e, n) {
      n.d(e, {
        Bu: function () {
          return i;
        },
      }),
        n(974916),
        n(115306),
        n(678580);
      var a = n(468811),
        i = function () {
          return a.v1();
        };
    },
    726469: function (t, e, n) {
      var a, i, o;
      n.d(e, {
        yP: function () {
          return a;
        },
        AQ: function () {
          return i;
        },
        JO: function () {
          return o;
        },
      }),
        (function (t) {
          (t.URL = "url"), (t.QR_CODE = "QRCode");
        })(a || (a = {})),
        (function (t) {
          (t.FONT = "font"), (t.SVG = "svg");
        })(i || (i = {})),
        (function (t) {
          (t.FONT = "font"), (t.SVG = "svg");
        })(o || (o = {}));
    },
    918596: function (t, e, n) {
      n.r(e),
        n.d(e, {
          FOOTER_LOGO_PHRASES: function () {
            return f;
          },
        });
      var a,
        i,
        o,
        r,
        l,
        s = n(863056),
        u = (n(366757), n(117847)),
        d = n(589499),
        c = function () {
          return (0, s.Z)("img", {
            style: { width: "88px", height: "20px" },
            src: (0, d.cdnAssetPath)(u.U.PBS_LOGO),
          });
        },
        f = {
          title: {
            en: function () {
              return (0, s.Z)(
                "div",
                { className: "pbs-text" },
                void 0,
                a ||
                  (a = (0, s.Z)(
                    "span",
                    { className: "pbs-span" },
                    void 0,
                    "Create a site with "
                  )),
                c()
              );
            },
            "zh-TW": function () {
              return (0, s.Z)(
                "div",
                { className: "pbs-text" },
                void 0,
                c(),
                i ||
                  (i = (0, s.Z)(
                    "span",
                    { className: "pbs-span" },
                    void 0,
                    " 輕鬆架設你的網站"
                  ))
              );
            },
            ja: function () {
              return (0, s.Z)(
                "div",
                { className: "pbs-text" },
                void 0,
                c(),
                o ||
                  (o = (0, s.Z)(
                    "span",
                    { className: "pbs-span" },
                    void 0,
                    "を使って、サイトを製作しましょう"
                  ))
              );
            },
            fr: function () {
              return (0, s.Z)(
                "div",
                { className: "pbs-text" },
                void 0,
                r ||
                  (r = (0, s.Z)(
                    "span",
                    { className: "pbs-span" },
                    void 0,
                    "Créer un site avec "
                  )),
                c()
              );
            },
            ar: function () {
              return (0, s.Z)(
                "div",
                { className: "pbs-text" },
                void 0,
                l ||
                  (l = (0, s.Z)(
                    "span",
                    { className: "pbs-span" },
                    void 0,
                    "أنشئ موقعًا باستخدام "
                  )),
                c()
              );
            },
          },
          tooltipText1: {
            en: "This website is built with Strikingly.",
            "zh-TW": "此網站通過 Strikingly 創建。",
            ja: "Strikinglyで作成されたサイトです。",
            fr: "Ce site est construit avec Strikingly.",
            ar: "تم بناء هذا الموقع مع Strikingly.",
          },
          tooltipText2: {
            en: "Create yours today!",
            "zh-TW": "立即免費創建！",
            ja: "今すぐあなたのサイトを作成ください！",
            fr: "Créer le votre aujourd'hui !",
            ar: "اصنع موقعك اليوم!",
          },
          guideText1: {
            en: "This website is built with Strikingly.",
            "zh-TW": "此網站通過 Strikingly 創建。",
            ja: "Strikinglyで作成されたサイトです。",
            fr: "Ce site est construit avec Strikingly.",
            ar: "تم بناء هذا الموقع مع Strikingly.",
          },
          guideText2: {
            en: "Create your FREE website today!",
            "zh-TW": "立即免費擁有一個網站！",
            ja: "今すぐに無料でウェブサイトを作成しましょう！",
            fr: "Créez votre site Web GRATUIT dès aujourd'hui !",
            ar: "أنشئ موقعك المجاني اليوم!",
          },
          startNow: {
            en: "start now",
            "zh-TW": "开始创建",
            ja: "今すぐ始める",
            fr: "démarrez de suite",
            ar: "ابدأ الآن",
          },
        };
    },
    267385: function (t, e, n) {
      n.r(e),
        n.d(e, {
          getBrowserLocale: function () {
            return a;
          },
        });
      var a = function () {
        return (
          navigator &&
          (navigator.language ||
            (navigator.languages && navigator.languages[0]) ||
            navigator.userLanguage)
        );
      };
    },
    596944: function (t, e, n) {
      var a = n(366757),
        i = n(496486);
      t.exports = function () {
        return function () {
          return (
            this.props.tagName,
            this.getCKEditor(),
            this.getDraftEditor(),
            this.getAIEditor(),
            a.createElement(
              "div",
              { className: "s-component s-text" },
              null,
              a.createElement(
                "div",
                { className: this.props.tagClassName },
                this.hasContent()
                  ? a.createElement(
                      "div",
                      i.assign(
                        {},
                        { ref: "content", key: "3469" },
                        this._getContentProps()
                      )
                    )
                  : null
              )
            )
          );
        }.apply(this, []);
      };
    },
    124218: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(51942),
        r = (0, i.default)(o),
        l = n(143393);
      function s(t) {
        return (0, l.Record)(
          (0, r.default)({ id: null, defaultValue: null }, t)
        );
      }
      var u = s({
          type: "Image",
          url: "",
          link_url: "",
          thumb_url: "",
          new_target: !1,
          noCompression: !1,
          caption: "",
          description: "",
          h: null,
          w: null,
          s: null,
          storageKey: null,
          storagePrefix: null,
          format: null,
          storage: null,
          _state: "normal",
          focus: null,
          border_radius: null,
          aspect_ratio: null,
        }),
        d = s({
          type: "Video",
          html: "",
          url: "",
          maxwidth: 700,
          thumbnail_url: "",
          description: "",
          _state: "normal",
        }),
        c = s({
          type: "Media",
          current: "image",
          image: u(),
          video: d(),
          _state: "normal",
        }),
        f = { Image: u, Video: d, Media: c };
      (e.default = f), (t.exports = e.default);
    },
    877909: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(213192),
        r = {
          ActionTypes: (0, (0, i.default)(o).default)({
            SET_SECTION_INDEX: null,
            DID_NAVIGATE_TO_SECTION: null,
            NAVIGATE_TO_HASH: null,
            NAVIGATE_TO_PREVIOUS_SECTION: null,
            NAVIGATE_TO_NEXT_SECTION: null,
            PAGE_CONTENT_UPDATED: null,
            PAGE_MOUNTED: null,
            SWITCH_PAGE: null,
            REPEATABLE_ITEM_MOVED: null,
            TOGGLE_CATEGORY_DRAWER: null,
            GET_BLOG_POSTS_REQUEST: null,
            GET_BLOG_POSTS_SUCCESS: null,
            GET_BLOG_ARCHIVE_POSTS_SUCCESS: null,
            SET_PRODUCT_PAGE_BINDING: null,
            SET_LAST_PAGE_SCROLL_TOP: null,
            SET_PAGE_TYPE: null,
            SET_PAGE_UID: null,
            UPDATE_GENERATING_PAGE_STATUS: null,
            SET_SECTIONS_BY_PAGE: null,
            SET_BLOG_SETTING: null,
            UPDATE_PAGE_DATA: null,
          }),
        };
      (e.default = r), (t.exports = e.default);
    },
    14137: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(855108),
        r = (0, i.default)(o);
      (e.default = new r.default("PageDispatcher")), (t.exports = e.default);
    },
    156503: function (t, e, n) {
      var a = n(223765),
        i = n(752424),
        o = n(663978),
        r = n(834074),
        l = n(60530)(n(60530));
      o(e, "__esModule", { value: !0 });
      var s,
        u = n(717187),
        d = (0, l.default)(u),
        c = p(n(496486)),
        f = p(n(143393));
      function g(t) {
        if ("function" != typeof i) return null;
        var e = new i(),
          n = new i();
        return (g = function (t) {
          return t ? n : e;
        })(t);
      }
      function p(t, e) {
        if (!e && t && t.__esModule) return t;
        if (null === t || ("object" !== a(t) && "function" != typeof t))
          return { default: t };
        var n = g(e);
        if (n && n.has(t)) return n.get(t);
        var i = {},
          l = o && r;
        for (var s in t)
          if ("default" !== s && Object.prototype.hasOwnProperty.call(t, s)) {
            var u = l ? r(t, s) : null;
            u && (u.get || u.set) ? o(i, s, u) : (i[s] = t[s]);
          }
        return (i.default = t), n && n.set(t, i), i;
      }
      var h = c.assign({}, d.default.prototype, {
        emitChange: function () {
          this.emit("element_measurements_event_id");
        },
        init: function (t) {
          t.set(new f.Map()), (s = t);
        },
        getBinding: function () {
          return s;
        },
        set: function (t, e) {
          s.set(t, e), this.emitChange();
        },
        get: function (t) {
          return s.get(t);
        },
      });
      (e.default = h), (t.exports = e.default);
    },
    818166: function (t, e, n) {
      var a = n(223765),
        i = (n(686902), n(14310), n(620116), n(834074)),
        o = (n(778914), n(239649), n(820368), n(663978)),
        r = n(752424),
        l = n(60530)(n(60530));
      o(e, "__esModule", { value: !0 });
      var s = n(359036),
        u = ((0, l.default)(s), n(418777)),
        d = ((0, l.default)(u), n(487672));
      (0, l.default)(d),
        n(241539),
        n(339714),
        n(382526),
        n(141817),
        n(974916),
        n(115306),
        n(864765),
        n(323123);
      var c = n(778914),
        f = (0, l.default)(c),
        g = n(492762),
        p = ((0, l.default)(g), n(981643)),
        h = (0, l.default)(p),
        v = n(359340),
        m = (0, l.default)(v),
        b = n(694473),
        _ = (0, l.default)(b),
        C = n(277149),
        y = (0, l.default)(C),
        S = n(2991),
        x = (0, l.default)(S),
        w = n(977766),
        E = (0, l.default)(w),
        P = n(686902),
        N = (0, l.default)(P),
        T = n(780426),
        k = (0, l.default)(T),
        I = n(666419),
        B = (0, l.default)(I),
        D = n(62462),
        A = (0, l.default)(D),
        M = n(678580),
        O = (0, l.default)(M),
        L = n(620116),
        Z = (0, l.default)(L),
        R = n(729828),
        G = (0, l.default)(R),
        U = n(410062),
        W = (0, l.default)(U),
        F = n(703649),
        H = (0, l.default)(F),
        V = n(25843),
        z = (0, l.default)(V),
        $ = n(560954),
        j = (0, l.default)($),
        J = n(933032),
        K = ((0, l.default)(J), n(496486)),
        X = (0, l.default)(K),
        Y = n(223336),
        q = (0, l.default)(Y),
        Q = n(143393),
        tt = (0, l.default)(Q),
        et = n(717187),
        nt = n(442279),
        at = n(183123),
        it = (0, l.default)(at),
        ot = n(234584),
        rt = (0, l.default)(ot),
        lt = n(843296),
        st = (0, l.default)(lt),
        ut = n(43138),
        dt = (0, l.default)(ut),
        ct = n(815549),
        ft = ((0, l.default)(ct), n(926941)),
        gt = ((0, l.default)(ft), n(14991)),
        pt = (0, l.default)(gt),
        ht = (function (t, e) {
          if (t && t.__esModule) return t;
          if (null === t || ("object" !== a(t) && "function" != typeof t))
            return { default: t };
          var n = Mt(e);
          if (n && n.has(t)) return n.get(t);
          var r = {},
            l = o && i;
          for (var s in t)
            if ("default" !== s && Object.prototype.hasOwnProperty.call(t, s)) {
              var u = l ? i(t, s) : null;
              u && (u.get || u.set) ? o(r, s, u) : (r[s] = t[s]);
            }
          return (r.default = t), n && n.set(t, r), r;
        })(n(636969)),
        vt = n(22874),
        mt = n(79752),
        bt = (0, l.default)(mt),
        _t = n(835416),
        Ct = (0, l.default)(_t),
        yt = n(680523),
        St = (0, l.default)(yt),
        xt = n(877909),
        wt = (0, l.default)(xt),
        Et = n(360941),
        Pt = ((0, l.default)(Et), n(14137)),
        Nt = (0, l.default)(Pt),
        Tt = n(549556),
        kt = ((0, l.default)(Tt), n(727505), n(112525)),
        It = n(329756),
        Bt = n(684961),
        Dt = (0, l.default)(Bt),
        At = n(177897);
      function Mt(t) {
        if ("function" != typeof r) return null;
        var e = new r(),
          n = new r();
        return (Mt = function (t) {
          return t ? n : e;
        })(t);
      }
      var Ot,
        Lt,
        Zt,
        Rt = ["blog", "blog1", "blog2", "blog3"],
        Gt = "page_data_store_event_id",
        Ut = "product_page",
        Wt = "search_page",
        Ft = "item_page",
        Ht = "store_page",
        Vt = "portfolio_categories_page",
        zt = "blog_categories_page",
        $t = "booking_page",
        jt = (0, nt.createSelector)(
          function (t) {
            return t.get("animations");
          },
          function (t) {
            return t.toJS();
          }
        ),
        Jt = X.default.assign({}, et.EventEmitter.prototype, {
          emitChange: function () {
            this.emit(Gt);
          },
          addChangeListener: function (t) {
            return this.on(Gt, t);
          },
          removeChangeListener: function (t) {
            return this.removeListener(Gt, t);
          },
          __set: function (t, e) {
            return this.getBinding().set(t, e);
          },
          get: function (t) {
            var e = this.getBinding();
            return (
              null != t && (e = e.get(t)),
              e && "function" == typeof e.toJS ? e.toJS() : e
            );
          },
          sub: function (t) {
            var e = this.getBinding();
            return null != t && (e = e.sub(t)), e;
          },
          hydrate: function (t, e) {
            var n = JSON.parse((0, m.default)(t));
            return Zt.atomically()
              .set(tt.default.fromJS(this.getDefault(n, e)))
              .commit({ notify: !1 });
          },
          getTemplateVariation: function () {
            if (this.getCustomColors().active) return "custom";
            if (it.default.getIsBlog())
              return rt.default.getIsV4()
                ? $S.blogPostData.pageMeta.templateVariation
                : "default";
            var t = this.get("templateVariation"),
              e = st.default.get(rt.default.getData("theme.name")).variations;
            return (
              null != e
                ? (0, _.default)(e).call(e, function (e) {
                    return e.id === t;
                  })
                : void 0
            )
              ? t
              : "default";
          },
          getTheFirstEmptyMetaDescriptionPage: function () {
            var t,
              e = this,
              n = this.getHomePageUID(),
              a =
                Zt.get("navigation") &&
                Zt.get("navigation").getIn(["items", 1, "id"], "");
            return (
              (0, y.default)(
                (t = this._getAllPageIds(Zt.get("navigation").get("items")))
              ).call(t, function (t) {
                if (t !== n && !e.getMetaDescriptionById(t)) return (a = t);
              }),
              a
            );
          },
          _getAllPageIds: function (t) {
            var e = this,
              n = [];
            return (
              (0, x.default)(t).call(t, function (t) {
                return "dropdown" === t.get("type")
                  ? (n = (0, E.default)(n).call(
                      n,
                      e._getAllPageIds(t.get("items"))
                    ))
                  : "page" === t.get("type")
                  ? n.push(t.get("id"))
                  : void 0;
              }),
              n
            );
          },
          getMetaDescriptionById: function (t) {
            var e;
            return (0, y.default)((e = Zt.get("pages"))).call(e, function (e) {
              if (e.get("uid") === t) return e.get("description");
            });
          },
          hasMetaDescriptionForEachPage: function () {
            var t,
              e = this.getHomePageUID();
            return !(0, y.default)((t = Zt.get("pages"))).call(t, function (t) {
              return t.get("uid") !== e && !t.get("description");
            });
          },
          getCustomColors: function () {
            return it.default.getIsBlog()
              ? null != $S.blogPostData.pageMeta.customColors
                ? $S.blogPostData.pageMeta.customColors
                : {}
              : this.get("customColors") || {};
          },
          getPreviewVariation: function () {
            return it.default.getIsBlog()
              ? null
              : this.getBinding().meta().sub("previewVariation").toJS();
          },
          getTemplateVariationOrPreview: function () {
            return it.default.getIsBlog()
              ? this.getTemplateVariation()
              : this.getBinding().meta().sub("previewVariation").toJS() ||
                  this.getTemplateVariation();
          },
          getIsCustomColorsSelectedOrPreview: function () {
            return "custom" === this.getTemplateVariationOrPreview();
          },
          getTemplateVariationClassNames: function () {
            if (this.getIsCustomColorsSelectedOrPreview())
              return "s-variation-default s-custom-colors";
            var t = (
              this.getTemplateVariationOrPreview() || "default"
            ).toSlug();
            return "s-variation-".concat(t);
          },
          getSiteAnimationClassNames: function () {
            var t = this.getSiteAnimations(),
              e = "";
            return (
              "none" !== t.image_link_hover &&
                (e += "s-animation-image_link_hover-".concat(
                  t.image_link_hover
                )),
              e
            );
          },
          pageHasBackgroundImage: function () {
            for (
              var t = this.getCurrentPageBinding().get("sections"), e = 0;
              e < t.count();

            ) {
              if (
                t.get(e).get("components") &&
                t.get(e).get("components").get("background1") &&
                t.get(e).get("components").get("background1").get("url")
              )
                return !0;
              e++;
            }
            return !1;
          },
          getUserOperation: function () {},
          getShowNav: function () {
            return this.getBinding().get("showNav");
          },
          getShowMobileMenu: function () {
            return this.getBinding().get("showMobileNav");
          },
          getShowNavigationButtons: function () {
            return this.getBinding().get("showNavigationButtons");
          },
          getShowFooter: function () {
            return this.getBinding().get("showFooter");
          },
          getShowShoppingCart: function () {
            return !1 !== this.getBinding().get("showShoppingCartIcon");
          },
          getShowStrikinglyLogo: function () {
            return this.getBinding().get("showStrikinglyLogo");
          },
          getShowCookieNotification: function () {
            return it.default.getIsBlog()
              ? $S.blogPostData.pageData.showCookieNotification
              : this.getBinding().get("showCookieNotification");
          },
          getCookieNotificationArea: function () {
            return it.default.getIsBlog()
              ? $S.blogPostData.pageData.cookieNotificationArea
              : this.getBinding().get("cookieNotificationArea");
          },
          getShowLegacyGallery: function () {
            return this.getBinding().get("showLegacyGallery");
          },
          getIsFullScreenOnlyOneSection: function () {
            var t;
            return null === (t = this.getBinding()) || void 0 === t
              ? void 0
              : t.get("isFullScreenOnlyOneSection");
          },
          getShowTermsAndConditions: function () {
            return this.getBinding()
              ? this.getBinding().get("showTermsAndConditions")
              : it.default.getIsBlog()
              ? $S.siteData.show_terms_and_conditions
              : $S.stores.pageData.showTermsAndConditions;
          },
          getActivateGDPRCompliance: function () {
            return this.getBinding().get("activateGDPRCompliance");
          },
          getNavDropdownFontWeight: function () {
            return this.getBinding().get("navDropdownFontWeight");
          },
          getTermsText: function () {
            return this.getBinding()
              ? this.getBinding().get("termsText")
              : it.default.getIsBlog()
              ? $S.siteData.terms_text
              : $S.stores.pageData.termsText;
          },
          getShowPrivacyPolicy: function () {
            return this.getBinding()
              ? this.getBinding().get("showPrivacyPolicy")
              : it.default.getIsBlog()
              ? $S.siteData.show_privacy_policy
              : $S.stores.pageData.showPrivacyPolicy;
          },
          getPrivacyPolicyText: function () {
            return this.getBinding()
              ? this.getBinding().get("privacyPolicyText")
              : it.default.getIsBlog()
              ? $S.siteData.privacy_policy_text
              : $S.stores.pageData.privacyPolicyText;
          },
          getGDPRHtml: function () {
            return this.getBinding().get("GDPRHtml");
          },
          getPageOptionCheckState: function (t) {
            return this.getBinding().get(t);
          },
          getThemeFontSize: function () {
            var t = this.getS5Theme();
            return t
              ? {
                  body: t.getIn(["section", "baseFontSize"]) || 15,
                  title: t.getIn(["section", "titleFontSize"]) || 36,
                  subTitle: t.getIn(["section", "subtitleFontSize"]) || 18,
                  itemTitle: t.getIn(["section", "itemTitleFontSize"]) || 18,
                  itemSubTitle:
                    t.getIn(["section", "itemSubtitleFontSize"]) || 18,
                }
              : {};
          },
          getIsS6Template: function () {
            var t = !1;
            try {
              it.default.getIsBlog() ||
                (t = this.getBinding().get("isS6Template"));
            } catch (t) {
              console.error(t);
            }
            return t;
          },
          tagAndSerialize: function () {
            var t = ht.compareAndMark(Zt.get()),
              e = this.serialize(),
              n = ht.getLogs();
            return ht.resetChangeLogs(), [e, n, t];
          },
          serialize: function () {
            var t = Zt.toJS();
            return bt.default.deleteMeta(t), t;
          },
          getBinding: function () {
            return Zt;
          },
          getDefault: function (t, e) {
            var n = function (e) {
              var n;
              return (
                bt.default.addMetaId(e),
                (t.productPage = e),
                e.initialPage ||
                  (t.productPage.description &&
                    (t.productPage.description = t.productPage.description
                      .toString()
                      .replace(/\n/g, "<br>")),
                  null != t.productPage.variations &&
                    (0, f.default)((n = t.productPage.variations)).call(
                      n,
                      function (t) {
                        (t.price /= 100), (t.originalPrice /= 100);
                      }
                    )),
                (e.initialPage = !0)
              );
            };
            return (
              $S.stores.productMeta && n($S.stores.productMeta),
              $S.stores.portfolioMeta && n($S.stores.portfolioMeta),
              t.navigation || (t.navigation = {}),
              0 === (0, N.default)(t).length ||
                !e ||
                t.animations ||
                (t.animations = (0, Ct.default)(e)),
              (t.s5Theme = (0, vt.migrateS5StyleConfig)(t.s5Theme, e)),
              bt.default.addMetaId(t)
            );
          },
          getSiteAnimations: function () {
            return it.default.getIsBlog()
              ? null != $S.blogPostData.pageMeta.animations
                ? $S.blogPostData.pageMeta.animations
                : (0, Ct.default)(rt.default.getThemeName())
              : jt(Zt.get());
          },
          getIsMultiPage: function () {
            return it.default.getIsBlog()
              ? $S.blogPostData.pageMeta.multiPage
              : this.getBinding().get("multi_pages");
          },
          getEnableCRMLiveChat: function () {
            return it.default.getIsBlog()
              ? (0, Dt.default)("siteData.live_chat")
              : this.getBinding().get("live_chat");
          },
          getPagesBinding: function () {
            return Zt.sub("pages");
          },
          getPages: function () {
            return Zt.get("pages");
          },
          getPagePathById: function (t) {
            var e = Jt.getPageFromUID(t);
            return St.default.PAGE.SHOW_MULTIPAGE(e.get("path") || "");
          },
          getPageStore: function () {
            return Zt.get();
          },
          getSectionsBinding: function () {
            var t;
            return (0, k.default)((t = this.getPages())).call(t, function (t) {
              return t.get("sections");
            });
          },
          getItemsBinding: function () {
            return Zt.sub("navigation").sub("items");
          },
          getItems: function () {
            var t,
              e = Zt.get("navigation");
            if (e) {
              var n = e.get("items");
              if (n) return n;
            }
            return (0, x.default)((t = this.getPages())).call(t, function (t) {
              return tt.default.fromJS({
                type: "page",
                id: t.get("uid"),
                visibility: !0,
              });
            });
          },
          flattenItems: function (t, e) {
            for (var n = 0, a = (0, B.default)(t); n < a.length; n++) {
              var i = a[n];
              "dropdown" === i.type ? this.flattenItems(i.items, e) : e.push(i);
            }
            return e;
          },
          getFlattenedNavItems: function () {
            var t = this.getItems(),
              e = [];
            return this.flattenItems(t.toJS(), e), e;
          },
          getShowInNavLinks: function (t) {
            if (!this.getIsMultiPage()) return !0;
            var e = Zt.get("navigation");
            if (!e) return !0;
            var n = e.get("links");
            return (
              !n ||
              (0, y.default)(n).call(n, function (e) {
                return e.get("id") === t;
              })
            );
          },
          getPage: function (t) {
            return this.getPagesBinding().get(t);
          },
          getCurrentPageBinding: function () {
            var t = this.getCurrentPageIndex();
            return this.getPagesBinding().sub(t);
          },
          getProductPageBinding: function () {
            return Zt.sub("productPage");
          },
          getSearchPageBinding: function () {
            return Zt.sub("searchPage");
          },
          getAIDescriptions: function () {
            var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "",
              e = rt.default.getDescription(),
              n =
                Jt.get("".concat(t, ".components.slideSettings.description")) ||
                "";
            return { siteDescription: e, sectionDescription: n };
          },
          getCurrentPageUID: function () {
            return it.default.getIsBlog()
              ? Zt.get("id")
              : Zt.get("_selectedPageUID") ||
                  Zt.get("navigation.items.0.id") ||
                  Zt.get("pages.0.uid") ||
                  this.getHomePageUID();
          },
          getInitPageUID: function () {
            return Zt.get("_initPageUID");
          },
          getInitialSectionIndex: function () {
            return Zt.get("_initialSectionIndex") || 1;
          },
          getLastPageUID: function () {
            return (
              Zt.get("_lastPageUID") ||
              Zt.get("navigation.items.0.id") ||
              Zt.get("pages.0.uid")
            );
          },
          isInProductPage: function () {
            return this.getCurrentPageUID() === Ut;
          },
          isInItemPage: function () {
            return this.getCurrentPageUID() === Ft;
          },
          isInStorePage: function () {
            return Jt.getCurrentPageUID() === Ht;
          },
          isInBlogCategoryPage: function () {
            return Jt.getCurrentPageUID() === zt;
          },
          isInPortfolioCategoriesPage: function () {
            return Jt.getCurrentPageUID() === Vt;
          },
          isInAiGeneratePage: function () {
            return Jt.getCurrentPageUID() === kt.PAGE_UID.AI_GENERATE_PAGE;
          },
          getCurrentPageIndex: function () {
            var t = this.getCurrentPageUID();
            return (
              (t !== Ut && t !== Ft) || (t = this.getLastPageUID()),
              this.getPageIndexByUid(t)
            );
          },
          getPageIndexByUid: function (t) {
            var e = this.getPages(),
              n = (0, A.default)(e).call(e, function (e) {
                return e.get("uid") === t;
              });
            return -1 === n && (n = 0), n;
          },
          getAiGeneratePageStatus: function () {
            return Zt.get("isAiGeneratingPage");
          },
          getCurrentPageType: function () {
            return Zt.get("_currentPageType");
          },
          getLastPageScrollTop: function () {
            return Zt.get("_lastPageScrollTop");
          },
          isPageExists: function (t) {
            var e;
            return (0, y.default)((e = this.getPages())).call(e, function (e) {
              return e.get("uid") === t;
            });
          },
          getPageFromUID: function (t) {
            if ("home" === t) return this.getPages().get("0");
            if (t === Ut) return Zt.sub("productPage");
            if (t === Ft) return Zt.sub("itemPage");
            if (t === Wt) return Zt.sub("searchPage");
            if (t === Ht) return Zt.sub("storePage");
            if (t === Vt) return Zt.sub("portfolioCategoriesPage");
            if (t === zt) return Zt.sub("blogCategoriesPage");
            if (t === $t) return Zt.sub("bookingPage");
            var e = this.getPages();
            return (0, _.default)(e).call(e, function (e) {
              return e.get("uid") === t;
            });
          },
          getSections: function () {
            return this.getCurrentPageBinding().get("sections").toJS();
          },
          getSectionsByPageUid: function (t) {
            var e = this.getPageFromUID(t);
            return null != e && e.get("sections")
              ? e.get("sections").toJS()
              : [];
          },
          getS5Theme: function () {
            return Zt.get("s5Theme");
          },
          hasSectionsDataUnderPage: function (t) {
            if (
              (0, O.default)(kt.INDEPENDENT_PAGE).call(kt.INDEPENDENT_PAGE, t)
            )
              return !0;
            var e = (function (t, e) {
                var n = null,
                  a = t.get("pages");
                return (
                  a &&
                    (0, f.default)(a).call(a, function (t, a) {
                      t.get("uid") === e && (n = a);
                    }),
                  n
                );
              })(Zt, t),
              n = Zt.get("pages.".concat(e, ".sections"));
            return !(0, y.default)(n).call(n, function (t) {
              return t.get("components").size <= 1;
            });
          },
          getSectionNames: function () {
            var t;
            return (0, x.default)(
              (t = this.getCurrentPageBinding().get("sections"))
            )
              .call(t, function (t) {
                return t.get("components").get("slideSettings").get("name");
              })
              .toJS();
          },
          getAllSectionBindingWithName: function () {
            var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "",
              e = this.getSectionsBinding();
            return (0, Z.default)(e).call(e, function (e) {
              var n;
              return null === (n = e.get("template_name")) || void 0 === n
                ? void 0
                : (0, G.default)(n).call(n, t);
            });
          },
          getAllSectionsWithName: function () {
            var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "",
              e = [];
            if (this.getIsMultiPage()) {
              var n = Zt.get("pages");
              (0, f.default)(n).call(n, function (t) {
                return (e = (0, E.default)(e).call(
                  e,
                  t.get("sections").toJS()
                ));
              });
            } else e = this.getSections();
            return t
              ? (0, Z.default)(e).call(e, function (e) {
                  var n;
                  return null === (n = e.template_name) || void 0 === n
                    ? void 0
                    : (0, G.default)(n).call(n, t);
                })
              : e;
          },
          isHomePage: function (t) {
            return (
              t === this.getItems().getIn([0, "id"]) ||
              "home" === t ||
              null === t
            );
          },
          getHomePageUID: function () {
            return this.getItems().getIn([0, "id"]) || "home";
          },
          getUIdByPathname: function (t) {
            var e = this.getPages(),
              n =
                (this.getItems(), It.RegexConstants.ECOMMERCE_STORE_PAGE_PATH),
              a = It.RegexConstants.PORTFOLIO_CATEGORIES_PAGE_PATH,
              i = It.RegexConstants.BLOG_CATEGORIES_PAGE_PATH;
            if ("/" === t) return this.getHomePageUID();
            if (
              ((t = t.replace(/\/+$/, "")),
              /^(\/)?([a-zA-Z0-9-]+)?(\/)?store\/products\/\.*/.test(t))
            )
              return Ut;
            if (/^(\/)?([a-zA-Z0-9-]+)?(\/)?booking\/events\/\.*/.test(t))
              return $t;
            if ("preview" === rt.default.getSiteMode()) {
              var o, r;
              if (/^\/s\/sites\/\d+\/search$/.test(t)) return Wt;
              if (
                (0, O.default)((o = location.search)).call(
                  o,
                  "preview_uid=product_page"
                )
              )
                return Ut;
              if (
                (0, O.default)((r = location.search)).call(
                  r,
                  "preview_uid=item_page"
                )
              )
                return Ft;
            }
            if ("show" === rt.default.getSiteMode() && /^\/?search$/.test(t))
              return Wt;
            if (/^(\/)?([a-zA-Z0-9-]+)?(\/)?portfolio\/items\/\.*/.test(t))
              return Ft;
            if (n.test(t)) return Ht;
            if (a.test(t)) return Vt;
            if (i.test(t)) return zt;
            var l,
              s,
              u = (0, _.default)(e).call(e, function (e) {
                return e.get("path") === t;
              });
            if (void 0 === u)
              if ((0, O.default)((l = ["/blog", "/_blog"])).call(l, t)) {
                var d = q.default.url(location.href).param("categoryId");
                (d = d || "all"),
                  void 0 ===
                    (u = (0, _.default)(e).call(e, function (t) {
                      var e;
                      return (0, y.default)((e = t.get("sections"))).call(
                        e,
                        function (t) {
                          return (
                            (0, O.default)(Rt).call(
                              Rt,
                              t.get("template_name")
                            ) &&
                            t
                              .getIn(
                                ["components", "blog1", "category", "id"],
                                "all"
                              )
                              .toString() === d
                          );
                        }
                      );
                    })) &&
                    (u = (0, _.default)(e).call(e, function (t) {
                      var e;
                      return (0, y.default)((e = t.get("sections"))).call(
                        e,
                        function (t) {
                          return (0, O.default)(Rt).call(
                            Rt,
                            t.get("template_name")
                          );
                        }
                      );
                    }));
              } else
                (0, O.default)((s = ["/store", "/_store"])).call(s, t) &&
                  (u = (0, _.default)(e).call(e, function (t) {
                    var e;
                    return (0, y.default)((e = t.get("sections"))).call(
                      e,
                      function (t) {
                        return "ecommerce" === t.get("template_name");
                      }
                    );
                  }));
            return u && u.get("uid");
          },
          hasSection: function (t) {
            var e = this.getSectionsBinding();
            return "blog" === t
              ? (0, y.default)(e).call(e, function (t) {
                  return (
                    -1 !== (0, h.default)(Rt).call(Rt, t.get("template_name"))
                  );
                })
              : (0, y.default)(e).call(e, function (e) {
                  var n;
                  return null === (n = e.get("template_name")) || void 0 === n
                    ? void 0
                    : (0, G.default)(n).call(n, t);
                });
          },
          hasSectionInPage: function (t, e) {
            return (0, y.default)(X.default).call(
              X.default,
              this.getSectionsByPageUid(e),
              function (e) {
                var n;
                return null === (n = e.template_name) || void 0 === n
                  ? void 0
                  : (0, G.default)(n).call(n, t);
              }
            );
          },
          isHiddenSectionByName: function (t) {
            var e = dt.default.isSmallScreen(),
              n = t.hidden_section,
              a = t.hidden_mobile_section,
              i = e ? (void 0 === a ? n : a) : n;
            return it.default.getCanUseNewMobileEditorFeature() ? i : n;
          },
          getIsHiddenSectionByName: function (t) {
            var e = this,
              n = this.getAllSectionBindingWithName(t);
            return (0, W.default)(n).call(n, function (t) {
              var n;
              return e.isHiddenSectionByName(
                null === (n = t.getIn(["components", "slideSettings"])) ||
                  void 0 === n
                  ? void 0
                  : n.toObject()
              );
            });
          },
          hasInitialProductPage: function () {
            return $S.stores.productMeta;
          },
          pathFirstLevelReserved: function (t) {
            var e = t;
            0 === (0, h.default)(t).call(t, "/") &&
              (e = (0, H.default)(t).call(t, 1, t.length));
            var n = it.default.getReservedMultiPagePaths(),
              a = (0, z.default)(e).call(e).split("/");
            return Boolean(
              (0, _.default)(n).call(n, function (t) {
                return t === a[0];
              })
            );
          },
          pageSecondLevelReserved: function (t) {
            var e = it.default.getReservedMultiPageSecondLevelPaths(),
              n = (0, z.default)(t).call(t).split("/");
            return Boolean(
              (0, _.default)(e).call(e, function (t) {
                return n[0] === t && 2 === n.length && n[1];
              })
            );
          },
          pathExists: function (t, e) {
            return (
              e || (e = Zt.get("pages")),
              Boolean(
                (0, _.default)(e).call(e, function (e) {
                  return e.get("path") === t;
                })
              )
            );
          },
          generatePath: function (t) {
            return (void 0)(this.getPage(t).get("title"), t);
          },
          getPathBySectionId: function (t) {
            var e,
              n,
              a = Zt.get("pages").toJS();
            if (!this.getIsMultiPage())
              return "#".concat(
                "undefined" != typeof hashName && null !== hashName
                  ? hashName
                  : (0, A.default)(X.default).call(
                      X.default,
                      a[0].sections,
                      function (e) {
                        return e.id === t;
                      }
                    ) + 1
              );
            if ("preview" === rt.default.getSiteMode())
              for (
                var i = rt.default.getId(), o = 0, r = (0, B.default)(a);
                o < r.length;
                o++
              ) {
                var l;
                if (
                  ((n = r[o]),
                  -1 !==
                    (e = (0, A.default)(X.default).call(
                      X.default,
                      n.sections,
                      function (e) {
                        return e.id === t;
                      }
                    )))
                )
                  return (0, E.default)(
                    (l = "".concat(
                      St.default.PAGE.PREVIEW_MULTIPAGE(i, n.uid),
                      "#"
                    ))
                  ).call(
                    l,
                    "undefined" != typeof hashName && null !== hashName
                      ? hashName
                      : e + 1
                  );
              }
            else
              for (var s = 0, u = (0, B.default)(a); s < u.length; s++) {
                var d;
                if (
                  ((n = u[s]),
                  -1 !==
                    (e = (0, A.default)(X.default).call(
                      X.default,
                      n.sections,
                      function (e) {
                        return e.id === t;
                      }
                    )))
                )
                  return (0, E.default)((d = "".concat(n.path, "#"))).call(
                    d,
                    "undefined" != typeof hashName && null !== hashName
                      ? hashName
                      : e + 1
                  );
              }
          },
          getUrlBySection: function (t) {
            return (
              rt.default.getPublicUrl().replace(/\/$/, "") +
              this.getPathBySection(t)
            );
          },
          getPathBySection: function (t) {
            var e = null;
            "ecommerce" === t && (e = "store"),
              null != t && (0, G.default)(t).call(t, "blog") && (e = "blog");
            var n,
              a,
              i = Zt.get("pages"),
              o = Zt.get("_currentPageType");
            if (this.getIsMultiPage()) {
              var r,
                l,
                s = Zt.get("navigation.items");
              if (!s) return "/";
              var u = s.get(0) && s.get(0).get("id");
              if ("preview" === rt.default.getSiteMode()) {
                var d = rt.default.getId();
                if ("home" === t)
                  return St.default.PAGE.PREVIEW_MULTIPAGE(d, u);
                for (
                  var c = 0, f = (0, B.default)(i.toJS());
                  c < f.length;
                  c++
                ) {
                  var g, p;
                  if (
                    ((l = f[c]),
                    -1 !==
                      (r = (0, A.default)((g = l.sections)).call(
                        g,
                        function (e) {
                          return e.template_name === t;
                        }
                      )))
                  )
                    return (0, E.default)(
                      (p = "".concat(
                        St.default.PAGE.PREVIEW_MULTIPAGE(d, l.uid),
                        "#"
                      ))
                    ).call(p, null != e ? e : r + 1);
                }
                return "/";
              }
              if ("home" === t)
                return (0, _.default)(i)
                  .call(i, function (t) {
                    return t.get("uid") === u;
                  })
                  .get("path");
              for (var h = 0, v = (0, B.default)(i.toJS()); h < v.length; h++) {
                var m, b;
                if (
                  ((l = v[h]),
                  -1 !==
                    (r = (0, A.default)((m = l.sections)).call(m, function (e) {
                      return "blog" === t
                        ? (0, O.default)(Rt).call(Rt, e.template_name)
                        : e.template_name === t;
                    })))
                )
                  return (0, E.default)((b = "".concat(l.path, "#"))).call(
                    b,
                    null != e ? e : r + 1
                  );
              }
              return "/";
            }
            if ("home" === t) {
              if (it.default.getIsBlog()) return rt.default.getPublicUrl();
              e = "1";
            }
            var C = (0, A.default)((n = i.get(0).get("sections"))).call(
              n,
              function (e) {
                return e.get("template_name") === t;
              }
            );
            return (
              ((0, O.default)(
                (a = [
                  "productPage",
                  "itemPage",
                  "searchPage",
                  "storePage",
                  "bookingPage",
                  "blogCategoriesPage",
                  "portfolioCategoriesPage",
                ])
              ).call(a, o)
                ? "/#"
                : "#") + (null != e ? e : C + 1)
            );
          },
          getBlogSectionUrl: function () {
            var t,
              e,
              n,
              a,
              i,
              o,
              r = (0, j.default)(X.default).call(
                X.default,
                rt.default.getPublicUrl(),
                "/"
              ),
              l = this.getIsMultiPage() ? "_blog" : "",
              s = it.default.getFromSiteToApp();
            return (t = q.default.url(location.href).param("categoryId"))
              ? (0, E.default)(
                  (e = (0, E.default)(
                    (n = (0, E.default)((a = "".concat(r, "/"))).call(
                      a,
                      l,
                      "?"
                    ))
                  ).call(n, s ? "site2app=1" : "", "categoryId="))
                ).call(e, t, "#_blog")
              : (0, E.default)(
                  (i = (0, E.default)((o = "".concat(r, "/"))).call(o, l))
                ).call(i, s ? "?site2app=1" : "", "#_blog");
          },
          getExternalLinkUrl: function (t, e, n, a) {
            if ("section" !== t) return e;
            var i,
              o = rt.default.getData("id");
            n = this.isPageExists(n) ? n : this.getHomePageUID();
            var r = this.getPageFromUID(n),
              l = (0, A.default)((i = r.get("sections"))).call(i, function (t) {
                return t.get("id") === a;
              }),
              s = "#".concat(l >= 1 ? l + 1 : ""),
              u = this.isHomePage(n);
            switch (rt.default.getSiteMode()) {
              case "editor":
                return St.default.PAGE.EDIT_MULTIPAGE(o, n, s);
              case "preview":
                return St.default.PAGE.PREVIEW_MULTIPAGE(o, n, s);
              case "show":
                var d = u ? "/" : r.get("path");
                return St.default.PAGE.SHOW_MULTIPAGE(d, s);
            }
          },
          getSectionIndexById: function () {
            var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "home",
              e = arguments.length > 1 ? arguments[1] : void 0,
              n = this.getSectionsByPageUid(t),
              a = (0, A.default)(n).call(n, function (t) {
                return t.id === e;
              });
            return Math.max(a + 1, 1);
          },
          fillPageIds: function () {
            var t,
              e = this;
            return (0, f.default)((t = this.getBinding().get("pages"))).call(
              t,
              function (t, n) {
                if (!t.get("uid"))
                  return e
                    .getBinding()
                    .set("pages.".concat(n, ".uid"), Ot.v4());
              }
            );
          },
          validatePageData: function () {
            var t = this.getBinding().get().toJS(),
              e = t.pages || [],
              n = "";
            e.length >
              (0, At.uniqBy)(function (t) {
                return t.uid;
              })(e).length && (n += "Duplicated page uid  ");
            for (
              var a = function (t) {
                  var a = e[t],
                    i = (0, A.default)(X.default).call(
                      X.default,
                      e,
                      function (t) {
                        return a.id === t.id;
                      }
                    ),
                    o = (0, A.default)(X.default).call(
                      X.default,
                      e,
                      function (t) {
                        return a.uid === t.uid;
                      }
                    );
                  i !== t &&
                    ((n += "Duplicated pageId: ".concat(a.id, ",  ")),
                    (a.id = "f_".concat(Ot.v4()))),
                    o !== t &&
                      ((n += "Duplicated uId: ".concat(a.uid, ",  ")),
                      (a.uid = Ot.v4()));
                },
                i = e.length - 1;
              i >= 0;
              --i
            )
              a(i);
            if (t.multi_pages) {
              var o = t.navigation,
                r = o.items;
              if (r) {
                var l = (0, Z.default)(r).call(r, function (t) {
                  return "page" === t.type;
                });
                (0, f.default)(l).call(l, function (t) {
                  -1 ===
                    (0, A.default)(X.default).call(X.default, e, function (e) {
                      return e.uid === t.id;
                    }) &&
                    ((r = (0, Z.default)(r).call(r, function (e) {
                      return e.id !== t.id;
                    })),
                    (n += "Navigation uid is not defined "));
                }),
                  (o.items = (0, Z.default)(r).call(r, function (t) {
                    return t;
                  }));
              }
            }
            return n && this.getBinding().set(tt.default.fromJS(t)), t;
          },
          getNavLayoutName: function () {
            var t, e, n, a;
            return it.default.getIsBlog()
              ? null === (n = $S.blogPostData) ||
                void 0 === n ||
                null === (a = n.s5Theme) ||
                void 0 === a
                ? void 0
                : a.nav.layout
              : null === (t = $S.stores.pageData) ||
                void 0 === t ||
                null === (e = t.s5Theme) ||
                void 0 === e
              ? void 0
              : e.nav.layout;
          },
          getCategorySettings: function (t) {
            var e,
              n =
                null === (e = Zt) || void 0 === e
                  ? void 0
                  : e.get("categorySettings");
            return t ? (null == n ? void 0 : n.get(t)) : n;
          },
          init: function (t) {
            return (Lt = new pt.default(t)), (Zt = Lt.binding);
          },
        });
      (Jt.dispatchToken = Nt.default.register(function (t) {
        switch (t.actionType) {
          case wt.default.ActionTypes.SWITCH_PAGE:
            !(function (t, e) {
              var n = Zt.get("_selectedPageUID"),
                a = Zt.atomically();
              if (t === Ut)
                a.set("_currentPageType", "productPage"),
                  a.set("_lastPageUID", n);
              else if (t === Wt) a.set("_currentPageType", "searchPage");
              else if (t === Ft)
                a.set("_currentPageType", "itemPage"), a.set("_lastPageUID", n);
              else if (t === Ht)
                a.set("_currentPageType", "storePage"),
                  a.set("_lastPageUID", n);
              else if (t === Vt)
                a.set("_currentPageType", "portfolioCategoriesPage"),
                  a.set("_lastPageUID", n);
              else if (t === zt)
                a.set("_currentPageType", "blogCategoriesPage"),
                  a.set("_lastPageUID", n);
              else if (t === $t)
                a.set("_currentPageType", "bookingPage"),
                  a.set("_lastPageUID", n);
              else {
                a.set("_currentPageType", "sitePage"),
                  (t = Jt.isPageExists(t) ? t : Jt.getHomePageUID());
                var i = Jt.getSectionIndexById(t, void 0);
                a.set("_initialSectionIndex", i);
              }
              a.set("_selectedPageUID", t), a.commit();
            })(t.uid),
              t.firstTime &&
                ((o = t.uid),
                (r = Zt.atomically()).set("_initPageUID", o),
                r.commit());
            break;
          case wt.default.ActionTypes.UPDATE_PAGE_DATA:
            !(function (t) {
              var e = Zt.atomically(),
                n = X.default.set(
                  t,
                  ["s5Theme", "nav", "itemSpacing"],
                  "compact"
                );
              e.set(tt.default.fromJS(n)).commit();
            })(t.newPageData);
            break;
          case wt.default.ActionTypes.SET_SECTIONS_BY_PAGE:
            !(function (t, e) {
              var n = Zt.atomically(),
                a = Zt.get("pages"),
                i = a.toArray(),
                o = a;
              (0, f.default)(i).call(i, function (n, a) {
                if (n.get("uid") === t) {
                  var i = o.get(a);
                  o = o.set(a, i.merge({ sections: e }));
                }
              }),
                n.set("pages", o).commit();
            })(t.uid, t.sectionsData);
            break;
          case wt.default.ActionTypes.SET_PRODUCT_PAGE_BINDING:
            (i = t.productBinding),
              tt.default.isImmutable(i)
                ? Zt.set("productPage", i)
                : Zt.set("productPage", i.get());
            break;
          case wt.default.ActionTypes.SET_LAST_PAGE_SCROLL_TOP:
            (a = t.scrollTop), Zt.set("_lastPageScrollTop", a);
            break;
          case wt.default.ActionTypes.SET_PAGE_TYPE:
            (n = t.type), Zt.set("_currentPageType", n);
            break;
          case wt.default.ActionTypes.SET_PAGE_UID:
            !(function (t) {
              Zt.set("_selectedPageUID", t);
            })(t.uid);
            break;
          case wt.default.ActionTypes.UPDATE_GENERATING_PAGE_STATUS:
            (e = t.status), Zt.set("isAiGeneratingPage", e);
        }
        var e, n, a, i, o, r;
      })),
        window.DEBUG || (window.DEBUG = {}),
        (window.DEBUG.PageDataStore = Jt),
        (e.default = Jt),
        (t.exports = e.default);
    },
    548273: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o,
        r,
        l = n(694473),
        s = (0, i.default)(l),
        u = n(778914),
        d = (0, i.default)(u),
        c = n(620116),
        f = ((0, i.default)(c), n(496486)),
        g = (0, i.default)(f),
        p = n(717187),
        h = n(143393),
        v = n(684961),
        m = (0, i.default)(v),
        b = n(14991),
        _ = (0, i.default)(b),
        C = {},
        y = { allTranslated: !1 },
        S = g.default.assign(
          {},
          p.EventEmitter.prototype,
          {
            getDefault: function (t) {
              return {
                _open: !1,
                _highlight: !1,
                _category: "suggested",
                sections: {},
                aiThemes: {},
              };
            },
            init: function (t) {
              (o = new _.default(t)), (r = o.binding);
              var e = {};
              for (var n in C) e[n] = C[n].content;
              return r.set("sections", (0, h.fromJS)(e)), o.binding;
            },
            getBinding: function () {
              return r;
            },
            setSelectorData: function (t) {
              if (
                ((C = t),
                (0, m.default)("globalConf.rollout.portfolio_section") ||
                  delete C.portfolio,
                r)
              ) {
                var e = {};
                for (var n in t) e[n] = t[n].content;
                r.set("sections", (0, h.fromJS)(e));
              }
            },
            getSelectorData: function () {
              return C;
            },
            getSectionDataBySectionName: function (t) {
              var e;
              return (
                y.allTranslated ||
                  y[t] ||
                  this.translateContentBySectionName(t),
                (0, s.default)((e = g.default.toArray(C))).call(
                  e,
                  function (e) {
                    return e.content.template_name === t;
                  }
                )
              );
            },
            getSectionDataByKeyValue: function (t, e, n) {
              var a;
              return (
                y.allTranslated ||
                  y[t] ||
                  this.translateContentBySectionName(t),
                (0, s.default)((a = g.default.toArray(C))).call(
                  a,
                  function (a) {
                    var i = a;
                    return (
                      (0, d.default)(e).call(e, function (t) {
                        i = i[t] || {};
                      }),
                      i === n && a.content.template_name === t
                    );
                  }
                )
              );
            },
            translateContentBySectionName: function () {
              var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : null;
              try {
                if (t) {
                  var e = C[t];
                  e.content, (y[t] = !0);
                } else {
                  for (var n in C) {
                    var a = C[n];
                    a.content;
                  }
                  y.allTranslated = !0;
                }
              } catch (t) {
                console.log(t);
              }
            },
          },
          {}
        );
      window.DEBUG || (window.DEBUG = {}),
        (window.DEBUG.SectionSelectorStore = S),
        (e.default = S),
        (t.exports = e.default);
    },
    8689: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 }),
        n(974916),
        n(864765),
        n(241539),
        n(339714);
      var o = n(439969),
        r = (0, i.default)(o),
        l = n(977766),
        s = ((0, i.default)(l), n(51942)),
        u = (0, i.default)(s),
        d = n(981643),
        c = (0, i.default)(d),
        f = n(836808),
        g = ((0, i.default)(f), n(183123)),
        p = (0, i.default)(g),
        h = n(918596),
        v = n(267385),
        m = (n(792681), /blog/g),
        b = ["en", "ja", "zh-TW", "fr"],
        _ = {
          getFooterLogoSeoData: function () {
            var t = ($S.stores && $S.stores.showStatic.footerLogoSeoData) || {},
              e = t.anchor_link;
            return (
              e &&
                m.test(window.location.href) &&
                (e = (function () {
                  var t =
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : "",
                    e = new r.default(t),
                    n = e.searchParams;
                  return (
                    n.set("ref", "blogpbs"),
                    (e.search = n.toString()),
                    e.toString()
                  );
                })(e)),
              e && p.default.getPbsI18n(),
              (0, u.default)({}, t, { anchor_link: e })
            );
          },
          getPhraseWithBrowserLocale: function (t) {
            var e = (0, v.getBrowserLocale)();
            return (0, c.default)(b).call(b, e) > -1
              ? h.FOOTER_LOGO_PHRASES[t][e]
              : h.FOOTER_LOGO_PHRASES[t].en;
          },
          isEditMode: function () {
            return (
              null ==
                (null != $S.stores
                  ? $S.stores.showStatic.isEditMode
                  : void 0) ||
              (null != $S.stores ? $S.stores.showStatic.isEditMode : void 0)
            );
          },
        };
      (e.default = _), (t.exports = e.default);
    },
    843296: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o,
        r = n(432366),
        l = (0, i.default)(r),
        s = n(678580),
        u = (0, i.default)(s),
        d = n(666419),
        c = (0, i.default)(d),
        f = n(2991),
        g = ((0, i.default)(f), n(496486)),
        p = (0, i.default)(g),
        h = n(14637),
        v = (0, i.default)(h),
        m = n(548273),
        b = ((0, i.default)(m), n(549556)),
        _ =
          ((0, i.default)(b),
          {
            selections: function () {
              return (
                o ||
                (o = (0, l.default)(p.default).call(
                  p.default,
                  $S.stores.themes,
                  function (t, e) {
                    return (t[e.internal] = e), t;
                  },
                  {}
                ))
              );
            },
            getSelection: function (t) {
              return this.selections()[t];
            },
            get: function (t) {
              return (
                this.store()[t] ||
                console.error("Theme not registered: [".concat(t, "]"))
              );
            },
            build: function (t) {
              return new v.default(t);
            },
            register: function (t) {
              return (this.store()[t.internal] = t), this.store()[t.internal];
            },
            buildAndRegister: function (t) {
              var e = this.build(t);
              return this.register(e), e;
            },
            isRegistered: function (t) {
              var e;
              return (0, u.default)((e = (0, c.default)(this.store()))).call(
                e,
                t
              );
            },
            store: function () {
              return this.__store || (this.__store = {});
            },
          });
      window.DEBUG || (window.DEBUG = {}),
        (window.DEBUG.ThemeStore = _),
        (e.default = _),
        (t.exports = e.default);
    },
    815549: function (t, e, n) {
      var a;
      n(663978)(e, "__esModule", { value: !0 });
      var i = n(229134);
      (a = n(11767)(i)()), (e.default = a), (t.exports = e.default);
    },
    953198: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(54103),
        r = (0, i.default)(o),
        l = n(176965),
        s = (0, i.default)(l),
        u = n(143393),
        d = (0, i.default)(u),
        c = n(496486),
        f = (0, i.default)(c),
        g = n(8689),
        p = (0, i.default)(g),
        h = {},
        v = {};
      (h.Mixin = {
        boundIndexMemoizer: function (t) {
          var e = [];
          return function (n) {
            var a = e[n];
            return (
              void 0 === a &&
                ((a = (0, r.default)(t).call(t, v, n)), (e[n] = a)),
              a
            );
          };
        },
        componentDidMount: function () {},
        getData: function (t) {
          return this._getBinding().get(t);
        },
        isEditMode: function () {
          return p.default.isEditMode();
        },
        nativeUpdateData: function (t) {
          return this.updateData(t);
        },
        setData: function (t, e) {
          if (!t) throw new Error("key should be provided");
          return this._getBinding().set(t, d.default.fromJS(e));
        },
        updateData: function (t, e) {
          if (!f.default.isUndefined(e))
            throw new Error("updateData with key is deprecated");
          this._getBinding().merge(d.default.fromJS(t));
        },
        _getBinding: function () {
          return this.getDefaultBinding();
        },
        getMergeStrategy: function () {
          return s.default.MergeStrategy.MERGE_PRESERVE;
        },
        isState: function (t) {
          return t === this._getBinding().get("_state");
        },
        updateState: function (t) {
          return this.setData("_state", t);
        },
        savePage: function () {
          return null;
        },
        onClickEditor: function () {
          return (
            this.isState("normal") && this.updateState("editor"),
            "function" == typeof this.afterClickEditor
              ? this.afterClickEditor()
              : void 0
          );
        },
        onClickCancel: function () {
          return (
            "function" == typeof this.constructor.sharedProps
              ? this.constructor.sharedProps().onClickCancel
              : void 0
          )
            ? this.constructor.sharedProps().onClickCancel()
            : this.updateState("normal");
        },
        toggleEditor: function () {
          return this.isState("editor")
            ? this.updateState("normal")
            : (this.updateState("editor"),
              "function" == typeof this.afterClickEditor &&
                this.afterClickEditor(),
              null != window.DEBUG
                ? (window.DEBUG.activeComponent = this)
                : void 0);
        },
      }),
        (v = h),
        (e.default = v),
        (t.exports = e.default);
    },
    237161: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(729828),
        r = (0, i.default)(o),
        l = n(678580),
        s = (0, i.default)(l),
        u = n(686902),
        d = (0, i.default)(u),
        c = n(977766),
        f = (0, i.default)(c),
        g = n(51942),
        p = (0, i.default)(g),
        h = n(176965),
        v = (0, i.default)(h),
        m = n(143393),
        b = (0, i.default)(m),
        _ = n(496486),
        C = (0, i.default)(_),
        y = n(8689),
        S = (0, i.default)(y),
        x = n(79752),
        w = (0, i.default)(x),
        E = n(443198),
        P = (0, i.default)(E),
        N = n(182410),
        T = (0, i.default)(N),
        k = {},
        I = {
          componentWillReceiveProps: function (t) {
            var e = this.props.layout;
            (this.dtProps = t),
              (this.dsProps = t),
              (this.iProps = t),
              (this.cbProps = t),
              null != t.layout && t.layout !== e && this.forceUpdate();
          },
          componentWillMount: function () {
            (this.dtProps = this.props),
              (this.dsProps = this.props),
              (this.iProps = this.props),
              (this.cbProps = this.props);
          },
          getData: function (t) {
            var e = this._getBinding();
            return null == e ? void 0 : e.get(t);
          },
          componentDidMount: function () {
            "editor" === this.props._state &&
              "function" == typeof this.startEditContent &&
              this.startEditContent();
          },
          componentWillUpdate: function (t) {
            var e = this.props.layout;
            null != e &&
              t.layout !== e &&
              "function" == typeof this.beforeLayoutChange &&
              this.beforeLayoutChange();
          },
          componentDidUpdate: function (t) {
            var e = this.props.layout;
            null != e &&
              t.layout !== e &&
              "function" == typeof this.afterLayoutChange &&
              this.afterLayoutChange(),
              this.trackEditBehavior(this.props, t);
          },
          isEditMode: function () {
            return S.default.isEditMode();
          },
          isAdminMode: function () {
            var t = this.props.isAdmin;
            return void 0 !== t ? t : n(914990).isAdmin();
          },
          setData: function (t, e) {
            if (!t) throw new Error("key should be provided");
            if (C.default.isUndefined(this._getBinding().get()))
              console.error("attempt to update a non-existing binding");
            else {
              var n = this._getBinding();
              (0, r.default)(C.default).call(C.default, t, "_") ||
                n.set("defaultValue", !1),
                n.set(t, b.default.fromJS(e));
            }
          },
          updateData: function (t, e) {
            if (!C.default.isUndefined(e))
              throw new Error("updateData with key is deprecated");
            if (C.default.isUndefined(this._getBinding().get()))
              throw new Error("attempt to update a non-existing binding");
            P.default.log(
              "updateData",
              this.constructor.displayName,
              this.getDefaultBinding().toJS(),
              t,
              e
            );
            var n = this._getBinding(),
              a = {
                actionType: "UPDATE_DATA",
                data: t,
                componentType: this.constructor.displayName,
              };
            T.default.pushAction("BasePageComponent", a),
              n.merge(
                b.default.fromJS(C.default.merge(t, { defaultValue: !1 }))
              );
          },
          _checkKey: function (t) {
            var e, n;
            if (!this.constructor.dataProps)
              throw new Error(
                "bobcatPropTypes.data is undefined for ".concat(
                  this.constructor.displayName
                )
              );
            if (
              "_" !== t.charAt(0) &&
              !(0, s.default)(
                (e = (0, d.default)(this.constructor.dataProps))
              ).call(e, t)
            )
              throw new Error(
                (0, f.default)(
                  (n = "key '".concat(
                    t,
                    "' past to updateData which isn't defined in bobcatPropTypes.data for "
                  ))
                ).call(n, this.constructor.displayName)
              );
          },
          _checkData: function (t) {
            for (var e in t) this._checkKey(e);
          },
          _getBinding: function () {
            return this.getDefaultBinding();
          },
          getMergeStrategy: function () {
            return v.default.MergeStrategy.MERGE_PRESERVE;
          },
          isState: function (t) {
            return t === this.props._state;
          },
          updateState: function (t) {
            return null;
          },
          savePage: function () {
            return null;
          },
          trackEditBehavior: function (t, e) {},
          setBehaviorData: function (t, e) {
            var n = this.props,
              a = n.editStateHook,
              i = n.targetId;
            "editor" === t && "editor" !== e
              ? a && "function" == typeof a && a("focus", i)
              : "editor" !== t &&
                "editor" === e &&
                a &&
                "function" == typeof a &&
                a("defocus", i);
          },
          _storeCancelValue: function () {
            this._storedCancelValue = this._getBinding().toJS();
          },
          _restoreCancelValue: function () {
            this._storedCancelValue &&
              (this.updateData(w.default.deleteMeta(this._storedCancelValue)),
              (this._storedCancelValue = null));
          },
          onClickEditor: function (t) {
            return null;
          },
          onToggleMobileViewEditorBox: function (t) {
            if (
              "function" == typeof this.constructor.sharedProps
                ? this.constructor.sharedProps().onToggleEditor
                : void 0
            )
              return this.constructor
                .sharedProps()
                .onToggleEditor.apply(null, [this, t]);
          },
          onClickCancel: function () {
            return null;
          },
          toggleEditor: function () {
            return null;
          },
          addIframeEditingClass: function () {
            return this.isIframeEditing() ? " s-mobile-view-editing-box" : "";
          },
          isIframeEditing: function () {
            return !1;
          },
        };
      (k.Mixin = (0, p.default)({}, I, {
        nativeUpdateData: function (t) {
          this.updateData(t);
        },
      })),
        (e.default = k),
        (t.exports = e.default);
    },
    399069: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(432366),
        r = (0, i.default)(o),
        l = n(169301),
        s = (0, i.default)(l),
        u = n(54103),
        d = (0, i.default)(u),
        c = n(977766),
        f = (0, i.default)(c),
        g = n(678580),
        p = (0, i.default)(g),
        h = n(972555),
        v = (0, i.default)(h),
        m = n(45697),
        b = (0, i.default)(m),
        _ = n(176965),
        C = (0, i.default)(_),
        y = n(496486),
        S = (0, i.default)(y),
        x = n(498481),
        w = (0, i.default)(x),
        E = n(953198),
        P = (0, i.default)(E),
        N = n(936501),
        T = (0, i.default)(N),
        k = n(269393),
        I = (0, i.default)(k),
        B = n(237161),
        D = (0, i.default)(B),
        A = n(205223),
        M = ((0, i.default)(A), n(387937)),
        O = (0, i.default)(M),
        L = n(836034),
        Z = (0, i.default)(L),
        R = n(83124),
        G = ((0, i.default)(R), {}),
        U = {
          _staticBuildBobcatProps: function (t) {
            return function (e) {
              var n,
                a = e.get().toObject();
              return (
                (0, r.default)(
                  (n = (0, s.default)(S.default).call(
                    S.default,
                    S.default.extend({}, t.internal, t.data)
                  ))
                ).call(
                  n,
                  function (t, n) {
                    var a = e.get(n);
                    return S.default.isNull(a) && (a = void 0), (t[n] = a), t;
                  },
                  a
                ),
                (a.binding = { default: e }),
                a
              );
            };
          },
          _getDefaultProps: function (t) {
            return (
              t.internal || (t.internal = {}),
              (t.internal._state = "normal"),
              S.default.extend({}, t.designer, t.internal, t.data, t.callbacks)
            );
          },
          _propTypes: function (t) {
            return (
              t.internal || (t.internal = {}),
              (t.internal._state = b.default.oneOf([
                "normal",
                "editor",
              ]).isRequired),
              S.default.extend(
                {
                  type: b.default.string,
                  id: b.default.string,
                  layout: b.default.string,
                  sectionModel: b.default.object,
                  _cName: b.default.string,
                  defaultValue: b.default.oneOfType([
                    b.default.string,
                    b.default.bool,
                    b.default.object,
                  ]),
                },
                t.designer,
                t.internal,
                t.data,
                t.callbacks
              )
            );
          },
          createPageComponent: function (t) {
            var e;
            t.getDefaultState &&
              console.error(
                "Setting getDefaultState is not allowed, use bobcatPropTypes and getBobcatDefaultProps"
              ),
              t.getDefaultProps &&
                console.error(
                  "Setting getDefaultProps directly is not allowed. Please use getBobcatDefaultProps"
                ),
              t.propTypes &&
                console.error(
                  "Setting propTypes directly is not allowed. Please use bobcatPropTypes"
                ),
              null == t.displayName &&
                console.warn("displayName is not defined");
            var n,
              a,
              i = t.bobcatPropTypes,
              o = t.getBobcatDefaultProps;
            return (
              i ||
                console.warn(
                  "bobcatPropTypes is undefined for ".concat(t.displayName)
                ),
              (t.getDefaultProps = o
                ? (0, d.default)((n = this._getDefaultProps)).call(n, null, o())
                : (0, d.default)((a = this._getDefaultProps)).call(
                    a,
                    null,
                    {}
                  )),
              i &&
                ((t.propTypes = this._propTypes(i)),
                t.statics || (t.statics = {}),
                (t.statics.dataProps = i.data),
                (t.statics.designerProps = i.designer),
                (t.statics.internalProps = i.internal),
                (t.statics.buildBobcatProps = this._staticBuildBobcatProps(i))),
              (t.mixins = S.default.compact(
                (0, f.default)(
                  (e = [D.default.Mixin, T.default, C.default.Mixin, I.default])
                ).call(e, t.mixins)
              )),
              (0, v.default)(t)
            );
          },
          create: function (t) {
            var e;
            if (t.getDefaultState)
              throw new Error(
                "Setting getDefaultState directly is not allowed. Please use bobcatDefaultState"
              );
            var n = t.getBobcatDefaultState;
            n && (t.getDefaultState = n),
              (t.mixins = S.default.compact(
                (0, f.default)(
                  (e = [P.default.Mixin, T.default, C.default.Mixin, I.default])
                ).call(e, t.mixins)
              ));
            var a = (0, v.default)(t);
            return (
              t.reduxUI && (a = (0, w.default)(t.reduxUI)(a)),
              t.mapStateToProps && (a = (0, O.default)(a, t.mapStateToProps)),
              a
            );
          },
          createSection: function (t) {
            return (
              (t = S.default.extend({}, t)).mixins || (t.mixins = []),
              (0, p.default)(S.default).call(S.default, t.mixins, Z.default) ||
                t.mixins.push(Z.default),
              this.create(t)
            );
          },
          get: function (t) {
            return G[t] || null;
          },
          register: function (t, e) {
            return (G[t] = e), this;
          },
          registerSection: function (t, e) {
            return this.register("_SECTION_".concat(t), e);
          },
          getSection: function (t) {
            return this.get("_SECTION_".concat(t));
          },
        };
      (e.default = U), (t.exports = e.default);
    },
    792656: function (t, e, n) {
      var a = n(223765),
        i = n(752424),
        o = n(663978),
        r = n(834074),
        l = n(60530)(n(60530));
      o(e, "__esModule", { value: !0 }),
        n(974916),
        n(115306),
        n(569600),
        n(209653);
      var s = n(981643),
        u = (0, l.default)(s),
        d = n(694473),
        c = (0, l.default)(d),
        f = n(497093),
        g = (0, l.default)(f),
        p = n(359340),
        h = (0, l.default)(p),
        v = n(223336),
        m = (0, l.default)(v),
        b = n(496486),
        _ = (0, l.default)(b),
        C = n(143393),
        y = (0, l.default)(C),
        S = B(n(143268)),
        x = B(n(144726)),
        w = n(43138),
        E = (0, l.default)(w),
        P = n(818166),
        N = (0, l.default)(P),
        T = n(926941),
        k = (0, l.default)(T);
      function I(t) {
        if ("function" != typeof i) return null;
        var e = new i(),
          n = new i();
        return (I = function (t) {
          return t ? n : e;
        })(t);
      }
      function B(t, e) {
        if (!e && t && t.__esModule) return t;
        if (null === t || ("object" !== a(t) && "function" != typeof t))
          return { default: t };
        var n = I(e);
        if (n && n.has(t)) return n.get(t);
        var i = {},
          l = o && r;
        for (var s in t)
          if ("default" !== s && Object.prototype.hasOwnProperty.call(t, s)) {
            var u = l ? r(t, s) : null;
            u && (u.get || u.set) ? o(i, s, u) : (i[s] = t[s]);
          }
        return (i.default = t), n && n.set(t, i), i;
      }
      var D = function (t) {
          var e;
          switch (t) {
            case "cover":
            case "stretch":
              e = "cover";
              break;
            case "contain":
              e = "contain";
              break;
            case "tile":
            case "center":
              e = "unset";
              break;
            default:
              e = "cover";
          }
          return {
            backgroundRepeat: "tile" === t ? "repeat" : "no-repeat",
            backgroundSize: e,
          };
        },
        A = {
          getBgClassName: function (t) {
            var e =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : "";
            return (null != t ? t.userClassName : void 0) || e;
          },
          getTextColorClassName: function (t) {
            var e =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : "";
            if (!t) return "";
            var n = x.createImage(t).getUrl("background");
            if (!S.imageHasContent(n)) return e;
            switch (t.textColor) {
              case "light":
              case "overlay":
                return "s-bg-light-text";
              case "dark":
                return "s-bg-dark-text";
              default:
                return "";
            }
          },
          getBgColorClassName: function (t) {
            if (!t) return "";
            var e = this.getBackgroundColorTextClass(t);
            return e ? "s-bg-".concat("dark" === e ? "white" : "dark") : "";
          },
          convertV3Style: function (t) {
            var e,
              n,
              a =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : [];
            switch (
              (t.selectedClassName &&
                !t.textColor &&
                (-1 !==
                (0, u.default)((e = t.selectedClassName)).call(
                  e,
                  "strikingly-dark-text"
                )
                  ? (t.textColor = "dark")
                  : -1 !==
                    (0, u.default)((n = t.selectedClassName)).call(
                      n,
                      "strikingly-text-overlay"
                    )
                  ? (t.textColor = "overlay")
                  : (t.textColor = "light")),
              t.textColor)
            ) {
              case "light":
                a.push("s-bg-light-text");
                break;
              case "dark":
                a.push("s-bg-dark-text");
                break;
              case "overlay":
                a.push("s-bg-light-text"), a.push("s-bg-overlay");
            }
            return a;
          },
          getContentProps: function (t) {
            var e =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : { size: "background", eagerLoad: !1 },
              n = [],
              a = x.createImage(t),
              i = a.getUrlWithoutFocus(e.size);
            E.default.isMobile() && (i = i.replace(".mp4", ".jpg"));
            var o = {};
            if (t.backgroundColor) {
              var r = this.getBackgroundColorString(t.backgroundColor);
              r && (o = { backgroundColor: r });
            }
            if (S.imageHasContent(i)) {
              t.videoHtml && !E.default.isMobile()
                ? n.push("s-bg-video video-bg s-bg-blurred")
                : n.push("s-bg-image s-bg-blurred"),
                (n = this.convertV3Style(t, n));
              var l = _.default.extend(
                D(t.sizing || t.style),
                {
                  backgroundColor: "transparent",
                  backgroundPosition: "50% 50%",
                },
                o
              );
              return (
                e.eagerLoad &&
                  (l = _.default.assign(l, {
                    backgroundImage: "url(".concat(i, ")"),
                  })),
                t.videoHtml &&
                  ((l.backgroundSize = "cover"),
                  (l.backgroundRepeat = "no-repeat")),
                {
                  image: a,
                  className: n.join(" "),
                  eagerLoad: e.eagerLoad,
                  style: l,
                  videoHtml: t.videoHtml,
                  videoUrl: t.videoUrl,
                  dataSrc: i,
                  textColor: t.textColor,
                  linkUrl: null != t ? t.linkUrl : void 0,
                  linkTarget: null != t ? t.linkTarget : void 0,
                }
              );
            }
            n.push("s-no-bg"), n.push(e.userClassName);
            var s = this.getBackgroundColorTextClass(t.backgroundColor);
            return (
              s && n.push("s-bg-".concat(s, "-text")),
              _.default.assign({
                image: a,
                className: n.join(" "),
                bgClassNames: e.bgClassNames,
                userClassName: e.userClassName,
                textColor: t.textColor,
                style: o,
              })
            );
          },
          getSectionBackgroundByIndex: function (t, e) {
            return e.length
              ? ((n = t),
                (a = e.length),
                e[(t = (((n = Number(n)) % (a = Number(a))) + a) % a)])
              : "";
            var n, a;
          },
          hasBgImageOrVideo: function (t) {
            return (
              !!t.hasClass("s-slider-section") ||
              (!t.hasClass("s-no-bg") && "none" !== t.css("backgroundImage"))
            );
          },
          collapsePaddingAdjacentSection: function (t) {
            var e = this;
            n(786483).isBackgroundPreviewOn ||
              (t.each(function (n, a) {
                var i = (0, m.default)(a);
                i.addClass("transition");
                var o = !e.hasBgImageOrVideo(i);
                if ((o && e.setThumbnailColor(i), 0 !== n)) {
                  var r = (0, m.default)(t.eq(n - 1));
                  !o ||
                  e.hasBgImageOrVideo(r) ||
                  i.is(".s-slider-section, .s-grid-section._wide") ||
                  r.is(".s-slider-section, .s-grid-section._wide") ||
                  "0px" !== r.css("border-bottom-width") ||
                  i.css("backgroundColor") !== r.css("backgroundColor")
                    ? r.removeClass("collapse-bottom-padding")
                    : r.addClass("collapse-bottom-padding");
                }
              }),
              window.edit_page.Event.publish("Section.updateBottomSpace"));
          },
          setThumbnailColor: function (t) {
            var e = t.css("background-color");
            (0, c.default)(t)
              .call(t, ".s-component.s-background .s-current-bg-thumbnail")
              .css("background-color", e);
          },
          hasContent: function (t) {
            return (
              "string" != typeof t && (t = t.get("url")), S.imageHasContent(t)
            );
          },
          getNavTextColor: function (t) {
            if (!t) return "dark";
            var e = t.get("url"),
              n = t.get("userClassName"),
              a = t.get("textColor");
            if (n)
              return {
                "s-bg-white": "dark",
                "s-bg-gray": "dark",
                "s-bg-dark": "light",
              }[n];
            var i = "dark" === a;
            if (_.default.isEmpty(e)) {
              var o = t.get("backgroundColor");
              return this.getBackgroundColorTextClass(o) || "dark";
            }
            return i ? "dark" : "light";
          },
          getThemeColorItems: function () {
            var t = N.default.getCustomColors() || {},
              e = t.highlight1,
              n = t.highlight2,
              a = e || n || "#fff",
              i = new k.default(a),
              o = k.default.getDiffLightnessColors(i.toHsl()) || [];
            return (0, g.default)(o).call(o);
          },
          getTransparentFixedBackgroundColor: function (t) {
            if (!t || t.size <= 0) return "";
            if ("overlay" !== t.get("textColor")) return "";
            var e = (N.default.getCustomColors() || {}).highlight2,
              n = e;
            return e || (n = this.getThemeColorItems()[4]), n;
          },
          getBackgroundColorString: function (t) {
            if (!t || 0 === t.size || "{}" === (0, h.default)(t)) return "";
            var e = t.value,
              n = t.type,
              a = t.themeColorRangeIndex;
            if (
              (y.default.isImmutable(t) &&
                ((e = t.get("value")),
                (n = t.get("type")),
                (a = t.get("themeColorRangeIndex"))),
              null !== a)
            ) {
              var i = N.default.getCustomColors()[n];
              if (!i) return "#fff";
              var o = new k.default(i);
              return (0, T.getDiffLightnessColors)(o.toHsl())[a];
            }
            return e;
          },
          getBackgroundColorTextClass: function (t) {
            if (!t || 0 === t.size || "{}" === (0, h.default)(t)) return "";
            var e = this.getBackgroundColorString(t);
            return e ? new k.default(e).getTextClass() : "";
          },
        };
      (e.default = A), (t.exports = e.default);
    },
    926941: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(359036),
        r = (0, i.default)(o),
        l = n(223765),
        s = (0, i.default)(l),
        u = n(726394),
        d = (0, i.default)(u),
        c = n(569198),
        f = (0, i.default)(c);
      n(241539), n(339714), n(974916), n(115306), n(209653);
      var g = n(854903),
        p = (0, i.default)(g),
        h = n(977766),
        v = (0, i.default)(h),
        m = n(394198),
        b = (0, i.default)(m),
        _ = n(703649),
        C = (0, i.default)(_),
        y = n(666419),
        S = (0, i.default)(y),
        x = n(169301),
        w = (0, i.default)(x),
        E = n(497093),
        P = (0, i.default)(E),
        N = n(2991),
        T = (0, i.default)(N),
        k = n(51942),
        I = (0, i.default)(k);
      function B(t) {
        var e =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          n =
            arguments.length > 2 && void 0 !== arguments[2]
              ? arguments[2]
              : 255;
        return Math.min(Math.max(t, e), n);
      }
      var D = function (t) {
          var e,
            n,
            a = t.h,
            i = t.s,
            o = t.l;
          o /= 100;
          var r = (i * Math.min(o, 1 - o)) / 100,
            l = function (t) {
              var e,
                n = (t + a / 30) % 12,
                i = o - r * Math.max(Math.min(n - 3, 9 - n, 1), -1);
              return (0, p.default)(
                (e = Math.round(255 * i).toString(16))
              ).call(e, 2, "0");
            };
          return (0, v.default)(
            (e = (0, v.default)((n = "#".concat(l(0)))).call(n, l(8)))
          ).call(e, l(4));
        },
        A = (function () {
          function t(e, n, a, i) {
            if (((0, d.default)(this, t), e instanceof t)) return e;
            if ("string" == typeof e) {
              var o = e.replace(/\s/g, ""),
                r = null;
              if ("transparent" === o)
                (this.r = 0), (this.g = 0), (this.b = 0), (this.a = 0);
              else if ((r = /^#?([a-f\d])([a-f\d])([a-f\d])$/i.exec(o)))
                (this.r = (0, b.default)(r[1] + r[1], 16)),
                  (this.g = (0, b.default)(r[2] + r[2], 16)),
                  (this.b = (0, b.default)(r[3] + r[3], 16));
              else if (
                (r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(o))
              )
                (this.r = (0, b.default)(r[1], 16)),
                  (this.g = (0, b.default)(r[2], 16)),
                  (this.b = (0, b.default)(r[3], 16));
              else if (
                (r =
                  /^rgba\(([\d]+),([\d]+),([\d]+),([\d]+|[\d]*.[\d]+)\)/.exec(
                    o
                  ))
              )
                (this.r = Number(r[1])),
                  (this.g = Number(r[2])),
                  (this.b = Number(r[3])),
                  (this.a = Number(r[4]));
              else {
                if (!(r = /^rgb\(([\d]+),([\d]+),([\d]+)\)/.exec(o)))
                  throw new Error("Invalid color constructor from ".concat(e));
                (this.r = Number(r[1])),
                  (this.g = Number(r[2])),
                  (this.b = Number(r[3]));
              }
            } else if ("object" === (0, s.default)(e) && "number" == typeof e.r)
              (this.r = B(~~e.r)),
                (this.g = B(~~e.g)),
                (this.b = B(~~e.b)),
                (this.a = B(e.a, 0, 1));
            else {
              if ("number" != typeof e)
                throw new Error("Invalid color constructor from ".concat(e));
              (this.r = B(~~e)),
                (this.g = B(~~n)),
                (this.b = B(~~a)),
                (this.a = B(i, 0, 1));
            }
            (void 0 === this.a || isNaN(this.a)) && (this.a = 1);
          }
          return (
            (0, f.default)(t, [
              {
                key: "fade",
                value: function (e) {
                  return new t(this.r, this.g, this.b, e);
                },
              },
              {
                key: "mix",
                value: function (e) {
                  var n =
                      arguments.length > 1 && void 0 !== arguments[1]
                        ? arguments[1]
                        : 0.5,
                    a =
                      arguments.length > 2 &&
                      void 0 !== arguments[2] &&
                      arguments[2],
                    i = new t(e),
                    o = B(n, 0, 1);
                  return new t(
                    this.r * (1 - o) + i.r * o,
                    this.g * (1 - o) + i.g * o,
                    this.b * (1 - o) + i.b * o,
                    a ? this.a * (1 - o) + i.a * o : this.a
                  );
                },
              },
              {
                key: "mult",
                value: function (e) {
                  return new t(this.r * e, this.g * e, this.b * e, this.a);
                },
              },
              {
                key: "lighten",
                value: function (t) {
                  return this.mix("#fff", t);
                },
              },
              {
                key: "toHex",
                value: function () {
                  var t;
                  return "#".concat(
                    (0, C.default)(
                      (t = (
                        (1 << 24) +
                        (this.r << 16) +
                        (this.g << 8) +
                        this.b
                      ).toString(16))
                    ).call(t, 1)
                  );
                },
              },
              {
                key: "toRgba",
                value: function () {
                  var t, e, n;
                  return 1 === this.a
                    ? this.toHex()
                    : (0, v.default)(
                        (t = (0, v.default)(
                          (e = (0, v.default)(
                            (n = "rgba(".concat(this.r, ","))
                          ).call(n, this.g, ","))
                        ).call(e, this.b, ","))
                      ).call(t, this.a, ")");
                },
              },
              {
                key: "toHsl",
                value: function () {
                  var t,
                    e,
                    n = this.r,
                    a = this.g,
                    i = this.b;
                  (n /= 255), (a /= 255), (i /= 255);
                  var o,
                    r,
                    l = Math.max(n, a, i),
                    s = Math.min(n, a, i),
                    u = (l + s) / 2;
                  if (l === s) (o = 0), (r = 0);
                  else {
                    var d = l - s;
                    switch (
                      ((r = u > 0.5 ? d / (2 - l - s) : d / (l + s)), l)
                    ) {
                      case n:
                        o = (a - i) / d + (a < i ? 6 : 0);
                        break;
                      case a:
                        o = (i - n) / d + 2;
                        break;
                      case i:
                        o = (n - a) / d + 4;
                        break;
                      default:
                        o = 0;
                    }
                    o /= 6;
                  }
                  return (
                    (r = Math.round(100 * r)),
                    (u = Math.round(100 * u)),
                    {
                      h: (o = Math.round(360 * o)),
                      s: r,
                      l: u,
                      color: (0, v.default)(
                        (t = (0, v.default)((e = "hsl(".concat(o, ", "))).call(
                          e,
                          r,
                          "%, "
                        ))
                      ).call(t, u, "%)"),
                    }
                  );
                },
              },
              {
                key: "luma",
                value: function () {
                  return (
                    (0.299 * this.r + 0.587 * this.g + 0.114 * this.b) / 255
                  );
                },
              },
              {
                key: "lumaCorrection",
                value: function () {
                  var t =
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : 0.7,
                    e = this.luma();
                  return t > 0 && e > t
                    ? this.mult(1 - (e - t) / 2)
                    : t < 0 && e < -t
                    ? this.lighten((-t - e) / 2)
                    : this;
                },
              },
              {
                key: "showOnBg",
                value: function (e) {
                  var n = new t(e);
                  return Math.abs(this.luma() - n.luma()) < 0.125
                    ? this.luma() > 0.9
                      ? this.mult(0.75)
                      : this.luma() > 0.6
                      ? this.luma() > n.luma()
                        ? this.lighten(0.5)
                        : this.mult(0.7)
                      : this.luma() > n.luma()
                      ? this.lighten(0.3)
                      : this.mult(0.5)
                    : this;
                },
              },
              {
                key: "validate",
                value: function (e, n, a, i) {
                  try {
                    return new t(e, n, a, i);
                  } catch (t) {
                    return null;
                  }
                },
              },
              {
                key: "getTextColor",
                value: function () {
                  return this.luma() > 0.65 ? "#000000" : "#ffffff";
                },
              },
              {
                key: "getTextClass",
                value: function () {
                  return this.luma() > 0.65 ? "dark" : "light";
                },
              },
              {
                key: "mix2",
                value: function (e, n) {
                  var a = new t(e),
                    i = this.a - a.a,
                    o = 2 * n - 1,
                    r =
                      1 -
                      (o = ((o * i == -1 ? o : (o + i) / (1 + o * i)) + 1) / 2);
                  return new t(
                    Math.round(o * this.r + r * a.r),
                    Math.round(o * this.g + r * a.g),
                    Math.round(o * this.b + r * a.b),
                    this.a * n + a.a * (1 - n)
                  );
                },
              },
              {
                key: "tint",
                value: function (t) {
                  var e,
                    n,
                    a,
                    i,
                    o,
                    r = t / 100,
                    l = Math.round(this.r + (255 - this.r) * r),
                    s = Math.round(this.g + (255 - this.g) * r),
                    u = Math.round(this.b + (255 - this.b) * r);
                  return (0, v.default)(
                    (e = (0, v.default)(
                      (n = "#".concat(
                        (0, p.default)((a = l.toString(16))).call(a, 2, "0")
                      ))
                    ).call(
                      n,
                      (0, p.default)((i = s.toString(16))).call(i, 2, "0")
                    ))
                  ).call(
                    e,
                    (0, p.default)((o = u.toString(16))).call(o, 2, "0")
                  );
                },
              },
              {
                key: "shade",
                value: function (t) {
                  return this.tint(-t);
                },
              },
            ]),
            t
          );
        })();
      (A.getDiffLightnessColors = function (t, e) {
        var n,
          a,
          i = t.h,
          o = t.s,
          l = t.l,
          s =
            arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 5,
          u = 100 / s,
          d = 95,
          c = 5,
          f = Math.ceil(l / u) - 1,
          g = (0, S.default)(
            (0, r.default)((0, w.default)((n = new Array(s))).call(n)),
            function (t) {
              var e = (t - f) * u + l;
              return (
                0 === t && (e = Math.max(e, c)),
                t === s - 1 && (e = Math.min(e, d)),
                e
              );
            }
          );
        return (0, P.default)(
          (a = (0, T.default)(g).call(g, function (t) {
            return D({ h: i, s: o, l: t });
          }))
        ).call(a);
      }),
        (A.isSameByDistance = function (t, e) {
          var n =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : 10,
            a = new A(t),
            i = new A(e);
          if (!a || !i) return !1;
          var o =
            Math.pow(a.r - i.r, 2) +
            Math.pow(a.g - i.g, 2) +
            Math.pow(a.b - i.b, 2);
          return !(o > n);
        }),
        (A.getDiffBrightnessColor = function (t) {
          var e =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : -5,
            n =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : {},
            a = new A(t),
            i = a.toHsl(),
            o = i.h,
            r = i.s,
            l = i.l,
            s = { h: o, s: r, l: l + e },
            u = (0, I.default)({}, s, n);
          return D(u);
        }),
        (e.default = A),
        (t.exports = e.default);
    },
    387937: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(205872),
        r = (0, i.default)(o),
        l = n(780122),
        s = (0, i.default)(l),
        u = ["__uid", "__store"];
      e.default = function (t, e, n) {
        var a,
          i =
            arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "",
          o = function (e) {
            e.__uid, e.__store;
            var n = (0, s.default)(e, u);
            return v.default.createElement(t, n);
          };
        o.displayName = "connectToMorearty_RemoveUid(".concat(
          t.displayName,
          ")"
        );
        var l = (0, f.connect)(function (t, n) {
          return e(n.__store.moreartyRootBinding.get(), n);
        }, n)(o);
        l.displayName = (0, c.default)(
          (a = "connectToMorearty".concat(i, "("))
        ).call(a, t.displayName, ")");
        var d = function (t, e) {
          return v.default.createElement(
            l,
            (0, r.default)({}, t, {
              __uid: p.default.uniqueId(),
              __store: e.store,
            })
          );
        };
        return (d.contextTypes = { store: b.default.object }), d;
      };
      var d = n(977766),
        c = (0, i.default)(d),
        f = n(50533),
        g = n(496486),
        p = (0, i.default)(g),
        h = n(366757),
        v = (0, i.default)(h),
        m = n(45697),
        b = (0, i.default)(m);
      t.exports = e.default;
    },
    205223: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 }),
        (e.default = function (t, e, n) {
          return (0, r.default)(
            t,
            function () {
              var t;
              return (t = "function" == typeof e ? e() : e), n(t);
            },
            void 0,
            "Bindings"
          );
        });
      var o = n(387937),
        r = (0, i.default)(o),
        l = n(496486);
      (0, i.default)(l), (t.exports = e.default);
    },
    43138: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(394198),
        r = (0, i.default)(o),
        l = n(31238),
        s = (0, i.default)(l),
        u = n(703649),
        d = (0, i.default)(u),
        c = n(981643),
        f = (0, i.default)(c),
        g = n(678580),
        p = (0, i.default)(g);
      n(974916), n(804723), n(324603), n(339714), n(323123);
      var h = n(223336),
        v = (0, i.default)(h),
        m = function () {
          var t = !1;
          return (
            "undefined" != typeof navigator &&
              null !== navigator &&
              navigator.userAgent &&
              (t = navigator.userAgent.match(/(android)/i)),
            t
          );
        },
        b = function () {
          if (m()) {
            var t =
              "undefined" != typeof navigator && null !== navigator
                ? navigator.userAgent
                : void 0;
            return (0, s.default)(
              (0, d.default)(t).call(
                t,
                (0, f.default)(t).call(t, "Android") + 8
              )
            );
          }
        },
        _ = {
          isMobile: function () {
            var t = !1;
            return (
              "undefined" != typeof navigator &&
                null !== navigator &&
                navigator.userAgent &&
                (t =
                  navigator.userAgent.match(
                    /(iPad)|(iPhone)|(iPod)|(android)|(webOS)|(windows phone)|(iemobile)/i
                  ) ||
                  (navigator.userAgent.match(/(Macintosh)/i) &&
                    navigator.maxTouchPoints > 0)),
              t
            );
          },
          isMobileWithoutIpad: function () {
            var t = !1;
            return (
              "undefined" != typeof navigator &&
                null !== navigator &&
                navigator.userAgent &&
                (t =
                  navigator.userAgent.match(
                    /(iPhone)|(iPod)|(android)|(webOS)|(windows phone)|(iemobile)/i
                  ) ||
                  (navigator.userAgent.match(/(Macintosh)/i) &&
                    navigator.maxTouchPoints > 0)),
              t
            );
          },
          isAndroid: m,
          isWindowsPhone: function () {
            var t = !1;
            return (
              "undefined" != typeof navigator &&
                null !== navigator &&
                navigator.userAgent &&
                (t = navigator.userAgent.match(/(windows phone)|(iemobile)/i)),
              t
            );
          },
          isIpad: function () {
            var t = !1;
            return (
              "undefined" != typeof navigator &&
                null !== navigator &&
                navigator.userAgent &&
                (t =
                  navigator.userAgent.match(/(iPad)/i) ||
                  (navigator.userAgent.match(/(Macintosh)/i) &&
                    navigator.maxTouchPoints > 0)),
              t
            );
          },
          isIOS: function () {
            var t = !1;
            return (
              "undefined" != typeof navigator &&
                null !== navigator &&
                navigator.userAgent &&
                (t = navigator.userAgent.match(/(iPad)|(iPhone)|(iPod)/i)),
              t
            );
          },
          isSmallScreen: function () {
            var t = (0, v.default)("#s-content").hasClass("side-menu-opened")
              ? 947
              : 727;
            return (
              (window.innerWidth || (0, v.default)(window).width()) <= t ||
              (0, v.default)(window).height() < 400
            );
          },
          isSmallerThanDesktop: function () {
            var t = (0, v.default)("#s-content").hasClass("side-menu-opened")
              ? 1147
              : 927;
            return (
              (window.innerWidth || (0, v.default)(window).width()) <= t ||
              (0, v.default)(window).height() < 400
            );
          },
          isPhoneScreen: function () {
            return screen.width <= 760;
          },
          isMobileScreen: function () {
            return screen.width <= 479;
          },
          isSmallMobileScreen: function () {
            return screen.width <= 400;
          },
          isAndroid2x: function () {
            return m() && b() < 3;
          },
          androidVersion: b,
          iOSversion: function () {
            if (/iP(hone|od|ad)/.test(navigator.platform)) {
              var t = navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
              return [
                (0, r.default)(t[1], 10),
                (0, r.default)(t[2], 10),
                (0, r.default)(t[3] || 0, 10),
              ][0];
            }
          },
          isIE11: function () {
            return (
              "Netscape" === window.navigator.appName &&
              null !==
                new RegExp("Trident/.*rv:([0-9]{1,}[.0-9]{0,})").exec(
                  null != window.navigator ? window.navigator.userAgent : void 0
                )
            );
          },
          isEdge: function () {
            return (
              "undefined" != typeof window &&
              /edge/i.test(
                null != window.navigator ? window.navigator.userAgent : void 0
              )
            );
          },
          isGoogle: function () {
            return (
              !!window.navigator &&
              (/google/i.test(window.navigator.vendor) ||
                /chrome/i.test(window.navigator.userAgent) ||
                /CriOS/i.test(window.navigator.userAgent))
            );
          },
          isSafari: function () {
            return (
              !!window.navigator &&
              (/apple/i.test(window.navigator.vendor) ||
                /safari/i.test(window.navigator.userAgent))
            );
          },
          isIE: function () {
            var t;
            return (
              "undefined" != typeof navigator &&
                null !== navigator &&
                navigator.userAgent &&
                (t = navigator.userAgent.toLowerCase()),
              -1 !== (0, f.default)(t).call(t, "msie") &&
                (0, r.default)(t.split("msie")[1])
            );
          },
          isFirefox: function () {
            var t;
            return (
              "undefined" != typeof navigator &&
              (0, p.default)((t = navigator.userAgent.toLowerCase())).call(
                t,
                "firefox"
              )
            );
          },
          isWechat: function () {
            var t = !1;
            return (
              "undefined" != typeof navigator &&
                null !== navigator &&
                navigator.userAgent &&
                (t = navigator.userAgent.match(/micromessenger/i)),
              t
            );
          },
          isTouchDevice: function () {
            try {
              return document.createEvent("TouchEvent"), !0;
            } catch (t) {
              return !1;
            }
          },
          isWindows: function () {
            return (
              "undefined" != typeof navigator &&
              /windows|win32/i.test(navigator.userAgent)
            );
          },
        };
      window.DEBUG || (window.DEBUG = {}),
        (window.DEBUG.DeviceHelper = _),
        (e.default = _),
        (t.exports = e.default);
    },
    157444: function (t, e, n) {
      var a = n(353147),
        i = n(663978),
        o = n(60530)(n(60530));
      i(e, "__esModule", { value: !0 });
      var r = n(977766),
        l = (0, o.default)(r);
      n(974916), n(115306), n(209653), n(556977);
      var s = {
        escapedValue: function () {
          var t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "",
            e = /<script\b[^>]*>([\s\S]*?)<\/script>/gim,
            n = /<\/script>/gim;
          return t && (t = t.replace(e, "").replace(n, "")), t;
        },
        safeEncodeURL: function (t) {
          try {
            return encodeURI(t);
          } catch (t) {
            return console.error(t), "";
          }
        },
        safeDecodeURL: function (t) {
          try {
            return decodeURI(t);
          } catch (e) {
            return console.error(e), t;
          }
        },
        applyWordBreaks: function (t) {
          t = t.replace(/<wbr\s?\/?>/g, "");
          for (var e = !1, n = 0; n < t.length; n++) {
            var a = t[n];
            if ("<" === a) e = !0;
            else if (">" === a) e = !1;
            else if (!e && "@" === a) {
              var i;
              t = (0, l.default)(
                (i = "".concat(t.substr(0, n), "@<wbr>"))
              ).call(i, t.substr(n + 1, t.length));
            }
          }
          return t;
        },
        handleSpace: function (t) {
          var e = (t = t.replace(/\u200B/g, "")).replace(
            /(<p[^>]*>(<\/?[^>]*>)*\s)\s+(.*?<\/p>)/g,
            "$1&emsp; &emsp;$3"
          );
          return (
            e !== t &&
              (e = t.replace(
                /(<p[^>]*>(<\/?[^>]*>)*)\s{2,}(.*?<\/p>)/g,
                "$1&emsp; &emsp;$3"
              )),
            e
          );
        },
        isGDPRHtmlValid: function (t) {
          return /^[^<>]*(<\s*a\s*href=[''""]([^''""<>]*)[''""][^<>=''""`]*>([^<>]+)<\s*\/\s*a\s*>[^<>]*)*[^<>]*$/.test(
            t
          );
        },
        getDefaultGDPRHtml: function () {
          return a(
            'By continuing, you agree to our <a href="/?open=terms-and-conditions">Terms &amp; Conditions</a> and <a href="/?open=privacy-policy">Privacy Policy</a>.'
          );
        },
        changeZoom: function () {
          var t,
            e,
            n,
            a,
            i =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {
                    initialScale: Number,
                    userScalable: Boolean,
                    minimumScale: Number,
                    maximumScale: Number,
                    width: String,
                  },
            o = i.width,
            r = void 0 === o ? "device-width" : o,
            s = i.initialScale,
            u = void 0 === s ? 1 : s,
            d = i.userScalable,
            c = void 0 === d || d,
            f = i.minimumScale,
            g = void 0 === f ? 1 : f,
            p = i.maximumScale,
            h = void 0 === p ? 3 : p;
          document
            .getElementById("viewport")
            .setAttribute(
              "content",
              (0, l.default)(
                (t = (0, l.default)(
                  (e = (0, l.default)(
                    (n = (0, l.default)(
                      (a = "width=".concat(r, ",initial-scale="))
                    ).call(a, u.toFixed(1), ",user-scalable="))
                  ).call(n, c ? "yes" : "no", ",minimum-scale="))
                ).call(e, g.toFixed(1), ",maximum-scale="))
              ).call(t, h.toFixed(1))
            );
        },
      };
      (e.default = s), (t.exports = e.default);
    },
    79752: function (t, e, n) {
      var a = n(353147),
        i = n(223765),
        o = n(752424),
        r = n(663978),
        l = n(834074),
        s = n(60530)(n(60530));
      r(e, "__esModule", { value: !0 });
      var u = n(729828),
        d = (0, s.default)(u),
        c = n(492762),
        f = (0, s.default)(c),
        g = n(778914),
        p = (0, s.default)(g),
        h = n(977766),
        v = (0, s.default)(h),
        m = n(496486),
        b = (0, s.default)(m),
        _ = n(577499),
        C = (0, s.default)(_),
        y = n(468811),
        S = (0, s.default)(y),
        x = n(143393),
        w = (0, s.default)(x),
        E = (function (t, e) {
          if (t && t.__esModule) return t;
          if (null === t || ("object" !== i(t) && "function" != typeof t))
            return { default: t };
          var n = P(e);
          if (n && n.has(t)) return n.get(t);
          var a = {},
            o = r && l;
          for (var s in t)
            if ("default" !== s && Object.prototype.hasOwnProperty.call(t, s)) {
              var u = o ? l(t, s) : null;
              u && (u.get || u.set) ? r(a, s, u) : (a[s] = t[s]);
            }
          return (a.default = t), n && n.set(t, a), a;
        })(n(861704));
      function P(t) {
        if ("function" != typeof o) return null;
        var e = new o(),
          n = new o();
        return (P = function (t) {
          return t ? n : e;
        })(t);
      }
      var N = {};
      (N = {
        addMetaId: E.addMetaId,
        deleteMeta: function (t) {
          var e =
            arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          return (
            C.default.traverseObj(t, function (t) {
              for (var n in t)
                t[n],
                  (0, d.default)(b.default).call(b.default, n, "_") &&
                    delete t[n],
                  e && delete t.id;
            }),
            t
          );
        },
        addRepeatItem: function (t) {
          var e = t.binding,
            n = e.get(),
            a = null != t.position ? t.position : n.size;
          return (
            (n = (0, f.default)(n).call(
              n,
              a,
              0,
              w.default.fromJS(t.noId ? t.newItem : N.addMetaId(t.newItem))
            )),
            e.set(n),
            n
          );
        },
        deleteRepeatItem: function (t) {
          var e = t.binding,
            n = e.get(),
            a = null != t.index ? t.index : n.size - 1,
            i = e.get(a);
          return e.set((0, f.default)(n).call(n, a, 1)), i;
        },
        reorderRepeatable: function (t, e) {
          b.default.remove(t, function (t) {
            return "" === t;
          });
          var n = e.atomically();
          return (
            (0, p.default)(t).call(t, function (t, a) {
              return n.set(a, e.get(t));
            }),
            n.commit()
          );
        },
        reorderRepeatableWithSplice: function (t, e) {
          var n;
          if ((this.reorderRepeatable(t, e), t.length < e.get().size))
            return e.set((0, f.default)((n = e.get())).call(n, t.length));
        },
        concatRepeatItem: function (t, e) {
          var n,
            a = e.atomically();
          return a.set((0, v.default)((n = e.get())).call(n, t)), a.commit();
        },
        convertProviderName: function (t) {
          return (
            {
              tencent_api: a("Editor|TencentYun"),
              aliyun_api: a("Editor|Aliyun"),
            }[t] || ""
          );
        },
        addSectionColumn: function (t) {
          return w.default.fromJS({
            name: "columnBlock",
            type: "BlockComponentItem",
            components: {
              block1: {
                type: "BlockComponent",
                items: [t],
                id: S.default.v4(),
              },
            },
            id: S.default.v4(),
          });
        },
        addSectionRow: function (t) {
          return w.default.fromJS({
            name: "rowBlock",
            type: "BlockComponentItem",
            components: {
              block1: {
                type: "BlockComponent",
                inlineLayout: "12",
                items: [this.addSectionColumn(t)],
                id: S.default.v4(),
              },
            },
            id: S.default.v4(),
          });
        },
      }),
        (e.default = N),
        (t.exports = e.default);
    },
    577499: function (t, e, n) {
      var a = n(223765),
        i = n(752424),
        o = n(663978),
        r = n(834074),
        l = n(60530)(n(60530));
      o(e, "__esModule", { value: !0 });
      var s = n(931581),
        u = (0, l.default)(s),
        d = (function (t, e) {
          if (t && t.__esModule) return t;
          if (null === t || ("object" !== a(t) && "function" != typeof t))
            return { default: t };
          var n = c(e);
          if (n && n.has(t)) return n.get(t);
          var i = {},
            l = o && r;
          for (var s in t)
            if ("default" !== s && Object.prototype.hasOwnProperty.call(t, s)) {
              var u = l ? r(t, s) : null;
              u && (u.get || u.set) ? o(i, s, u) : (i[s] = t[s]);
            }
          return (i.default = t), n && n.set(t, i), i;
        })(n(175892));
      function c(t) {
        if ("function" != typeof i) return null;
        var e = new i(),
          n = new i();
        return (c = function (t) {
          return t ? n : e;
        })(t);
      }
      (e.default = {
        waitFor: function (t, e, n) {
          var a;
          return (
            (n = n || 100),
            (a = (0, u.default)(function () {
              if (t()) return window.clearInterval(a), e();
            }, n))
          );
        },
        isBlank: function (t) {
          return null == t || 0 === t.length;
        },
        traverseObj: d.traverseObj,
      }),
        (t.exports = e.default);
    },
    936501: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(439392),
        r = (0, i.default)(o),
        l = n(410062),
        s = (0, i.default)(l),
        u = n(432366),
        d = (0, i.default)(u),
        c = n(977766),
        f = (0, i.default)(c),
        g = n(54103),
        p = (0, i.default)(g),
        h = n(496486),
        v = (0, i.default)(h);
      (e.default = {
        boundParamsMemoizer: function (t, e) {
          var n = new r.default();
          return function () {
            for (var a = arguments.length, i = new Array(a), o = 0; o < a; o++)
              i[o] = arguments[o];
            if (
              (0, s.default)(v.default).call(v.default, i, function (t) {
                return v.default.isObject(t);
              })
            )
              throw new TypeError(
                "boundParamsMemoizer cannot take only objects as parameters. Use simple parameters like string or number."
              );
            var r,
              l = (0, d.default)(i).call(
                i,
                function (t, e) {
                  var n;
                  return (0, f.default)((n = "".concat(t, "_"))).call(n, e);
                },
                ""
              ),
              u = n.get(l);
            return (
              void 0 === u &&
                ((u = (0, p.default)(Function.prototype).apply(
                  t,
                  (0, f.default)((r = [e])).call(r, i)
                )),
                n.set(l, u)),
              u
            );
          };
        },
      }),
        (t.exports = e.default);
    },
    83124: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(977766),
        r = (0, i.default)(o),
        l = n(496486),
        s = (0, i.default)(l),
        u = {
          componentWillMount: function () {
            this.validateProps(this.props);
          },
          componentWillReceiveProps: function (t) {
            this.validateProps(t);
          },
          validateProps: function (t) {
            var e = this.constructor,
              n = e.displayName,
              a = e.propTypes;
            if (s.default.isUndefined(a))
              console.warn(
                'Component "'.concat(n, "\" doesn't have propType set.")
              );
            else
              for (var i in t) {
                var o;
                a[i] ||
                  console.warn(
                    (0, r.default)(
                      (o = 'You set a property "'.concat(i, '" on Component "'))
                    ).call(
                      o,
                      n,
                      '" but did not provide a PropType declaration for this prop.'
                    )
                  );
              }
          },
        };
      (e.default = u), (t.exports = e.default);
    },
    269393: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(359340),
        r = (0, i.default)(o),
        l = n(432366),
        s = (0, i.default)(l),
        u = n(496486),
        d = (0, i.default)(u);
      (e.default = {
        printAllData: function () {
          var t = {};
          return (
            this.props.dataProps && (t = this.props.dataProps.toJS()),
            (0, r.default)(t, null, 2)
          );
        },
        printAllBindings: function () {
          if (!this.getBinding) return print({});
          var t,
            e = this.getBinding();
          return (
            (t = d.default.isPlainObject(e)
              ? (0, s.default)(d.default).call(
                  d.default,
                  this.getBinding(),
                  function (t, e, n) {
                    return (t[n] = e.toJS()), t;
                  },
                  {}
                )
              : e.toJS()),
            (0, r.default)(t, null, 2)
          );
        },
      }),
        (t.exports = e.default);
    },
    230139: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 }), n(974916), n(115306);
      var o = n(143393),
        r = (0, i.default)(o),
        l = n(496486),
        s = (0, i.default)(l);
      (e.default = function (t) {
        return {
          _b: void 0,
          setMeta: function (t, e) {
            if (!t) throw new Error("key should be provided");
            this.getMetaBinding().set(t, r.default.fromJS(e));
          },
          updateMeta: function (t) {
            var e =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : null,
              n = this.getMetaBinding();
            s.default.isUndefined(n.get()) &&
              console.warn("attempt to update a non-existing binding"),
              e ? n.set(e, r.default.fromJS(t)) : n.merge(r.default.fromJS(t));
          },
          getMeta: function (t) {
            return this.getMetaBinding().get(t);
          },
          getMetaBinding: function () {
            if (this._b) return this._b;
            var e = this.getDefaultBinding().meta();
            return t && (e = e.sub(t)), this._b || (this._b = e);
          },
          initMeta: function (t) {
            var e = this;
            this._b = void 0;
            var n = this.getMetaBinding();
            for (var a in (n
              .atomically()
              .set(r.default.fromJS(t))
              .commit({ notify: !1 }),
            t)) {
              var i = a.replace(/^(\w)/, function (t) {
                return t.toUpperCase();
              });
              (this["_get".concat(i)] = (function (t) {
                return function () {
                  return e.getMeta(t);
                };
              })(a)),
                (this["_set".concat(i)] = (function (t) {
                  return function (n) {
                    e.updateMeta(n, t), "currentTab" === t && e.forceUpdate();
                  };
                })(a));
            }
          },
        };
      }),
        (t.exports = e.default);
    },
    636969: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 }),
        (e.getLogs =
          e.resetChangeLogs =
          e.markStructChange =
          e.compareAndMark =
          e.initRecorderData =
          e.deleteExpiredData =
          e.updatePreviousData =
            void 0);
      var o,
        r = n(79752),
        l = (0, i.default)(r),
        s = n(496486),
        u = (0, i.default)(s),
        d = { timestamp: 0, data: null },
        c = !1,
        f = {},
        g = function () {
          (o = {}), p("modified_pages_indexes", []), p("struct_changed", !1);
        },
        p = function (t, e) {
          o[t] = e;
        },
        h =
          ((e.updatePreviousData = function (t) {
            var e = f[t];
            t > d.timestamp && ((d.timestamp = t), (d.data = e));
          }),
          (e.deleteExpiredData = function (t) {
            delete f[t];
          }),
          (e.initRecorderData = function (t) {
            c ||
              (g(),
              (d.data = t),
              (d.timestamp = new Date().valueOf()),
              (c = !0));
          }),
          (e.compareAndMark = function (t) {
            var e = new Date().valueOf();
            if (
              ((function (t, e) {
                f[t] = e;
              })(e, t),
              !d.data)
            )
              return h(), e;
            var n,
              a = d.data.get("pages"),
              i = t.get("pages"),
              r = a.size,
              s = i.size;
            if (r != s) return h(), e;
            for (var c = 0; c < s; c++) {
              var g = l.default.deleteMeta(i.get(c).toJS()),
                p = l.default.deleteMeta(a.get(c).toJS());
              if (!u.default.isEqual(g, p)) {
                if (g.uid !== p.uid) {
                  h();
                  break;
                }
                (n = c), o.modified_pages_indexes.push(n);
              }
            }
            return (
              u.default.isEqual(o, {
                modified_pages_indexes: [],
                struct_changed: !1,
              }) && h(),
              e
            );
          }),
          (e.markStructChange = function () {
            p("struct_changed", !0);
          }));
      (e.resetChangeLogs = function () {
        g();
      }),
        (e.getLogs = function () {
          return o;
        });
    },
    836034: function (t, e, n) {
      var a = n(686902),
        i = n(14310),
        o = n(620116),
        r = n(834074),
        l = n(778914),
        s = n(239649),
        u = n(820368),
        d = n(663978),
        c = n(60530)(n(60530));
      d(e, "__esModule", { value: !0 });
      var f = n(487672),
        g = (0, c.default)(f);
      n(569600), n(974916), n(323123);
      var p = n(2991),
        h = (0, c.default)(p),
        v = n(666419),
        m = (0, c.default)(v),
        b = n(977766),
        _ = (0, c.default)(b),
        C = n(277149),
        y = (0, c.default)(C),
        S = n(432366),
        x = (0, c.default)(S),
        w = n(981643),
        E = (0, c.default)(w),
        P = n(51942),
        N = (0, c.default)(P),
        T = n(25843),
        k = (0, c.default)(T),
        I = n(620116),
        B = (0, c.default)(I),
        D = n(410062),
        A = (0, c.default)(D),
        M = n(366757),
        O = ((0, c.default)(M), n(45697)),
        L = (0, c.default)(O),
        Z = n(973935),
        R = (0, c.default)(Z),
        G = n(143393),
        U = (0, c.default)(G),
        W = n(496486),
        F = (0, c.default)(W),
        H = n(8689),
        V = (0, c.default)(H),
        z = n(548273),
        $ = (0, c.default)(z),
        j = n(786483),
        J = (0, c.default)(j),
        K = n(792656),
        X = (0, c.default)(K),
        Y = n(183123),
        q = (0, c.default)(Y),
        Q = n(884920);
      function tt(t, e) {
        var n = a(t);
        if (i) {
          var l = i(t);
          e &&
            (l = o(l).call(l, function (e) {
              return r(t, e).enumerable;
            })),
            n.push.apply(n, l);
        }
        return n;
      }
      var et = F.default.debounce(function (t) {
          return J.default.Event.publish("Section.changed", {
            target: R.default.findDOMNode(t),
          });
        }, 500),
        nt = {
          propTypes: { binding: L.default.object.isRequired },
          contextTypes: { theme: L.default.object },
          componentDidUpdate: function (t) {
            var e = this;
            et(this);
            var n = this.getMoreartyContext(),
              a = this.getDefaultBinding().sub("components"),
              i = function (t) {
                if (n.isChanged(t) && "normal" === t.get())
                  return (
                    J.default.Event.publish("Section.componentSaved", {
                      target: R.default.findDOMNode(e),
                    }),
                    !0
                  );
              },
              o = a.toJS(),
              r = function (t) {
                var r = o[t];
                if ("SlideSettings" === r.type) {
                  var l = a.sub("".concat(t, ".layout_variation"));
                  if (n.isChanged(l))
                    return (
                      J.default.Event.publish("Section.componentSaved", {
                        target: R.default.findDOMNode(e),
                      }),
                      "break"
                    );
                } else if ("Repeatable" === r.type) {
                  var s;
                  (0, h.default)((s = (0, m.default)(r.list))).call(
                    s,
                    function (e, n) {
                      for (var o in e.components) {
                        e.components[o];
                        var r,
                          l,
                          s = a.sub(
                            (0, _.default)(
                              (r = (0, _.default)(
                                (l = "".concat(t, ".list."))
                              ).call(l, n, ".components."))
                            ).call(r, o, "._state")
                          );
                        if (i(s)) break;
                      }
                    }
                  );
                } else {
                  var u = a.sub("".concat(t, "._state"));
                  if (i(u)) return "break";
                }
              };
            for (var l in o) if ("break" === r(l)) break;
          },
          getTemplate: function () {
            return this.sectionModel.template;
          },
          _getSectionId: function () {
            return this.getDefaultBinding().sub("id").get();
          },
          _getOriginSectionId: function () {
            return this.getDefaultBinding().sub("origin_id").get();
          },
          _getIsShowLayoutSelector: function () {
            return !0;
          },
          _getLayoutProps: function () {
            var t = this.getDefaultBinding().sub("components.slideSettings"),
              e = t.get("padding");
            e = e && e.toJS ? e.toJS() : e;
            var n = t.sub("layout_config");
            return {
              padding: e || { top: "normal", bottom: "normal" },
              layoutVariation: t.get("layout_variation") || "",
              binding: t,
              parentBinding: this.getDefaultBinding(),
              s5ClassProps: this.props.s5ClassProps,
              sectionLayoutConfig: n,
            };
          },
          _getLayoutBinding: function () {
            return this.getDefaultBinding().sub("components.slideSettings");
          },
          _getLayoutKey: function () {
            var t,
              e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : null,
              n = this.getDefaultBinding().get(
                "components.slideSettings.layout_variation"
              );
            return null != e &&
              (t =
                "function" == typeof this._getLayoutOptions
                  ? this._getLayoutOptions()
                  : void 0)
              ? (0, y.default)(F.default).call(F.default, t, function (t) {
                  return t.key === n;
                })
                ? n
                : e
              : n;
          },
          _getRepeatableItemProps: function (t, e) {
            var n = t.sub(e).get(),
              a = { key: n.get("id") };
            return (function (t) {
              for (var e = 1; e < arguments.length; e++) {
                var n,
                  a = null != arguments[e] ? arguments[e] : {};
                if (e % 2)
                  l((n = tt(Object(a), !0))).call(n, function (e) {
                    (0, g.default)(t, e, a[e]);
                  });
                else if (s) u(t, s(a));
                else {
                  var i;
                  l((i = tt(Object(a)))).call(i, function (e) {
                    d(t, e, r(a, e));
                  });
                }
              }
              return t;
            })(
              {
                parentSize: t.get().size,
                hasEditorOpened: this._hasEditorOpened(n),
              },
              a
            );
          },
          _hasEditorOpened: function (t) {
            return (0, y.default)(F.default).call(
              F.default,
              t.get("components").toObject(),
              function (t, e) {
                return "editor" === t.get("_state");
              }
            );
          },
          getComponentProps: function (t, e) {
            var n,
              a = this.getComponentBinding(t, e),
              i = a.get().toObject(),
              o = (0, x.default)(F.default).call(
                F.default,
                i,
                function (t, e, n) {
                  return F.default.isNull(e) && (e = void 0), (t[n] = e), t;
                },
                {}
              );
            return (
              (o.binding = { default: a }),
              (o._cName = t),
              (o.sectionModel = this.sectionModel),
              (o.layout = this.getDefaultBinding().get(
                "components.slideSettings.layout_variation"
              )),
              (o.layoutConfig = this.getDefaultBinding().get(
                "components.slideSettings.layout_config"
              )),
              null === o.layout && (o.layout = void 0),
              (o.eagerLoad = this.props.eagerLoad),
              "media" === this.getDefaultBinding().get("template_name") &&
                (o.assetType = "background"),
              -1 !==
                (0, E.default)((n = ["background1", "background2"])).call(
                  n,
                  t
                ) &&
                ((o.bgClassNames = this.getThemeFeature(
                  "backgroundColorClassNames"
                )),
                (o.userClassName = this.getDefaultBackground(a))),
              o
            );
          },
          getReduxComponentProps: function (t, e) {
            var n,
              a = this.getComponentBinding(t, e),
              i = (0, Q.getReduxComponentProps)(a);
            return (
              (i._cName = t),
              (i.sectionModel = this.sectionModel),
              (i.layout = this.getDefaultBinding().get(
                "components.slideSettings.layout_variation"
              )),
              (i.layoutConfig = this.getDefaultBinding().get(
                "components.slideSettings.layout_config"
              )),
              null === i.layout && (i.layout = void 0),
              (i.eagerLoad = this.props.eagerLoad),
              "media" === this.getDefaultBinding().get("template_name") &&
                (i.assetType = "background"),
              -1 !==
                (0, E.default)((n = ["background1", "background2"])).call(
                  n,
                  t
                ) &&
                ((i.bgClassNames = this.getThemeFeature(
                  "backgroundColorClassNames"
                )),
                (i.userClassName = this.getDefaultBackground(a))),
              i
            );
          },
          getDefaultBackground: function (t) {
            var e = this.getThemeFeature("backgroundColorClassNames"),
              n = this.getThemeFeature("backgroundColorRotate"),
              a = t.get("userClassName"),
              i = X.default.getBgColorClassName(t.get("backgroundColor"));
            return a && e.length && -1 !== (0, E.default)(e).call(e, a)
              ? a
              : i && e.length && -1 !== (0, E.default)(e).call(e, i)
              ? i
              : n
              ? X.default.getSectionBackgroundByIndex(this.props.index, e)
              : "";
          },
          getBackgroundProps: function (t, e) {
            var n =
                arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
              a = this.getComponentBinding(t, e),
              i = q.default.getBackgroundForAllSections(),
              o = {
                bgClassNames: this.getThemeFeature("backgroundColorClassNames"),
                userClassName: this.getDefaultBackground(a),
              },
              r = a.get("useImage"),
              l = a.get("videoHtml"),
              s = a.get("backgroundColor");
            if (!n || i || r || l || (s && 0 !== s.size)) {
              var u = !!i || this.props.eagerLoad;
              return (
                (o = (0, N.default)(
                  {
                    size: "background",
                    hackRoundShapeFlag: this.props.hackRoundShapeFlag,
                    eagerLoad: u,
                  },
                  o
                )),
                (0, N.default)(
                  { parentBinding: a, sectionIndex: this.props.index },
                  X.default.getContentProps(a.get().toObject(), o),
                  { inSectionSelector: this.props.inSectionSelector }
                )
              );
            }
            return this.getMinBackgroundColorProps(a);
          },
          getMinBackgroundColorProps: function (t) {
            var e = this.getDefaultBackground(t);
            return {
              bgClassNames: this.getThemeFeature("backgroundColorClassNames"),
              userClassName: e,
              className: e,
            };
          },
          getSliderBackgroundProps: function (t, e, n) {
            return "noForeground" === n
              ? this.getFullViewBackgroundProps(t, e)
              : this.getBackgroundProps(t, e);
          },
          getFullViewBackgroundProps: function (t, e) {
            var n = this.getComponentBinding(t, e),
              a = n.get().toObject(),
              i = X.default.getContentProps(a),
              o = F.default.assign(i.style, { backgroundPosition: "0 0" });
            return (i.style = o), (0, N.default)({ parentBinding: n }, i);
          },
          getFooterBackgroundProps: function (t, e) {
            var n = this.getComponentBinding(t, e),
              a = {
                bgClassNames: this.getThemeFeature("backgroundColorClassNames"),
                userClassName: this.getDefaultBackground(n),
              };
            return (0, N.default)({ className: a.userClassName }, a);
          },
          hasBackgroundVideo: function (t, e) {
            return (
              "" !== this.getComponentBinding(t, e).get().toObject().videoHtml
            );
          },
          getComponentBinding: function (t, e) {
            var n,
              a,
              i = this.generateComponentBindingIfMissing([t], e);
            if (!i.get("type"))
              throw new Error(
                (0, _.default)(
                  (n = (0, _.default)(
                    (a = "".concat(this.displayName, '.getComponentBinding("'))
                  ).call(a, t, '"): "'))
                ).call(n, t, '" data not found.')
              );
            return i;
          },
          generateComponentBindingIfMissing: function (t, e) {
            if (
              (e || (e = this.getDefaultBinding()),
              e.get("components").getIn(t))
            )
              return e.sub("components").sub(t.join("."));
            var n = this.getDefaultBinding().get("template_name");
            n || (n = this.getDefaultBinding().get("type").toLowerCase());
            var a = $.default.getSectionDataBySectionName(n),
              i = (0, x.default)(t).call(
                t,
                function (t, e) {
                  return t[e];
                },
                a.content.components
              );
            return (
              !i &&
                a.content.components.repeatable1 &&
                (i = (0, x.default)(t).call(
                  t,
                  function (t, e) {
                    return t[e];
                  },
                  a.content.components.repeatable1.components
                )),
              (i = U.default.fromJS(i)),
              e
                .sub("components")
                .atomically()
                .set(t.join("."), i)
                .commit({ notify: !1 }),
              e.sub("components").sub(t.join("."))
            );
          },
          getRepeatableBinding: function (t) {
            return this.getDefaultBinding().sub(
              "components.".concat(t, ".list")
            );
          },
          getGalleryBinding: function (t) {
            return this.getDefaultBinding().sub(
              "components.".concat(t, ".sources")
            );
          },
          sbHasContent: function (t) {
            var e,
              a =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              i = n(399069),
              o = (n(234584), { showOnly: !0, parentBinding: null });
            a = F.default.merge(o, a);
            var r = this.getComponentBinding(t, a.parentBinding),
              l = r.get("type");
            if ("Background" === l) e = X.default.hasContent(r);
            else {
              var s = i.get(l);
              if (!s.hasContent)
                throw new Error(
                  "Component ".concat(l, " does not have hasContent defined!")
                );
              e = s.hasContent(r);
            }
            return a.showOnly ? e || V.default.isEditMode() : e;
          },
          sbAnyHasContent: function (t) {
            var e = this,
              n =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {};
            return (0, y.default)(F.default).call(
              F.default,
              t.split(" "),
              function (t) {
                return e.sbHasContent(t, n);
              }
            );
          },
          sbEditState: function (t) {
            var e =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              n = this.getComponentBinding(t, e.parentBinding);
            return (
              "editor" === n.get("_state") ||
              ("undefined" != typeof window && void 0 !== window.document
                ? Boolean(
                    document.querySelectorAll(
                      ".s-onyxnew-logo .s-component-editor"
                    ).length
                  )
                : void 0)
            );
          },
          sbTextAlignment: function (t) {
            var e =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              a = (n(399069), n(234584), { parentBinding: null });
            e = F.default.merge(a, e);
            var i = this.getComponentBinding(t, e.parentBinding),
              o = i.get("type");
            if ("RichText" === o) {
              var r,
                l = i.get("value"),
                s = n(554807),
                u = null != (r = s.getTextAlignment(l)) ? r : "";
              return u;
            }
            return (
              console.error(
                "Error: calling sbTextAlignment on a non-text element!"
              ),
              null
            );
          },
          sbAlignmentClass: function (t) {
            var e,
              n =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {};
            n = F.default.extend({ oldClass: "", classSuffix: "-align" }, n);
            var a = this.sbTextAlignment(t, n);
            return (
              (a = a ? a + n.classSuffix : ""),
              (0, k.default)((e = [n.oldClass, a].join(" "))).call(e)
            );
          },
          sbUniformTextAlignment: function (t) {
            var e = this,
              n =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              a = { showOnly: !1, parentBinding: null };
            n = F.default.merge(a, n);
            var i = t.split(" "),
              o = (0, B.default)(i).call(i, function (t) {
                return e.sbHasContent(t, n);
              });
            return 0 === o.length
              ? ""
              : (0, A.default)(F.default).call(F.default, o, function (t) {
                  return "left" === e.sbTextAlignment(t, n);
                })
              ? "left-align"
              : (0, A.default)(F.default).call(F.default, o, function (t) {
                  return "right" === e.sbTextAlignment(t, n);
                })
              ? "right-align"
              : (0, A.default)(F.default).call(F.default, o, function (t) {
                  return "center" === e.sbTextAlignment(t, n);
                })
              ? "center-align"
              : "";
          },
          getThemeFeature: function (t) {
            var e = n(234584),
              a = n(843296).get(e.getTheme().get("name"));
            return a && a.features && a.features[t];
          },
        };
      (e.default = nt), (t.exports = e.default);
    },
    808833: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(726394),
        r = (0, i.default)(o);
      n(382526), n(141817);
      var l = n(496486),
        s = (0, i.default)(l),
        u = n(399069),
        d = (0, i.default)(u);
      (e.default = function t(e, n) {
        (0, r.default)(this, t),
          (this.sectionName = n),
          (this.template = e.template),
          (this.displayName = e.displayName),
          (this.thumbnail = e.thumbnail || {}),
          (this.category = e.category),
          (this.description = e.description),
          (this.content = e.content),
          (this.proFeature = e.proFeature),
          (this.position = e.position),
          (this.canEditInMobileApp = e.canEditInMobileApp);
        var a = e.component,
          i = s.default.extend(a, { sectionModel: this });
        this.component = d.default.createSection(i);
      }),
        (t.exports = e.default);
    },
    389689: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(726394),
        r = (0, i.default)(o),
        l = n(569198),
        s = (0, i.default)(l),
        u = n(620116),
        d = (0, i.default)(u),
        c = n(847302),
        f = (0, i.default)(c),
        g = n(496486),
        p = (0, i.default)(g),
        h = n(808833),
        v = (0, i.default)(h),
        m = (function () {
          function t(e) {
            (0, r.default)(this, t), (this.theme = e), (this.coll = {});
          }
          return (
            (0, s.default)(t, [
              {
                key: "get",
                value: function (t) {
                  return this.coll[t];
                },
              },
              {
                key: "set",
                value: function (t, e) {
                  e instanceof v.default || (e = new v.default(e, t)),
                    (e.theme = this.theme),
                    (this.coll[t] = e);
                },
              },
              {
                key: "reset",
                value: function (t) {
                  for (var e in ((this.coll = {}), t)) this.set(e, t[e]);
                },
              },
              {
                key: "byCategory",
                value: function (t) {
                  return "all" === t || null == t
                    ? this.getAll()
                    : this._sort(
                        (0, d.default)(p.default).call(
                          p.default,
                          this.coll,
                          function (e) {
                            return e.category === t;
                          }
                        )
                      );
                },
              },
              {
                key: "getAll",
                value: function () {
                  return this._sort(
                    (0, d.default)(p.default).call(
                      p.default,
                      this.coll,
                      function (t) {
                        return null != t.category;
                      }
                    )
                  );
                },
              },
              {
                key: "_sort",
                value: function (t) {
                  return (0, f.default)(t).call(t, function (t, e) {
                    return (
                      ((t = t.position) - (e = e.position)) / Math.abs(t - e)
                    );
                  });
                },
              },
            ]),
            t
          );
        })();
      (e.default = m), (t.exports = e.default);
    },
    14637: function (t, e, n) {
      var a = n(663978),
        i = n(60530)(n(60530));
      a(e, "__esModule", { value: !0 });
      var o = n(726394),
        r = (0, i.default)(o),
        l = n(569198),
        s = (0, i.default)(l),
        u = n(678580),
        d = (0, i.default)(u);
      n(382526), n(141817);
      var c = n(496486),
        f = (0, i.default)(c),
        g = n(389689),
        p = (0, i.default)(g),
        h = n(183123),
        v = (0, i.default)(h),
        m = (function () {
          function t(e) {
            var n;
            (0, r.default)(this, t),
              (this.sections = new p.default(this)),
              (this.internal = e.internal),
              (this.displayName = e.displayName),
              (this.description = e.description),
              (this.variations = e.variations),
              (this.features = e.features),
              (this.thumbnail = e.thumbnail),
              (this.defaultFonts = e.defaultFonts);
            var a = v.default.getEnvironment();
            (this.activated =
              e.activated ||
              (0, d.default)((n = ["uat", "development"])).call(n, a)),
              this._resetSections(e.sections),
              this._setCallbacks(e.callbacks);
          }
          return (
            (0, s.default)(t, [
              {
                key: "getVariation",
                value: function (t) {
                  return f.default.detect(this.variations, function (e) {
                    return e.id === t;
                  });
                },
              },
              {
                key: "getSection",
                value: function (t, e) {
                  var n = e
                    ? this.sections.get("s6_common_section")
                    : this.sections.get(t);
                  if (null == n)
                    throw new Error("".concat(t, " section not found"));
                  return n;
                },
              },
              {
                key: "getSectionComponent",
                value: function (t) {
                  if (this.getSection(t)) return this.getSection(t).component;
                },
              },
              {
                key: "getSectionTemplate",
                value: function (t) {
                  if (this.getSection(t)) return this.getSection(t).template;
                },
              },
              {
                key: "_resetSections",
                value: function (t) {
                  this.sections.reset(t);
                },
              },
              {
                key: "_setCallbacks",
                value: function (t) {
                  for (var e in t) {
                    var n = t[e];
                    this[e] || (this[e] = n);
                  }
                },
              },
            ]),
            t
          );
        })();
      (e.default = m), (t.exports = e.default);
    },
    554807: function (t, e, n) {
      var a = n(353147),
        i = n(686902),
        o = n(14310),
        r = n(620116),
        l = n(834074),
        s = n(778914),
        u = n(239649),
        d = n(820368),
        c = n(663978),
        f = n(60530)(n(60530));
      c(e, "__esModule", { value: !0 });
      var g = n(487672),
        p = (0, f.default)(g),
        h = n(694473),
        v = (0, f.default)(h),
        m = n(933032),
        b = (0, f.default)(m),
        _ = n(666419),
        C = (0, f.default)(_),
        y = n(729828),
        S = (0, f.default)(y),
        x = n(981643),
        w = (0, f.default)(x),
        E = n(977766),
        P = (0, f.default)(E),
        N = n(277149),
        T = (0, f.default)(N),
        k = n(678580),
        I = (0, f.default)(k),
        B = n(25843),
        D = (0, f.default)(B);
      n(974916), n(115306), n(323123), n(569600);
      var A,
        M,
        O = n(223336),
        L = (0, f.default)(O),
        Z = n(45697),
        R = (0, f.default)(Z),
        G = n(973935),
        U = (0, f.default)(G),
        W = n(496486),
        F = (0, f.default)(W),
        H = n(143393),
        V = (0, f.default)(H),
        z = n(230139),
        $ = (0, f.default)(z),
        j = n(157444),
        J = (0, f.default)(j),
        K = n(43138),
        X = ((0, f.default)(K), n(399069)),
        Y = (0, f.default)(X),
        q = n(183123),
        Q = (0, f.default)(q),
        tt = n(234584),
        et = (0, f.default)(tt);
      function nt(t, e) {
        var n = i(t);
        if (o) {
          var a = o(t);
          e &&
            (a = r(a).call(a, function (e) {
              return l(t, e).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      function at(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n,
            a = null != arguments[e] ? arguments[e] : {};
          if (e % 2)
            s((n = nt(Object(a), !0))).call(n, function (e) {
              (0, p.default)(t, e, a[e]);
            });
          else if (u) d(t, u(a));
          else {
            var i;
            s((i = nt(Object(a)))).call(i, function (e) {
              c(t, e, l(a, e));
            });
          }
        }
        return t;
      }
      var it = ["<h1", "<h2", "<h3", "<h4", "<h5"],
        ot = Y.default.createPageComponent({
          displayName: "RichText",
          mixins: [(0, $.default)("editor")],
          observedProps: ["shouldAutoFocus"],
          statics: {
            hasContent: function (t) {
              return (
                "string" != typeof t && (t = t.get("value")),
                null != t && !/^\s*$/.test(t)
              );
            },
            isLeftAligned: function (t) {
              return /text-align:\s*left/.test(t);
            },
            isRightAligned: function (t) {
              return /text-align:\s*right/.test(t);
            },
            isCenterAligned: function (t) {
              return /text-align:\s*center/.test(t);
            },
            getTextAlignment: function (t) {
              return ot.isLeftAligned(t)
                ? "left"
                : ot.isRightAligned(t)
                ? "right"
                : ot.isCenterAligned(t)
                ? "center"
                : "";
            },
          },
          bobcatPropTypes: {
            shared: {
              publishedPageCount: R.default.number,
              isBlog: R.default.bool,
              sectionsNameSync: R.default.bool,
            },
            designer: {
              tagClassName: R.default.string,
              tagName: R.default.string,
              textType: R.default.oneOf(["heading", "body", "title"])
                .isRequired,
              defaultStyle: R.default.oneOf(["", "bold", "italic"]),
              className: R.default.string,
              emptyMessage: R.default.string,
              emptyTooltip: R.default.string,
              onlyNormalToolbar: R.default.bool,
              slideSettingsBinding: R.default.object,
            },
            data: {
              version: R.default.number,
              value: R.default.string,
              binding: R.default.object.isRequired,
            },
            callbacks: {
              checkParagraph: R.default.func,
              inputCallback: R.default.func,
            },
          },
          getBobcatDefaultProps: function () {
            return {
              designer: {
                tagClassName: "",
                tagName: "div",
                textType: "body",
                defaultStyle: "",
                applyWordBreaks: !1,
              },
              data: { version: 0, value: "" },
              callback: {
                checkParagraph: function () {},
                inputCallback: function () {},
              },
            };
          },
          _isPreviewMode: function () {
            return this.props.isPreviewMode;
          },
          _emptyMessage: function () {
            return this.props.emptyMessage || a("Editor|Add text.");
          },
          _emptyTooltip: function () {
            return (
              this.props.emptyTooltip ||
              a("Editor|Empty space won't be shown in the published site")
            );
          },
          _isBlog: function () {
            return "function" == typeof this.constructor.sharedProps
              ? this.constructor.sharedProps().isBlog
              : void 0;
          },
          _themeName: function () {
            return "function" == typeof this.constructor.sharedProps
              ? this.constructor.sharedProps().themeName
              : void 0;
          },
          _useDraftEditor: function () {
            return this._isBlog()
              ? Q.default.getIsNewBlogEditor()
              : Q.default.getCanUseDraftEditor();
          },
          _useAiDraftEditor: function () {
            return !this._isBlog() && et.default.getEnableAIRichText();
          },
          canUseCurrentEditor: function (t) {
            switch (t) {
              case "aiEditor":
                return this._useAiDraftEditor();
              case "draftEditor":
                return this._useDraftEditor() && !this._useAiDraftEditor();
              case "cKEditor":
                return !this._useDraftEditor() && !this._useAiDraftEditor();
              default:
                return !1;
            }
          },
          componentWillMount: function () {
            this.initMeta({
              textContentHash: new Date().getTime(),
              textEditorComponent: null,
              AIEditorComponent: null,
            });
          },
          componentDidMount: function () {
            this._oldBindingData = this.getDefaultBinding().get();
          },
          componentDidUpdate: function (t) {
            this._oldBindingData = this.getDefaultBinding().get();
          },
          showEmptyTooltip: function () {
            if (
              !A &&
              !("function" == typeof this.constructor.sharedProps
                ? this.constructor.sharedProps().isBlog
                : void 0) &&
              0 ===
                ("function" == typeof this.constructor.sharedProps
                  ? this.constructor.sharedProps().publishedPageCount
                  : void 0)
            ) {
              var t,
                e = (0, v.default)(
                  (t = (0, L.default)(U.default.findDOMNode(this)))
                ).call(t, ".s-component-editor-inner");
              return (
                e.tooltip({
                  placement: "top",
                  trigger: "manual",
                  container: (0, L.default)(U.default.findDOMNode(this)),
                  callback: function (t) {
                    return (0, b.default)(function () {
                      return t.one("mouseout", function () {
                        return e.tooltip("destroy");
                      });
                    }, 2500);
                  },
                }),
                e.tooltip("show"),
                (0, b.default)(function () {
                  return e.tooltip("destroy");
                }, 5e3),
                (A = !0)
              );
            }
          },
          shouldComponentUpdateOverride: function (t, e, n) {
            return e.binding.default
              ? e.binding.default.get() !== this._oldBindingData
              : t(e, n);
          },
          hasContent: function () {
            return ot.hasContent(this.props.value);
          },
          getTextAlignment: function () {
            return ot.getTextAlignment(this.props.value);
          },
          _highlightDefaultContent: function (t, e) {
            if (this.getData("defaultValue"))
              return t.selection.select(t.getBody(), !0);
            t.selection.select(t.getBody(), !0), t.selection.collapse(!1);
            for (
              var n = (function (t) {
                  var e = document.createElement("div");
                  return (e.innerHTML = t), e.textContent || e.innerText || "";
                })(e),
                a = 0,
                i = (0, C.default)(M);
              a < i.length;
              a++
            ) {
              var o,
                r = i[a];
              if ((0, S.default)((o = n.toLowerCase())).call(o, r)) {
                t.selection.select(t.getBody(), !0);
                break;
              }
            }
          },
          _getWordBreakValue: function () {
            var t,
              e,
              n = this.dtProps,
              a = n.tagName,
              i = n.textType,
              o = "";
            return (
              (o = this.props.applyWordBreaks
                ? J.default.applyWordBreaks(this.dtProps.value)
                : this.dtProps.value || ""),
              (Q.default.getCanUseDraftEditor() || this._isPreviewMode()) &&
                (o = this.dtProps.value || ""),
              ((a &&
                -1 !== (0, w.default)(a).call(a, "h") &&
                -1 === (0, w.default)(o).call(o, "<h")) ||
                this.props.inSectionSelector) &&
                (o = (0, P.default)(
                  (t = (0, P.default)((e = "<".concat(a, ">"))).call(
                    e,
                    o,
                    "</"
                  ))
                ).call(t, a, ">")),
              Q.default.getIsBlog() &&
                "body" === i &&
                (o = this.matchHeaderTag(o)),
              o
            );
          },
          matchHeaderTag: function (t) {
            return (0, T.default)(F.default).call(F.default, it, function (e) {
              return -1 !== (0, w.default)(t).call(t, e);
            })
              ? t
              : (0, I.default)(t).call(t, "font-size: 48px;")
              ? "<h1>".concat(t, "</h1>")
              : (0, I.default)(t).call(t, "font-size: 28px;")
              ? "<h2>".concat(t, "</h2>")
              : (0, I.default)(t).call(t, "font-size: 24px;")
              ? "<h3>".concat(t, "</h3>")
              : (0, I.default)(t).call(t, "font-size: 20px;")
              ? "<h4>".concat(t, "</h4>")
              : (0, I.default)(t).call(t, "font-size: inherit;")
              ? "<h5>".concat(t, "</h5>")
              : t;
          },
          _getContentProps: function () {
            var t = "s-component-content s-font-".concat(this.dsProps.textType);
            return (
              (!(this.isState("editor") && !this.props.inSectionSelector) &&
                this.hasContent()) ||
                (t += " hidden"),
              this.props.className && (t += " ".concat(this.props.className)),
              this.props.tagClassName &&
                (t += " ".concat(this.props.tagClassName)),
              {
                dangerouslySetInnerHTML: { __html: this._getWordBreakValue() },
                className: t,
                style: { whiteSpace: "pre-wrap" },
              }
            );
          },
          _getContentEditableContentProps: function () {
            var t = this;
            return {
              className: "s-component-content s-font-".concat(
                this.dsProps.textType
              ),
              dangerouslySetInnerHTML: {
                __html: this.dtProps.value || "<p><br></p>",
              },
              contentEditable: !0,
              style: { outline: "none" },
              ref: "textEditor",
              onFocus: function () {
                var e = (0, L.default)(t.refs.textEditor).closest(
                    ".s-component-editor-inner"
                  ),
                  n = e.parent();
                e.addClass("active"), n.removeClass("empty");
                var a = t.refs.textEditor.textContent;
                if (
                  t.getData("defaultValue") ||
                  (0, T.default)(M).call(M, function (t) {
                    return (0, S.default)(a).call(a, t);
                  })
                )
                  return (0, b.default)(function () {
                    if (window.getSelection && document.createRange) {
                      var e = window.getSelection(),
                        n = document.createRange();
                      return (
                        n.selectNodeContents(t.refs.textEditor),
                        e.removeAllRanges(),
                        e.addRange(n)
                      );
                    }
                  }, 0);
              },
              onBlur: function () {
                var e = (0, L.default)(t.refs.textEditor).closest(
                    ".s-component-editor-inner"
                  ),
                  n = e.parent();
                e.removeClass("active");
                var a = t.refs.textEditor.textContent;
                a || n.addClass("empty");
                var i = t.refs.textEditor.innerHTML;
                return t._saveContentEditableData(i, a);
              },
            };
          },
          getSaveButtonProps: function () {
            var t = this;
            return {
              onClickRemove: function (e) {
                var n = t._getEditor();
                return n.setContent(""), n.focus(), t.updateData({ value: "" });
              },
              onClickCancel: function (e) {
                var n = t._getEditor();
                return (
                  null != n && n.setContent(t.dtProps.value), t.onClickCancel()
                );
              },
              onClickSave: function (e) {
                return t._updateValue(), t.updateState("normal"), t.savePage();
              },
              onClickFont: function () {
                return (
                  t._updateValue(),
                  t.updateState("normal"),
                  "function" == typeof t.constructor.sharedProps
                    ? t.constructor
                        .sharedProps()
                        .openStylePanel(t.dsProps.textType)
                    : void 0
                );
              },
              binding: this.getDefaultBinding(),
            };
          },
          _initCKData: function (t, e) {
            if (this.dtProps.backupValue)
              return this.updateData({ backupValue: null });
          },
          transformHTML: function (t) {
            var e = "<transform>"
              .concat(t, "</transform>")
              .replace(/<wbr>|<wbr \/>/g, "");
            return L.default.parseHTML(e)[0].innerHTML;
          },
          _saveCKData: function (t) {
            var e = t || {},
              n = e.richTextData,
              a = e.version,
              i = e.aiSettings,
              o = void 0 === i ? {} : i,
              r = this.transformHTML(n),
              l = { value: r, version: a };
            return (
              this._useAiDraftEditor() &&
                (l = at(at({}, l), {}, { aiSettings: o })),
              this.props.slideSettingsBinding &&
                !et.default.getIsCROSectionTemplate() &&
                this._syncSectionName(r),
              this.updateData(l),
              this.savePage()
            );
          },
          _saveContentEditableData: function (t, e) {
            var n = this.transformHTML(t);
            if (
              (e || (n = ""),
              (e || this.previousContentEditableData) &&
                n !== this.previousContentEditableData)
            )
              return (
                (this.previousContentEditableData = n),
                this.updateData({ value: n }),
                this.savePage()
              );
          },
          _onFocusCK: function (t) {
            return (
              this.onClickEditor(),
              (this.getData("defaultValue") ||
                (0, T.default)(M).call(M, function (e) {
                  var n;
                  return (0, S.default)((n = t.editable().getText())).call(
                    n,
                    e
                  );
                })) &&
                (0, b.default)(function () {
                  var e = t.createRange();
                  return e.selectNodeContents(t.editable()), e.select();
                }, 0),
              "function" == typeof this.props.onfocus
                ? this.props.onfocus()
                : void 0
            );
          },
          _onFocusDraft: function () {
            return (
              this.onClickEditor(),
              "function" == typeof this.props.onfocus
                ? this.props.onfocus()
                : void 0
            );
          },
          _syncSectionName: function (t) {
            var e;
            if (
              "function" == typeof this.constructor.sharedProps
                ? this.constructor.sharedProps().sectionsNameSync
                : void 0
            ) {
              var n = (0, D.default)(
                (e = (0, L.default)("<div>".concat(t, "</div>")).text())
              ).call(e);
              if (0 !== n.length) {
                var a;
                if (
                  (n.length > 25 &&
                    (n = (0, D.default)((a = n.substr(0, 25))).call(a)),
                  25 === n.length && -1 !== (0, w.default)(n).call(n, " "))
                ) {
                  var i = n.substr(0, 25).split(" ");
                  i.pop(), (n = i.join(" "));
                }
                return "function" == typeof this.constructor.sharedProps
                  ? this.constructor
                      .sharedProps()
                      .updateSectionName(this.props.slideSettingsBinding, n)
                  : void 0;
              }
            }
          },
          _toNormalState: function () {
            var t = this.props.onblur;
            return "function" == typeof t && t(), this.updateState("normal");
          },
          _onChange: function () {
            if (this.props.onChange) return this.props.onChange();
          },
          _clickEditButton: function (t) {
            var e = this.props.clickEditButton,
              n = this.refs,
              a = n.ck,
              i = n.draft;
            "function" == typeof e && e(),
              this.onClickEditor(),
              a &&
                a.editor &&
                "function" == typeof a.editor.focus &&
                a.editor.focus(),
              i &&
                i.domEditor &&
                "function" == typeof i.domEditor.focus &&
                i.domEditor.focus(),
              t.stopPropagation();
          },
          _clickEditOverlay: function () {
            "function" == typeof this.props.clickEditOverlay &&
              this.props.clickEditOverlay();
          },
          _getSectionName: function () {
            return (
              this.props.sectionModel && this.props.sectionModel.sectionName
            );
          },
          _getAiSettings: function () {
            return (
              this.props.aiSettings ||
              V.default.fromJS({
                tone: et.default.getSiteBuilderTone(),
                language: et.default.getSiteBuilderlang(),
              })
            ).toObject();
          },
          getCKEditor: function () {
            return (
              this.getMeta("textEditorComponent"),
              function () {
                return null;
              }
            );
          },
          getDraftEditor: function () {
            return (
              this.getMeta("textEditorComponent"),
              function () {
                return null;
              }
            );
          },
          getAIEditor: function () {
            return (
              this.getMeta("AIEditorComponent"),
              function () {
                return null;
              }
            );
          },
          getCurrentPath: function () {
            return this.getDefaultBinding()._path;
          },
          getTextAiGenerateParams: function () {
            return {};
          },
          render: function () {
            return n(596944).apply(this);
          },
        });
      (e.default = ot), (t.exports = e.default);
    },
  },
]);
