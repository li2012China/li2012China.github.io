/*! For license information please see 8072.621c289b3c58357697e5-site-bundle.js.LICENSE.txt */
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [8072],
  {
    98926: function (e, t, n) {
      e.exports = n(576258);
    },
    408072: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          areBackgroundAnimationsEnabledOnThisDevice: function () {
            return I;
          },
          default: function () {
            return M;
          },
        });
      var i,
        a = n(468420),
        o = n(327344),
        s = n(844845),
        r = n(54103),
        c = n.n(r),
        l = n(778914),
        u = n.n(l),
        h = n(786483),
        d = n(818166),
        f = n(496486),
        m = n(694473),
        g = n.n(m),
        p = n(933032),
        v = n.n(p),
        _ = n(820666),
        y = n(223336),
        w = (function () {
          function e(t, n) {
            var i, o, r, l;
            if (
              ((0, a.Z)(this, e),
              (0, s.Z)(this, "_waypoints", void 0),
              (0, s.Z)(this, "_refreshTimeout", null),
              (0, s.Z)(this, "_animationType", null),
              (this._waypoints = []),
              t && "none" !== t.page_scroll)
            ) {
              var u = t.page_scroll;
              this._animationType = u;
              var h = "s-animation-page-".concat(u, "-before");
              g()((i = y(n)))
                .call(
                  i,
                  ".s-section .s-component, .s-section.s-rows-section .s-item-text-group, .process-item-infos"
                )
                .each(function (e, t) {
                  if (!_(t)) {
                    var n = (t = y(t)).parents(".s-info-box"),
                      i = t.parents(".s-item-text-group");
                    n.length > 0 ? (t = n) : i.length > 0 && (t = i),
                      t.addClass(h);
                  }
                }),
                y("." + h).each(function () {
                  y(this)
                    .parents("." + h)
                    .removeClass(h);
                });
              var d = c()((o = this._onScrolledToElement)).call(o, this);
              (this._waypoints = g()((r = y(n)))
                .call(r, "." + h)
                .waypoint(
                  function (e) {
                    "down" === e && (d(this.element), this.destroy());
                  },
                  { offset: "100%" }
                )),
                (this._onScroll = f.debounce(
                  c()((l = this._onScroll)).call(l, this),
                  200
                )),
                y(window).on("scroll", this._onScroll),
                (this._refreshTimeout = v()(function () {
                  Waypoint.refreshAll(), (this._refreshTimeout = null);
                }, 500));
            }
          }
          return (
            (0, o.Z)(e, [
              {
                key: "_onScrolledToElement",
                value: function (e) {
                  y(e)
                    .addClass("s-animation-page-".concat(this._animationType))
                    .removeClass(
                      "s-animation-page-".concat(this._animationType, "-before")
                    );
                },
              },
              {
                key: "_onScroll",
                value: function () {
                  var e = this;
                  y(window).scrollTop() + y(window).height() >=
                    y("body").height() &&
                    y(
                      ".s-animation-page-".concat(
                        this._animationType,
                        "-before"
                      )
                    ).each(function (t, n) {
                      return e._onScrolledToElement(n);
                    });
                },
              },
              {
                key: "destroy",
                value: function () {
                  var e;
                  u()((e = this._waypoints)).call(e, function (e) {
                    return e.destroy();
                  }),
                    y(window).off("resize", this._onScroll),
                    clearTimeout(this._refreshTimeout);
                },
              },
            ]),
            e
          );
        })(),
        b = n(977766),
        k = n.n(b),
        S = n(620116),
        A = n.n(S),
        T = n(981643),
        x = n.n(T),
        P = n(98926),
        E = n.n(P),
        C = n(43138),
        H = n(234584);
      function Z(e) {
        var t, n;
        return (
          g()((t = y(e))).call(t, ".s-bg-image").length > 0 &&
            (e = g()((n = y(e))).call(n, ".s-bg-image")[0]),
          e
        );
      }
      var I,
        B = ["zine", "glow", "pitch_new"],
        W = k()((i = ["app", "s5-theme"])).call(i, B),
        D = (function () {
          function e(t, n) {
            var i, o;
            (0, a.Z)(this, e),
              (0, s.Z)(this, "_sectionsThatShouldBeAnimated", void 0),
              (0, s.Z)(this, "_parallaxSpeed", void 0),
              (0, s.Z)(this, "_contentElement", void 0),
              (0, s.Z)(this, "_isDestroyed", !1),
              (this._contentElement = n),
              (this._applyParallax = c()((i = this._applyParallax)).call(
                i,
                this
              )),
              (this._onWindowResize = f.debounce(
                c()((o = this._onWindowResize)).call(o, this),
                200
              )),
              y(window).on("resize", this._onWindowResize),
              y(window).on("scroll", this._applyParallax),
              this._updateSectionsThatShouldBeAnimated(),
              this._updateBackgroundAnimationSpeed(t, !0);
          }
          return (
            (0, o.Z)(e, [
              {
                key: "_updateBackgroundAnimationSpeed",
                value: function (e, t) {
                  var n = this._getParallaxSpeed(e);
                  n !== this._parallaxSpeed &&
                    ((this._parallaxSpeed = n),
                    1 === this._parallaxSpeed
                      ? this._removeParallax()
                      : t || this._applyParallax(!0));
                },
              },
              {
                key: "_getParallaxSpeed",
                value: function (e) {
                  return "none" === e.background
                    ? 1
                    : "fixed" === e.background
                    ? 0
                    : "parallax" === e.background
                    ? 0.3
                    : void 0;
                },
              },
              {
                key: "_onWindowResize",
                value: function () {
                  var e = this;
                  I() ||
                    this._sectionsThatShouldBeAnimated.each(function (t, n) {
                      e._revertAnimationStyles(n);
                    }),
                    this._applyParallax(!0);
                },
              },
              {
                key: "handlePageDataChange",
                value: function (e) {
                  this._updateSectionsThatShouldBeAnimated(),
                    this._updateBackgroundAnimationSpeed(e);
                },
              },
              {
                key: "_removeParallax",
                value: function () {
                  var e = this;
                  this._sectionsThatShouldBeAnimated.each(function (t, n) {
                    e._revertAnimationStyles(n);
                  });
                },
              },
              {
                key: "_updateSectionsThatShouldBeAnimated",
                value: function () {
                  var e, t;
                  this._sectionsThatShouldBeAnimated = A()(
                    (e = g()((t = y(this._contentElement))).call(
                      t,
                      ".s-section"
                    ))
                  ).call(e, function (e, t) {
                    var n = y(t),
                      i = n.is(".s-slider-section"),
                      a = n.is(".s-grid-section"),
                      o =
                        "none" != n.css("backgroundImage") ||
                        "none" !=
                          g()(n).call(n, "s-bg-image").css("backgroundImage"),
                      s = n.is(".s-bg-video");
                    return o && !i && !s && !a;
                  });
                },
              },
              {
                key: "_applyParallax",
                value: function (e) {
                  var t = this;
                  if (I() && 1 !== this._parallaxSpeed) {
                    var n = y(window).scrollTop();
                    this._sectionsThatShouldBeAnimated.each(function (i, a) {
                      if (((a = Z(a)), y(a).hasClass("_animate-background"))) {
                        var o = y(a).parents(".slide").index(),
                          s = o <= 1,
                          r = o < 1,
                          c = 1 === o,
                          l =
                            y(a).data("imageHeight") > y(a).outerHeight() + 150,
                          u = t._parallaxSpeed,
                          h = 0.3 === u,
                          f = a.offsetHeight,
                          m = window.innerHeight,
                          g =
                            (window.innerWidth,
                            a.getBoundingClientRect().top + n),
                          p = g,
                          v = H.getThemeName(),
                          _ = -1 !== x()(W).call(W, v);
                        if (s && _ && h && l && !C.isSmallerThanDesktop()) {
                          u = 0.7;
                          var w = "s5-theme" === v,
                            b = -1 === x()(B).call(B, v);
                          if (w) {
                            var S = d.getS5Theme(),
                              A = null == S ? void 0 : S.getIn(["nav", "name"]);
                            b =
                              !(
                                null != S && S.getIn(["nav", "isTransparent"])
                              ) && "left" !== A;
                          }
                          b &&
                            (p -=
                              y(".s-navbar-desktop").outerHeight() ||
                              y("#header-container").outerHeight()),
                            c && (p -= y(".s-section-1").outerHeight());
                        }
                        var T = p - m,
                          P = p + f,
                          I = g - m <= n && n <= g + f,
                          D = P - T,
                          N = (n - T) / D,
                          z = (Math.max(m, f), P - m),
                          F = P - (z + (m * u - D * u * ((z - T) / D)));
                        if (
                          (e &&
                            $B.TH.getBackgroundImageSize(y(a), function (e) {
                              if (!t._isDestroyed) {
                                var n = e.width / e.height;
                                if (y(a).hasClass("_image-position-center"))
                                  y(a).data("imageWidth", e.width),
                                    y(a).data("imageHeight", e.height);
                                else {
                                  var i = F,
                                    o = F * n,
                                    s = y(a).outerWidth() || 0;
                                  o < s && (i = (o = s) / n),
                                    y(a).data("imageWidth", o),
                                    y(a).data("imageHeight", i);
                                }
                                t._applyParallax(!1);
                              }
                            }),
                          I)
                        ) {
                          var L,
                            M = y(a).outerWidth() || 0,
                            R =
                              y(a).offset().left +
                              (M - y(a).data("imageWidth")) / 2,
                            O = m * u - D * u * N,
                            V = (F - y(a).data("imageHeight")) / 2 + O;
                          if (
                            (r || (V += 2.75),
                            s && _ && h && l && !C.isSmallerThanDesktop())
                          ) {
                            var j =
                                (y(a).data("imageHeight") -
                                  y(a).outerHeight()) /
                                2,
                              J = (y(a).offset() || {}).top;
                            if (!E()(J) && ((V = J - j + O), c)) {
                              var $ = J - n;
                              V = Math.min($, V);
                            }
                          }
                          if (E()(V)) return;
                          y(a).css({
                            "background-attachment": "fixed",
                            "background-position-x": R,
                            "background-position-y": V,
                          }),
                            "repeat" !== y(a).css("background-repeat") &&
                              y(a).css({
                                "background-size": k()(
                                  (L = "".concat(
                                    y(a).data("imageWidth"),
                                    "px "
                                  ))
                                ).call(L, y(a).data("imageHeight"), "px"),
                              });
                        }
                      } else t._revertAnimationStyles(a);
                    });
                  }
                },
              },
              {
                key: "_revertAnimationStyles",
                value: function (e) {
                  (e = Z(e)), y(e).css("background-attachment", "");
                  var t = y(e).attr("data-react-style");
                  t && y(e).css(JSON.parse(t));
                },
              },
              {
                key: "destroy",
                value: function () {
                  this._removeParallax(),
                    y(window).off("resize", this._onWindowResize),
                    y(window).off("scroll", this._applyParallax),
                    (this._isDestroyed = !0);
                },
              },
            ]),
            e
          );
        })();
      (I = function () {
        return !(C.isMobile() || C.isSmallScreen() || C.isEdge() || C.isIE11());
      }),
        n(569600);
      var N = n(2991),
        z = n.n(N),
        F = (function () {
          function e(t, n, i) {
            if (
              ((0, a.Z)(this, e),
              (0, s.Z)(this, "_contentElement", void 0),
              (this._contentElement = n),
              (!C.isMobile() && "zoom_in" === t.image_link_hover) || i)
            ) {
              var o = [
                  ".s-component.s-media",
                  ".s-gallery-item",
                  ".image-wrapper",
                  ".s-image",
                  ".s-blog-avatar-container",
                ],
                r = z()(o)
                  .call(o, function (e) {
                    return ".s-section:not(.s-footer-section) ".concat(
                      e,
                      " a img"
                    );
                  })
                  .join(", ");
              (r += ", .s-blog-avatar, .s-grid-section-cell a .s-bg-image"),
                y(n).on("mouseenter.imageLinkHoverAnimator", r, function () {
                  var e,
                    t = y(this),
                    n = t.width(),
                    i = t.height();
                  (e = n > i ? (n + 20) / n : (i + 20) / i),
                    y(this).css("transform", "scale(".concat(e, ")"));
                }),
                y(n).on("mouseleave.imageLinkHoverAnimator", r, function () {
                  y(this).css("transform", "");
                });
            }
          }
          return (
            (0, o.Z)(e, [
              {
                key: "destroy",
                value: function () {
                  y(this._contentElement).off(
                    "mouseenter.imageLinkHoverAnimator"
                  ),
                    y(this._contentElement).off(
                      "mouseleave.imageLinkHoverAnimator"
                    );
                },
              },
            ]),
            e
          );
        })(),
        L = (function () {
          function e(t) {
            var n, i;
            (0, a.Z)(this, e),
              (0, s.Z)(this, "_newPageFadeInToken", null),
              (0, s.Z)(this, "_animations", void 0),
              (0, s.Z)(this, "_contentElement", void 0),
              (0, s.Z)(this, "isPreviewMode", function () {
                return !1;
              }),
              (this._contentElement = t),
              this._shouldAnimate() &&
                (d.getSiteAnimations(),
                this._initAnimations(t),
                (this._onPageDataChange = f.debounce(
                  c()((n = this._onPageDataChange)).call(n, this),
                  50
                )),
                d.addChangeListener(this._onPageDataChange),
                (this._onNewPageFadeIn = c()((i = this._onNewPageFadeIn)).call(
                  i,
                  this
                )),
                (this._newPageFadeInToken = h.Event.subscribe(
                  "Page.afterNewOneFadeIn",
                  this._onNewPageFadeIn
                )));
          }
          return (
            (0, o.Z)(e, [
              {
                key: "_onPageDataChange",
                value: function () {
                  var e,
                    t = d.getSiteAnimations();
                  u()((e = this._animations)).call(e, function (e) {
                    e.handlePageDataChange && e.handlePageDataChange(t);
                  });
                },
              },
              {
                key: "_onNewPageFadeIn",
                value: function () {
                  d.getSiteAnimations(),
                    this._destroyAnimations(),
                    this._initAnimations(this._contentElement);
                },
              },
              {
                key: "_initAnimations",
                value: function (e) {
                  var t = d.getSiteAnimations();
                  (this._animations = []),
                    this._animations.push(new w(t, e)),
                    this._animations.push(new F(t, e, this.isPreviewMode())),
                    this._animations.push(new D(t, e));
                },
              },
              {
                key: "_shouldAnimate",
                value: function () {
                  return !/animation=0/.test(window.location.href);
                },
              },
              {
                key: "destroy",
                value: function () {
                  this._shouldAnimate() &&
                    (d.removeChangeListener(this._onPageDataChange),
                    h.Event.unsubscribe(this._newPageFadeInToken),
                    this._destroyAnimations());
                },
              },
              {
                key: "_destroyAnimations",
                value: function () {
                  var e;
                  u()((e = this._animations)).call(e, function (e) {
                    return e.destroy();
                  });
                },
              },
            ]),
            e
          );
        })(),
        M = L;
    },
    770063: function (e, t, n) {
      n(789622);
      var i = n(354058);
      e.exports = i.Number.isNaN;
    },
    789622: function (e, t, n) {
      n(276887)(
        { target: "Number", stat: !0 },
        {
          isNaN: function (e) {
            return e != e;
          },
        }
      );
    },
    576258: function (e, t, n) {
      var i = n(770063);
      e.exports = i;
    },
    820666: function (e, t, n) {
      e.exports = function (e, t, r) {
        var c = {
          container: n.g.document.body,
          offset: 0,
          debounce: 15,
          failsafe: 150,
        };
        (void 0 !== t && "function" != typeof t) || ((r = t), (t = {}));
        var l = (c.container = t.container || c.container),
          u = (c.offset = t.offset || c.offset),
          h = (c.debounce = t.debounce || c.debounce),
          d = (c.failsafe = t.failsafe || c.failsafe);
        !0 === d ? (d = 150) : !1 === d && (d = 0),
          d > 0 && d < h && (d = h + 50);
        for (var f = 0; f < i.length; f++)
          if (
            i[f].container === l &&
            i[f]._debounce === h &&
            i[f]._failsafe === d
          )
            return i[f].isInViewport(e, u, r);
        return i[
          i.push(
            (function (e, t, i) {
              var r,
                c,
                l,
                u,
                h = (function () {
                  var e = [];
                  function t(t) {
                    for (var n = e.length - 1; n >= 0; n--)
                      if (e[n][0] === t) return n;
                    return -1;
                  }
                  function n(e) {
                    return -1 !== t(e);
                  }
                  return {
                    add: function (t, i, a) {
                      n(t) || e.push([t, i, a]);
                    },
                    remove: function (n) {
                      var i = t(n);
                      -1 !== i && e.splice(i, 1);
                    },
                    isWatched: n,
                    checkAll: function (t) {
                      return function () {
                        for (var n = e.length - 1; n >= 0; n--)
                          t.apply(this, e[n]);
                      };
                    },
                  };
                })(),
                d = e === n.g.document.body ? n.g : e,
                f =
                  ((r = h.checkAll(function (e, t, n) {
                    m(e, t) && (h.remove(e), n(e));
                  })),
                  (c = t),
                  function () {
                    var e = this,
                      t = arguments,
                      n = l;
                    function i() {
                      (u = null), r.apply(e, t);
                    }
                    clearTimeout(u), (u = setTimeout(i, c)), n && r.apply(e, t);
                  });
              function m(t, i) {
                if (!t) return !1;
                if (
                  !s(n.g.document.documentElement) ||
                  !s(n.g.document.documentElement)
                )
                  return !1;
                if (!t.offsetWidth || !t.offsetHeight) return !1;
                var a = t.getBoundingClientRect(),
                  o = {};
                if (e === n.g.document.body)
                  o = {
                    top: -i,
                    left: -i,
                    right: n.g.document.documentElement.clientWidth + i,
                    bottom: n.g.document.documentElement.clientHeight + i,
                  };
                else {
                  var r = e.getBoundingClientRect();
                  o = {
                    top: r.top - i,
                    left: r.left - i,
                    right: r.right + i,
                    bottom: r.bottom + i,
                  };
                }
                return (
                  a.right >= o.left &&
                  a.left <= o.right &&
                  a.bottom >= o.top &&
                  a.top <= o.bottom
                );
              }
              return (
                o(d, "scroll", f),
                d === n.g && o(n.g, "resize", f),
                a &&
                  (function (e, t, n) {
                    var i = new MutationObserver(function (e) {
                        !0 === e.some(s) && setTimeout(n, 0);
                      }),
                      a = Array.prototype.filter,
                      o = Array.prototype.concat;
                    function s(t) {
                      var n = o.call(
                        [],
                        Array.prototype.slice.call(t.addedNodes),
                        t.target
                      );
                      return a.call(n, e.isWatched).length > 0;
                    }
                    i.observe(t, {
                      childList: !0,
                      subtree: !0,
                      attributes: !0,
                    });
                  })(h, e, f),
                i > 0 && setInterval(f, i),
                {
                  container: e,
                  isInViewport: function (e, t, n) {
                    if (!n) return m(e, t);
                    var i = (function (e, t, n) {
                      function i() {
                        h.add(e, t, n);
                      }
                      function a() {
                        h.remove(e);
                      }
                      return { watch: i, dispose: a };
                    })(e, t, n);
                    return i.watch(), i;
                  },
                  _debounce: t,
                  _failsafe: i,
                }
              );
            })(l, h, d)
          ) - 1
        ].isInViewport(e, u, r);
      };
      var i = [],
        a = "function" == typeof n.g.MutationObserver;
      function o(e, t, n) {
        e.attachEvent
          ? e.attachEvent("on" + t, n)
          : e.addEventListener(t, n, !1);
      }
      var s = function () {
        return (
          !n.g.document ||
          (n.g.document.documentElement.compareDocumentPosition
            ? function (e, t) {
                return !!(16 & e.compareDocumentPosition(t));
              }
            : n.g.document.documentElement.contains
            ? function (e, t) {
                return e !== t && !!e.contains && e.contains(t);
              }
            : function (e, t) {
                for (; (t = t.parentNode); ) if (t === e) return !0;
                return !1;
              })
        );
      };
    },
  },
]);
