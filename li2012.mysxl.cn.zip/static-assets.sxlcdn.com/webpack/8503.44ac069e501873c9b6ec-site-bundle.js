/*! For license information please see 8503.44ac069e501873c9b6ec-site-bundle.js.LICENSE.txt */
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [8503],
  {
    168503: function (e) {
      e.exports = (function () {
        var e = function (e, t, n) {
            for (var r = n, o = 0, i = e.length; o < i; o++)
              r = t(r, e[o], o, e);
            return r;
          },
          t = !{ toString: null }.propertyIsEnumerable("toString"),
          n = [
            "toString",
            "toLocaleString",
            "valueOf",
            "hasOwnProperty",
            "isPrototypeOf",
            "propertyIsEnumerable",
            "constructor",
          ],
          r = function (e) {
            return e < 10 ? "0" + e : e;
          },
          o = function (t, n) {
            return e(
              t,
              function (e, t, r, o) {
                return e.concat(n(t, r, o));
              },
              []
            );
          },
          i = e,
          a = function (t, n) {
            return e(
              t,
              function (e, t, r, o) {
                return n(t, r, o) ? e.concat(t) : e;
              },
              []
            );
          },
          s = function (t, n) {
            return e(
              t,
              function (e, t, r, o) {
                return !0 === e || t === n;
              },
              !1
            );
          },
          u = function (e) {
            var r = [],
              o = void 0;
            for (o in e)
              Object.prototype.hasOwnProperty.call(e, o) && r.push(o);
            if (!t) return r;
            for (var i = 0, a = n.length; i < a; i++)
              Object.prototype.hasOwnProperty.call(e, n[i]) && r.push(n[i]);
            return r;
          },
          c = function (e) {
            return "[object Array]" === Object.prototype.toString.call(e);
          },
          f = function () {
            var e = new Date();
            return (
              e.getUTCFullYear() +
              "-" +
              r(e.getUTCMonth() + 1) +
              "-" +
              r(e.getUTCDate()) +
              "T" +
              r(e.getUTCHours()) +
              ":" +
              r(e.getUTCMinutes()) +
              ":" +
              r(e.getUTCSeconds()) +
              "." +
              (e.getUTCMilliseconds() / 1e3).toFixed(3).slice(2, 5) +
              "Z"
            );
          };
        function l(e, t) {
          if (!(e instanceof t))
            throw new TypeError("Cannot call a class as a function");
        }
        var d = f,
          g = (function () {
            function e() {
              var t =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : "[anonymous]",
                n =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {},
                r =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : "manual",
                o =
                  arguments.length > 3 && void 0 !== arguments[3]
                    ? arguments[3]
                    : d();
              l(this, e),
                (this.type = r),
                (this.name = t),
                (this.metaData = n),
                (this.timestamp = o);
            }
            return (
              (e.prototype.toJSON = function () {
                return {
                  type: this.type,
                  name: this.name,
                  timestamp: this.timestamp,
                  metaData: this.metaData,
                };
              }),
              e
            );
          })(),
          h = g,
          p = {},
          v = s;
        (p.positiveIntIfDefined = function (e) {
          return (
            v(["undefined", "number"], typeof e) &&
            parseInt("" + e, 10) === e &&
            e > 0
          );
        }),
          (p.stringWithLength = function (e) {
            return "string" == typeof e && !!e.length;
          });
        var m = {},
          y = a,
          b = i,
          w = u,
          S = c,
          O = s,
          j = p.positiveIntIfDefined,
          E = p.stringWithLength;
        (m.schema = {
          apiKey: {
            defaultValue: function () {
              return null;
            },
            message: "is required",
            validate: E,
          },
          appVersion: {
            defaultValue: function () {
              return null;
            },
            message: "should be a string",
            validate: function (e) {
              return null === e || E(e);
            },
          },
          autoNotify: {
            defaultValue: function () {
              return !0;
            },
            message: "should be true|false",
            validate: function (e) {
              return !0 === e || !1 === e;
            },
          },
          beforeSend: {
            defaultValue: function () {
              return [];
            },
            message: "should be a function or array of functions",
            validate: function (e) {
              return (
                "function" == typeof e ||
                (S(e) &&
                  y(e, function (e) {
                    return "function" == typeof e;
                  }).length === e.length)
              );
            },
          },
          endpoints: {
            defaultValue: function () {
              return {
                notify: "https://notify.bugsnag.com",
                sessions: "https://sessions.bugsnag.com",
              };
            },
            message:
              "should be an object containing endpoint URLs { notify, sessions }. sessions is optional if autoCaptureSessions=false",
            validate: function (e, t) {
              return (
                e &&
                "object" == typeof e &&
                E(e.notify) &&
                (!1 === t.autoCaptureSessions || E(e.sessions)) &&
                0 ===
                  y(w(e), function (e) {
                    return !O(["notify", "sessions"], e);
                  }).length
              );
            },
          },
          autoCaptureSessions: {
            defaultValue: function (e, t) {
              return (
                void 0 === t.endpoints ||
                (!!t.endpoints && !!t.endpoints.sessions)
              );
            },
            message: "should be true|false",
            validate: function (e) {
              return !0 === e || !1 === e;
            },
          },
          notifyReleaseStages: {
            defaultValue: function () {
              return null;
            },
            message: "should be an array of strings",
            validate: function (e) {
              return (
                null === e ||
                (S(e) &&
                  y(e, function (e) {
                    return "string" == typeof e;
                  }).length === e.length)
              );
            },
          },
          releaseStage: {
            defaultValue: function () {
              return "production";
            },
            message: "should be a string",
            validate: function (e) {
              return "string" == typeof e && e.length;
            },
          },
          maxBreadcrumbs: {
            defaultValue: function () {
              return 20;
            },
            message: "should be a number ≤40",
            validate: function (e) {
              return 0 === e || (j(e) && (void 0 === e || e <= 40));
            },
          },
          autoBreadcrumbs: {
            defaultValue: function () {
              return !0;
            },
            message: "should be true|false",
            validate: function (e) {
              return "boolean" == typeof e;
            },
          },
          user: {
            defaultValue: function () {
              return null;
            },
            message: "(object) user should be an object",
            validate: function (e) {
              return "object" == typeof e;
            },
          },
          metaData: {
            defaultValue: function () {
              return null;
            },
            message: "should be an object",
            validate: function (e) {
              return "object" == typeof e;
            },
          },
          logger: {
            defaultValue: function () {},
            message:
              "should be null or an object with methods { debug, info, warn, error }",
            validate: function (e) {
              return (
                !e ||
                (e &&
                  b(
                    ["debug", "info", "warn", "error"],
                    function (t, n) {
                      return t && "function" == typeof e[n];
                    },
                    !0
                  ))
              );
            },
          },
        }),
          (m.mergeDefaults = function (e, t) {
            if (!e || !t)
              throw new Error("opts and schema objects are required");
            return b(
              w(t),
              function (n, r) {
                return (
                  (n[r] = void 0 !== e[r] ? e[r] : t[r].defaultValue(e[r], e)),
                  n
                );
              },
              {}
            );
          }),
          (m.validate = function (e, t) {
            if (!e || !t)
              throw new Error("opts and schema objects are required");
            var n = b(
              w(t),
              function (n, r) {
                return t[r].validate(e[r], e)
                  ? n
                  : n.concat({ key: r, message: t[r].message, value: e[r] });
              },
              []
            );
            return { valid: !n.length, errors: n };
          });
        var N = function (e) {
            return e.app && "string" == typeof e.app.releaseStage
              ? e.app.releaseStage
              : e.config.releaseStage;
          },
          B = function (e) {
            return !(
              !e ||
              (!e.stack && !e.stacktrace && !e["opera#sourceloc"]) ||
              "string" !=
                typeof (e.stack || e.stacktrace || e["opera#sourceloc"]) ||
              e.stack === e.name + ": " + e.message
            );
          },
          k = {};
        !(function (e, t) {
          "use strict";
          "object" == typeof k ? (k = t()) : (e.StackFrame = t());
        })(this, function () {
          "use strict";
          function e(e) {
            return !isNaN(parseFloat(e)) && isFinite(e);
          }
          function t(e) {
            return e.charAt(0).toUpperCase() + e.substring(1);
          }
          function n(e) {
            return function () {
              return this[e];
            };
          }
          var r = ["isConstructor", "isEval", "isNative", "isToplevel"],
            o = ["columnNumber", "lineNumber"],
            i = ["fileName", "functionName", "source"],
            a = r.concat(o, i, ["args"]);
          function s(e) {
            if (e instanceof Object)
              for (var n = 0; n < a.length; n++)
                e.hasOwnProperty(a[n]) &&
                  void 0 !== e[a[n]] &&
                  this["set" + t(a[n])](e[a[n]]);
          }
          s.prototype = {
            getArgs: function () {
              return this.args;
            },
            setArgs: function (e) {
              if ("[object Array]" !== Object.prototype.toString.call(e))
                throw new TypeError("Args must be an Array");
              this.args = e;
            },
            getEvalOrigin: function () {
              return this.evalOrigin;
            },
            setEvalOrigin: function (e) {
              if (e instanceof s) this.evalOrigin = e;
              else {
                if (!(e instanceof Object))
                  throw new TypeError(
                    "Eval Origin must be an Object or StackFrame"
                  );
                this.evalOrigin = new s(e);
              }
            },
            toString: function () {
              return (
                (this.getFunctionName() || "{anonymous}") +
                "(" +
                (this.getArgs() || []).join(",") +
                ")" +
                (this.getFileName() ? "@" + this.getFileName() : "") +
                (e(this.getLineNumber()) ? ":" + this.getLineNumber() : "") +
                (e(this.getColumnNumber()) ? ":" + this.getColumnNumber() : "")
              );
            },
          };
          for (var u = 0; u < r.length; u++)
            (s.prototype["get" + t(r[u])] = n(r[u])),
              (s.prototype["set" + t(r[u])] = (function (e) {
                return function (t) {
                  this[e] = Boolean(t);
                };
              })(r[u]));
          for (var c = 0; c < o.length; c++)
            (s.prototype["get" + t(o[c])] = n(o[c])),
              (s.prototype["set" + t(o[c])] = (function (t) {
                return function (n) {
                  if (!e(n)) throw new TypeError(t + " must be a Number");
                  this[t] = Number(n);
                };
              })(o[c]));
          for (var f = 0; f < i.length; f++)
            (s.prototype["get" + t(i[f])] = n(i[f])),
              (s.prototype["set" + t(i[f])] = (function (e) {
                return function (t) {
                  this[e] = String(t);
                };
              })(i[f]));
          return s;
        });
        var R = {};
        !(function (e, t) {
          "use strict";
          "object" == typeof R
            ? (R = t(k))
            : (e.ErrorStackParser = t(e.StackFrame));
        })(this, function (e) {
          "use strict";
          var t = /(^|@)\S+\:\d+/,
            n = /^\s*at .*(\S+\:\d+|\(native\))/m,
            r = /^(eval@)?(\[native code\])?$/;
          return {
            parse: function (e) {
              if (void 0 !== e.stacktrace || void 0 !== e["opera#sourceloc"])
                return this.parseOpera(e);
              if (e.stack && e.stack.match(n)) return this.parseV8OrIE(e);
              if (e.stack) return this.parseFFOrSafari(e);
              throw new Error("Cannot parse given Error object");
            },
            extractLocation: function (e) {
              if (-1 === e.indexOf(":")) return [e];
              var t = /(.+?)(?:\:(\d+))?(?:\:(\d+))?$/.exec(
                e.replace(/[\(\)]/g, "")
              );
              return [t[1], t[2] || void 0, t[3] || void 0];
            },
            parseV8OrIE: function (t) {
              return t.stack
                .split("\n")
                .filter(function (e) {
                  return !!e.match(n);
                }, this)
                .map(function (t) {
                  t.indexOf("(eval ") > -1 &&
                    (t = t
                      .replace(/eval code/g, "eval")
                      .replace(/(\(eval at [^\()]*)|(\)\,.*$)/g, ""));
                  var n = t
                      .replace(/^\s+/, "")
                      .replace(/\(eval code/g, "(")
                      .split(/\s+/)
                      .slice(1),
                    r = this.extractLocation(n.pop()),
                    o = n.join(" ") || void 0,
                    i =
                      ["eval", "<anonymous>"].indexOf(r[0]) > -1
                        ? void 0
                        : r[0];
                  return new e({
                    functionName: o,
                    fileName: i,
                    lineNumber: r[1],
                    columnNumber: r[2],
                    source: t,
                  });
                }, this);
            },
            parseFFOrSafari: function (t) {
              return t.stack
                .split("\n")
                .filter(function (e) {
                  return !e.match(r);
                }, this)
                .map(function (t) {
                  if (
                    (t.indexOf(" > eval") > -1 &&
                      (t = t.replace(
                        / line (\d+)(?: > eval line \d+)* > eval\:\d+\:\d+/g,
                        ":$1"
                      )),
                    -1 === t.indexOf("@") && -1 === t.indexOf(":"))
                  )
                    return new e({ functionName: t });
                  var n = /((.*".+"[^@]*)?[^@]*)(?:@)/,
                    r = t.match(n),
                    o = r && r[1] ? r[1] : void 0,
                    i = this.extractLocation(t.replace(n, ""));
                  return new e({
                    functionName: o,
                    fileName: i[0],
                    lineNumber: i[1],
                    columnNumber: i[2],
                    source: t,
                  });
                }, this);
            },
            parseOpera: function (e) {
              return !e.stacktrace ||
                (e.message.indexOf("\n") > -1 &&
                  e.message.split("\n").length >
                    e.stacktrace.split("\n").length)
                ? this.parseOpera9(e)
                : e.stack
                ? this.parseOpera11(e)
                : this.parseOpera10(e);
            },
            parseOpera9: function (t) {
              for (
                var n = /Line (\d+).*script (?:in )?(\S+)/i,
                  r = t.message.split("\n"),
                  o = [],
                  i = 2,
                  a = r.length;
                i < a;
                i += 2
              ) {
                var s = n.exec(r[i]);
                s &&
                  o.push(
                    new e({ fileName: s[2], lineNumber: s[1], source: r[i] })
                  );
              }
              return o;
            },
            parseOpera10: function (t) {
              for (
                var n =
                    /Line (\d+).*script (?:in )?(\S+)(?:: In function (\S+))?$/i,
                  r = t.stacktrace.split("\n"),
                  o = [],
                  i = 0,
                  a = r.length;
                i < a;
                i += 2
              ) {
                var s = n.exec(r[i]);
                s &&
                  o.push(
                    new e({
                      functionName: s[3] || void 0,
                      fileName: s[2],
                      lineNumber: s[1],
                      source: r[i],
                    })
                  );
              }
              return o;
            },
            parseOpera11: function (n) {
              return n.stack
                .split("\n")
                .filter(function (e) {
                  return !!e.match(t) && !e.match(/^Error created at/);
                }, this)
                .map(function (t) {
                  var n,
                    r = t.split("@"),
                    o = this.extractLocation(r.pop()),
                    i = r.shift() || "",
                    a =
                      i
                        .replace(/<anonymous function(: (\w+))?>/, "$2")
                        .replace(/\([^\)]*\)/g, "") || void 0;
                  i.match(/\(([^\)]*)\)/) &&
                    (n = i.replace(/^[^\(]+\(([^\)]*)\)$/, "$1"));
                  var s =
                    void 0 === n || "[arguments not available]" === n
                      ? void 0
                      : n.split(",");
                  return new e({
                    functionName: a,
                    args: s,
                    fileName: o[0],
                    lineNumber: o[1],
                    columnNumber: o[2],
                    source: t,
                  });
                }, this);
            },
          };
        });
        var D = {};
        !(function (e, t) {
          "use strict";
          "object" == typeof D
            ? (D = t(k))
            : (e.StackGenerator = t(e.StackFrame));
        })(this, function (e) {
          return {
            backtrace: function (t) {
              var n = [],
                r = 10;
              "object" == typeof t &&
                "number" == typeof t.maxStackSize &&
                (r = t.maxStackSize);
              for (
                var o = arguments.callee;
                o && n.length < r && o.arguments;

              ) {
                for (
                  var i = new Array(o.arguments.length), a = 0;
                  a < i.length;
                  ++a
                )
                  i[a] = o.arguments[a];
                /function(?:\s+([\w$]+))+\s*\(/.test(o.toString())
                  ? n.push(
                      new e({ functionName: RegExp.$1 || void 0, args: i })
                    )
                  : n.push(new e({ args: i }));
                try {
                  o = o.caller;
                } catch (e) {
                  break;
                }
              }
              return n;
            },
          };
        });
        var _ =
          Object.assign ||
          function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          };
        function x(e, t) {
          if (!(e instanceof t))
            throw new TypeError("Cannot call a class as a function");
        }
        var L = i,
          C = a,
          q = (function () {
            function e(t, n) {
              var r =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : [],
                o =
                  arguments.length > 3 && void 0 !== arguments[3]
                    ? arguments[3]
                    : A();
              x(this, e),
                (this.__isBugsnagReport = !0),
                (this._ignored = !1),
                (this._handledState = o),
                (this.app = void 0),
                (this.apiKey = void 0),
                (this.breadcrumbs = []),
                (this.context = void 0),
                (this.device = void 0),
                (this.errorClass = P(t, "[no error class]")),
                (this.errorMessage = P(n, "[no error message]")),
                (this.groupingHash = void 0),
                (this.metaData = {}),
                (this.request = void 0),
                (this.severity = this._handledState.severity),
                (this.stacktrace = L(
                  r,
                  function (e, t) {
                    var n = T(t);
                    try {
                      return "{}" === JSON.stringify(n) ? e : e.concat(n);
                    } catch (t) {
                      return e;
                    }
                  },
                  []
                )),
                (this.user = void 0),
                (this.session = void 0);
            }
            return (
              (e.prototype.ignore = function () {
                this._ignored = !0;
              }),
              (e.prototype.isIgnored = function () {
                return this._ignored;
              }),
              (e.prototype.updateMetaData = function (e) {
                var t;
                if (!e) return this;
                var n = void 0;
                return null === (arguments.length <= 1 ? void 0 : arguments[1])
                  ? this.removeMetaData(e)
                  : null === (arguments.length <= 2 ? void 0 : arguments[2])
                  ? this.removeMetaData(
                      e,
                      arguments.length <= 1 ? void 0 : arguments[1],
                      arguments.length <= 2 ? void 0 : arguments[2]
                    )
                  : ("object" ==
                      typeof (arguments.length <= 1 ? void 0 : arguments[1]) &&
                      (n = arguments.length <= 1 ? void 0 : arguments[1]),
                    "string" ==
                      typeof (arguments.length <= 1 ? void 0 : arguments[1]) &&
                      (((t = {})[
                        arguments.length <= 1 ? void 0 : arguments[1]
                      ] = arguments.length <= 2 ? void 0 : arguments[2]),
                      (n = t)),
                    n
                      ? (this.metaData[e] || (this.metaData[e] = {}),
                        (this.metaData[e] = _({}, this.metaData[e], n)),
                        this)
                      : this);
              }),
              (e.prototype.removeMetaData = function (e, t) {
                return "string" != typeof e
                  ? this
                  : t
                  ? this.metaData[e]
                    ? (delete this.metaData[e][t], this)
                    : this
                  : (delete this.metaData[e], this);
              }),
              (e.prototype.toJSON = function () {
                return {
                  payloadVersion: "4",
                  exceptions: [
                    {
                      errorClass: this.errorClass,
                      message: this.errorMessage,
                      stacktrace: this.stacktrace,
                      type: "browserjs",
                    },
                  ],
                  severity: this.severity,
                  unhandled: this._handledState.unhandled,
                  severityReason: this._handledState.severityReason,
                  app: this.app,
                  device: this.device,
                  breadcrumbs: this.breadcrumbs,
                  context: this.context,
                  user: this.user,
                  metaData: this.metaData,
                  groupingHash: this.groupingHash,
                  request: this.request,
                  session: this.session,
                };
              }),
              e
            );
          })(),
          T = function (e) {
            var t = {
              file: e.fileName,
              method: M(e.functionName),
              lineNumber: e.lineNumber,
              columnNumber: e.columnNumber,
              code: void 0,
              inProject: void 0,
            };
            return (
              t.lineNumber > -1 &&
                !t.file &&
                !t.method &&
                (t.file = "global code"),
              t
            );
          },
          M = function (e) {
            return /^global code$/i.test(e) ? "global code" : e;
          },
          A = function () {
            return {
              unhandled: !1,
              severity: "warning",
              severityReason: { type: "handledException" },
            };
          },
          P = function (e, t) {
            return "string" == typeof e && e ? e : t;
          };
        (q.getStacktrace = function (e) {
          var t =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : 0,
            n =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : 0;
          return B(e)
            ? R.parse(e).slice(t)
            : C(D.backtrace(), function (e) {
                return (
                  -1 === (e.functionName || "").indexOf("StackGenerator$$")
                );
              }).slice(1 + n);
        }),
          (q.ensureReport = function (e) {
            var t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : 0,
              n =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 0;
            if (e.__isBugsnagReport) return e;
            try {
              var r = q.getStacktrace(e, t, 1 + n);
              return new q(e.name, e.message, r);
            } catch (t) {
              return new q(e.name, e.message, []);
            }
          });
        var V = q,
          U = function (e, t) {
            var n = "000000000" + e;
            return n.substr(n.length - t);
          },
          H = "object" == typeof window ? window : self,
          I = 0;
        for (var $ in H) Object.hasOwnProperty.call(H, $) && I++;
        var F = navigator.mimeTypes ? navigator.mimeTypes.length : 0,
          K = U(
            (F + navigator.userAgent.length).toString(36) + I.toString(36),
            4
          ),
          X = function () {
            return K;
          },
          J = 0,
          z = Math.pow(36, 4);
        function G() {
          return U(((Math.random() * z) << 0).toString(36), 4);
        }
        function W() {
          return (
            "c" +
            new Date().getTime().toString(36) +
            U(((J = J < z ? J : 0), ++J - 1).toString(36), 4) +
            X() +
            (G() + G())
          );
        }
        W.fingerprint = X;
        var Y = W;
        var Z = f,
          Q = (function () {
            function e() {
              (function (e, t) {
                if (!(e instanceof t))
                  throw new TypeError("Cannot call a class as a function");
              })(this, e),
                (this.id = Y()),
                (this.startedAt = Z()),
                (this._handled = 0),
                (this._unhandled = 0);
            }
            return (
              (e.prototype.toJSON = function () {
                return {
                  id: this.id,
                  startedAt: this.startedAt,
                  events: {
                    handled: this._handled,
                    unhandled: this._unhandled,
                  },
                };
              }),
              (e.prototype.trackError = function (e) {
                this[
                  e._handledState.unhandled ? "_unhandled" : "_handled"
                ] += 1;
              }),
              e
            );
          })(),
          ee = function (e) {
            switch (Object.prototype.toString.call(e)) {
              case "[object Error]":
              case "[object Exception]":
              case "[object DOMException]":
                return !0;
              default:
                return e instanceof Error;
            }
          };
        var te =
          Object.assign ||
          function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          };
        function ne(e, t) {
          if (!(e instanceof t))
            throw new TypeError("Cannot call a class as a function");
        }
        var re = o,
          oe = i,
          ie = s,
          ae = c,
          se = function () {},
          ue = (function () {
            function e(t) {
              var n =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : m.schema,
                r =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : null;
              if ((ne(this, e), !(t && t.name && t.version && t.url)))
                throw new Error("`notifier` argument is required");
              (this.notifier = t),
                (this.configSchema = n),
                (this._configured = !1),
                (this._transport = { sendSession: se, sendReport: se }),
                (this._logger = { debug: se, info: se, warn: se, error: se }),
                (this.plugins = []),
                (this.session = r),
                (this.beforeSession = []),
                (this.breadcrumbs = []),
                (this.app = {}),
                (this.context = void 0),
                (this.device = void 0),
                (this.metaData = void 0),
                (this.request = void 0),
                (this.user = {}),
                (this.BugsnagReport = V),
                (this.BugsnagBreadcrumb = h),
                (this.BugsnagSession = Q);
            }
            return (
              (e.prototype.configure = function () {
                var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : {};
                this.config = m.mergeDefaults(
                  te({}, this.config, e),
                  this.configSchema
                );
                var t = m.validate(this.config, this.configSchema);
                if (1 == !t.valid) throw new Error(le(t.errors));
                return (
                  "function" == typeof this.config.beforeSend &&
                    (this.config.beforeSend = [this.config.beforeSend]),
                  null !== this.config.appVersion &&
                    (this.app.version = this.config.appVersion),
                  this.config.metaData &&
                    (this.metaData = this.config.metaData),
                  this.config.user && (this.user = this.config.user),
                  this.config.logger && this.logger(this.config.logger),
                  (this._configured = !0),
                  this._logger.debug("Loaded!"),
                  this
                );
              }),
              (e.prototype.use = function (e) {
                return this.plugins.push(e), e.init(this);
              }),
              (e.prototype.transport = function (e) {
                return (this._transport = e), this;
              }),
              (e.prototype.logger = function (e, t) {
                return (this._logger = e), this;
              }),
              (e.prototype.sessionDelegate = function (e) {
                return (this._sessionDelegate = e), this;
              }),
              (e.prototype.startSession = function () {
                return this._sessionDelegate
                  ? this._sessionDelegate.startSession(this)
                  : (this._logger.warn(
                      "No session implementation is installed"
                    ),
                    this);
              }),
              (e.prototype.leaveBreadcrumb = function (e, t, n, r) {
                if (!this._configured) throw new Error("client not configured");
                if (
                  ((n = "string" == typeof n ? n : void 0),
                  (r = "string" == typeof r ? r : void 0),
                  (t = "object" == typeof t && null !== t ? t : void 0),
                  "string" == typeof (e = e || void 0) || t)
                ) {
                  var o = new h(e, t, n, r);
                  return (
                    this.breadcrumbs.push(o),
                    this.breadcrumbs.length > this.config.maxBreadcrumbs &&
                      (this.breadcrumbs = this.breadcrumbs.slice(
                        this.breadcrumbs.length - this.config.maxBreadcrumbs
                      )),
                    this
                  );
                }
              }),
              (e.prototype.notify = function (e) {
                var t =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {};
                if (!this._configured) throw new Error("client not configured");
                var n = N(this),
                  r = ce(e, t, this._logger),
                  o = r.err,
                  i = r.errorFramesToSkip,
                  a = r._opts;
                if ((a && (t = a), !o)) {
                  var s = de("nothing");
                  this._logger.warn("Usage error. " + s),
                    (o = new Error("Bugsnag usage error. " + s));
                }
                ("object" == typeof t && null !== t) || (t = {});
                var u = V.ensureReport(o, i, 1);
                if (
                  ((u.app = te({ releaseStage: n }, u.app, this.app)),
                  (u.context =
                    u.context || t.context || this.context || void 0),
                  (u.device = te({}, u.device, this.device, t.device)),
                  (u.request = te({}, u.request, this.request, t.request)),
                  (u.user = te({}, u.user, this.user, t.user)),
                  (u.metaData = te({}, u.metaData, this.metaData, t.metaData)),
                  (u.breadcrumbs = this.breadcrumbs.slice(0)),
                  this.session &&
                    (this.session.trackError(u), (u.session = this.session)),
                  void 0 !== t.severity &&
                    ((u.severity = t.severity),
                    (u._handledState.severityReason = {
                      type: "userSpecifiedSeverity",
                    })),
                  ae(this.config.notifyReleaseStages) &&
                    !ie(this.config.notifyReleaseStages, n))
                )
                  return (
                    this._logger.warn(
                      "Report not sent due to releaseStage/notifyReleaseStages configuration"
                    ),
                    !1
                  );
                var c = u.severity,
                  f = [].concat(t.beforeSend).concat(this.config.beforeSend);
                return oe(
                  f,
                  function (e, t) {
                    return (
                      !0 === e ||
                      ("function" == typeof t && !1 === t(u)) ||
                      !!u.isIgnored()
                    );
                  },
                  !1
                )
                  ? (this._logger.debug(
                      "Report not sent due to beforeSend callback"
                    ),
                    !1)
                  : (this.config.autoBreadcrumbs &&
                      this.leaveBreadcrumb(
                        u.errorClass,
                        {
                          errorClass: u.errorClass,
                          errorMessage: u.errorMessage,
                          severity: u.severity,
                        },
                        "error"
                      ),
                    c !== u.severity &&
                      (u._handledState.severityReason = {
                        type: "userCallbackSetSeverity",
                      }),
                    this._transport.sendReport(this._logger, this.config, {
                      apiKey: u.apiKey || this.config.apiKey,
                      notifier: this.notifier,
                      events: [u],
                    }),
                    !0);
              }),
              e
            );
          })(),
          ce = function (e, t, n) {
            var r = void 0,
              o = 0,
              i = void 0;
            switch (typeof e) {
              case "string":
                if ("string" == typeof t) {
                  var a = de("string/string");
                  n.warn("Usage error. " + a),
                    (r = new Error("Bugsnag usage error. " + a)),
                    (i = { metaData: { notifier: { notifyArgs: [e, t] } } });
                } else (r = new Error(String(e))), (o += 2);
                break;
              case "number":
              case "boolean":
                r = new Error(String(e));
                break;
              case "function":
                var s = de("function");
                n.warn("Usage error. " + s),
                  (r = new Error("Bugsnag usage error. " + s));
                break;
              case "object":
                if (null !== e && (ee(e) || e.__isBugsnagReport)) r = e;
                else if (null !== e && fe(e))
                  ((r = new Error(e.message || e.errorMessage)).name =
                    e.name || e.errorClass),
                    (o += 2);
                else {
                  var u = de("unsupported object");
                  n.warn("Usage error. " + u),
                    (r = new Error("Bugsnag usage error. " + u));
                }
            }
            return { err: r, errorFramesToSkip: o, _opts: i };
          },
          fe = function (e) {
            return !(
              ("string" != typeof e.name && "string" != typeof e.errorClass) ||
              ("string" != typeof e.message &&
                "string" != typeof e.errorMessage)
            );
          },
          le = function (e) {
            return (
              "Bugsnag configuration error\n" +
              re(e, function (e) {
                return (
                  '"' + e.key + '" ' + e.message + " \n    got " + ge(e.value)
                );
              }).join("\n\n")
            );
          },
          de = function (e) {
            return "notify() expected error/opts parameters, got " + e;
          },
          ge = function (e) {
            return "object" == typeof e ? JSON.stringify(e) : String(e);
          },
          he = ue,
          pe = p.positiveIntIfDefined,
          ve = {
            init: function (e) {
              var t = 0;
              e.config.beforeSend.push(function (n) {
                if (t >= e.config.maxEvents) return n.ignore();
                t++;
              }),
                (e.refresh = function () {
                  t = 0;
                });
            },
            configSchema: {
              maxEvents: {
                defaultValue: function () {
                  return 10;
                },
                message: "should be a positive integer ≤100",
                validate: function (e) {
                  return pe(e) && e < 100;
                },
              },
            },
          },
          me =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            },
          ye = m.schema,
          be = o,
          we = {
            releaseStage: {
              defaultValue: function () {
                return /^localhost(:\d+)?$/.test(window.location.host)
                  ? "development"
                  : "production";
              },
              message: "should be set",
              validate: p.stringWithLength,
            },
            collectUserIp: {
              defaultValue: function () {
                return !0;
              },
              message: "should be true|false",
              validate: function (e) {
                return !0 === e || !1 === e;
              },
            },
            logger: me({}, ye.logger, {
              defaultValue: function () {
                return "undefined" != typeof console &&
                  "function" == typeof console.debug
                  ? Se()
                  : void 0;
              },
            }),
          },
          Se = function () {
            var e = {},
              t = console.log;
            return (
              be(["debug", "info", "warn", "error"], function (n) {
                var r = console[n];
                e[n] =
                  "function" == typeof r
                    ? r.bind(console, "[bugsnag]")
                    : t.bind(console, "[bugsnag]");
              }),
              e
            );
          },
          Oe = {},
          je = o,
          Ee = i,
          Ne = a;
        (Oe.init = function (e) {
          je(Be, function (t) {
            var n = console[t];
            (console[t] = function () {
              for (var r = arguments.length, o = Array(r), i = 0; i < r; i++)
                o[i] = arguments[i];
              e.leaveBreadcrumb(
                "Console output",
                Ee(
                  o,
                  function (e, t, n) {
                    var r = String(t);
                    if ("[object Object]" === r)
                      try {
                        r = JSON.stringify(t);
                      } catch (e) {}
                    return (e["[" + n + "]"] = r), e;
                  },
                  { severity: 0 === t.indexOf("group") ? "log" : t }
                ),
                "log"
              ),
                n.apply(console, o);
            }),
              (console[t]._restore = function () {
                console[t] = n;
              });
          });
        }),
          (Oe.configSchema = {
            consoleBreadcrumbsEnabled: {
              defaultValue: function () {},
              validate: function (e) {
                return !0 === e || !1 === e || void 0 === e;
              },
              message: "should be true|false",
            },
          });
        var Be = Ne(["log", "debug", "info", "warn", "error"], function (e) {
            return (
              "undefined" != typeof console && "function" == typeof console[e]
            );
          }),
          ke = {
            init: function (e) {
              e.config.beforeSend.unshift(function (e) {
                e.context || (e.context = window.location.pathname);
              });
            },
          },
          Re =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            },
          De = f,
          _e = {
            init: function (e) {
              e.config.beforeSend.unshift(function (e) {
                e.device = Re(
                  {
                    time: De(),
                    locale:
                      navigator.browserLanguage ||
                      navigator.systemLanguage ||
                      navigator.userLanguage ||
                      navigator.language,
                    userAgent: navigator.userAgent,
                  },
                  e.device
                );
              }),
                e.beforeSession.push(function (e) {
                  e.device = { userAgent: navigator.userAgent };
                });
            },
          },
          xe = {},
          Le = i;
        xe = {
          init: function (e) {
            var t = "",
              n = !1,
              r = function () {
                return document.documentElement.outerHTML;
              },
              o = window.location.href;
            (t = r()),
              (document.onreadystatechange = function () {
                "interactive" === document.readyState && ((t = r()), (n = !0));
              }),
              e.config.beforeSend.unshift(function (e) {
                var i = e.stacktrace[0];
                if (!i || !i.file || !i.lineNumber) return i;
                if (i.file.replace(/#.*$/, "") !== o.replace(/#.*$/, ""))
                  return i;
                (n && t) || (t = r());
                var a = ["\x3c!-- DOC START --\x3e"].concat(t.split("\n")),
                  s = Te(a, i.lineNumber - 1),
                  u = s.script,
                  c = s.start,
                  f = Le(
                    u,
                    function (e, t, n) {
                      return (
                        Math.abs(c + n + 1 - i.lineNumber) > 10 ||
                          (e["" + (c + n + 1)] = t),
                        e
                      );
                    },
                    {}
                  );
                (i.code = f),
                  e.updateMetaData("script", { content: u.join("\n") });
              });
          },
        };
        var Ce = /^.*<script.*?>/,
          qe = /<\/script>.*$/,
          Te = (xe.extractScriptContent = function (e, t) {
            for (var n = t; n < e.length && !qe.test(e[n]); ) n++;
            for (var r = n; n > 0 && !Ce.test(e[n]); ) n--;
            var o = n,
              i = e.slice(o, r + 1);
            return (
              (i[0] = i[0].replace(Ce, "")),
              (i[i.length - 1] = i[i.length - 1].replace(qe, "")),
              { script: i, start: o }
            );
          }),
          Me = {
            init: function (e) {
              "addEventListener" in window &&
                window.addEventListener(
                  "click",
                  function (t) {
                    var n = void 0,
                      r = void 0;
                    try {
                      (n = Ae(t.target)), (r = Pe(t.target));
                    } catch (t) {
                      (n = "[hidden]"),
                        (r = "[hidden]"),
                        e._logger.error(
                          "Cross domain error when tracking click event. See docs: https://tinyurl.com/y94fq5zm"
                        );
                    }
                    e.leaveBreadcrumb(
                      "UI click",
                      { targetText: n, targetSelector: r },
                      "user"
                    );
                  },
                  !0
                );
            },
            configSchema: {
              interactionBreadcrumbsEnabled: {
                defaultValue: function () {},
                validate: function (e) {
                  return !0 === e || !1 === e || void 0 === e;
                },
                message: "should be true|false",
              },
            },
          },
          Ae = function (e) {
            var t,
              n,
              r,
              o = e.textContent || e.innerText || "";
            return (
              o ||
                ("submit" !== e.type && "button" !== e.type) ||
                (o = e.value),
              (t = o = o.replace(/^\s+|\s+$/g, "")),
              (n = 140),
              (r = "(...)"),
              t && t.length <= n ? t : t.slice(0, n - r.length) + r
            );
          };
        function Pe(e) {
          var t = [e.tagName];
          if (
            (e.id && t.push("#" + e.id),
            e.className &&
              e.className.length &&
              t.push("." + e.className.split(" ").join(".")),
            !document.querySelectorAll || !Array.prototype.indexOf)
          )
            return t.join("");
          try {
            if (1 === document.querySelectorAll(t.join("")).length)
              return t.join("");
          } catch (e) {
            return t.join("");
          }
          if (e.parentNode.childNodes.length > 1) {
            var n =
              Array.prototype.indexOf.call(e.parentNode.childNodes, e) + 1;
            t.push(":nth-child(" + n + ")");
          }
          return 1 === document.querySelectorAll(t.join("")).length
            ? t.join("")
            : e.parentNode
            ? Pe(e.parentNode) + " > " + t.join("")
            : t.join("");
        }
        var Ve =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            },
          Ue = {
            init: function (e) {
              e.config.collectUserIp ||
                e.config.beforeSend.push(function (e) {
                  (e.user = Ve({ id: "[NOT COLLECTED]" }, e.user)),
                    (e.request = Ve(
                      { clientIp: "[NOT COLLECTED]" },
                      e.request
                    ));
                });
            },
          },
          He = {
            init: function (e) {
              if ("addEventListener" in window) {
                var t = function (t) {
                  return function () {
                    return e.leaveBreadcrumb(t, {}, "navigation");
                  };
                };
                window.addEventListener("pagehide", t("Page hidden"), !0),
                  window.addEventListener("pageshow", t("Page shown"), !0),
                  window.addEventListener("load", t("Page loaded"), !0),
                  window.document.addEventListener(
                    "DOMContentLoaded",
                    t("DOMContentLoaded"),
                    !0
                  ),
                  window.addEventListener("load", function () {
                    return window.addEventListener(
                      "popstate",
                      t("Navigated back"),
                      !0
                    );
                  }),
                  window.addEventListener(
                    "hashchange",
                    function (t) {
                      var n = t.oldURL
                        ? { from: Ie(t.oldURL), to: Ie(t.newURL), state: Fe() }
                        : { to: Ie(window.location.href) };
                      e.leaveBreadcrumb("Hash changed", n, "navigation");
                    },
                    !0
                  ),
                  window.history.replaceState &&
                    $e(e, window.history, "replaceState"),
                  window.history.pushState &&
                    $e(e, window.history, "pushState"),
                  e.leaveBreadcrumb("Bugsnag loaded", {}, "navigation");
              }
            },
            configSchema: {
              navigationBreadcrumbsEnabled: {
                defaultValue: function () {},
                validate: function (e) {
                  return !0 === e || !1 === e || void 0 === e;
                },
                message: "should be true|false",
              },
            },
          },
          Ie = function (e) {
            var t = document.createElement("A");
            return (t.href = e), "" + t.pathname + t.search + t.hash;
          },
          $e = function (e, t, n) {
            var r = t[n];
            (t[n] = function (o, i, a) {
              e.leaveBreadcrumb(
                "History " + n,
                (function (e, t, n) {
                  var r = Ie(window.location.href);
                  return {
                    title: t,
                    state: e,
                    prevState: Fe(),
                    to: n || r,
                    from: r,
                  };
                })(o, i, a),
                "navigation"
              ),
                "function" == typeof e.refresh && e.refresh(),
                e.session && e.startSession(),
                r.apply(t, [o, i].concat(void 0 !== a ? a : []));
            }),
              (t[n]._restore = function () {
                t[n] = r;
              });
          },
          Fe = function () {
            try {
              return window.history.state;
            } catch (e) {}
          },
          Ke = {},
          Xe = "request",
          Je = s,
          ze = void 0,
          Ge = function () {
            return [ze.config.endpoints.notify, ze.config.endpoints.sessions];
          };
        (Ke.init = function (e) {
          (ze = e), We(), Qe();
        }),
          (Ke.configSchema = {
            networkBreadcrumbsEnabled: {
              defaultValue: function () {},
              validate: function (e) {
                return !0 === e || !1 === e || void 0 === e;
              },
              message: "should be true|false",
            },
          });
        var We = function () {
          if ("addEventListener" in window.XMLHttpRequest.prototype) {
            var e = window.XMLHttpRequest.prototype.open;
            window.XMLHttpRequest.prototype.open = function (t, n) {
              (this["BS~~U"] = n),
                (this["BS~~M"] = t),
                this["BS~~S"] &&
                  (this.removeEventListener("load", Ye),
                  this.removeEventListener("error", Ze)),
                this.addEventListener("load", Ye),
                this.addEventListener("error", Ze),
                (this["BS~~S"] = !0),
                e.apply(this, arguments);
            };
          }
        };
        function Ye() {
          if (!Je(Ge(), this["BS~~U"])) {
            var e = {
              status: this.status,
              request: this["BS~~M"] + " " + this["BS~~U"],
            };
            this.status >= 400
              ? ze.leaveBreadcrumb("XMLHttpRequest failed", e, Xe)
              : ze.leaveBreadcrumb("XMLHttpRequest succeeded", e, Xe);
          }
        }
        function Ze() {
          Je(Ge(), this["BS~~U"]) ||
            ze.leaveBreadcrumb(
              "XMLHttpRequest error",
              { request: this["BS~~M"] + " " + this["BS~~U"] },
              Xe
            );
        }
        var Qe = function () {
            if ("fetch" in window) {
              var e = window.fetch;
              window.fetch = function () {
                for (var t = arguments.length, n = Array(t), r = 0; r < t; r++)
                  n[r] = arguments[r];
                var o = n[0],
                  i = n[1],
                  a = "GET";
                return (
                  i && i.method && (a = i.method),
                  new Promise(function (t, r) {
                    e.apply(void 0, n)
                      .then(function (e) {
                        et(e, a, o), t(e);
                      })
                      .catch(function (e) {
                        tt(a, o), r(e);
                      });
                  })
                );
              };
            }
          },
          et = function (e, t, n) {
            var r = { status: e.status, request: t + " " + n };
            e.status >= 400
              ? ze.leaveBreadcrumb("fetch() failed", r, Xe)
              : ze.leaveBreadcrumb("fetch() succeeded", r, Xe);
          },
          tt = function (e, t) {
            ze.leaveBreadcrumb("fetch() error", { request: e + " " + t }, Xe);
          },
          nt =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            },
          rt = {
            init: function (e) {
              e.config.beforeSend.unshift(function (e) {
                (e.request && e.request.url) ||
                  (e.request = nt({}, e.request, {
                    url: window.location.href,
                  }));
              });
            },
          },
          ot =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            },
          it = o,
          at = c,
          st = s,
          ut = {
            init: function (e) {
              return e.sessionDelegate(ct);
            },
          },
          ct = {
            startSession: function (e) {
              var t = e;
              (t.session = new e.BugsnagSession()),
                it(t.beforeSession, function (e) {
                  return e(t);
                });
              var n = N(t);
              return at(t.config.notifyReleaseStages) &&
                !st(t.config.notifyReleaseStages, n)
                ? (t._logger.warn(
                    "Session not sent due to releaseStage/notifyReleaseStages configuration"
                  ),
                  t)
                : t.config.endpoints.sessions
                ? (t._transport.sendSession(t._logger, t.config, {
                    notifier: t.notifier,
                    device: t.device,
                    app: ot({ releaseStage: n }, t.app),
                    sessions: [
                      {
                        id: t.session.id,
                        startedAt: t.session.startedAt,
                        user: t.user,
                      },
                    ],
                  }),
                  t)
                : (t._logger.warn(
                    "Session not sent due to missing endpoints.sessions configuration"
                  ),
                  t);
            },
          },
          ft = {},
          lt =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            },
          dt = o;
        ft = {
          init: function (e) {
            e.config.beforeSend.push(function (e) {
              e.stacktrace = dt(e.stacktrace, function (e) {
                return lt({}, e, { file: gt(e.file) });
              });
            });
          },
        };
        var gt = (ft._strip = function (e) {
            return "string" == typeof e
              ? e.replace(/\?.*$/, "").replace(/#.*$/, "")
              : e;
          }),
          ht = {},
          pt = i;
        ht.init = function (e) {
          var t = function (t) {
            var n = t.reason,
              r = !1;
            t.detail && t.detail.reason && ((n = t.detail.reason), (r = !0));
            var o = {
                severity: "error",
                unhandled: !0,
                severityReason: { type: "unhandledPromiseRejection" },
              },
              i = void 0;
            if (n && B(n))
              (i = new e.BugsnagReport(n.name, n.message, R.parse(n), o)),
                r && (i.stacktrace = pt(i.stacktrace, mt(n), []));
            else {
              (i = new e.BugsnagReport(
                n && n.name ? n.name : "UnhandledRejection",
                n && n.message
                  ? n.message
                  : 'Rejection reason was not an Error. See "Promise" tab for more detail.',
                [],
                o
              )).updateMetaData("promise", "rejection reason", vt(n));
            }
            e.notify(i);
          };
          "addEventListener" in window
            ? window.addEventListener("unhandledrejection", t)
            : (window.onunhandledrejection = function (e, n) {
                t({ detail: { reason: e, promise: n } });
              });
        };
        var vt = function (e) {
            return null == e
              ? "undefined (or null)"
              : ee(e)
              ? (((t = {})[Object.prototype.toString.call(e)] = {
                  name: e.name,
                  message: e.message,
                  code: e.code,
                  stack: e.stack,
                }),
                t)
              : e;
            var t;
          },
          mt = function (e) {
            return function (t, n) {
              return n.file === e.toString()
                ? t
                : (n.method && (n.method = n.method.replace(/^\s+/, "")),
                  t.concat(n));
            };
          },
          yt = {
            init: function (e) {
              var t = window.onerror;
              window.onerror = function (n, r, o, i, a) {
                if (0 === o && /Script error\.?/.test(n))
                  e._logger.warn(
                    "Ignoring cross-domain or eval script error. See docs: https://tinyurl.com/y94fq5zm"
                  );
                else {
                  var s = {
                      severity: "error",
                      unhandled: !0,
                      severityReason: { type: "unhandledException" },
                    },
                    u = void 0;
                  if (a)
                    a.name && a.message
                      ? (u = new e.BugsnagReport(
                          a.name,
                          a.message,
                          bt(e.BugsnagReport.getStacktrace(a), r, o, i),
                          s
                        ))
                      : (u = new e.BugsnagReport(
                          "window.onerror",
                          String(a),
                          bt(e.BugsnagReport.getStacktrace(a, 1), r, o, i),
                          s
                        )).updateMetaData("window onerror", { error: a });
                  else if (
                    "object" != typeof n ||
                    null === n ||
                    r ||
                    o ||
                    i ||
                    a
                  )
                    (u = new e.BugsnagReport(
                      "window.onerror",
                      String(n),
                      bt(e.BugsnagReport.getStacktrace(a, 1), r, o, i),
                      s
                    )).updateMetaData("window onerror", { event: n });
                  else {
                    var c = n.type ? "Event: " + n.type : "window.onerror",
                      f = n.message || n.detail || "";
                    (u = new e.BugsnagReport(
                      c,
                      f,
                      e.BugsnagReport.getStacktrace(new Error(), 1).slice(1),
                      s
                    )).updateMetaData("window onerror", { event: n });
                  }
                  e.notify(u), "function" == typeof t && t(n, r, o, i, a);
                }
              };
            },
          },
          bt = function (e, t, n, r) {
            var o = e[0];
            return o
              ? (o.fileName || o.setFileName(t),
                o.lineNumber || o.setLineNumber(n),
                o.columnNumber ||
                  (void 0 !== r
                    ? o.setColumnNumber(r)
                    : window.event &&
                      window.event.errorCharacter &&
                      o.setColumnNumber(
                        window.event && window.event.errorCharacter
                      )),
                e)
              : e;
          },
          wt = function (e, t, n) {
            return JSON.stringify(
              (function (e) {
                var t = [],
                  n = 0;
                function r(e, o) {
                  function i() {
                    return o > 8 && n > 25e3;
                  }
                  if ((n++, void 0 === o && (o = 0), o > 20)) return St;
                  if (i()) return St;
                  if (null === e || "object" != typeof e) return e;
                  if (
                    (function (e, t) {
                      for (var n = 0, r = e.length; n < r; n++)
                        if (e[n] === t) return !0;
                      return !1;
                    })(t, e)
                  )
                    return "[Circular]";
                  if ((t.push(e), "function" == typeof e.toJSON))
                    try {
                      n--;
                      var a = r(e.toJSON(), o);
                      return t.pop(), a;
                    } catch (e) {
                      return Ot(e);
                    }
                  if (
                    (function (e) {
                      return (
                        "[object Array]" === Object.prototype.toString.call(e)
                      );
                    })(e)
                  ) {
                    for (var s = [], u = 0, c = e.length; u < c; u++) {
                      if (i()) {
                        s.push(St);
                        break;
                      }
                      s.push(r(e[u], o + 1));
                    }
                    return t.pop(), s;
                  }
                  var f = {};
                  try {
                    for (var l in e)
                      if (Object.prototype.hasOwnProperty.call(e, l)) {
                        if (i()) {
                          f[l] = St;
                          break;
                        }
                        f[l] = r(jt(e, l), o + 1);
                      }
                  } catch (e) {}
                  return t.pop(), f;
                }
                return r(e);
              })(e),
              t,
              n
            );
          },
          St = "...";
        function Ot(e) {
          return "[Throws: " + (e ? e.message : "?") + "]";
        }
        function jt(e, t) {
          try {
            return e[t];
          } catch (e) {
            return Ot(e);
          }
        }
        var Et = function (e) {
            var t = wt(e);
            if (
              t.length > 1e6 &&
              (delete e.events[0].metaData,
              (e.events[0].metaData = {
                notifier:
                  "WARNING!\nSerialized payload was " +
                  t.length / 1e6 +
                  "MB (limit = 1MB)\nmetaData was removed",
              }),
              (t = wt(e)).length > 1e6)
            )
              throw new Error("payload exceeded 1MB limit");
            return t;
          },
          Nt = {},
          Bt = f;
        Nt = {
          sendReport: function (e, t, n) {
            var r =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : function () {},
              o = Rt(t, "notify", "4.0"),
              i = new window.XDomainRequest();
            (i.onload = function () {
              r(null, i.responseText);
            }),
              i.open("POST", o),
              setTimeout(function () {
                try {
                  i.send(Et(n));
                } catch (t) {
                  e.error(t);
                }
              }, 0);
          },
          sendSession: function (e, t, n) {
            var r =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : function () {},
              o = Rt(t, "sessions", "1.0"),
              i = new window.XDomainRequest();
            (i.onload = function () {
              r(null, i.responseText);
            }),
              i.open("POST", o),
              setTimeout(function () {
                try {
                  i.send(wt(n));
                } catch (t) {
                  e.error(t);
                }
              }, 0);
          },
        };
        var kt,
          Rt = function (e, t, n) {
            return (
              Dt(e.endpoints[t], window.location.protocol) +
              "?apiKey=" +
              encodeURIComponent(e.apiKey) +
              "&payloadVersion=" +
              n +
              "&sentAt=" +
              encodeURIComponent(Bt())
            );
          },
          Dt = (Nt._matchPageProtocol = function (e, t) {
            return "http:" === t ? e.replace(/^https:/, "http:") : e;
          }),
          _t = f,
          xt = {
            sendReport: function (e, t, n) {
              var r =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : function () {};
              try {
                var o = t.endpoints.notify,
                  i = new window.XMLHttpRequest();
                (i.onreadystatechange = function () {
                  i.readyState === window.XMLHttpRequest.DONE &&
                    r(null, i.responseText);
                }),
                  i.open("POST", o),
                  i.setRequestHeader("Content-Type", "application/json"),
                  i.setRequestHeader("Bugsnag-Api-Key", n.apiKey || t.apiKey),
                  i.setRequestHeader("Bugsnag-Payload-Version", "4.0"),
                  i.setRequestHeader("Bugsnag-Sent-At", _t()),
                  i.send(Et(n));
              } catch (t) {
                e.error(t);
              }
            },
            sendSession: function (e, t, n) {
              var r =
                arguments.length > 3 && void 0 !== arguments[3]
                  ? arguments[3]
                  : function () {};
              try {
                var o = t.endpoints.sessions,
                  i = new window.XMLHttpRequest();
                (i.onreadystatechange = function () {
                  i.readyState === window.XMLHttpRequest.DONE &&
                    r(null, i.responseText);
                }),
                  i.open("POST", o),
                  i.setRequestHeader("Content-Type", "application/json"),
                  i.setRequestHeader("Bugsnag-Api-Key", t.apiKey),
                  i.setRequestHeader("Bugsnag-Payload-Version", "1.0"),
                  i.setRequestHeader("Bugsnag-Sent-At", _t()),
                  i.send(wt(n));
              } catch (t) {
                e.error(t);
              }
            },
          },
          Lt =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            },
          Ct = "Bugsnag JavaScript",
          qt = "4.7.3",
          Tt = "https://github.com/bugsnag/bugsnag-js",
          Mt = o,
          At = i,
          Pt = Lt({}, m.schema, we),
          Vt = [yt, ht, _e, ke, rt, ve, Oe, Ke, He, Me, xe, ut, Ue, ft];
        kt = function (e) {
          var t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
          "string" == typeof e && (e = { apiKey: e });
          var n = [];
          e.sessionTrackingEnabled &&
            (n.push(
              "deprecated option sessionTrackingEnabled is now called autoCaptureSessions"
            ),
            (e.autoCaptureSessions = e.sessionTrackingEnabled)),
            (!e.endpoint && !e.sessionEndpoint) ||
              e.endpoints ||
              (n.push(
                "deprecated options endpoint/sessionEndpoint are now configured in the endpoints object"
              ),
              (e.endpoints = {
                notify: e.endpoint,
                sessions: e.sessionEndpoint,
              })),
            e.endpoints &&
              e.endpoints.notify &&
              !e.endpoints.sessions &&
              n.push(
                "notify endpoint is set but sessions endpoint is not. No sessions will be sent."
              );
          var r = At(
              [].concat(Vt).concat(t),
              function (e, t) {
                return t.configSchema ? Lt({}, e, t.configSchema) : e;
              },
              Pt
            ),
            o = new he({ name: Ct, version: qt, url: Tt }, r);
          return (
            o.transport(window.XDomainRequest ? Nt : xt),
            o.configure(e),
            Mt(n, function (e) {
              return o._logger.warn(e);
            }),
            o.use(_e),
            o.use(ke),
            o.use(rt),
            o.use(xe),
            o.use(ve),
            o.use(ut),
            o.use(Ue),
            o.use(ft),
            !1 !== o.config.autoNotify && (o.use(yt), o.use(ht)),
            Ut(o.config, "navigationBreadcrumbsEnabled") && o.use(He),
            Ut(o.config, "interactionBreadcrumbsEnabled") && o.use(Me),
            Ut(o.config, "networkBreadcrumbsEnabled") && o.use(Ke),
            Ut(o.config, "consoleBreadcrumbsEnabled", !1) && o.use(Oe),
            Mt(t, function (e) {
              return o.use(e);
            }),
            o.config.autoCaptureSessions ? o.startSession() : o
          );
        };
        var Ut = function (e, t) {
          var n =
            !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
          return "boolean" == typeof e[t]
            ? e[t]
            : e.autoBreadcrumbs &&
                (n || !/^dev(elopment)?$/.test(e.releaseStage));
        };
        return (
          (kt.Bugsnag = { Client: he, Report: V, Session: Q, Breadcrumb: h }),
          (kt.default = kt),
          kt
        );
      })();
    },
  },
]);
