/*! For license information please see 2786.8058d5b51ac83dc93c97-site-bundle.js.LICENSE.txt */
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [2786],
  {
    626295: function (e, t, n) {
      e.exports = n(686209);
    },
    278637: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          default: function () {
            return Se;
          },
        });
      var a = n(863056),
        i = n(573126),
        r = n(841266),
        o = n(981643),
        s = n.n(o),
        l = n(366757),
        p = n(602285),
        u = n(14310),
        c = n.n(u),
        d = n(620116),
        h = n.n(d),
        g = n(834074),
        f = n.n(g),
        m = n(239649),
        y = n.n(m),
        v = n(820368),
        w = n.n(v),
        S = n(663978),
        b = n.n(S),
        _ = n(501068),
        C = n.n(_),
        O = n(468420),
        U = n(327344),
        k = n(505281),
        x = n(484441),
        I = n(103020),
        q = n(803362),
        P = n(859056),
        R = n(844845),
        N = (n(569600), n(778914)),
        Z = n.n(N),
        E = n(626295),
        D = n.n(E),
        F = n(2991),
        T = n.n(F),
        L = n(51942),
        A = n.n(L),
        M = n(359340),
        j = n.n(M),
        z = n(841511),
        W = n.n(z),
        G = n(25843),
        J = n.n(G),
        V = n(694473),
        B = n.n(V),
        K = n(933032),
        H = n.n(K),
        $ = n(277149),
        Q = n.n($),
        X = n(686902),
        Y = n.n(X),
        ee = n(678580),
        te = n.n(ee),
        ne = n(232558),
        ae = n(294184),
        ie = n.n(ae),
        re = n(318592),
        oe = n(674615),
        se = n(234584),
        le = n(918186),
        pe = n(10711),
        ue = n(496486),
        ce = n(353147);
      function de(e, t) {
        var n = Y()(e);
        if (c()) {
          var a = c()(e);
          t &&
            (a = h()(a).call(a, function (t) {
              return f()(e, t).enumerable;
            })),
            n.push.apply(n, a);
        }
        return n;
      }
      function he(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n,
            a = null != arguments[t] ? arguments[t] : {};
          if (t % 2)
            Z()((n = de(Object(a), !0))).call(n, function (t) {
              (0, R.Z)(e, t, a[t]);
            });
          else if (y()) w()(e, y()(a));
          else {
            var i;
            Z()((i = de(Object(a)))).call(i, function (t) {
              b()(e, t, f()(a, t));
            });
          }
        }
        return e;
      }
      var ge = function (e) {
          var t = le.getDecimalNum(),
            n = Math.pow(10, t);
          return Math.round(e * n);
        },
        fe = function (e) {
          var t,
            n = he({}, e);
          return (
            Z()((t = D()(e))).call(t, function (e) {
              var t = (0, P.Z)(e, 2),
                a = t[0],
                i = t[1];
              "number" == typeof i && (n[a] = ge(i));
            }),
            n
          );
        },
        me = function () {
          var e = le.userHasCouponWithType("free_shipping");
          return {
            total: le.getTotalNum(),
            subtotal: le.getSubtotalWithDiscountNum(),
            shippingFee: e ? 0 : le.getShippingFeeNum(),
            taxes: le.getTaxesNum(),
          };
        },
        ye = (function (e) {
          (0, x.Z)(r, e);
          var t,
            n,
            i =
              ((t = r),
              (n = (function () {
                if ("undefined" == typeof Reflect || !C()) return !1;
                if (C().sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                  return (
                    Boolean.prototype.valueOf.call(
                      C()(Boolean, [], function () {})
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              })()),
              function () {
                var e,
                  a = (0, q.Z)(t);
                if (n) {
                  var i = (0, q.Z)(this).constructor;
                  e = C()(a, arguments, i);
                } else e = a.apply(this, arguments);
                return (0, I.Z)(this, e);
              });
          function r(e) {
            var t;
            return (
              (0, O.Z)(this, r),
              (t = i.call(this, e)),
              (0, R.Z)((0, k.Z)(t), "paymentRequest", void 0),
              (0, R.Z)((0, k.Z)(t), "getOrderSendingData", function (e) {
                var n,
                  a = e.payerEmail,
                  i = e.payerName,
                  r = e.payerPhone,
                  o = e.shippingAddress,
                  s = e.dependentLocality,
                  l = void 0 === s ? "" : s,
                  p = t.props,
                  u = p.rawOrderData,
                  c = p.isShippingRequired,
                  d = p.selectedShippingOption,
                  h =
                    (null == u || null === (n = u.toJS) || void 0 === n
                      ? void 0
                      : n.call(u)) ||
                    u ||
                    {},
                  g = h.items,
                  f = h.coupon,
                  m = h.shipping,
                  y = t.state.addressFilled,
                  v = {
                    coupon: f.token,
                    email: a,
                    gateway: "stripe_connect",
                    orderItems: T()(g).call(g, function (e) {
                      return {
                        id: e.orderItem.id,
                        quantity: e.orderItem.quantity,
                        weight: e.orderItem.weight,
                      };
                    }),
                  };
                if (((v.shipping = { firstName: i, phone: r }), c && y && o)) {
                  var w = o.country,
                    S = o.addressLine,
                    b = o.city,
                    _ = o.region,
                    C = o.postalCode;
                  v.shipping = A()(v.shipping, {
                    country: w,
                    city: b,
                    state: _,
                    line1: l + S.join(";"),
                    zip: C,
                  });
                }
                return (
                  m.notes.value && (v.notes = m.notes.value),
                  d && (v.shippingOptionId = d.id),
                  v
                );
              }),
              (0, R.Z)((0, k.Z)(t), "getShippingOptions", function () {
                var e = t.props.shippingOptions;
                if (!e) {
                  var n,
                    a = le.userHasCouponWithType("free_shipping");
                  e = T()((n = le.getShippingOptions())).call(n, function (e) {
                    return he({ amount: a ? 0 : le.getShippingFeeNum(e) }, e);
                  });
                }
                return e || [];
              }),
              (0, R.Z)((0, k.Z)(t), "createOrder", function (e, n, a) {
                var i = t.props.isShippingRequired,
                  r = t.state.addressFilled;
                if (i && !r)
                  return (
                    a(),
                    alert(
                      ce(
                        "Ecommerce|Transaction failure due to the incomplete shipping address!"
                      )
                    )
                  );
                var o = t.getOrderSendingData(e);
                return pe.orders.create({
                  rest: !0,
                  pageId: se.getId(),
                  data: j()(o),
                  success: function (e) {
                    n(e);
                  },
                  error: function (e) {
                    var t;
                    return (
                      a(),
                      400 === e.status
                        ? -1 !==
                          s()((t = e.responseJSON.data.errors)).call(
                            t,
                            "is not enough"
                          )
                          ? alert(
                              ce(
                                "Ecommerce|Sorry! The item in your shopping cart has just sold out. Please refresh your page!"
                              )
                            )
                          : alert(
                              ce(
                                "Ecommerce|Seller has not connected his/her payment gateway. Can not buy now."
                              )
                            )
                        : alert(
                            ce(
                              "Ecommerce|There has been an error. Our engineers are looking into it now. Please retry!"
                            )
                          )
                    );
                  },
                });
              }),
              (t.state = { applePay: !1, otherPay: !1, addressFilled: !1 }),
              t
            );
          }
          return (
            (0, U.Z)(r, [
              {
                key: "componentDidMount",
                value: function () {
                  var e = this,
                    t = this.props,
                    n = t.isShippingRequired,
                    a = t.settings,
                    i = t.updateCartData,
                    r = t.publishableApiKey,
                    o = t.stripe,
                    s = t.onCreateFailed,
                    l = t.onCreateSuccess,
                    p = t.updateSelectedShippingOption,
                    u = String(
                      a.paymentGateways && a.paymentGateways.stripeCountry
                    ).toUpperCase();
                  if (o) {
                    try {
                      this.paymentRequest = o.paymentRequest(
                        he(
                          {
                            country: u,
                            currency: String(
                              a.currencyCode
                            ).toLocaleLowerCase(),
                            requestShipping: n,
                            requestPayerName: !0,
                            requestPayerEmail: !0,
                            requestPayerPhone: !0,
                          },
                          this.getSharedUpdateOptions()
                        )
                      );
                    } catch (e) {
                      return (
                        console.error(e), void ("function" == typeof s && s())
                      );
                    }
                    this.paymentRequest.canMakePayment().then(function (t) {
                      t
                        ? (t.applePay
                            ? e.setState({ applePay: !0 })
                            : e.setState({ otherPay: !0 }),
                          "function" == typeof l && l())
                        : "function" == typeof s && s();
                    }),
                      this.paymentRequest.on(
                        "shippingaddresschange",
                        function (t) {
                          var n,
                            a = t.updateWith,
                            r = t.shippingAddress,
                            o = r.addressLine,
                            s = r.region,
                            l = r.city,
                            p = r.dependentLocality,
                            u = r.postalCode,
                            c = r.phone,
                            d = r.country,
                            h = String(d).toLocaleLowerCase(),
                            g = W()(o)
                              ? T()(o)
                                  .call(o, function (e) {
                                    var t;
                                    return J()((t = String(e || ""))).call(t);
                                  })
                                  .join(";")
                              : J()((n = String(o || ""))).call(n);
                          oe.e.getIsNewCheckoutDesign()
                            ? e.props.updateShippingData({
                                country: h,
                                state: s,
                                city: l,
                                county: p,
                                address: g,
                                zip: u,
                                phone: c,
                              })
                            : "function" == typeof i &&
                              (i("shipping.country", { value: h }),
                              i("shipping.state", { value: r.region }),
                              i("shipping.city", { value: r.city }),
                              r.dependentLocality &&
                                i("shipping.county", {
                                  value: r.dependentLocality,
                                }),
                              i("shipping.address", { value: g }),
                              i("shipping.zip", { value: r.postalCode }),
                              i("shipping.phone", { value: r.phone })),
                            e.isValidShippingAddress()
                              ? e.setState({ addressFilled: !0 }, function () {
                                  a(
                                    he(
                                      { status: "success" },
                                      e.getSharedUpdateOptions(!0)
                                    )
                                  );
                                })
                              : e.setState({ addressFilled: !1 }, function () {
                                  a({ status: "invalid_shipping_address" });
                                });
                        }
                      ),
                      this.paymentRequest.on(
                        "shippingoptionchange",
                        function (t) {
                          var n,
                            a = t.updateWith,
                            i = t.shippingOption,
                            r = B()((n = e.getShippingOptions())).call(
                              n,
                              function (e) {
                                var t = e.id;
                                return String(t) === i.id;
                              }
                            );
                          r && p(r),
                            e.isValidShippingAddress()
                              ? a(
                                  he(
                                    { status: "success" },
                                    e.getSharedUpdateOptions(!0)
                                  )
                                )
                              : a({ status: "invalid_shipping_address" });
                        }
                      ),
                      this.paymentRequest.on("cancel", function () {
                        console.info("canceled");
                      }),
                      this.paymentRequest.on("paymentmethod", function (t) {
                        console.info(t),
                          e.createOrder(
                            t,
                            function (n) {
                              var a = n.data.chargeInfo,
                                i = a.paymentIntentClientSecret,
                                s = a.error;
                              if (s) return t.complete("fail"), alert(s);
                              (0, o.confirmPaymentIntent)(i, {
                                payment_method: t.paymentMethod.id,
                              }).then(function (n) {
                                var a = n.error;
                                if (a)
                                  t.complete("fail"),
                                    a.message &&
                                      H()(function () {
                                        return alert(a.message);
                                      }, 1);
                                else {
                                  if (
                                    (t.complete("success"),
                                    !window.Stripe && !r)
                                  )
                                    return alert("error");
                                  new window.Stripe(r)
                                    .handleCardPayment(i)
                                    .then(function (t) {
                                      var n = t.error,
                                        a = t.paymentIntent;
                                      n
                                        ? (console.info("error"),
                                          n.message && alert(n.message))
                                        : "succeeded" === a.status
                                        ? (console.info("success"),
                                          oe.e.getIsNewCheckoutDesign()
                                            ? e.props.onSuccess()
                                            : "function" ==
                                                typeof e.props.gotoPanel &&
                                              e.props.gotoPanel("confirm"))
                                        : console.info("error");
                                    })
                                    .catch(function (e) {
                                      e.message && alert(e.message);
                                    });
                                }
                              });
                            },
                            function () {
                              return t.complete("fail");
                            }
                          );
                      });
                  }
                },
              },
              {
                key: "componentDidUpdate",
                value: function (e) {
                  var t = this.props,
                    n = t.rawOrderData,
                    a = t.settings;
                  if (!ue.isEqual(e.rawOrderData, n) && this.paymentRequest) {
                    var i,
                      r,
                      o = (
                        (null == n || null === (i = n.toJS) || void 0 === i
                          ? void 0
                          : i.call(n)) ||
                        n ||
                        {}
                      ).items,
                      s = void 0 === o ? [] : o;
                    r = Q()(s).call(s, function (e) {
                      if ((e.orderItem || {}).shippingInfo) return !0;
                    });
                    try {
                      this.paymentRequest.update(
                        he(
                          {
                            currency: String(
                              a.currencyCode
                            ).toLocaleLowerCase(),
                          },
                          this.getSharedUpdateOptions(r)
                        )
                      );
                    } catch (e) {}
                  }
                },
              },
              {
                key: "isValidShippingAddress",
                value: function () {
                  var e,
                    t = this.props,
                    n = t.settings,
                    a = t.rawOrderData,
                    i = (
                      (null == a || null === (e = a.toJS) || void 0 === e
                        ? void 0
                        : e.call(a)) || a
                    ).shipping ||
                      le.getShippingAddress() || {
                        country: { value: "" },
                        state: { value: "" },
                        city: { value: "" },
                      },
                    r = Y()(n.shippingRegions || {}) || [],
                    o = i.country.value,
                    s = i.state.value,
                    l = i.city.value;
                  return (
                    o &&
                    (te()(r).call(r, o) || te()(r).call(r, "default")) &&
                    (s || l)
                  );
                },
              },
              {
                key: "getSharedUpdateOptions",
                value: function () {
                  var e =
                      arguments.length > 0 &&
                      void 0 !== arguments[0] &&
                      arguments[0],
                    t = this.props,
                    n = t.isShippingRequired,
                    a = t.orderFeeList,
                    i = this.state.addressFilled,
                    r = fe(a || me()),
                    o = r.total,
                    s = r.subtotal,
                    l = r.shippingFee,
                    p = r.taxes,
                    u = r.couponDiscount,
                    c = this.getShippingOptions(),
                    d = [],
                    h = { total: { label: ce("Ecommerce|Total"), amount: o } };
                  return (
                    o !== s &&
                      (d.push({ amount: s, label: ce("Ecommerce|Subtotal") }),
                      u &&
                        d.push({
                          amount: u,
                          label: ce("EcommerceCoupon|Coupon"),
                        })),
                    n &&
                      "number" == typeof l &&
                      d.push({ amount: l, label: ce("Ecommerce|Shipping") }),
                    "number" == typeof p &&
                      d.push({ amount: p, label: ce("Ecommerce|Tax") }),
                    (h.displayItems = d),
                    n &&
                      (e || i) &&
                      c.length &&
                      (h.shippingOptions = T()(c).call(c, function (e) {
                        var t = e.id,
                          n = e.name,
                          a = e.shippingGuideline,
                          i = e.amount;
                        return {
                          id: String(t),
                          label: n,
                          detail: a || "",
                          amount: i ? ge(i) : 0,
                        };
                      })),
                    h
                  );
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this.state,
                    t = e.applePay,
                    n = e.otherPay,
                    i = this.props,
                    r = i.settings,
                    o = i.onCreateFailed;
                  return r && r.paymentGateways && r.paymentGateways.stripe
                    ? (0, a.Z)(
                        "div",
                        { className: ie()((0, re.css)("inline-block")) },
                        void 0,
                        t || n
                          ? (0, a.Z)(ne.c8, {
                              className: "payment-request-button",
                              paymentRequest: this.paymentRequest,
                              style: {
                                paymentRequestButton: {
                                  theme: "dark",
                                  height: "48px",
                                },
                              },
                            })
                          : null
                      )
                    : ("function" == typeof o && o(), null);
                },
              },
            ]),
            r
          );
        })(l.Component),
        ve = (0, ne.kv)(ye),
        we = 389 != n.j ? ["locale"] : null,
        Se =
          389 != n.j
            ? function (e) {
                var t,
                  n,
                  o,
                  u,
                  c = e.locale,
                  d = (0, r.Z)(e, we),
                  h =
                    null === (t = d.settings.paymentGateways) || void 0 === t
                      ? void 0
                      : t.stripePublishableKey;
                return h &&
                  -1 !==
                    (null === (n = window) ||
                    void 0 === n ||
                    null === (o = n.location) ||
                    void 0 === o
                      ? void 0
                      : s()((u = o.protocol)).call(u, "https"))
                  ? (0, a.Z)(
                      p.Z,
                      { publishableApiKey: h, locale: c },
                      void 0,
                      l.createElement(ve, (0, i.Z)({ publishableApiKey: h }, d))
                    )
                  : ("function" == typeof d.onCreateFailed &&
                      d.onCreateFailed(),
                    null);
              }
            : null;
    },
    709597: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          ENV: function () {
            return i;
          },
          PRODUCT_NAME: function () {
            return a;
          },
          getConfig: function () {
            return o;
          },
        });
      var a = { NODE_ENV: "production", VERBOSE: void 0 }.PRODUCT_NAME || "sxl",
        i = "production",
        r = {
          bobcat: {
            strikingly: {
              development: {
                baseUrl: "strikingly.io:3000",
                mainUrl: "http://www.strikingly.io:3000",
                assetUrl: "//strikingly.io:3000",
              },
              staging: {
                baseUrl: "staging.strikingly.com",
                mainUrl: "http://www.staging.strikingly.com",
                assetUrl: "//staging.strikingly.com",
              },
              uat: {
                baseUrl: "uat.strikingly.com",
                mainUrl: "http://www.uat.strikingly.com",
                assetUrl: "//uat.strikingly.com",
              },
              production: {
                baseUrl: "strikingly.com",
                mainUrl: "http://www.strikingly.com",
                assetUrl: "//strikingly.com",
              },
            },
            sxl: {
              development: {
                baseUrl: "shangxianle.me:3000",
                mainUrl: "http://www.shangxianle.me:3000",
                assetUrl: "//shangxianle.me:3000",
              },
              staging: {
                baseUrl: "staging.sxl.cn",
                mainUrl: "http://www.staging.sxl.cn",
                assetUrl: "//staging.sxl.cn",
              },
              uat: {
                baseUrl: "uat.sxl.cn",
                mainUrl: "http://www.uat.sxl.cn",
                assetUrl: "//uat.sxl.cn",
              },
              production: {
                baseUrl: "sxl.cn",
                mainUrl: "http://www.sxl.cn",
                assetUrl: "//assets.sxlcdn.com",
              },
            },
          },
          qiniu: {
            strikingly: {
              development: { host: "" },
              staging: { host: "" },
              uat: { host: "" },
              production: { host: "" },
            },
            sxl: {
              development: { host: "//7xpea4.com1.z0.glb.clouddn.com" },
              staging: { host: "http://7xpea4.com1.z0.glb.clouddn.com" },
              uat: { host: "http://7xpea4.com1.z0.glb.clouddn.com" },
              production: { host: "http://user-assets.sxlcdn.com" },
            },
          },
        },
        o = function (e) {
          return r[e][a][i];
        };
    },
    433137: function (e, t, n) {
      "use strict";
      var a = n(353147),
        i = n(663978),
        r = n(60530)(n(60530));
      i(t, "__esModule", { value: !0 }),
        (t.getWxConfForOauth = q),
        (t.storeShoppingCart = P),
        (t.getShoppingCart = function () {
          var e = decodeURIComponent(location ? location.href : ""),
            t = (0, h.default)(e).paramsToMap() || {},
            n = t.wechat_pre_order_id;
          return (
            delete t.open_payment_dialog,
            delete t.wechat_pre_order_id,
            new p.default(function (e, a) {
              x.default.orders.getShoppingCart({
                pageId: f.default.getId(),
                weChatPreOrderId: n,
                success: function (n) {
                  var a = n.data,
                    i = _.merge(
                      {},
                      JSON.parse(w.default.getItem("__strk_shopping_cart")),
                      t,
                      a
                    );
                  e(i);
                },
                fail: function (e) {
                  a(e);
                },
              });
            })
          );
        }),
        (t.getOauthUri = function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            t = "",
            n = U.default.v4();
          P(n, e);
          var a,
            i,
            r,
            o,
            s = "https://open.weixin.qq.com/connect/oauth2/authorize?";
          t = b.default.getRollout("new_wechat_oauth")
            ? (0, c.default)(
                (a = (0, c.default)(
                  (i = "https://www.".concat(
                    (0, C.getConfig)("bobcat").baseUrl,
                    "/mp/wechat_auth?open_payment_dialog=true&wechat_pre_order_id="
                  ))
                ).call(i, n, "&site_id="))
              ).call(a, f.default.getId())
            : (0, c.default)(
                (r = (0, c.default)(
                  (o = "https://www.".concat(
                    (0, C.getConfig)("bobcat").baseUrl,
                    "/s/wechat_auth?open_payment_dialog=true&wechat_pre_order_id="
                  ))
                ).call(o, n, "&site_id="))
              ).call(r, f.default.getId());
          var l = q(encodeURIComponent(t)),
            p = I.transformToParamsWithMap(l);
          return "".concat(s).concat(p, "#wechat_redirect");
        });
      var o = n(686902),
        s = (0, r.default)(o),
        l = n(493476),
        p = (0, r.default)(l),
        u = n(977766),
        c = (0, r.default)(u),
        d = n(350723),
        h = (0, r.default)(d),
        g = n(234584),
        f = (0, r.default)(g),
        m = n(80827),
        y = (0, r.default)(m),
        v = n(991003),
        w = (0, r.default)(v),
        S = n(183123),
        b = (0, r.default)(S),
        C = n(709597),
        O = n(468811),
        U = (0, r.default)(O),
        k = n(10711),
        x = (0, r.default)(k),
        I = (0, h.default)(location.href);
      function q(e, t) {
        return {
          appid: $S.stores.pageMeta.ecommerce.seller_wechat_app_id,
          redirect_uri: e,
          response_type: "code",
          scope: t || "snsapi_base",
        };
      }
      function P(e, t) {
        var n = (function (e) {
          var t =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : {},
            n = {};
          try {
            for (var a in (n = b.default.getIsNewCheckoutDesign()
              ? 0 === (0, s.default)(t).length
                ? JSON.parse(w.default.getItem("__strk_shopping_cart"))
                : t
              : y.default.getCart()).shipping)
              delete n.shipping[a].errorTrigger;
            n.wechatPreOrderId = e;
          } catch (e) {
            console.error("出现了未知的错误，请联系我们的客服人员");
          }
          return n;
        })(e, t);
        x.default.orders.setShoppingCart({
          pageId: f.default.getId(),
          data: n,
          success: function () {
            console.info("set shopping cart successful");
          },
          fail: function (e) {
            console.error(e),
              alert(
                a(
                  "Ecommerce|Sorry, we had a problem processing your payment. Please try another payment method."
                )
              );
          },
        });
      }
    },
    273081: function (e, t, n) {
      n(921078);
      var a = n(354058);
      e.exports = a.Object.entries;
    },
    921078: function (e, t, n) {
      var a = n(276887),
        i = n(88810).entries;
      a(
        { target: "Object", stat: !0 },
        {
          entries: function (e) {
            return i(e);
          },
        }
      );
    },
    686209: function (e, t, n) {
      var a = n(273081);
      e.exports = a;
    },
  },
]);
