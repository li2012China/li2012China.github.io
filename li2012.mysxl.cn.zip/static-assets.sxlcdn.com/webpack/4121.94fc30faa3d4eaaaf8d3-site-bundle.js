/*! For license information please see 4121.94fc30faa3d4eaaaf8d3-site-bundle.js.LICENSE.txt */
"use strict";
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [4121],
  {
    962354: function (e, t, a) {
      var n = a(353147),
        l = a(223765),
        o = a(752424),
        u = a(663978),
        i = a(834074),
        r = a(60530)(a(60530));
      u(t, "__esModule", { value: !0 });
      var d,
        f = a(812077),
        s = (0, r.default)(f);
      a(569600);
      var c = a(678580),
        m = (0, r.default)(c),
        p = a(366757),
        v = ((0, r.default)(p), a(45697)),
        g = (0, r.default)(v),
        h = a(399069),
        y = (0, r.default)(h),
        _ = a(234584),
        b = (0, r.default)(_),
        P = a(834243),
        N = (0, r.default)(P),
        k = a(266004),
        C = (0, r.default)(k),
        x = a(80827),
        w = (0, r.default)(x),
        D = a(271866),
        S = (0, r.default)(D),
        A = a(174001),
        B = (0, r.default)(A),
        M = a(869371),
        F = (0, r.default)(M),
        E = a(230139),
        I = (0, r.default)(E),
        O = a(43138),
        T = (0, r.default)(O),
        j = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" !== l(e) && "function" != typeof e))
            return { default: e };
          var a = W(t);
          if (a && a.has(e)) return a.get(e);
          var n = {},
            o = u && i;
          for (var r in e)
            if ("default" !== r && Object.prototype.hasOwnProperty.call(e, r)) {
              var d = o ? i(e, r) : null;
              d && (d.get || d.set) ? u(n, r, d) : (n[r] = e[r]);
            }
          return (n.default = e), a && a.set(e, n), n;
        })(a(589499)),
        U = a(184635),
        R = (0, r.default)(U);
      function W(e) {
        if ("function" != typeof o) return null;
        var t = new o(),
          a = new o();
        return (W = function (e) {
          return e ? a : t;
        })(e);
      }
      (t.default = y.default.createPageComponent({
        displayName: "EcommerceBuyDialog",
        mixins: [(0, I.default)("editor")],
        bobcatPropTypes: { data: { binding: g.default.object.isRequired } },
        componentWillMount: function () {
          this.initMeta({
            needExtend: !0,
            showCloseBtn: !0,
            loadComponent: !1,
            mounted: !1,
          });
        },
        componentDidMount: function () {
          var e = this;
          this._setMounted(!0),
            (this._token = B.default.register(function (t) {
              t.actionType === F.default.ActionTypes.LOAD_ECOMMERCE_BUY &&
                e._setLoadComponent(!0);
            }));
        },
        componentWillUnmount: function () {
          B.default.unregister(this._token);
        },
        _isProOrVip: function () {
          var e;
          return (0, m.default)(
            (e = ["pro", "namecheap", "reseller", "sxlpro", "sxlbiz", "vip"])
          ).call(e, b.default.getUser().get("membership"));
        },
        _changeExtendState: function (e) {
          return this._setNeedExtend(e);
        },
        render: function () {
          this.observeBinding(C.default.getProductsBinding()),
            this.observeBinding(C.default.getSettingsBinding()),
            this.observeBinding(w.default.getCartBinding()),
            this.observeBinding(w.default.getUIBinding());
          var e = ["ecommerce-buy-dialog", "s-edit-modal"];
          return (
            this._getMounted() &&
              T.default.isSmallScreen() &&
              e.push("mobile-mode"),
            this._getNeedExtend() && e.push("extend"),
            this._isProOrVip() || e.push("show-copyright"),
            (0, s.default)(
              "div",
              { className: e.join(" "), id: "ecommerce-buy-dialog" },
              void 0,
              (0, s.default)(R.default, {
                binding: w.default.getCartBinding(),
                immediate: this._getLoadComponent(),
                componentName: "ecommerceBuy",
                componentProps: {
                  binding: w.default.getCartBinding(),
                  currentPanelName: w.default.getCurrentPanelName(),
                  needToAdjustHeight: w.default.getNeedToAdjustHeight(),
                  showMsg: w.default.getShowMsg(),
                  changeDialogExtendState: this._changeExtendState,
                },
              }),
              !this._isProOrVip() &&
                (0, s.default)(
                  "div",
                  { className: "copyright" },
                  void 0,
                  (0, s.default)(
                    S.default,
                    {},
                    void 0,
                    (0, s.default)(
                      "div",
                      {},
                      void 0,
                      (0, s.default)(
                        "div",
                        { className: "powered-by" },
                        void 0,
                        n("Powered By")
                      ),
                      (0, s.default)("img", {
                        src: j.cdnAssetPath(
                          "/images/ecommerce/ecommerce-footer-logo.png"
                        ),
                      })
                    ),
                    (0, s.default)(
                      "div",
                      {},
                      void 0,
                      (0, s.default)("img", {
                        style: { width: "auto" },
                        src: j.cdnAssetPath(
                          N.default.isZbjUser()
                            ? "/images/zbj-logo.png"
                            : "/images/ecommerce/ecommerce-footer-logo-sxl-grey.png"
                        ),
                      }),
                      d ||
                        (d = (0, s.default)(
                          "div",
                          { className: "powered-by" },
                          void 0,
                          "提供技术支持"
                        ))
                    )
                  )
                )
            )
          );
        },
      })),
        (e.exports = t.default);
    },
    76904: function (e, t, a) {
      var n = a(353147),
        l = a(223765),
        o = a(501068),
        u = a(752424),
        i = a(663978),
        r = a(834074),
        d = a(60530)(a(60530));
      i(t, "__esModule", { value: !0 }), (t.default = void 0);
      var f = a(812077),
        s = (0, d.default)(f),
        c = a(726394),
        m = (0, d.default)(c),
        p = a(569198),
        v = (0, d.default)(p),
        g = a(705824),
        h = (0, d.default)(g),
        y = a(351379),
        _ = (0, d.default)(y),
        b = a(900214),
        P = (0, d.default)(b),
        N = a(566380),
        k = (0, d.default)(N),
        C = a(54103),
        x = (0, d.default)(C),
        w = a(366757),
        D = (0, d.default)(w),
        S = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" !== l(e) && "function" != typeof e))
            return { default: e };
          var a = A(t);
          if (a && a.has(e)) return a.get(e);
          var n = {},
            o = i && r;
          for (var u in e)
            if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
              var d = o ? r(e, u) : null;
              d && (d.get || d.set) ? i(n, u, d) : (n[u] = e[u]);
            }
          return (n.default = e), a && a.set(e, n), n;
        })(a(589499));
      function A(e) {
        if ("function" != typeof u) return null;
        var t = new u(),
          a = new u();
        return (A = function (e) {
          return e ? a : t;
        })(e);
      }
      var B = (function (e) {
        (0, _.default)(u, e);
        var t,
          a,
          l =
            ((t = u),
            (a = (function () {
              if ("undefined" == typeof Reflect || !o) return !1;
              if (o.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    o(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                n = (0, k.default)(t);
              if (a) {
                var l = (0, k.default)(this).constructor;
                e = o(n, arguments, l);
              } else e = n.apply(this, arguments);
              return (0, P.default)(this, e);
            });
        function u(e) {
          var t, a;
          return (
            (0, m.default)(this, u),
            ((a = l.call(this, e))._closeDialog = (0, x.default)(
              (t = a._closeDialog)
            ).call(t, (0, h.default)(a))),
            a
          );
        }
        return (
          (0, v.default)(u, [
            {
              key: "_closeDialog",
              value: function () {
                var e = this.props,
                  t = e.closeDialog,
                  a = e.changePanel;
                t(), a("form");
              },
            },
            {
              key: "render",
              value: function () {
                var e = this.props.settings;
                return (0, s.default)(
                  "div",
                  { className: "buy-panel confirm no-extend" },
                  void 0,
                  (0, s.default)(
                    "div",
                    { className: "confirm" },
                    void 0,
                    (0, s.default)(
                      "div",
                      { className: "title" },
                      void 0,
                      (0, s.default)("img", {
                        src: S.cdnAssetPath("/images/editor2/ic_heart.png"),
                      }),
                      (0, s.default)(
                        "span",
                        {},
                        void 0,
                        n("Donation|THANK YOU!")
                      )
                    ),
                    (0, s.default)(
                      "div",
                      { className: "message" },
                      void 0,
                      e.data.thanksMessage ||
                        n(
                          "Donation|Please accept my heartfelt thanks for your gift donations. Our company picnic was a huge success, in part due to your help. The raffle was a hot item with your gifts as the prize. Thank you for your generosity and your quality products!"
                        )
                    ),
                    (0, s.default)(
                      "div",
                      { className: "s-btn green", onClick: this._closeDialog },
                      void 0,
                      n("Donation|Got it!")
                    )
                  )
                );
              },
            },
          ]),
          u
        );
      })(D.default.Component);
      (t.default = B), (e.exports = t.default);
    },
    408548: function (e, t, a) {
      var n = a(353147),
        l = a(501068),
        o = a(663978),
        u = a(60530)(a(60530));
      o(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i,
        r = a(812077),
        d = (0, u.default)(r),
        f = a(726394),
        s = (0, u.default)(f),
        c = a(569198),
        m = (0, u.default)(c),
        p = a(351379),
        v = (0, u.default)(p),
        g = a(900214),
        h = (0, u.default)(g),
        y = a(566380),
        _ = (0, u.default)(y),
        b = a(366757),
        P = (0, u.default)(b),
        N = a(589499),
        k = a(271866),
        C = (0, u.default)(k),
        x = a(467653),
        w = (0, u.default)(x),
        D = a(141655),
        S = (0, u.default)(D),
        A = a(834243),
        B = (0, u.default)(A);
      var M = (function (e) {
        (0, v.default)(u, e);
        var t,
          a,
          o =
            ((t = u),
            (a = (function () {
              if ("undefined" == typeof Reflect || !l) return !1;
              if (l.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    l(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                n = (0, _.default)(t);
              if (a) {
                var o = (0, _.default)(this).constructor;
                e = l(n, arguments, o);
              } else e = n.apply(this, arguments);
              return (0, h.default)(this, e);
            });
        function u(e) {
          return (0, s.default)(this, u), o.call(this, e);
        }
        return (
          (0, m.default)(u, [
            {
              key: "_openDialog",
              value: function () {
                var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : {};
                S.default.openDialog("donateDialog", e);
              },
            },
            {
              key: "_closeDialog",
              value: function () {
                S.default.closeDialog("donateDialog");
              },
            },
            {
              key: "render",
              value: function () {
                return (0, d.default)(
                  "div",
                  {
                    id: "donate-dialog",
                    className: "donate-dialog s-edit-modal",
                  },
                  void 0,
                  (0, d.default)(
                    "div",
                    { className: "close-button" },
                    void 0,
                    (0, d.default)(
                      "h5",
                      {},
                      void 0,
                      (0, d.default)(
                        "a",
                        { onClick: this._closeDialog },
                        void 0,
                        " × "
                      )
                    )
                  ),
                  (0, d.default)(w.default, {
                    closeDialog: this._closeDialog,
                    openDialog: this._openDialog,
                  }),
                  (0, d.default)(
                    "div",
                    { className: "copyright" },
                    void 0,
                    (0, d.default)(
                      C.default,
                      {},
                      void 0,
                      (0, d.default)(
                        "div",
                        {},
                        void 0,
                        (0, d.default)(
                          "div",
                          { className: "powered-by" },
                          void 0,
                          n("Powered By")
                        ),
                        (0, d.default)("img", {
                          src: (0, N.cdnAssetPath)(
                            "/images/ecommerce/ecommerce-footer-logo.png"
                          ),
                        })
                      ),
                      (0, d.default)(
                        "div",
                        {},
                        void 0,
                        (0, d.default)("img", {
                          style: { width: "auto" },
                          src: (0, N.cdnAssetPath)(
                            B.default.isZbjUser()
                              ? "/images/zbj-logo.png"
                              : "/images/ecommerce/ecommerce-footer-logo-sxl-grey.png"
                          ),
                        }),
                        i ||
                          (i = (0, d.default)(
                            "div",
                            { className: "powered-by" },
                            void 0,
                            "提供技术支持"
                          ))
                      )
                    )
                  )
                );
              },
            },
          ]),
          u
        );
      })(P.default.Component);
      (t.default = M), (e.exports = t.default);
    },
    190534: function (e, t, a) {
      var n = a(353147),
        l = a(223765),
        o = a(501068),
        u = a(752424),
        i = a(663978),
        r = a(834074),
        d = a(60530)(a(60530));
      i(t, "__esModule", { value: !0 }), (t.default = void 0);
      var f,
        s = a(812077),
        c = (0, d.default)(s),
        m = a(726394),
        p = (0, d.default)(m),
        v = a(569198),
        g = (0, d.default)(v),
        h = a(705824),
        y = (0, d.default)(h),
        _ = a(351379),
        b = (0, d.default)(_),
        P = a(900214),
        N = (0, d.default)(P),
        k = a(566380),
        C = (0, d.default)(k),
        x = a(54103),
        w = (0, d.default)(x),
        D = a(366757),
        S = (0, d.default)(D),
        A = a(234584),
        B = (0, d.default)(A),
        M = a(372742),
        F = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" !== l(e) && "function" != typeof e))
            return { default: e };
          var a = T(t);
          if (a && a.has(e)) return a.get(e);
          var n = {},
            o = i && r;
          for (var u in e)
            if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
              var d = o ? r(e, u) : null;
              d && (d.get || d.set) ? i(n, u, d) : (n[u] = e[u]);
            }
          return (n.default = e), a && a.set(e, n), n;
        })(a(589499)),
        E = a(329756),
        I = a(378763),
        O = (0, d.default)(I);
      function T(e) {
        if ("function" != typeof u) return null;
        var t = new u(),
          a = new u();
        return (T = function (e) {
          return e ? a : t;
        })(e);
      }
      var j = (function (e) {
        (0, b.default)(u, e);
        var t,
          a,
          l =
            ((t = u),
            (a = (function () {
              if ("undefined" == typeof Reflect || !o) return !1;
              if (o.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    o(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                n = (0, C.default)(t);
              if (a) {
                var l = (0, C.default)(this).constructor;
                e = o(n, arguments, l);
              } else e = n.apply(this, arguments);
              return (0, N.default)(this, e);
            });
        function u(e) {
          var t, a, n, o, i, r;
          return (
            (0, p.default)(this, u),
            ((r = l.call(this, e)).state = { amountDirty: !1, saving: !1 }),
            (r._channelConf = {
              alipay: { logo: "/images/ecommerce/pay_with_alipay.png" },
              wechat: { logo: "/images/ecommerce/wechatpay.png" },
            }),
            (r._renderPaymentChannels = (0, w.default)(
              (t = r._renderPaymentChannels)
            ).call(t, (0, y.default)(r))),
            (r._gotoNextPanel = (0, w.default)((a = r._gotoNextPanel)).call(
              a,
              (0, y.default)(r)
            )),
            (r._onChangeAmount = (0, w.default)((n = r._onChangeAmount)).call(
              n,
              (0, y.default)(r)
            )),
            (r._onBlurAmount = (0, w.default)((o = r._onBlurAmount)).call(
              o,
              (0, y.default)(r)
            )),
            (r._submitForm = (0, w.default)((i = r._submitForm)).call(
              i,
              (0, y.default)(r)
            )),
            r
          );
        }
        return (
          (0, g.default)(u, [
            {
              key: "_gotoNextPanel",
              value: function () {
                if (!this.state.saving) {
                  var e = this.props,
                    t = e.donateForm,
                    a = (e.updateForm, t.get("total"));
                  !E.RegexConstants.PRICE.test(a) || a <= 0
                    ? this.setState({ amountDirty: !0 })
                    : this._submitForm();
                }
              },
            },
            {
              key: "_submitForm",
              value: function () {
                var e = this,
                  t = this.props,
                  a = t.donateForm,
                  n = (t.changePanel, a.toJS());
                (n.total = Math.round(100 * n.total)),
                  O.default.submitForm({
                    pageId: B.default.getId(),
                    data: n,
                    success: function (t) {
                      t.data.order.chargeUrl &&
                        (window.location.href = t.data.order.chargeUrl),
                        e.setState({ saving: !1 });
                    },
                    error: function () {
                      e.setState({ saving: !1 });
                    },
                  }),
                  this.setState({ saving: !0 });
              },
            },
            {
              key: "_onBlurAmount",
              value: function () {
                this.setState({ amountDirty: !0 });
              },
            },
            {
              key: "_onChangeAmount",
              value: function (e) {
                this.props.updateForm("total", e.target.value),
                  this.setState({ amountDirty: !0 });
              },
            },
            {
              key: "_renderPaymentChannels",
              value: function (e) {
                var t = this.props,
                  a = t.donateForm,
                  n = t.updateForm,
                  l = a.get("gateway"),
                  o = function () {
                    return n("gateway", e);
                  };
                return (0, c.default)(
                  "div",
                  { className: "payment-method", onClick: o },
                  void 0,
                  (0, c.default)("input", {
                    type: "radio",
                    checked: l === e,
                    name: "payment",
                    onChange: o,
                  }),
                  (0, c.default)("img", {
                    src: F.cdnAssetPath(this._channelConf[e].logo),
                  })
                );
              },
            },
            {
              key: "render",
              value: function () {
                var e = this.props,
                  t = e.donateForm,
                  a = e.updateForm,
                  l = e.currencyFormat,
                  o = this.state,
                  u = o.saving,
                  i = o.amountDirty,
                  r = t.get("total"),
                  d = i && (!E.RegexConstants.PRICE.test(r) || r < 0);
                return (0, c.default)(
                  "div",
                  { className: "s-donate-form s-form buy-panel" },
                  void 0,
                  (0, c.default)(
                    "div",
                    { className: "title" },
                    void 0,
                    n("Donation|Donation Info")
                  ),
                  (0, c.default)(
                    "div",
                    { className: "s-form-section" },
                    void 0,
                    (0, c.default)(
                      "div",
                      { className: "small-title" },
                      void 0,
                      n("Donation|Amount")
                    ),
                    (0, c.default)(
                      "div",
                      { className: "s-form-field amount" },
                      void 0,
                      (0, c.default)("input", {
                        type: "text",
                        className: d ? "error" : "",
                        onChange: this._onChangeAmount,
                        onBlur: this._onBlurAmount,
                      }),
                      (0, c.default)(
                        "div",
                        { className: "currency" },
                        void 0,
                        l.symbol
                      ),
                      d &&
                        (0, c.default)(
                          "div",
                          { className: "s-form-field-error" },
                          void 0,
                          n("Donation|Invalid Amount")
                        )
                    )
                  ),
                  (0, c.default)(
                    "div",
                    { className: "s-form-section" },
                    void 0,
                    (0, c.default)(
                      "div",
                      { className: "small-title" },
                      void 0,
                      n("Donation|Personal Information (optional)")
                    ),
                    (0, c.default)(
                      "div",
                      { className: "s-form-field-group" },
                      void 0,
                      (0, c.default)(
                        "div",
                        { className: "s-form-field inline" },
                        void 0,
                        (0, c.default)("input", {
                          type: "text",
                          onChange: function (e) {
                            return a("name", e.target.value);
                          },
                          placeholder: n("Donation|Full Name"),
                        })
                      ),
                      (0, c.default)(
                        "div",
                        { className: "s-form-field inline" },
                        void 0,
                        (0, c.default)("input", {
                          type: "text",
                          onChange: function (e) {
                            return a("phone", e.target.value);
                          },
                          placeholder: n("Donation|Phone Number"),
                        })
                      )
                    ),
                    (0, c.default)(
                      "div",
                      { className: "s-form-field" },
                      void 0,
                      (0, c.default)("input", {
                        type: "text",
                        onChange: function (e) {
                          return a("email", e.target.value);
                        },
                        placeholder: n("Donation|Email"),
                      })
                    ),
                    (0, c.default)(
                      "div",
                      { className: "s-form-field" },
                      void 0,
                      (0, c.default)("textarea", {
                        onChange: function (e) {
                          return a("notes", e.target.value);
                        },
                        placeholder: n("Donation|Send us a note"),
                      })
                    )
                  ),
                  (0, c.default)(
                    "div",
                    { className: "s-form-section" },
                    void 0,
                    (0, c.default)(
                      "div",
                      { className: "small-title" },
                      void 0,
                      n("Donation|Choose Payment Method")
                    ),
                    (0, c.default)(
                      "div",
                      {},
                      void 0,
                      this._renderPaymentChannels("alipay")
                    )
                  ),
                  (0, c.default)(
                    "div",
                    { className: "bottom" },
                    void 0,
                    (0, c.default)(
                      "div",
                      {
                        className: "s-btn green",
                        onClick: this._gotoNextPanel,
                      },
                      void 0,
                      n("Donation|Donate %{amount}", {
                        amount: (0, M.getFormattedPrice)(d ? 0 : r, l),
                      }),
                      u &&
                        (f ||
                          (f = (0, c.default)("i", {
                            className: "fa fa-spin fa-spinner",
                          })))
                    )
                  )
                );
              },
            },
          ]),
          u
        );
      })(S.default.Component);
      (t.default = j), (e.exports = t.default);
    },
    467653: function (e, t, a) {
      var n = a(501068),
        l = a(663978),
        o = a(60530)(a(60530));
      l(t, "__esModule", { value: !0 }), (t.default = void 0);
      var u = a(812077),
        i = (0, o.default)(u),
        r = a(726394),
        d = (0, o.default)(r),
        f = a(569198),
        s = (0, o.default)(f),
        c = a(705824),
        m = (0, o.default)(c),
        p = a(351379),
        v = (0, o.default)(p),
        g = a(900214),
        h = (0, o.default)(g),
        y = a(566380),
        _ = (0, o.default)(y);
      a(974916), a(115306);
      var b = a(54103),
        P = (0, o.default)(b),
        N = a(51942),
        k = (0, o.default)(N),
        C = a(366757),
        x = (0, o.default)(C),
        w = a(143393),
        D = (0, o.default)(w),
        S = a(190534),
        A = (0, o.default)(S),
        B = a(342004),
        M = (0, o.default)(B),
        F = a(76904),
        E = (0, o.default)(F),
        I = a(103356),
        O = (0, o.default)(I),
        T = a(815549),
        j = (0, o.default)(T);
      var U = (function (e) {
        (0, v.default)(o, e);
        var t,
          a,
          l =
            ((t = o),
            (a = (function () {
              if ("undefined" == typeof Reflect || !n) return !1;
              if (n.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    n(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                l = (0, _.default)(t);
              if (a) {
                var o = (0, _.default)(this).constructor;
                e = n(l, arguments, o);
              } else e = l.apply(this, arguments);
              return (0, h.default)(this, e);
            });
        function o(e) {
          var t, a, n, u, i;
          return (
            (0, d.default)(this, o),
            ((i = l.call(this, e)).state = {
              currentPanelName: "form",
              donateForm: D.default.fromJS({
                total: 0,
                name: "",
                phone: "",
                email: "",
                notes: "",
                gateway: "alipay",
              }),
            }),
            (i._changePanel = (0, P.default)((t = i._changePanel)).call(
              t,
              (0, m.default)(i)
            )),
            (i._getPanelProps = (0, P.default)((a = i._getPanelProps)).call(
              a,
              (0, m.default)(i)
            )),
            (i._updateForm = (0, P.default)((n = i._updateForm)).call(
              n,
              (0, m.default)(i)
            )),
            (i._listener = (0, P.default)((u = i._listener)).call(
              u,
              (0, m.default)(i)
            )),
            i
          );
        }
        return (
          (0, s.default)(o, [
            {
              key: "componentDidMount",
              value: function () {
                var e = this;
                O.default.addChangeListener(this._listener),
                  $.url().param("donation") &&
                    (this._changePanel("confirm"),
                    this.props.openDialog({
                      closeCallback: function () {
                        return e._changePanel("form");
                      },
                    }),
                    j.default.replace("/", {}));
              },
            },
            {
              key: "componentWillUnmount",
              value: function () {
                O.default.removeChangeListener(this._listener);
              },
            },
            {
              key: "_listener",
              value: function () {
                this.forceUpdate();
              },
            },
            {
              key: "_changePanel",
              value: function (e) {
                var t =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {};
                this.setState({ currentPanelName: e }),
                  (this._currenOptions = t);
              },
            },
            {
              key: "_updateForm",
              value: function (e, t) {
                var a = this.state.donateForm;
                this.setState({ donateForm: a.set(e, t) });
              },
            },
            {
              key: "_getPanelProps",
              value: function () {
                return {
                  changePanel: this._changePanel,
                  donateForm: this.state.donateForm,
                  updateForm: this._updateForm,
                  closeDialog: this.props.closeDialog,
                };
              },
            },
            {
              key: "_renderCurrentPanel",
              value: function () {
                var e = this.state.currentPanelName,
                  t = (0, k.default)(
                    this._getPanelProps(),
                    this._currenOptions,
                    O.default.getData()
                  );
                switch (e) {
                  case "form":
                    return x.default.createElement(A.default, t);
                  case "paymentQR":
                    return x.default.createElement(M.default, t);
                  case "confirm":
                    return x.default.createElement(E.default, t);
                  default:
                    return x.default.createElement(A.default, t);
                }
              },
            },
            {
              key: "render",
              value: function () {
                return (0, i.default)(
                  "div",
                  { className: "s-component s-donate-panel s-ecommerce-buy" },
                  void 0,
                  this._renderCurrentPanel()
                );
              },
            },
          ]),
          o
        );
      })(x.default.Component);
      (t.default = U), (e.exports = t.default);
    },
    342004: function (e, t, a) {
      var n = a(353147),
        l = a(501068),
        o = a(663978),
        u = a(60530)(a(60530));
      o(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i,
        r = a(812077),
        d = (0, u.default)(r),
        f = a(726394),
        s = (0, u.default)(f),
        c = a(569198),
        m = (0, u.default)(c),
        p = a(351379),
        v = (0, u.default)(p),
        g = a(900214),
        h = (0, u.default)(g),
        y = a(566380),
        _ = (0, u.default)(y),
        b = a(981643),
        P = (0, u.default)(b),
        N = a(366757),
        k = (0, u.default)(N),
        C = a(179361),
        x = (0, u.default)(C);
      var w = (function (e) {
        (0, v.default)(u, e);
        var t,
          a,
          o =
            ((t = u),
            (a = (function () {
              if ("undefined" == typeof Reflect || !l) return !1;
              if (l.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    l(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                n = (0, _.default)(t);
              if (a) {
                var o = (0, _.default)(this).constructor;
                e = l(n, arguments, o);
              } else e = n.apply(this, arguments);
              return (0, h.default)(this, e);
            });
        function u(e) {
          return (0, s.default)(this, u), o.call(this, e);
        }
        return (
          (0, m.default)(u, [
            {
              key: "render",
              value: function () {
                var e,
                  t =
                    -1 !==
                    (0, P.default)(
                      (e = this.props.donateForm.get("paymentMethod"))
                    ).call(e, "alipay"),
                  a =
                    (n(t ? "Ecommerce|Alipay" : "Ecommerce|WeChat"),
                    t ? "#00a9f2" : "#00ca00");
                return (0, d.default)(
                  "div",
                  { className: "buy-panel payment-panel" },
                  void 0,
                  (0, d.default)(
                    "div",
                    { className: "title" },
                    void 0,
                    (0, d.default)(
                      "span",
                      { style: { display: "inline-block" } },
                      void 0,
                      n("Donation|Payment")
                    )
                  ),
                  (0, d.default)(
                    "div",
                    { className: "qr-image", style: { textAlign: "center" } },
                    void 0,
                    i ||
                      (i = (0, d.default)(x.default, { value: "", size: 200 }))
                  ),
                  (0, d.default)(
                    "div",
                    {
                      className: "additional",
                      style: {
                        width: "100%",
                        textAlign: "center",
                        paddingTop: "20px",
                        margin: "0 auto",
                        display: "table",
                      },
                    },
                    void 0,
                    (0, d.default)(
                      "span",
                      {
                        style: {
                          padding: "0 2px",
                          color: a,
                          border: "solid 1px ".concat(a),
                          borderRadius: "1px",
                          fontWeight: "300",
                        },
                      },
                      void 0,
                      n(
                        t
                          ? "Ecommerce|Payment secured by Alipay"
                          : "Ecommerce|Payment secured by WeChat"
                      )
                    ),
                    (0, d.default)(
                      "p",
                      {
                        style: {
                          color: "#52616a",
                          fontWeight: "300",
                          padding: "37px 0 10px 0",
                        },
                      },
                      void 0,
                      n(
                        t
                          ? "Ecommerce|Please use the scan function in Alipay"
                          : "Ecommerce|Please use the scan Function in WeChat: [Discovery]-[Scan]"
                      )
                    )
                  )
                );
              },
            },
          ]),
          u
        );
      })(k.default.Component);
      (t.default = w), (e.exports = t.default);
    },
    707394: function (e, t, a) {
      var n = a(223765),
        l = a(501068),
        o = a(752424),
        u = a(663978),
        i = a(834074),
        r = a(60530)(a(60530));
      u(t, "__esModule", { value: !0 }), (t.default = void 0);
      var d = a(205872),
        f = (0, r.default)(d),
        s = a(812077),
        c = (0, r.default)(s),
        m = a(726394),
        p = (0, r.default)(m),
        v = a(569198),
        g = (0, r.default)(v),
        h = a(705824),
        y = (0, r.default)(h),
        _ = a(351379),
        b = (0, r.default)(_),
        P = a(900214),
        N = (0, r.default)(P),
        k = a(566380),
        C = (0, r.default)(k),
        x = a(487672),
        w = (0, r.default)(x),
        D = a(977766),
        S = (0, r.default)(D),
        A = a(678580),
        B = (0, r.default)(A),
        M = a(2991),
        F = (0, r.default)(M),
        E = a(54103),
        I = (0, r.default)(E),
        O = a(366757),
        T = (0, r.default)(O),
        j = a(45697),
        U = ((0, r.default)(j), a(345129)),
        R = (0, r.default)(U),
        W = a(469155),
        z = (0, r.default)(W),
        L = a(183123),
        q = (0, r.default)(L),
        H = a(234584),
        V = (0, r.default)(H),
        J = a(818166),
        Y = (0, r.default)(J),
        Z = a(223930),
        $ =
          ((0, r.default)(Z),
          (function (e, t) {
            if (e && e.__esModule) return e;
            if (null === e || ("object" !== n(e) && "function" != typeof e))
              return { default: e };
            var a = te(t);
            if (a && a.has(e)) return a.get(e);
            var l = {},
              o = u && i;
            for (var r in e)
              if (
                "default" !== r &&
                Object.prototype.hasOwnProperty.call(e, r)
              ) {
                var d = o ? i(e, r) : null;
                d && (d.get || d.set) ? u(l, r, d) : (l[r] = e[r]);
              }
            return (l.default = e), a && a.set(e, l), l;
          })(a(143268))),
        G = a(294184),
        K = (0, r.default)(G),
        Q = a(141655),
        X = (0, r.default)(Q),
        ee = a(805803);
      function te(e) {
        if ("function" != typeof o) return null;
        var t = new o(),
          a = new o();
        return (te = function (e) {
          return e ? a : t;
        })(e);
      }
      var ae = (function (e) {
        (0, b.default)(o, e);
        var t,
          a,
          n =
            ((t = o),
            (a = (function () {
              if ("undefined" == typeof Reflect || !l) return !1;
              if (l.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    l(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                n = (0, C.default)(t);
              if (a) {
                var o = (0, C.default)(this).constructor;
                e = l(n, arguments, o);
              } else e = n.apply(this, arguments);
              return (0, N.default)(this, e);
            });
        function o() {
          var e, t;
          (0, p.default)(this, o);
          for (var a = arguments.length, l = new Array(a), u = 0; u < a; u++)
            l[u] = arguments[u];
          return (
            (t = n.call.apply(n, (0, S.default)((e = [this])).call(e, l))),
            (0, w.default)(
              (0, y.default)(t),
              "_onClickActionItemAt",
              function (e, a, n) {
                var l = q.default.getFromSiteToApp(),
                  o = t.props.mode,
                  u = t.state.activeIndex;
                return (
                  "preview" === o && n.preventDefault(),
                  "introduction" !== o &&
                    (!l &&
                      "ecommerce" === a &&
                      Y.default.getAllSectionsWithName("ecommerce").length >=
                        2 &&
                      R.default.openCategoryDrawer(),
                    !l &&
                      "blog" === a &&
                      Y.default.getAllSectionsWithName("blog").length >= 2 &&
                      z.default.toggleCategoryDrawer("blog"),
                    u !== e && void t.forceUpdateState({ activeIndex: e }))
                );
              }
            ),
            (0, w.default)(
              (0, y.default)(t),
              "_getStyleClass",
              function (e, t, a) {
                return 1 === e
                  ? "s-show-mobile-actions-item s-mobile-actions-one-item ".concat(
                      ""
                    )
                  : t === a
                  ? "s-show-mobile-actions-item selected ".concat("")
                  : "s-show-mobile-actions-item ".concat("");
              }
            ),
            (0, w.default)(
              (0, y.default)(t),
              "_onClickEditMobileActions",
              function () {
                X.default.openPageSettings({ tabName: "mobile-actions" });
              }
            ),
            (0, w.default)((0, y.default)(t), "getTargetName", function (e, t) {
              return "location" === e || "url" === e
                ? "_blank"
                : self.location == top.location || t
                ? ""
                : "_parent";
            }),
            t
          );
        }
        return (
          (0, g.default)(o, [
            {
              key: "componentWillMount",
              value: function () {
                var e = this.props.activeIndex;
                this._updateActiveIndex(e);
              },
            },
            {
              key: "componentWillReceiveProps",
              value: function (e) {
                var t = this.props.activeIndex;
                e.activeIndex !== t && this._updateActiveIndex(e.activeIndex);
              },
            },
            {
              key: "_updateActiveIndex",
              value: function (e) {
                this.forceUpdateState({ activeIndex: e });
              },
            },
            {
              key: "forceUpdateState",
              value: function (e) {
                this.setState(e), this.forceUpdate();
              },
            },
            {
              key: "_getActionTarget",
              value: function (e, t) {
                var a = null;
                switch (e) {
                  case "phone":
                    a = "tel:".concat(t);
                    break;
                  case "email":
                    a = "mailto:".concat(t);
                    break;
                  case "location":
                    a = q.default.getIsSxl()
                      ? "http://m.amap.com/search/view/keywords=".concat(t)
                      : "https://maps.google.com/maps?q=".concat(t);
                    break;
                  case "url":
                    a = $.addProtocol(t);
                    break;
                  case "home":
                    ("show" !== V.default.getSiteMode() &&
                      "preview" !== V.default.getSiteMode()) ||
                      (a = Y.default.getPathBySection(e));
                    break;
                  case "blog":
                    q.default.getFromSiteToApp()
                      ? (a = "/blog/page")
                      : ("show" !== V.default.getSiteMode() &&
                          "preview" !== V.default.getSiteMode()) ||
                        (Y.default.hasSection("blog") &&
                          (a = Y.default.getPathBySection(e)));
                    break;
                  case "ecommerce":
                    q.default.getFromSiteToApp()
                      ? (a = "/store/page")
                      : ("show" !== V.default.getSiteMode() &&
                          "preview" !== V.default.getSiteMode()) ||
                        (Y.default.getAllSectionsWithName("ecommerce").length <=
                          1 &&
                          (a = Y.default.getPathBySection(e)));
                    break;
                  default:
                    a = t;
                }
                return a;
              },
            },
            {
              key: "_isPageSelected",
              value: function (e, t) {
                var a;
                return (
                  !!q.default.getFromSiteToApp() &&
                  (!(
                    "ecommerce" !== e ||
                    !(0, B.default)(
                      (a = ["productPage", "itemPage", "storePage"])
                    ).call(a, t)
                  ) ||
                    ("blog" === e && "blogPage" === t) ||
                    ("home" === e &&
                      "sitePage" === t &&
                      Y.default.isHomePage(Y.default.getCurrentPageUID())))
                );
              },
            },
            {
              key: "render",
              value: function () {
                var e = this,
                  t = this,
                  a = t.props,
                  n = a.actions,
                  l = a.activePage,
                  o = n.size;
                return (0, c.default)(
                  "ul",
                  { className: "s-mobile-actions clearfix s-font-body" },
                  void 0,
                  (0, F.default)(n).call(n, function (a, u) {
                    var i,
                      r,
                      d = a.get("type"),
                      s = t._getActionTarget(d, a.get("target")),
                      m =
                        !$S.conf.isBlog &&
                        (0, B.default)(
                          (i = ["home", "ecommerce", "blog"])
                        ).call(i, d),
                      p = e.getTargetName(d, m),
                      v = {
                        width: "".concat(100 / n.count(), "%"),
                        display: "block",
                      },
                      g = e._isPageSelected(d, l),
                      h = {
                        key: "link-key-".concat(u),
                        className: (0, K.default)(
                          "s-mobile-actions-item padding-adapting",
                          {
                            "less-than-three": o < 3,
                            "one-item": 1 === o,
                            selected: g,
                          }
                        ),
                        onClick: (0, I.default)(
                          (r = e._onClickActionItemAt)
                        ).call(r, null, u, d),
                        style: v,
                      },
                      y = T.default.createElement(
                        T.default.Fragment,
                        null,
                        (0, c.default)(
                          "div",
                          { className: "s-mobile-actions-item-icon" },
                          void 0,
                          (0, c.default)("i", { className: a.get("icon") })
                        ),
                        (0, c.default)(
                          "div",
                          { className: "s-mobile-actions-item-text" },
                          void 0,
                          a.get("name")
                        )
                      );
                    return d
                      ? s
                        ? m
                          ? T.default.createElement(
                              ee.Link,
                              (0, f.default)({}, h, {
                                href: s,
                                target: p,
                                to: s,
                              }),
                              y
                            )
                          : T.default.createElement(
                              "a",
                              (0, f.default)({}, h, { href: s, target: p }),
                              y
                            )
                        : T.default.createElement("div", h, y)
                      : null;
                  }),
                  null
                );
              },
            },
          ]),
          o
        );
      })(T.default.Component);
      (0, w.default)(ae, "defaultProps", {
        onClickMobileActionsItem: function () {},
      }),
        (t.default = ae),
        (e.exports = t.default);
    },
  },
]);
