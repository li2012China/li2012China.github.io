/*! For license information please see 9261.425e0e93cf9fe1fe4cba-site-bundle.js.LICENSE.txt */
"use strict";
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [9261],
  {
    500134: function (t, e, n) {
      n.r(e),
        n.d(e, {
          Input: function () {
            return o.Z;
          },
          Tooltip: function () {
            return r.Z;
          },
          Tag: function () {
            return u.Z;
          },
          FormLabel: function () {
            return i.Z;
          },
          Icon: function () {
            return l.Z;
          },
          NewDatePicker: function () {
            return a.Z;
          },
          Card: function () {
            return c.Z;
          },
          Radio: function () {
            return f.ZP;
          },
          Modal: function () {
            return s.Z;
          },
          Button: function () {
            return d.Z;
          },
          BigSelect: function () {
            return g.Z;
          },
          Checkbox: function () {
            return p.Z;
          },
          Collapse: function () {
            return m.Z;
          },
          Form: function () {
            return h.Z;
          },
          Alert: function () {
            return v.Z;
          },
          Slider: function () {
            return b.Z;
          },
          Table: function () {
            return C.Z;
          },
          Select: function () {
            return S.Z;
          },
          Popover: function () {
            return T.Z;
          },
          Badge: function () {
            return N.Z;
          },
          Rate: function () {
            return k.Z;
          },
        });
      var o = n(990369),
        r = n(384788),
        u = n(551751),
        i = n(2441),
        l = n(601765),
        a = n(967217),
        c = n(225152),
        f = n(569670),
        s = n(685231),
        d = n(171725),
        g = n(991718),
        p = n(622587),
        m = n(350491),
        h = n(198545),
        v = n(107463),
        b = n(31130),
        C = n(458103),
        S = n(685186),
        T = n(665172),
        N = n(138479),
        k = n(454647);
    },
    880022: function (t, e, n) {
      n.d(e, {
        um: function () {
          return s;
        },
        FZ: function () {
          return d;
        },
        hn: function () {
          return g;
        },
        Bj: function () {
          return p;
        },
        Ye: function () {
          return m;
        },
      });
      var o = n(62462),
        r = n.n(o),
        u = n(442279),
        i = n(818166),
        l = n(621460),
        a = n(792656),
        c = n(217136),
        f = n(183123),
        s = function (t) {
          return f.getIsBlog() ? t.get("pageMeta") : t.get("pageData");
        },
        d = (0, u.createSelector)(s, function (t) {
          return i.getCurrentPageBinding().get();
        });
      function g(t, e) {
        var n = t.getIn(["sections", e]),
          o = n.getIn(["components", "background1"]),
          r = n.get("template_name");
        return l(r) ? a.getNavTextColor(o) : "dark";
      }
      var p = (0, u.createSelector)(d, function (t) {
          var e = t.get("sections");
          return 0 == e.size
            ? -1
            : r()(e).call(e, function (t) {
                return !(0, c.isSectionHidden)(t);
              });
        }),
        m = (0, u.createSelector)(d, p, function (t, e) {
          if (-1 === e) return !1;
          var n = t.getIn(["sections", e]),
            o = n.getIn(["components", "background1"]);
          if (!o) return !1;
          var r = n.get("template_name");
          if (!l(r)) return !1;
          var u = o.get("url");
          return Boolean(u);
        });
      (0, u.createSelector)(s, function (t) {
        return t.getIn(["footer", "components", "socialMedia"]);
      });
    },
    104802: function (t, e, n) {
      n.r(e),
        n.d(e, {
          getSectionContentWidth: function () {
            return z;
          },
          getNavObject: function () {
            return _;
          },
          getNavTheme: function () {
            return v;
          },
          getNavThemeDesignProps: function () {
            return j;
          },
          getButtonBackgroundColor: function () {
            return E;
          },
          getNavBackgroundColor1: function () {
            return b;
          },
          getUsedNavBackgroundColor1: function () {
            return D;
          },
          getS5Theme: function () {
            return h;
          },
          getNavOverlapsContent: function () {
            return F;
          },
          getButtonShape: function () {
            return B;
          },
          getButtonFill: function () {
            return I;
          },
          getFixedNavBackgroundColor: function () {
            return R;
          },
          getNavIsTransparent: function () {
            return M;
          },
          getNavIsSticky: function () {
            return x;
          },
          getFontSizes: function () {
            return W;
          },
          getTextColors: function () {
            return K;
          },
          getTextHighlightColor: function () {
            return y;
          },
          getRawNavHighlightColor: function () {
            return C;
          },
          getNavHighlightColor: function () {
            return T;
          },
          getNavHighlightObj: function () {
            return Y;
          },
          getNavBorderColor: function () {
            return N;
          },
          getItemColor: function () {
            return k;
          },
          getShowNavSocialMedia: function () {
            return w;
          },
          getNavSocialMedia: function () {
            return L;
          },
          getNavSocialMediaButtonList: function () {
            return P;
          },
          getNavSocialMediaListType: function () {
            return O;
          },
          getNavSocialMediaContactList: function () {
            return A;
          },
          getShowNavSocialMediaIcon: function () {
            return U;
          },
        });
      var o = n(620116),
        r = n.n(o),
        u = n(51942),
        i = n.n(u),
        l = n(183123),
        a = n(442279),
        c = n(880022),
        f = n(727505),
        s = n(926941),
        d = n(143393),
        g = n(350723),
        p = { color: "textColor", block: "blockTextColor" },
        m = l.getIsNewNavLayout(),
        h = function (t) {
          return (0, c.um)(t).get("s5Theme");
        },
        v = function (t) {
          return h(t).get("nav");
        },
        b = function (t) {
          return v(t).get("backgroundColor1") || "#fff";
        },
        C = function (t) {
          return v(t).get("highlightColor");
        },
        S = function (t) {
          return (0, c.um)(t).get("customColors");
        },
        T = function (t) {
          var e = C(t) || (S(t) && S(t).get("highlight1")) || "#57bcdb";
          if (l.getNewNavHeaderDesign()) {
            var n = Y(t);
            return "underline" === n.type ? e : n[p[n.type]] || e;
          }
          return e;
        },
        N = function (t) {
          return v(t).getIn(["border", "borderColor"]);
        },
        k = function (t) {
          var e = b(t),
            n = "rgba(0,0,0,0.8)";
          return (
            e && (n = new s(e).luma() > 0.7 ? "rgba(0,0,0,0.8)" : "#fff"),
            (function (t) {
              return v(t).get("itemColor");
            })(t) || n
          );
        },
        E = function (t) {
          return h(t).getIn(["button", "backgroundColor"]);
        },
        y = function (t) {
          return h(t).getIn(["section", "textHighlightColor"]);
        },
        _ = (0, a.createSelector)(
          function (t) {
            return v(t).get("layout");
          },
          function (t) {
            return v(t).get("name");
          },
          function (t, e) {
            return m ? (0, f.getNavByLayout)(t) : (0, f.getNavByName)(e);
          }
        ),
        B = function (t) {
          return h(t).getIn(["button", "shape"]);
        },
        I = function (t) {
          return h(t).getIn(["button", "fill"]);
        },
        M = function (t) {
          return (
            _(t).supportsSettingKey("isTransparent") &&
            v(t).get("isTransparent")
          );
        },
        x = function (t) {
          return _(t).supportsSettingKey("isSticky") && v(t).get("isSticky");
        },
        w = function (t) {
          return v(t).get("showSocialMedia");
        },
        L = function (t) {
          return v(t).get("socialMedia").toJS();
        },
        P = function (t) {
          return v(t).get("socialMediaButtonList");
        },
        O = function (t) {
          return v(t).get("socialMediaListType");
        },
        A = function (t) {
          return v(t).get("socialMediaContactList");
        },
        U = function (t) {
          var e = L(t);
          return r()(e).call(e, function (t) {
            return t.show_button;
          });
        },
        z = (0, a.createSelector)(h, function (t) {
          var e = t.getIn(["section", "contentWidth"]);
          return {
            normal: {
              full: (0, g.isProductDetailPageInLiveSite)() ? "1200px" : "94%",
              wide: "1200px",
              normal: "1000px",
              narrow: "800px",
            }[e],
            slider: {
              full: "88%",
              wide: "1200px",
              normal: "1000px",
              narrow: "800px",
            }[e],
          };
        }),
        D = function (t) {
          return v(t), M(t) ? "rgba(0, 0, 0, 0)" : b(t);
        },
        Z = (0, a.createSelector)(T, function (t) {
          return new s(t).luma() > 0.7 ? "rgba(0,0,0,0.8)" : "#fff";
        }),
        F = (0, a.createSelector)(
          function (t) {
            return _(t).orientation;
          },
          D,
          function (t, e) {
            var n = new s(e);
            return "horizontal" === t && n.a < 1;
          }
        ),
        R = (0, a.createSelector)(D, function (t) {
          var e = new s(t);
          return e.a > 0.75
            ? t
            : e.a > 0.3
            ? ((e.a = 0.75), e.toRgba())
            : "#ffffff";
        }),
        H = (0, a.createSelector)(M, _, T, b, function (t, e, n, o) {
          return t
            ? "#ffffff"
            : e.getDropdownBackgroundColor
            ? e.getDropdownBackgroundColor(o, n)
            : o;
        }),
        V = (0, a.createSelector)(H, function (t) {
          var e = new s(t);
          return e.luma() > 0.7 ? e.mult(0.95).toHex() : e.lighten(0.2).toHex();
        }),
        j = (0, a.createSelector)(
          v,
          _,
          M,
          D,
          T,
          Z,
          F,
          R,
          I,
          V,
          function (t, e, n, o, r, u, l, a, c, f) {
            var s,
              d = {
                normal: { small: 10, medium: 20, large: 30, extra: 45 },
                large: { small: 20, medium: 40, large: 60, extra: 90 },
              };
            switch (e.name) {
              case "topCenter":
                s = d.large[t.get("padding")] / 2;
                break;
              case "left":
                s = d.large[t.get("padding")];
                break;
              default:
                s = d.normal[t.get("padding")];
            }
            var g = { small: 85, medium: 100, large: 117 }[t.get("fontSize")],
              p = "".concat(g, "%");
            return (
              (t = t.toJS()),
              i()({}, t, {
                padding: s,
                fontSize: p,
                fontSizePercentage: g,
                navObject: e,
                isTransparent: n,
                backgroundColor1: o,
                navHighlightColor: r,
                overlapsContent: l,
                navHighlightTextColor: u,
                fixedNavBackgroundColor: a,
                navTheme: t,
                buttonFill: c,
                dropdownItemHighlightColor: f,
              })
            );
          }
        ),
        G = function (t) {
          return h(t).get("section");
        },
        W = (0, a.createSelector)(G, function (t) {
          return {
            baseFontSize: t.get("baseFontSize") || 15,
            titleFontSize: t.get("titleFontSize") || 36,
            subtitleFontSize: t.get("subtitleFontSize") || 18,
            itemTitleFontSize: t.get("itemTitleFontSize") || 18,
            itemSubtitleFontSize: t.get("itemSubtitleFontSize") || 18,
          };
        }),
        K = (0, a.createSelector)(G, function (t) {
          return {
            baseColor: t.get("baseColor"),
            titleColor: t.get("titleColor"),
            subtitleColor: t.get("subtitleColor"),
            itemTitleColor: t.get("itemTitleColor"),
            itemSubtitleColor: t.get("itemSubtitleColor"),
          };
        }),
        Y = (0, a.createSelector)(
          function (t) {
            return v(t).get("highlight") || d.fromJS({});
          },
          function (t) {
            var e;
            return (
              (null === (e = S(t)) || void 0 === e
                ? void 0
                : e.get("highlight1")) || "#fff"
            );
          },
          function (t, e) {
            return i()(t.toObject(), {
              textColor: t.get("textColor") || e,
              blockTextColor: t.get("blockTextColor") || e,
              blockBackgroundColor:
                t.get("blockBackgroundColor") || new s(e).tint(80),
            });
          }
        );
    },
    832313: function (t, e, n) {
      n.r(e),
        n.d(e, {
          LINK_TYPE: function () {
            return r;
          },
          LINK_OPTIONS: function () {
            return u;
          },
          BUTTON_SIZE_VALUE: function () {
            return i;
          },
          BUTTON_CONFIG: function () {
            return l;
          },
          CUSTOM_BUTTON_TAB: function () {
            return a;
          },
          CONTENT_ALIGNMENT_SECTION_NAMES: function () {
            return c;
          },
        });
      var o = n(353147),
        r = {
          SECTION: "Section",
          DOCUMENT: "Document",
          REGISTRATION: "registration",
          EMAIL: "Email",
          WEB: "Web",
        },
        u = [
          {
            name: function () {
              return o("Web");
            },
            value: r.WEB,
            defaultValue: "http://yourwebsite.com",
            tips: function () {
              return o(
                "Enter full URL (http://yourwebsite.com) to link to another website."
              );
            },
            product: ["strikingly", "sxl"],
          },
          {
            name: function () {
              return o("Email");
            },
            value: r.EMAIL,
            defaultValue: "mailto:youremail@gmail.com",
            tips: function () {
              return o(
                'Enter "mailto:youremail@gmail.com" to link to your email.'
              );
            },
            product: ["strikingly", "sxl"],
          },
          {
            name: function () {
              return o("Section");
            },
            value: r.SECTION,
            defaultValue: "#2",
            tips: function () {
              return o(
                'Enter "#2" to link to the second section on this page.'
              );
            },
            product: ["strikingly", "sxl"],
          },
          {
            name: function () {
              return o("Document");
            },
            value: r.DOCUMENT,
            defaultValue: "",
            tips: function () {
              return o("Upload a doc for viewers to download.");
            },
            product: ["strikingly"],
          },
          {
            name: function () {
              return o("Membership|Member registration");
            },
            value: r.REGISTRATION,
            defaultValue: "",
            tips: function () {
              return o(
                "Membership|This button will open the Log In & Registration screen for this site's members. (If already logged in, this button will go to the default member's page.)"
              );
            },
            product: ["strikingly", "sxl"],
          },
        ],
        i = {
          SMALL: "small",
          MEDIUM: "medium",
          LARGE: "large",
          FULL: "full",
          AUTOMATIC: "automatic",
        },
        l = {
          size: [
            {
              name: function () {
                return o("Editor|Large");
              },
              value: i.LARGE,
            },
            {
              name: function () {
                return o("Editor|Medium");
              },
              value: i.MEDIUM,
            },
            {
              name: function () {
                return o("Editor|Small");
              },
              value: i.SMALL,
            },
            {
              name: function () {
                return o("Editor|Full width");
              },
              value: i.FULL,
            },
          ],
          mobile_size: [
            {
              name: function () {
                return o("Editor|Large");
              },
              value: i.LARGE,
            },
            {
              name: function () {
                return o("Editor|Medium");
              },
              value: i.MEDIUM,
            },
            {
              name: function () {
                return o("Editor|Small");
              },
              value: i.SMALL,
            },
            {
              name: function () {
                return o("Automatic");
              },
              value: i.AUTOMATIC,
            },
          ],
          alignment: [
            {
              name: function () {
                return o("Editor|Left");
              },
              value: "flex-start",
            },
            {
              name: function () {
                return o("Editor|Center");
              },
              value: "center",
            },
            {
              name: function () {
                return o("Editor|Right");
              },
              value: "flex-end",
            },
            {
              name: function () {
                return o("Editor|Auto");
              },
              value: "inherit",
            },
          ],
          style: [
            {
              name: function () {
                return o("Editor|Solid");
              },
              value: "solid",
            },
            {
              name: function () {
                return o("Editor|Ghost");
              },
              value: "ghost",
            },
          ],
        },
        a = { CONTENT: "content", DESIGN: "design" },
        c = ["hero", "cta"];
    },
    628568: function (t, e, n) {
      n.r(e),
        n.d(e, {
          getAlignmentForStyle: function () {
            return l;
          },
          getSectionAlignmentForStyle: function () {
            return a;
          },
        });
      var o = n(678580),
        r = n.n(o),
        u = n(183123),
        i = n(832313),
        l = function (t) {
          switch (t) {
            case "left":
              return "flex-start";
            case "right":
              return "flex-end";
            default:
              return "center";
          }
        };
      function a(t) {
        var e,
          n,
          o,
          a,
          c,
          f,
          s,
          d,
          g,
          p,
          m = "center";
        return (
          t &&
            r()(i.CONTENT_ALIGNMENT_SECTION_NAMES).call(
              i.CONTENT_ALIGNMENT_SECTION_NAMES,
              t
            ) &&
            (m = u.getIsBlog()
              ? (null === (e = $S) ||
                void 0 === e ||
                null === (n = e.blogPostData) ||
                void 0 === n ||
                null === (o = n.pageData) ||
                void 0 === o ||
                null === (a = o.s5Theme) ||
                void 0 === a ||
                null === (c = a.section) ||
                void 0 === c
                  ? void 0
                  : c.contentAlignment) || "center"
              : (null === (f = $S) ||
                void 0 === f ||
                null === (s = f.stores) ||
                void 0 === s ||
                null === (d = s.pageData) ||
                void 0 === d ||
                null === (g = d.s5Theme) ||
                void 0 === g ||
                null === (p = g.section) ||
                void 0 === p
                  ? void 0
                  : p.contentAlignment) || "center"),
          l(m)
        );
      }
    },
    365940: function (t, e, n) {
      var o = n(223765),
        r = (n(686902), n(14310), n(620116), n(834074)),
        u = (n(778914), n(239649), n(820368), n(663978)),
        i = n(752424),
        l = n(60530)(n(60530));
      u(e, "__esModule", { value: !0 });
      var a = n(487672),
        c = ((0, l.default)(a), n(51942)),
        f = (0, l.default)(c),
        s =
          ((function (t, e) {
            if (t && t.__esModule) return t;
            if (null === t || ("object" !== o(t) && "function" != typeof t))
              return { default: t };
            var n = b(e);
            if (n && n.has(t)) return n.get(t);
            var i = {},
              l = u && r;
            for (var a in t)
              if (
                "default" !== a &&
                Object.prototype.hasOwnProperty.call(t, a)
              ) {
                var c = l ? r(t, a) : null;
                c && (c.get || c.set) ? u(i, a, c) : (i[a] = t[a]);
              }
            (i.default = t), n && n.set(t, i);
          })(n(366757)),
          n(62431)),
        d = n(108679),
        g = (0, l.default)(d),
        p = n(454992),
        m = (0, l.default)(p),
        h = n(660422),
        v = (0, l.default)(h);
      function b(t) {
        if ("function" != typeof i) return null;
        var e = new i(),
          n = new i();
        return (b = function (t) {
          return t ? n : e;
        })(t);
      }
      v.default.sharedProps = (0, s.sharedPropsBuilder)(
        function () {
          return [];
        },
        function () {
          return (0, f.default)({}, {});
        },
        function () {
          return {};
        }
      );
      var C = v.default,
        S = (0, m.default)(C),
        T = (0, g.default)(S, C);
      (e.default = T), (t.exports = e.default);
    },
    454992: function (t, e, n) {
      var o = n(663978),
        r = n(60530)(n(60530));
      o(e, "__esModule", { value: !0 });
      var u = n(812077),
        i = (0, r.default)(u);
      e.default = function (t) {
        return function (e) {
          return "s5-theme" === f.default.getThemeName()
            ? (0, i.default)(
                h,
                { themeSiteState: e.themeSiteState },
                void 0,
                a.default.createElement(t, e)
              )
            : a.default.createElement(t, e);
        };
      };
      var l = n(366757),
        a = (0, r.default)(l),
        c = n(234584),
        f = (0, r.default)(c),
        s = n(387937),
        d = (0, r.default)(s),
        g = n(851172),
        p = n(595386),
        m = (0, (0, r.default)(p).default)("div", { target: "css-1jb95gw0" })(
          "&{.s-common-button{border-radius:",
          function (t) {
            return t.borderRadius;
          },
          "px;border:",
          function (t) {
            return t.border;
          },
          ";background:",
          function (t) {
            return t.backgroundColor;
          },
          ";color:",
          function (t) {
            return t.textColor;
          },
          ";transition:all 0.15s;&:hover{opacity:",
          function (t) {
            return t.hoverOpacity;
          },
          ";background:",
          function (t) {
            return t.hoverBackgroundColor;
          },
          ";}}.s-section.s-bg-light-text & .s-common-button.ghost{color:#fff;}.s-section.s-bg-dark-text & .s-common-button.ghost{color:#222;}}"
        ),
        h = function (t) {
          var e = t.buttonThemeProps,
            n = t.children;
          return a.default.createElement(m, e, n);
        };
      (h = (0, d.default)(h, function (t, e) {
        var n = e.themeSiteState || t;
        return { buttonThemeProps: (0, g.getButtonThemeProps)(n) };
      })),
        (t.exports = e.default);
    },
    315321: function (t, e, n) {
      n(663978)(e, "__esModule", { value: !0 }),
        (e.default = {
          url: function (t, e, n) {},
          html: function (t, e, n) {},
        }),
        (t.exports = e.default);
    },
    621460: function (t, e, n) {
      n(663978)(e, "__esModule", { value: !0 }),
        (e.default = function (t) {
          return {
            blog: !0,
            block: !0,
            slider: !0,
            html: !0,
            social_feed: !1,
            portfolio: !1,
            donation: !1,
            title: !0,
            cta: !0,
            hero: !0,
            rows: !1,
            media: !1,
            gallery: !1,
            icons: !1,
            info: !0,
            process: !1,
            columns: !1,
            text: !0,
            ecommerce: !1,
            grid: !1,
            signup_form: !0,
            contact_form: !0,
          }[t];
        }),
        (t.exports = e.default);
    },
    660422: function (t, e, n) {
      var o = n(353147),
        r = n(223765),
        u = n(752424),
        i = n(663978),
        l = n(834074),
        a = n(60530)(n(60530));
      i(e, "__esModule", { value: !0 });
      var c = n(205872),
        f = ((0, a.default)(c), n(359036)),
        s = ((0, a.default)(f), n(812077)),
        d = (0, a.default)(s),
        g = n(487672);
      (0, a.default)(g), n(974916), n(115306);
      var p = n(620116),
        m = (0, a.default)(p),
        h = n(981643),
        v = (0, a.default)(h),
        b = n(977766),
        C = (0, a.default)(b),
        S = n(678580),
        T = (0, a.default)(S),
        N = n(694473),
        k = (0, a.default)(N),
        E = n(344494),
        y = (0, a.default)(E),
        _ = n(54103),
        B = ((0, a.default)(_), n(366757)),
        I = (0, a.default)(B),
        M = n(50533),
        x = n(176965),
        w = ((0, a.default)(x), n(45697)),
        L = (0, a.default)(w),
        P = n(692381),
        O = (0, a.default)(P),
        A = n(294184),
        U = (0, a.default)(A),
        z = n(496486),
        D = (0, a.default)(z),
        Z = n(183123),
        F = (0, a.default)(Z),
        R = n(916784),
        H = (0, a.default)(R),
        V = n(817449),
        j = (0, a.default)(V),
        G = n(461853),
        W = (0, a.default)(G),
        K = n(315321),
        Y = (0, a.default)(K),
        $ = n(399069),
        J = (0, a.default)($),
        q = (function (t, e) {
          if (t && t.__esModule) return t;
          if (null === t || ("object" !== r(t) && "function" != typeof t))
            return { default: t };
          var n = at(e);
          if (n && n.has(t)) return n.get(t);
          var o = {},
            u = i && l;
          for (var a in t)
            if ("default" !== a && Object.prototype.hasOwnProperty.call(t, a)) {
              var c = u ? l(t, a) : null;
              c && (c.get || c.set) ? i(o, a, c) : (o[a] = t[a]);
            }
          return (o.default = t), n && n.set(t, o), o;
        })(n(143268)),
        Q = n(818166),
        X = (0, a.default)(Q),
        tt = n(234584),
        et = (0, a.default)(tt),
        nt = n(881701),
        ot = n(143393),
        rt = ((0, a.default)(ot), n(926941)),
        ut = (0, a.default)(rt),
        it = (n(500134), n(628568)),
        lt = n(832313);
      function at(t) {
        if ("function" != typeof u) return null;
        var e = new u(),
          n = new u();
        return (at = function (t) {
          return t ? n : e;
        })(t);
      }
      var ct = ["sleek", "ion"],
        ft = (0, m.default)(lt.LINK_OPTIONS).call(
          lt.LINK_OPTIONS,
          function (t) {
            return t.value !== lt.LINK_TYPE.DOCUMENT;
          }
        ),
        st = J.default.createPageComponent({
          displayName: "Button",
          mixins: [W.default.enableAfterOpen(), j.default],
          bobcatPropTypes: {
            shared: { onClickUpload: L.default.func },
            data: {
              id: L.default.string,
              text: L.default.string,
              url: Y.default.url,
              new_target: L.default.bool,
              className: L.default.string,
              needCeiling: L.default.bool,
              binding: L.default.shape({
                default: L.default.object.isRequired,
              }),
              size: L.default.string,
              mobile_size: L.default.string,
              style: L.default.string,
              alignment: L.default.string,
              color: L.default.string,
              font: L.default.string,
              isNavBtn: L.default.bool,
              inSectionSelector: L.default.bool,
            },
            designer: {
              emptyMessage: L.default.string,
              emptyTooltip: L.default.string,
              smallButton: L.default.bool,
              fullWidth: L.default.bool,
            },
            hasAddBtn: L.default.bool,
            onClickAdd: L.default.func,
            onClickRemove: L.default.func,
            onChangeParentButtonGroupLayoutConfig: L.default.func,
          },
          statics: {
            hasContent: function (t) {
              return (
                t && "string" != typeof t && (t = t.get("text")),
                !/^\s*$/.test(t)
              );
            },
          },
          getInitialState: function () {
            return {
              customBtnVisible: !1,
              draftButtonText: "",
              colorPickerVisible: !1,
              buttonCurrentTab: lt.CUSTOM_BUTTON_TAB.CONTENT,
            };
          },
          componentDidMount: function () {
            var t = this.dtProps,
              e = t.url,
              n = (t.isNavBtn, t.navLayout, t.size, t.inSectionSelector);
            /^#/.test(e) && !n && this.updateData({ new_target: !1 }),
              "function" == typeof this.props.onRef && this.props.onRef(this);
          },
          getBobcatDefaultProps: function () {
            return {
              data: {
                text: "Click Here",
                url: "",
                new_target: !0,
                needCeiling: !1,
                isNavBtn: !1,
                size: lt.BUTTON_SIZE_VALUE.SMALL,
                mobile_size: lt.BUTTON_SIZE_VALUE.AUTOMATIC,
                style: "",
                alignment: "",
                color: "",
                font: "Montserrat",
                link_type: lt.LINK_TYPE.WEB,
              },
            };
          },
          hasContent: function () {
            return st.hasContent(this.props.text);
          },
          _emptyMessage: function () {
            return this.props.emptyMessage || o("Editor|Add a button.");
          },
          _emptyTooltip: function () {
            return (
              this.props.emptyTooltip ||
              o("Editor|Empty space won't be shown in the published site")
            );
          },
          _changeUrl: function (t) {
            return null;
          },
          _onChangeUrl: function (t) {
            return null;
          },
          _onChangeText: function (t) {
            return null;
          },
          _fileUploaded: function (t) {
            return null;
          },
          _onClickUpload: function () {
            return null;
          },
          _onClickLinkToSection: function () {
            this.updateData({ new_target: !1 });
          },
          startEditContent: function () {
            return "function" == typeof this.props.setEditingChild
              ? this.props.setEditingChild()
              : void 0;
          },
          stopEditContent: function () {
            return "function" == typeof this.props.unsetEditingChild
              ? this.props.unsetEditingChild()
              : void 0;
          },
          _onAddButton: function () {
            return null;
          },
          onClickEditorCustomBtn: function (t) {},
          _onClickToggleTarget: function () {
            return null;
          },
          getSaveButtonProps: function () {
            return {};
          },
          _getSelectedButtonConfig: function () {
            var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "Web",
              e =
                arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              n = (0, k.default)(ft).call(ft, function (e) {
                return e.value === t;
              });
            return e ? n.tips() : n || {};
          },
          _onSelectedByKey: function (t, e) {
            e.target.value;
          },
          _onChangeColor: function (t) {
            var e = "default" === t ? "" : t;
            return this.updateData({ color: e });
          },
          reverseColor: function (t) {
            return new ut.default(t).luma() > 0.7 ? "rgba(0,0,0,0.8)" : "#fff";
          },
          canCloseCustomBtnPopover: function (t) {
            this.state.colorPickerVisible ||
              (this.getSaveButtonProps().onClickCancel(),
              t || this.updateState("normal"));
          },
          getStyleButtonColor: function (t) {
            var e,
              n,
              o,
              r =
                arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              u = r ? t.backgroundColor : t.get("backgroundColor"),
              i = r ? (0, y.default)(t) : t.get("fill"),
              l = this.dsProps,
              a = l.color,
              c = l.style,
              f = l.backgroundColor,
              s = void 0 === f ? null : f,
              d = l.storageKey,
              g = void 0 === d ? null : d,
              p = l.useImage,
              m = void 0 !== p && p,
              h = l.videoHtml,
              v = void 0 === h ? null : h,
              b = l.videoUrl,
              S = void 0 === b ? null : b,
              T = a || u || "#ffffff",
              N = this.reverseColor(T),
              k = "";
            a
              ? ("ghost" === i &&
                  (k = "\n          color: ".concat(a, ";\n        ")),
                "solid" === i &&
                  (k = (0, C.default)(
                    (e = "\n          color: ".concat(
                      N,
                      ";\n          background: "
                    ))
                  ).call(e, a, "\n        ")),
                "ghost" === c &&
                  (k = "\n          color: ".concat(
                    a,
                    ";\n          border: 2px solid;\n          background: transparent;\n        "
                  )),
                "solid" === c &&
                  (k = (0, C.default)(
                    (n = "\n          color: ".concat(
                      N,
                      ";\n          background: "
                    ))
                  ).call(n, a, "\n          border: none;\n        ")))
              : ("ghost" === c &&
                  (k =
                    "\n          color: inherit;\n          border: 2px solid;\n          background: transparent;\n        "),
                "solid" === c &&
                  (k = (0, C.default)(
                    (o = "\n          color: ".concat(
                      N,
                      ";\n          background: "
                    ))
                  ).call(o, T, "\n          border: none;\n        ")),
                (s || g || m || v || S) &&
                  (("ghost" !== c && "ghost" !== i) ||
                    (k =
                      "\n            color: inherit;\n            border: 2px solid;\n            background: transparent;\n          ")),
                r &&
                  (("ghost" !== c && "ghost" !== i) ||
                    (k = "\n            color: ".concat(
                      T,
                      ";\n            border: 2px solid;\n            background: transparent;\n          "
                    ))));
            return (0, nt.css)(
              "&.s-common-button.s-custom-btn{#s-content &{",
              k,
              "}}"
            );
          },
          getStyleButtonLayout: function () {
            var t = this.dsProps.alignment,
              e = this.dtProps.sectionName,
              n = (0, it.getSectionAlignmentForStyle)(e);
            return (0, nt.css)(
              "display:flex;justify-content:",
              t || n,
              ";> a{margin:unset;}"
            );
          },
          handleSwitchTab: function (t) {},
          getValidateUrl: function () {
            var t = "";
            try {
              t = decodeURIComponent(this.dtProps.url);
            } catch (t) {
              console.info(t);
            }
            return t;
          },
          buttonColorPicker: function (t) {
            return null;
          },
          contentEditor: function (t) {
            return null;
          },
          designEditor: function (t) {
            return null;
          },
          isPreviewMode: function () {
            return !1;
          },
          getButtonUrl: function () {
            this.props.link_type;
            var t = this.getValidateUrl();
            if (t && -1 !== (0, v.default)(t).call(t, "{{")) {
              var e = {
                "site.permalink": decodeURIComponent(
                  et.default.getPermalink()
                ).replace("pages/", ""),
              };
              t = q.addProtocol(q.replaceParamsByObj(t, e));
            }
            return t;
          },
          handleClickBtn: function () {
            var t = this.props.beforeClick;
            D.default.isFunction(t) && t();
          },
          getS5ButtonSetting: function (t) {
            var e, n, o, r, u;
            return t
              ? (null === (e = $S) ||
                void 0 === e ||
                null === (n = e.blogPostData) ||
                void 0 === n ||
                null === (o = n.pageData) ||
                void 0 === o ||
                null === (r = o.s5Theme) ||
                void 0 === r
                  ? void 0
                  : r.button) || {}
              : (null === (u = this.props.s5Theme) || void 0 === u
                  ? void 0
                  : u.getIn(["button"])) ||
                  X.default.getS5Theme().getIn(["button"]);
          },
          getButtonPlacement: function (t) {
            var e = "bottom";
            return (
              null != t &&
                t.isNavBtn &&
                (e = (0, T.default)(ct).call(ct, et.default.getThemeName())
                  ? "right"
                  : "bottomRight"),
              "i" === (null == t ? void 0 : t.navLayout) && (e = "topRight"),
              e
            );
          },
          getButtonSizeClassName: function (t) {
            var e;
            return (0, C.default)(
              (e = "mobile-".concat(
                t.mobile_size || lt.BUTTON_SIZE_VALUE.AUTOMATIC,
                " pc-"
              ))
            ).call(e, t.size);
          },
          render: function () {
            this.state.buttonCurrentTab;
            var t,
              e,
              n,
              o = F.default.getIsBlog(),
              r = this.getS5ButtonSetting(o),
              u =
                (this.getButtonPlacement(this.props),
                this.getButtonSizeClassName(this.dsProps)),
              i = "".concat(this.dsProps.style),
              l = this.hasContent(),
              a = (0, d.default)(
                "a",
                {
                  className: (0, C.default)(
                    (t = (0, C.default)(
                      (e = (0, C.default)(
                        (n = "s-common-button s-custom-btn ".concat(
                          this.getStyleButtonColor(r, o),
                          " "
                        ))
                      ).call(n, this.props.className || "", " s-font-button "))
                    ).call(e, u, " "))
                  ).call(t, i),
                  href: this.getButtonUrl(),
                  onClick: this.handleClickBtn,
                  "data-is-nav-btn": this.props.isNavBtn,
                  "data-type": this.props.link_type,
                  "data-component": "button",
                  target: this.dtProps.new_target ? "_blank" : "_self",
                },
                void 0,
                this.dtProps.text
              );
            return I.default.createElement(
              "div",
              {
                className: (0, U.default)("s-button s-component", {
                  fullwidth: this.dsProps.fullWidth,
                }),
                ref: "popoverWrapper",
              },
              (0, d.default)(
                O.default,
                {},
                void 0,
                (0, d.default)(
                  H.default,
                  {
                    className: "s-component-content ".concat(
                      this.getStyleButtonLayout()
                    ),
                  },
                  void 0,
                  l && a
                )
              )
            );
          },
        });
      (e.default = (0, M.connect)(function (t) {
        var e = et.default.getMembershipSettings();
        return { isMembershipActive: Boolean(e && e.isMembershipUsed) };
      }, null)(st)),
        (t.exports = e.default);
    },
  },
]);
