/*! For license information please see 8544.051b5805dd5ec50d3b59-site-bundle.js.LICENSE.txt */
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [8544],
  {
    68544: function (e) {
      e.exports = {
        domain: "messages",
        locale_data: {
          messages: {
            "": { domain: "messages", plural_forms: "", lang: "" },
            " LIVE CHAT": [" 在线聊天"],
            "%{num} sites": ["%{num} 个网站"],
            "%{siteName} (copy)": ["%{siteName} (复本)"],
            "%{storageUsage} / %{storageLimit} storage used": [
              "%{storageUsage} / %{storageLimit} 已用存储空间",
            ],
            "%{timer}s Retry": ["%{timer}秒后重试"],
            "%{var1} users can add up to %{var2} pages per site.": [
              "%{var1}版用户单个页面最多可以添加%{var2}个页面。",
            ],
            "(Keep in mind some phones might automatically kill background apps. if your phone does this, you'll have to specifically allow our app to run in the background.)":
              [
                "（请注意，某些手机可能会自动终止后台应用程序。如果你的手机执行此操作，你必须特别允许我们的应用程序在后台运行。）",
              ],
            "(Right click > Save Image as)": ["(单击右键 > 图片另存为)"],
            "(billed annually)": ["（按年支付）"],
            "(optional)": ["（选填）"],
            "/mo": ["/月"],
            "10 Years": ["10年"],
            "14 days risk-free": ["14 天无风险"],
            "2 Years": ["2年"],
            "2-step authentication with SMS is now enabled.": [
              "手机短信验证已激活。",
            ],
            "24/7 Livechat Support": ["24/7 在线客服支持"],
            "3 Years": ["3年"],
            "5 Years": ["5年"],
            "<a></a> is currently editing. Their unsaved changes will be lost if you start editing! <strong>Are you sure you want to take over?</strong>":
              [
                "<a></a> 正在编辑中。如果你现在开始编辑，之前未保存的信息将会丢失，<strong>确定覆盖所有未保存信息吗？</strong>",
              ],
            "<strong>1 GB</strong> total storage per site": [
              "<strong>1 GB</strong> 文件存储空间/网站",
            ],
            "<strong>100 GB</strong> total storage per site": [
              "<strong>100 GB</strong> 文件存储空间/网站",
            ],
            "<strong>20 GB</strong> total storage per site": [
              "<strong>20 GB</strong> 文件存储空间/网站",
            ],
            "<strong>2</strong> Limited Sites": [
              "<strong>2</strong> 个基础版网站",
            ],
            "<strong>3</strong> Pro Sites": ["<strong>3</strong>个专业版网站"],
            "<strong>5 GB</strong> Monthly Bandwidth": [
              "每月带宽<strong> 5 GB</strong>",
            ],
            "<strong>50 GB</strong> Monthly Bandwidth": [
              "每月带宽<strong> 50 GB</strong>",
            ],
            "<strong>500 MB</strong> total storage per site": [
              "<strong>500 MB</strong> 文件存储空间/网站",
            ],
            "<strong>5</strong> Pro Sites": ["<strong>5</strong>专业版网站"],
            "<strong>Free Domain</strong> with Yearly!": [
              "赠送1年<strong>免费域名</strong>！",
            ],
            "<strong>Password Protect</strong> Your Site": [
              "可用<strong>密码保护</strong>你的网站",
            ],
            "<strong>Send Newsletters</strong> - 2000 contacts/month": [
              "<strong>发送营销邮件</strong> - 2000有效联系人/月",
            ],
            "<strong>Strikingly.com</strong> Domain": [
              "<strong>sxl.cn</strong> 域名",
            ],
            "<strong>Unlimited</strong> Bandwidth": [
              "<strong>无限</strong>带宽",
            ],
            "<strong>Unlimited</strong> Free Sites": [
              "<strong>无限</strong>免费版网站",
            ],
            "A few advanced techniques to increase your site visibility. Try these below and see the results!":
              [
                "使用一些高级技巧可以提升网站的曝光度。试试下面这些，看看会有什么效果吧",
              ],
            "A few sentences describing your site. Used for search engines and social media sharing.":
              ["显示于搜索引擎结果以及社交媒体分享内容中"],
            "A list of comma-separated tags related to your page. What should people search for to find this page?":
              ['可优化搜索引擎结果，请用英文逗号","分隔'],
            "A short message to display when the form is submitted.": [
              "表单提交后显示的简短消息",
            ],
            "A social share image makes your site more attractive when shared on social media.":
              ["在分享网站的时候会出现的图片"],
            "A/B testing with <a href='http://optimizely.com' target='_blank'>optimizely.com</a> is only available for Pro users.":
              [
                "用 <a href='http://optimizely.com' target='_blank'>optimizely.com</a> 进行 A/B 测试（仅限专业版用户）",
              ],
            "ADD SELECTED IMAGES": ["添加选定图片"],
            "ADD VIDEO": ["添加视频"],
            "ADMIN: Are you sure you want to add more sections? This exceeds the soft limit(%{var1}).":
              ["管理员：你确定要添加更多的板块吗？这超过了(%{var1})个的限制"],
            "AI Site Builder": ["AI网站生成器"],
            "AI Writer": ["AI智能写手"],
            AMP: ["加速移动页面 (AMP)"],
            "API Key": ["API密钥"],
            "Accepted file types: gif, jpeg, png, bmp, ico. Up to 10MB.": [
              "支持 10MB 以下的图片格式：gif, jpeg, png, bmp, ico",
            ],
            "Accepted file types: txt, pdf, doc, xls, ppt, pages, key, numbers, wps.":
              [
                "支持文件类型：txt, pdf, doc, xls, ppt, pages, key, numbers, wps",
              ],
            Account: ["账户"],
            "Account Management": ["专属账户服务"],
            "Account email: %{var1}": ["您的账号邮箱: %{var1}"],
            Actions: ["操作"],
            "Activate AMP": ["激活AMP"],
            "Activate AMP for all your blog posts for an SEO boost.": [
              "将你的所有博文都激活AMP来优化SEO。",
            ],
            "Activate MIP": ["激活MIP"],
            "Activate SMS verification": ["激活短信验证"],
            "Add A New Section": ["添加新版块"],
            "Add Alt Text": ["添加描述文字"],
            "Add Description": ["添加描述"],
            "Add Email Account (50% off)": ["添加邮箱账号（五折优惠）"],
            "Add Images": ["添加图片"],
            "Add Item": ["添加"],
            "Add Link": ["添加链接"],
            "Add New Link": ["添加新链接"],
            "Add New Section": ["添加新版块"],
            "Add Slide": ["添加滑块"],
            "Add Store, Blog, and more": ["添加商店，博客和其他版块"],
            "Add Title": ["添加标题"],
            "Add Videos": ["添加视频"],
            "Add a password to your site to keep it private.": [
              "为网站添加密码以保持私密",
            ],
            "Add a professional email address to your domain, like [email]": [
              "为你的域名添加一个专业的邮箱地址，例如 [email]",
            ],
            "Add a redirect": ["添加跳转规则"],
            "Add accounts": ["添加账号"],
            "Add email account": ["添加邮箱账号"],
            "Add membership": ["添加会员功能"],
            "Add mobile-specific actions like calling, texting, finding directions, and emailing.":
              ["给手机网站添加一些操作，如拨号、地址信息、网站导航！"],
            "Add specific actions visitors can take from their phone, like dialing a number or launching a map! These will appear in a special menu on mobile phones. You can fill in any, all, or none of these.":
              [
                "你可以设置访客在手机上使用的快捷操作，例如拨打一个号码或打开地图。你可以选填任何一个、全部或不填。",
              ],
            "Add up to %{var1} pages per site, and add dropdown menus to organize your pages.":
              [
                "单个网站最多可以有%{var1}个页面，并且可以添加下拉菜单来管理你的页面。",
              ],
            "Add your phone number": ["添加手机号"],
            "Adding pages to your site...": ["正在为你的网站添加页面…"],
            "Admin Email": ["管理员邮件"],
            "Ads|Ads will appear in this section after your Mini-Program is published. Click [link:here] to manage and troubleshoot.":
              [
                "该版块将显示广告位。如果发布小程序后，广告位不能正常显示，请检查[link:操作指引]或咨询在线客服",
              ],
            "Ads|Ads will be displayed on the homepage and on each blog post.":
              ["广告将展示在每篇文章底部、小程序首页"],
            "Ads|Ads will be displayed on the homepage.": [
              "广告将展示在小程序首页",
            ],
            "Ads|Are you sure you want to disable Ads? All ads will be removed and you will no longer earn any revenue from them.":
              ["你确定要停用广告位功能吗？全部广告位将移除并停止赚取分成。"],
            "Ads|Disable Ads": ["停用广告位功能"],
            "Ads|Enable Ads": ["开始配置"],
            "Ads|Go to WeChat platform": ["前往创建和管理"],
            "Ads|Introduction": ["功能介绍"],
            "Ads|Mini-Program Ads": ["广告位 (流量主)"],
            "Ads|Monetize your traffic by displaying WeChat Ads in your Mini-Program! Earn money each month based on ad performance. The more clicks, the more you earn.":
              [
                "将指定位置用于微信公共广告位（如某品牌广告），微信将根据广告表现给予一定的金钱分成，让您按月获得广告收入，实现流量变现！点击量越多，广告收入越多。",
              ],
            "Ads|Must be in format <ad unit-id=xxxxxxxxx></ad>": [
              "请输入有效广告代码！遵循格式如 <ad unit-id=xxxxxxxxx></ad>",
            ],
            "Ads|Paste Mini-Program Ads code below": [
              "获取广告位代码后粘贴至下方",
            ],
            "Ads|Paste Mini-Program Ads code below and click Publish. Ads will be activated when your Mini-Program's content review is complete.":
              [
                "粘贴至下方输入框，保存后点击【立即发布】小程序。审核通过后广告位生效",
              ],
            "Ads|Please check the Ads code carefully! If the code is incorrect, it could break your Mini-Program.":
              ["请小心检查代码正确无误，否则小程序会显示乱码。"],
            "Ads|Read Instructions": ["详细操作指引"],
            "Ads|Save and enable": ["保存并启用广告位"],
            "Ads|Successfully enabled!": [
              "新功能开启成功！需更新发布小程序后生效",
            ],
            "Ads|You can view your ads' performance and earnings in the Mini-Program official platform":
              ["前往微信小程序后台，定期查看广告数据表现、广告分成结算"],
            "Ads|You'll need to visit WeChat's Mini-Program official platform to create Ads and copy Ads code":
              ["前往微信小程序后台，创建广告位后获取广告位代码"],
            "Ads|Your Ads code must be properly entered and this Mini-Program must be published!":
              [
                "必须粘贴代码和重新发布小程序，广告位才生效并开始计算分成，否则小程序端不会显示广告位。",
              ],
            'Ads|e.g. <ad unit-id="adunit-324d7787d36f62ee"></ad>': [
              '仅支持微信小程序banner类广告位的代码如 <ad unit-id="adunit-324d7787d36f62ee"></ad>',
            ],
            "Advanced Tools": ["高级工具"],
            "Affiliate|Earn More Commission Now": ["现在就升级佣金"],
            "Affiliate|Earn generous recurring commissions for life.": [
              "可永久得到常续性的佣金。",
            ],
            "Affiliate|Ending Soon": ["即将结束"],
            "Affiliate|Enter legacy affiliate account email": [
              "输入旧版分销系统邮箱地址",
            ],
            "Affiliate|Legacy affiliate link migrated: %{var1}": [
              "已完成迁移旧版分销链接: %{var1}",
            ],
            "Affiliate|Migrate from Legacy Affiliate System": [
              "旧版分销系统迁移",
            ],
            "Affiliate|New Affiliate Program commission structure:": [
              "全新联盟分销计划的佣金结构：",
            ],
            "Affiliate|Now's the perfect time to promote your link!": [
              "将你的推广链接广而告之的最好时节！",
            ],
            "Affiliate|Our legacy affiliate platform will no longer be supported after December 31, 2022. If you are currently using [link1: affiliate.strikingly.com] or [link2: getambassador.com] to view and manage your affiliate commissions, [strong: you must migrate to our new system to keep earning commissions.]":
              [
                "我们旧版的分销系统将在2022年12月31日后正式下线。如果你现在还在使用 [link1: affiliate.strikingly.com] 或 [link2: getambassador.com] 来查看以及管理你的分销佣金，[strong: 请务必尽快迁移到我们的新版分销系统以继续赚取佣金。]",
              ],
            "Affiliate|Our legacy affiliate platform will no longer be supported. If you have an affiliate account registered on affiliate.strikingly.com or getambassador.com, you must migrate to our new system to keep earning commissions.":
              [
                "旧版的分销系统即将下线。如果你在 affiliate.strikingly.com 或者 getambassador.com 上注册过联盟分销的账号，你现在必须迁移至我们的新版联盟分销系统才能继续赚取佣金。",
              ],
            "Affiliate|Please confirm your email to complete the process.": [
              "请完成验证你的邮箱",
            ],
            "Affiliate|Please confirm your email to reactivate your affiliate account.":
              ["请完成验证你的邮箱以重新激活你的分销账号"],
            "Affiliate|Please reapply to earn more.": ["佣金升级需要申请"],
            'Affiliate|Please reapply to our updated Strikingly Affiliate Program in order to migrate legacy links from Ambassador. Click "OK" to reapply.':
              [
                "请重新申请加入我们的新版Strikingly联盟分销计划，加入后可以进行旧版分销链接（Ambassador）的迁移。点击“好的”开始申请。",
              ],
            "Affiliate|Reapply to Affiliate Program & Earn More": [
              "申请升级我的佣金",
            ],
            "Affiliate|Reapply to Strikingly Affiliate Program": [
              "申请加入升级版Strikingly联盟分销计划",
            ],
            "Affiliate|Send Email Verification & Migrate": [
              "发送验证邮件并开始迁移",
            ],
            "Affiliate|Strikingly's %{var1} is ending in %{var2} days.": [
              "Strikingly 的 %{var1}即将在%{var2}天后结束！",
            ],
            "Affiliate|Strikingly's %{var1} is ending in %{var2} hours.": [
              "Strikingly 的 %{var1}即将将在%{var2}小时后结束！",
            ],
            "Affiliate|This is the account you use to login to affiliate.strikingly.com or getambassador.com. It may be different from your regular Strikingly account email.":
              [
                "这个邮箱地址应该是你用来登录 affiliate.strikingly.com 或 getambassador.com 时用的（有可能与你平时用来登录Strikingly所用的邮箱不是同一个地址）。",
              ],
            "Affiliate|This link has now successfully been connected to our new affiliate program. Referred users from this link will earn you commissions in our new Affiliate Program, in the same way as your primary link. You don't need to update this link.":
              [
                "该链接已经成功迁移到这里了。从现在起通过该链接注册并完成付费的引荐用户所产生的佣金将以新版的分销计划计入你的名下，而且可以与你在新版计划里的分销链接同时并存使用。你不需要更新任何链接。",
              ],
            "Affiliate|This link will no longer earn you referral commissions. To continue earning commissions, you must change your existing affiliate links (e.g. on your blog posts, websites, and published content) to your new link: %{var1}":
              [
                "该链接从现在起将不会再为你赚取任何佣金。你必须将你现在所有用到该链接的地方替换成新的链接（比如你的博文、网站、任何发布内容）才可以继续赚取联盟分销佣金。新链接：%{var1}",
              ],
            "Affiliate|This means you'll be able to earn [strong1: unlimited] commissions for each customer you refer. You can even [strong2: keep your existing affiliate link.]":
              [
                "这意味着你将有可能在每一个你引荐的付费用户上获得[strong1: 无限永续的]佣金收入。而且你还可以[strong2: 保留你现在已经在用的专属分销链接，不需作出任何更改。]",
              ],
            "Affiliate|Verification email sent. Please check your email to complete the migration process!":
              ["验证邮件已发送。请检查您的邮箱以完成迁移。"],
            "Affiliate|Verify your legacy affiliate account email": [
              "验证你的旧版分销系统账户邮箱",
            ],
            "Affiliate|View the summary & FAQ here.": [
              "点击此处查看政策概要以及FAQ常见问题的回答。",
            ],
            "Affiliate|We're upgrading our Affiliate Program and offering higher commissions! Please reapply to make sure you understand our new affiliate program policies.":
              [
                "Strikingly联盟分销计划已全新升级，带给你更高、更持久的佣金！请申请并详细了解新分销计划的相关政策。",
              ],
            "Affiliate|We're upgrading our Affiliate Program with higher commissions! Please reapply to earn more.":
              [
                "Strikingly联盟分销计划已全新升级，带给你更高、更持久的佣金！现在就来升级吧",
              ],
            "Affiliate|You have successfully migrated your [link1: a.strk.ly] link to our new Affiliate Program. However, if you were using an [link2: mbsy.co] link, you must update your content to use your new affiliate link. See instructions below:":
              [
                "你已经成功把你的 [link1: a.strk.ly] 分销链接迁移到了新版分销系统！但是如果你先前用的是一个地址为 [link2: mbsy.co] 的分销链接，你还需要把新版链接更换到你现在正在用该旧版链接的内容里。请参见以下说明：",
              ],
            "Affiliate|Your legacy affiliate link has been migrated, so referrals from that link will be attributed to your account. Click to read more detailed instructions.":
              [
                "你的旧版分销链接已经完成迁移到新版Strikingly联盟分销计划！从现在起，通过你这个链接在Strikingly付费的用户都将归因到你的分销账户下。点击此处了解详情。",
              ],
            "Affiliate|Your referrals will automatically get %{var1} off their first payment.":
              ["你的引荐用户将自动获得 %{var1} 优惠！"],
            "Affiliate|[strong: If you were using an [link1: mbsy.co] link] (e.g. %{link2}):":
              [
                "[strong: 如果你之前用的是 [link1: mbsy.co] 链接]（如：%{link2}）：",
              ],
            "After that, you can claim a free email account!": [
              "之后，你可以领取免费的邮箱账号!",
            ],
            Alipay: ["支付宝"],
            All: ["全部"],
            "All Time": ["全部时间"],
            "All uploaded images": ["所有已上传的图片"],
            "Allow visitors to register as members, create members-only content, and attach memberships to product sales! Add up to %{num_products} members, with more":
              [
                "允许访客注册成为会员、创建会员专享页面以及向会员出售专享商品！ 可添加多至%{num_products}名会员，以及更多",
              ],
            "Allow your site to register members with their own accounts and logins. Click to learn more.":
              [
                "允许网站访客注册成为会员，并使用他们自己的帐户密码登录。 点击此处了解更多。",
              ],
            "Already on this plan": ["已在该套餐内"],
            "Alt Text": ["描述文字"],
            "Analytics|(%{conversion}%% conversion)": [
              "(%{conversion}%%转化率)",
            ],
            "Analytics|Added products to cart": ["商品已添加到购物车"],
            "Analytics|Analytics": ["数据分析"],
            "Analytics|Analytics is undergoing regularly scheduled maintenance. Please check back in an hour!":
              ["网站数据分析正在进行定期维护, 请在一小时内回来查看！"],
            "Analytics|Blog": ["博客"],
            "Analytics|Blog Subscriptions": ["博客订阅"],
            "Analytics|Contact Form Responses": ["联系表单信息"],
            "Analytics|Contacts, Signups, Subscriptions": [
              "联系表单，报名表单，订阅表单",
            ],
            "Analytics|Conversion rate from unique pageviews to form responses":
              ["不重复的页面浏览量到表格回复的转换率"],
            "Analytics|Conversion rate from unique pageviews to live chat conversations":
              ["不重复的页面浏览量到即时聊天对话的转换率"],
            "Analytics|Countries/Regions": ["国家/地区"],
            "Analytics|Desktop": ["桌面"],
            "Analytics|Devices": ["设备"],
            "Analytics|Direct Traffic": ["直接访问"],
            "Analytics|File Downloads": ["文件下载量"],
            "Analytics|Last 24 hours": ["最近 24 小时"],
            "Analytics|Last 30 days": ["过去 30 天"],
            "Analytics|Last 7 days": ["过去 7 天"],
            "Analytics|Last 90 days": ["过去 90 天"],
            "Analytics|Live Chat Conversations": ["在线聊天对话"],
            "Analytics|Mobile": ["手机"],
            "Analytics|Only showing revenue from orders in %{currency}": [
              "只显示货币为%{currency}的订单收入",
            ],
            "Analytics|Orders Received": ["订单数"],
            "Analytics|Other": ["其它"],
            "Analytics|Past 24 hours": ["过去 24 小时"],
            "Analytics|Past 3 months": ["过去 90 天"],
            "Analytics|Past month": ["过去 30 天"],
            "Analytics|Past week": ["过去 7 天"],
            "Analytics|Return to Dashboard": ["返回控制面板"],
            "Analytics|Revenue": ["收入"],
            "Analytics|Sales Funnel": ["销售漏斗"],
            "Analytics|Sign Ups": ["注册"],
            "Analytics|Store": ["简易商店"],
            "Analytics|Top Pages": ["访问最多的页面"],
            "Analytics|Top Viewed Blog Posts": ["阅读量最多的博客"],
            "Analytics|Top country/Region": ["访问量最多的国家/地区"],
            "Analytics|Total Blog Subscriptions - All Time": [
              "博客订阅总数 - 所有时间",
            ],
            "Analytics|Total Contact Form Responses - All Time": [
              "联系表单信息总数 - 所有时间",
            ],
            "Analytics|Total Live Chat Conversations - All Time": [
              "总的在线聊天对话 - 全部时间",
            ],
            "Analytics|Total Orders Received - All Time": [
              "总订单数 － 所有时间",
            ],
            "Analytics|Total Revenue - All Time": ["总收入 - 所有时间"],
            "Analytics|Total Sign Ups - All Time": ["总注册数 - 所有时间"],
            "Analytics|Traffic Sources": ["访问来源"],
            "Analytics|Unique Visitors": ["独立访客"],
            "Analytics|View all form responses": ["查看所有信息"],
            "Analytics|View all live chats": ["查看全部对话"],
            "Analytics|View all orders": ["查看所有的订单"],
            "Analytics|Viewed store page": ["查看商店页面"],
            "Analytics|Visited checkout": ["已访问结账页面"],
            "Analytics|Visitors": ["访客"],
            "Analytics|downloads past 24 hours": ["过去 24 小时的下载"],
            "Analytics|downloads past 3 months": ["最近 3 個月的下载"],
            "Analytics|downloads past month": ["上个月的下载"],
            "Analytics|downloads past week": ["上一周的下载"],
            "Analyzing your business...": ["正在分析你的业务…"],
            Animations: ["动画"],
            "Animations|Background": ["背景"],
            "Another collaborator has taken over editing this page.": [
              "另一个协作帐户已经接管进行此页面的编辑",
            ],
            "Any pages beyond this limit will not be published when you publish this site. Upgrade to Pro to unlock.":
              [
                "当发布网站后，超出这个限制的页面不会上线。请升级到专业来解锁。",
              ],
            Apply: ["应用"],
            "Are you absolutely sure you wish to delete this blog post? This action is PERMANENT!":
              ["您确定要删除这篇文章吗? 删除之后是无法恢复的！"],
            "Are you sure you want to delete this spec type?": ["确定删除吗?"],
            "Are you sure you want to disable Live Chat? The chat box will no longer be displayed in this site. You can turn this back on at anytime.":
              [
                "确定要关闭在线聊天吗？关闭后网站将不再显示在线聊天窗口。你也可以随时开启。",
              ],
            "Are you sure you want to regenerate recovery codes? The old codes will no longer be effective.":
              ["是否确定生成新的恢复码？旧恢复码将作废。"],
            "Are you sure you want to remove the Blog section from your site? All of your blog posts and settings will be kept. Just add the section back to bring them back!":
              [
                "你确定要删除网站的博客版块吗？系统会保存所有设置和博客文章，方便删除后再次添加该版块！",
              ],
            "Are you sure you want to remove the Product Showcase section from your site? All of your products and settings will be kept. Just add the section back to bring them back!":
              [
                "你确定要删除网站的产品展示版块吗？系统会保存所有设置和产品信息，方便删除后再次添加该版块！",
              ],
            "Are you sure you want to remove the Store section from your site? All of your products and settings will be kept. Just add the section back to bring them back!":
              [
                "你确定要删除网站的商城版块吗？系统会保存所有设置和商品信息，方便删除后再次添加该版块！",
              ],
            "Are you sure you want to remove the password for this page? This page will be public for all visitors.":
              ["确定要删除这个页面的密码？这个页面的内容会被公开。"],
            "Are you sure you want to set %{pageTitle} as the new homepage? The password for this page will be removed.":
              ["确定要将 %{pageTitle} 设为主页？现有的页面密码会被移除。"],
            "Are you sure you want to set a password for this page? Visitors must enter the password to see the page content.":
              ["确定要为这个页面设置密码？访客需要输入密码才能浏览页面内容。"],
            "Are you sure you wish to cancel your Audience Plan? You will no longer be billed.":
              ["确定取消营销版套餐？取消后，你不会再收到账单。"],
            "Are you sure you wish to change your Audience Plan? Starting %{startDate}, your Audience Plan will change to $%{pricing}/%{period}.":
              [
                "确定取消营销版套餐？从%{startDate}开始，你的套餐费用将改为$%{pricing}/%{period}.。",
              ],
            "Are you sure you wish to upgrade your Audience Plan? Starting immediately, you'll be billed an additional $%{pricing}/%{period}.":
              [
                "确定升级你的营销版套餐？确认后，费用会增加 $%{pricing}/%{period}。",
              ],
            "Are you sure?": ["确认？"],
            'AssetLibrary|%{var1} results found for [keyword:"%{var2}"]': [
              "找到%{var1}个与[keyword:“%{var2}”]相关的结果",
            ],
            "AssetLibrary|<span class='total'>%{var5}</span> results found for \"%{var6}\"":
              ["找到<span class='total'>%{var5}</span>个与“%{var6}”相关的结果"],
            "AssetLibrary|Abstract": ["文艺清新"],
            "AssetLibrary|All": ["全部"],
            "AssetLibrary|Animals": ["动物"],
            "AssetLibrary|App Store Badges": ["应用商店徽章"],
            "AssetLibrary|Blurred": ["模糊"],
            "AssetLibrary|Blurred Backgrounds": ["模糊背景"],
            "AssetLibrary|Business": ["商业风格"],
            "AssetLibrary|Can't find a good image? [link:Update the description] and search for more.":
              ["找不到你想要的图片？[link:更新图片描述]可以搜索更多图片。"],
            "AssetLibrary|City": ["城市"],
            "AssetLibrary|Cityscapes": ["城市"],
            "AssetLibrary|Crowd": ["人群"],
            "AssetLibrary|Delicate Icons": ["经典图标"],
            "AssetLibrary|Fashion": ["时尚"],
            "AssetLibrary|Flat Circle Icons": ["扁平圆形图标"],
            "AssetLibrary|Flat Circle Icons - Pro": ["扁平圆形图标 - 专业版"],
            "AssetLibrary|Flat Modern Icons": ["人气扁平图标"],
            "AssetLibrary|Flat Modern Icons - Pro": ["平面现代图标"],
            "AssetLibrary|Food": ["食品"],
            "AssetLibrary|Food & Drinks": ["美食饮品"],
            "AssetLibrary|Images": ["图片"],
            "AssetLibrary|Line Icons": ["线性图标"],
            "AssetLibrary|Nature": ["自然风光"],
            "AssetLibrary|Objects": ["物体"],
            "AssetLibrary|Oops! There's something wrong. Try again later.": [
              "有些地方出错了。请稍后再试。",
            ],
            "AssetLibrary|Pastel Solids": ["纯色背景"],
            "AssetLibrary|Patterns": ["图案纹理"],
            "AssetLibrary|People": ["人物"],
            "AssetLibrary|Popular searches": ["热门搜索"],
            "AssetLibrary|Powered by Unsplash": ["由 Unsplash 提供图片支持"],
            "AssetLibrary|Recreation": ["休闲"],
            "AssetLibrary|Search over 3 million images...": [
              "搜索超过3百万张图片...",
            ],
            "AssetLibrary|Show newest first": ["优先显示新图片"],
            "AssetLibrary|Social Icons - Black": ["社交图标 - 黑色"],
            "AssetLibrary|Social Icons - Blue": ["社交图标－蓝色"],
            "AssetLibrary|Social Icons - Brown": ["社交图标－棕色"],
            "AssetLibrary|Social Icons - Green": ["社交图标－绿色"],
            "AssetLibrary|Technology": ["科技"],
            "AssetLibrary|Things": ["静物聚焦"],
            "AssetLibrary|Videos": ["视频"],
            "AssetLibrary|Wellness": ["健康"],
            Audience: ["客户"],
            "Audience| (2 months free!)": ["（免2个月费！）"],
            "Audience| All Audience plans unlock [boldText] on your sites.": [
              "你的所有网站都享用营销版套餐的[boldText]。",
            ],
            "Audience| To send to %{recipients} recipients, you must upgrade your Audience Plan.":
              ["要发送给%{recipients} 收件人，请升级你的营销版套餐。"],
            "Audience|%{balance} Balance, %{points} Points": [
              "%{balance} 余额，%{points} 积分",
            ],
            "Audience|%{days} days since first follow-up, %{totalCount} follow-ups total":
              ["已跟进 %{days}，共计 %{totalCount} 次"],
            "Audience|%{memberTypeName} Member": ["%{memberTypeName}会员"],
            "Audience|%{num} recipient selected": ["已选 %{num} 收件人"],
            "Audience|%{num} recipients selected": ["已选 %{num} 收件人"],
            "Audience|%{percent}%% off Audience Plans": [
              "营销套餐 %{percent} 折优惠",
            ],
            "Audience|%{percent}%% off Yearly Audience Plans": [
              "包年营销套餐%{percent}折优惠！",
            ],
            "Audience|%{userName}, how likely are you to recommend SXL to a friend or colleague?":
              ["%{userName}，你有多大的可能性会将 上线了 推荐给朋友或同事？"],
            "Audience|%{userName}, how likely are you to recommend Strikingly to a friend or colleague?":
              [
                "%{userName}，你有多大可能向你的朋友或同事推荐使用 Strikingly？",
              ],
            "Audience|%{var1}d : %{var2}h : %{var3}m : %{var4} remaining!": [
              "优惠还剩%{var1}天 : %{var2}小时 : %{var3}分 : %{var4}!",
            ],
            "Audience|(Active contacts includes site members, live chats, and email recipients.)":
              ["（有效联系人包括网站会员功能、在线聊天对话、邮件收件人）"],
            "Audience|(Untitled Forms)": ["(未命名表单)"],
            "Audience|2 unread messages": ["2条未读消息"],
            "Audience|Actions": ["操作"],
            "Audience|Activity Log": ["行为记录"],
            "Audience|Add Additional Phone Number": ["添加额外的电话号码"],
            "Audience|Add Button": ["添加按钮"],
            "Audience|Add a Store Section": ["添加商店板块"],
            "Audience|Add a store to your site.": ["为你的网站添加电商功能。"],
            "Audience|Additional Info": ["详细资料"],
            "Audience|Allows %{contactsCount} active contacts and unlimited emails/messages sent per month":
              [
                "此套餐包括%{contactsCount}个有效联系人，每个月可以发送无限个邮件或信息。",
              ],
            "Audience|Allows %{contactsCount} active contacts and unlimited emails/messages sent per month when your monthly cycle renews.":
              [
                "此套餐包括%{contactsCount} 个有效联系人，每个月可以发送无限个邮件或信息。这将在你的月周期更新后生效。",
              ],
            "Audience|Allows %{contactsCount} active contacts and unlimited emails/messages sent per month when your yearly cycle renews.":
              [
                "此套餐包括%{contactsCount} 个有效联系人，每个月可以发送无限个邮件或信息。这将在你的年周期更新后生效。",
              ],
            "Audience|Allows 100 active contacts and 100 emails/messages sent per month.":
              ["此套餐包括100个有效联系人，每个月可以发送100封邮件和信息。"],
            "Audience|Are you absolutely sure you wish to delete this newsletter? This action is PERMANENT!":
              ["你确定要删除这封邮件吗? 删除之后是无法恢复的！"],
            "Audience|Are you sure you want to delete the selected conversations?":
              ["你确定要删除所选的消息吗？"],
            "Audience|Are you sure you want to set this contact's email to %{email}?":
              ["您确定要将此联系人的电子邮件设置为 %{email} 吗？"],
            "Audience|Are you sure you want to unschedule this newsletter? This newsletter will not be sent but will still be saved as a draft.":
              [
                "你确定要撤销定时发送该邮件吗？ 此邮件将不会发送，但会保存为草稿。",
              ],
            "Audience|Are you sure you wish to mark %{count} contact(s) as spam? These will be removed from the audience list.":
              [
                "你确定要将已选择的 %{count} 个粉丝标记为垃圾信息吗？标记后将会移至垃圾信息列表中。",
              ],
            "Audience|Are you sure you'd like to send a message to %{recipient}? We'll deliver the message and the recipient can reply to your own email address (%{sender}).":
              [
                "你确定想要发消息给 %{recipient}? 我们将通过你的邮箱地址 %{sender} 发送消息以及接收回复。",
              ],
            "Audience|Audience": ["粉丝运营"],
            "Audience|Audience List": ["粉丝列表"],
            "Audience|Average revenue per order": ["每个订单的平均消费金额"],
            "Audience|Avg Order Value": ["客单价"],
            "Audience|Blog Subscriber": ["博客订阅人"],
            "Audience|Blog Subscription Canceled": ["博客订阅已取消"],
            "Audience|Blog Subscription Confirmed": ["博客订阅已确认"],
            "Audience|Blog Subscriptions": ["博客订阅"],
            "Audience|Booking": ["预约服务"],
            "Audience|Button Text Here": ["按钮文字"],
            "Audience|By default, newsletters will be sent from mystrikingly.com you can choose to send newsletters from a custom domain if you register a new domain or transfer a domain to Strikingly.":
              [
                "默认的邮件发件人是来自 mystrikingly.com。注册新域名或转入域名到 Strikingly，来使用自定义域名来做为发件人地址。",
              ],
            "Audience|By default, newsletters will be sent from mystrikingly.com you can choose to send newsletters from a custom domain if you upgrade to Pro, then register a new domain or transfer a domain to Strikingly.":
              [
                "默认的邮件发件人是来自 mystrikingly.com。你可以使用自定义域名做为发件人地址。升级到专业版套餐，然后注册新域名或转入域名到 Strikingly，",
              ],
            "Audience|Cancel": ["取消"],
            "Audience|Cancel Audience Plan": ["取消套餐"],
            "Audience|Cancel scheduling": ["撤销定时发送"],
            "Audience|Canceled order": ["取消订单"],
            "Audience|Change Audience Plan": ["更改套餐"],
            "Audience|Chat on mobile": ["在手机端联系粉丝"],
            "Audience|Chat on mobile after publishing this Mini Program.": [
              "发布小程序后即可在手机端沟通。",
            ],
            "Audience|Confirm Newsletter": ["确认邮件"],
            "Audience|Contact Form": ["联系表单"],
            "Audience|Contact Forms": ["注册与报名表单"],
            "Audience|Contact Us": ["联系我们"],
            "Audience|Contact email invalid": ["联系人的电子邮件无效"],
            "Audience|Contact email is invalid.": ["联系人的邮箱地址无效。"],
            "Audience|Contact support": ["联系客服"],
            "Audience|Contact unsubscribed": ["联系人已取消订阅"],
            "Audience|Convert your audience into customers!": [
              "将你的粉丝转化为顾客！",
            ],
            "Audience|Create Contact": ["创建联系人"],
            "Audience|Custom": ["筛选粉丝"],
            "Audience|Customers": ["商店顾客"],
            "Audience|Date": ["消费日期"],
            "Audience|Date Sent": ["发送日期"],
            "Audience|Delete": ["删除"],
            "Audience|Delete Membership": ["取消会员资格"],
            "Audience|Did you know that you may earn cash for every customer you refer to Strikingly as an affiliate? We share [strong: 30% of the first-time revenue] we earn for every new customer that signs up through your affiliate link. Sign up and get started today!":
              [
                "你知道吗？分销合伙人是可以通过给 Strikingly 推荐用户来赚取现金奖金的！每一位通过你的分销链接注册的新付费用户，我们都会给你[strong: 首次收入30% 的现金分成]。还在等什么，马上注册加入吧！",
              ],
            "Audience|Displays all paid orders, including invoice payments.": [
              "将显示已支付的订单，包括云收款。",
            ],
            "Audience|Displays all paid orders, including purchased products and balance top-ups.":
              ["将显示已支付的订单，包括购物、会员储值。"],
            "Audience|Draft": ["草稿"],
            "Audience|Duplicate": ["复制"],
            "Audience|EARLY BIRD SPECIAL": ["早鸟价"],
            "Audience|Earn Referral Rewards as a Strikingly Affiliate!": [
              "成为 Strikingly 分销合伙人，赚取丰厚奖金！",
            ],
            "Audience|Edit Agent Profile": ["编辑代理者资料"],
            "Audience|Edit Button": ["编辑按钮"],
            "Audience|Edit Contact": ["编辑联系人"],
            "Audience|Edit Info": ["编辑信息"],
            "Audience|Edit Link": ["编辑链接"],
            "Audience|Edit Link: %{link}": ["编辑链接：%{link}"],
            "Audience|Edit email": ["编辑邮件"],
            "Audience|Edit newsletter": ["编辑邮件"],
            "Audience|Email": ["邮件"],
            "Audience|Email address": ["邮箱"],
            "Audience|Enter site": ["进入网站"],
            "Audience|Excludes unreachable emails": ["不包括无法触达的邮箱"],
            "Audience|Export Audience CSV": ["导出粉丝数据"],
            "Audience|Export Form CSV": ["导出表单数据"],
            "Audience|Export audience profile": ["导出粉丝资料"],
            "Audience|Export includes all custom form fields.": [
              "包括自定义表单的所有字段",
            ],
            "Audience|Exporting": ["正在导出"],
            "Audience|Extremely likely": ["非常愿意！"],
            "Audience|Failed to activate": ["启用失败"],
            "Audience|Failed to send": ["发送失败"],
            "Audience|Filter your audience by site and source.": [
              "通过网站与来源筛选客户",
            ],
            "Audience|Follow up on mobile": ["在手机端跟进粉丝"],
            "Audience|Follow up on mobile after publishing this Mini Program.":
              ["发布小程序后即可在手机端跟进。"],
            "Audience|Follow up reports": ["跟进记录"],
            "Audience|Font Size": ["字体大小"],
            "Audience|For this Audience Plan, [boldText: you will be billed an additional $[pricing]/[period]] starting [trialEndsAt].":
              [
                "对于此营销套餐，[boldText: 你额外被收取的费用为$[pricing]/[period]]，将于[trialEndsAt]开始。",
              ],
            "Audience|For this Audience Plan, [boldText: you will be billed an additional $[pricing]/[period]].":
              ["若选择此套餐，[boldText: 每[period]的费用会增加$[pricing]]。"],
            "Audience|For this Audience Plan, [boldText: you will be billed an additional [originPrice] [currentPrice][period]] ([percentage]% off!) starting [trialEndsAt].":
              [
                "若选择此套餐，[boldText: 每[period]的费用会增加[originPrice] [currentPrice]] （[percentage]折优惠！）开始于 [trialEndsAt]。",
              ],
            "Audience|For this Audience Plan, [boldText: you will be billed an additional [originPrice] [currentPrice][period]] ([percentage]% off!).":
              [
                "若选择此套餐，[boldText: 每[period]的费用会增加[originPrice] [currentPrice]] （[percentage]折优惠！）.",
              ],
            "Audience|Form responses and contacts from your website audience will appear here!":
              ["表单回复与来自你网站的联系信息都会显示在这里！"],
            "Audience|Form responses, customers, memberships, and more!": [
              "表单提交、浏览顾客、设置会员以及更多！",
            ],
            "Audience|Forms": ["表单"],
            "Audience|Free Member": ["免费会员"],
            "Audience|Full Audience": ["全部粉丝"],
            "Audience|Got It!": ["明白了！"],
            "Audience|Grant Membership": ["授予会员资格"],
            "Audience|Grant Membership to": ["授予会员资格"],
            "Audience|Grant membership": ["授予会员资格"],
            "Audience|Have your team members write follow-up reports to advance the sales process.":
              ["让团队成员勤跟进、勤记录，可推进销售进程，助力赢单。"],
            "Audience|Hello": ["你好"],
            "Audience|Hi there! How can i help you?": [
              "嗨！欢迎！请问有什么能帮到您的吗？",
            ],
            "Audience|Hi there, welcome! Let me know if you have any questions, or if there's anything we can help with.":
              ["嗨！欢迎！请问有什么疑问，或能帮到您的吗？"],
            "Audience|Hide Spam": ["隐藏垃圾信息"],
            "Audience|How likely are you to recommend SXL to a friend or colleague?":
              ["你有多大可能向你的朋友或同事推荐使用上线了？"],
            "Audience|How likely are you to recommend Strikingly to a friend or colleague?":
              ["你有多大的可能性会向朋友或同事推荐 Strikingly?"],
            "Audience|I confirm that I have permission to send marketing emails to these contacts that I am about to upload.":
              ["我确认我即将上传的这些联系人都已允许我向他们发送营销邮件。"],
            "Audience|I confirm that I have permission to send marketing emails to this contact.":
              ["我确认我已获得该联系人的许可，可以向其发送营销邮件。"],
            "Audience|I'd like to place an order for a birthday cake!": [
              "我想订个生日蛋糕！",
            ],
            "Audience|Insert Recipient Name": ["插入收件人姓名"],
            "Audience|Invalid date!": ["日期无效！"],
            "Audience|Issues with sending audience email": ["粉丝邮件发送问题"],
            "Audience|Issues with sending email automation": [
              "自动邮件发送问题",
            ],
            "Audience|Issues with sending newsletter": ["营销邮件发送问题"],
            "Audience|Join affiliate program now": ["加入分销合伙人计划"],
            "Audience|Last 30 days": ["近 30 天"],
            "Audience|Last 7 days": ["近 7 天"],
            "Audience|Last 90 days": ["近 90 天"],
            "Audience|Last Contact": ["上次联系"],
            "Audience|Last Message": ["最近一次消息"],
            "Audience|Leave empty to link to your homepage": [
              "留空以链接到你的主页",
            ],
            "Audience|Limit reached": ["达到上限"],
            "Audience|Link To": ["链接到"],
            "Audience|Live Chat": ["在线聊天"],
            "Audience|Live chat available!": ["和我们在线聊聊吧！"],
            "Audience|Live chat by": ["在线聊天源自"],
            "Audience|Manually Imported": ["手动导入"],
            "Audience|Manually add a contact into your contact list for a single site.":
              ["为单个网站的粉丝列表手动录入一个联系人。"],
            "Audience|Mark As NonSpam": ["标记为非垃圾信息"],
            "Audience|Mark As Spam": ["标记为垃圾信息"],
            "Audience|Mark As Unread": ["标记为未读"],
            "Audience|Mark as Primary": ["标为主要"],
            "Audience|Maybe next time": ["下次再说"],
            "Audience|Members": ["商店会员"],
            "Audience|Membership": ["会员功能"],
            "Audience|Message": ["消息"],
            "Audience|Messages": ["消息"],
            "Audience|Minutes": ["分钟"],
            "Audience|Modify Page Access": ["修改页面访问权限"],
            "Audience|Modify page access": ["修改页面访问权限"],
            "Audience|Modify page access for %{emailText} on %{siteName}. This member will be able to access members-only pages associated with the selected products.":
              [
                "修改网站 %{siteName} 上 %{emailText} 的页面访问权限。 该会员将能够访问与所选商品关联的会员专享页面。",
              ],
            "Audience|Monthly": ["包月"],
            "Audience|More Actions": ["更多操作"],
            "Audience|More Options": ["更多选项"],
            "Audience|Name": ["姓名"],
            "Audience|Need a larger Audience Plan? [boldText: Contact us to get started!]":
              ["需要发邮件给更多客户？ [boldText: 联系我们吧！]"],
            "Audience|New": ["新"],
            "Audience|New orders will appear here.": [
              "新的订单将会显示在这里。",
            ],
            "Audience|Newsletter": ["邮件"],
            "Audience|Newsletter scheduled": ["定时发送邮件已生效"],
            "Audience|Next follow-up date：": ["下次跟进时间："],
            "Audience|No Plan Change": ["无变动"],
            "Audience|No follow-ups found": ["暂无跟进记录"],
            "Audience|No messages found": ["暂无消息"],
            "Audience|No orders found": ["暂无订单"],
            "Audience|No visit log found": ["暂无来访记录"],
            "Audience|Not at all likely": ["绝对不会"],
            "Audience|Not now...": ["暂无..."],
            "Audience|Order": ["订单"],
            "Audience|Order Canceled": ["订单已取消"],
            "Audience|Order Purchased": ["订单已支付"],
            "Audience|Order Refunded": ["订单已退款"],
            "Audience|Order Shipped": ["订单已发货"],
            "Audience|Orders": ["订单"],
            "Audience|Paid Member": ["付费会员"],
            "Audience|Phone": ["手机号"],
            "Audience|Physical Address (Required)": ["实体地址（必填）"],
            "Audience|Please confirm.": ["请确认。"],
            "Audience|Please enter valid email name.": ["请输入有效的邮箱名"],
            'Audience|Powered By <a href="%{link}" style="%{style}" target="_blank">Strikingly</a>':
              [
                '<a href="%{link}" style="%{style}" target="_blank">Strikingly</a>提供技术服务',
              ],
            'Audience|Powered By <a href="https://www.strikingly.com" target="_blank">Strikingly</a>':
              [
                '<a href="https://www.strikingly.com" target="_blank">Strikingly</a>提供技术支持',
              ],
            "Audience|Primary": ["主要的"],
            "Audience|Publish and share this Mini Program, and see the visitor log here.  (Unpublish)":
              ["发布小程序后，将小程序转发给ta，访问后可在此追踪浏览记录。"],
            "Audience|Purchase history": ["消费记录"],
            "Audience|Purchased %{itemCount} in order": [
              "购买 %{itemCount}  商品",
            ],
            "Audience|Recipients": ["收件人"],
            "Audience|Refunded order": ["退款订单"],
            "Audience|Register a new domain": ["注册新域名"],
            "Audience|Reply Now": ["立即回复"],
            "Audience|Reset Password": ["重置密码"],
            "Audience|Restore": ["恢复"],
            "Audience|Revenue": ["消费总额"],
            "Audience|Save": ["保存"],
            "Audience|Save As Draft": ["保存为草稿"],
            "Audience|Scan code with WeChat to chat.": ["微信扫码立即开始联系"],
            "Audience|Scan code with WeChat to follow up.": [
              "微信扫码立即开始跟进",
            ],
            "Audience|Schedule": ["设置生效"],
            "Audience|Schedule for later": ["定时发送"],
            "Audience|Schedule newsletter": ["定时发送邮件"],
            "Audience|Scheduled": ["定时发送"],
            "Audience|Scheduled %{var1}": ["%{var1}定时发送"],
            "Audience|Search...": ["搜索粉丝"],
            "Audience|Select Recipients": ["选择收件人"],
            "Audience|Select Site": ["选择网站"],
            "Audience|Select all": ["全选"],
            "Audience|Select date & time": ["选择日期时间"],
            "Audience|Select none": ["取消全部"],
            "Audience|Select site for granting membership": [
              "选择授予会员资格的网站",
            ],
            "Audience|Send": ["发送"],
            "Audience|Send From Custom Domain": ["发自自定义域名"],
            "Audience|Send Newsletter": ["发送邮件"],
            "Audience|Send Newsletter Now": ["立即发送邮件"],
            "Audience|Send Now": ["立即发送"],
            "Audience|Send Test Email": ["发送测试邮件"],
            "Audience|Send Via Email": ["通过邮箱发送"],
            "Audience|Send test email": ["发送测试邮件"],
            "Audience|Sending": ["发送中"],
            "Audience|Sent": ["已发送"],
            "Audience|Set physical address (required)": [
              "设置实体地址（必填）",
            ],
            "Audience|Set the email address and domain that your newsletter will be sent from. (if your desired domain isn't in this list, please [registerLink: register a new domain] or [transferLink: transfer a domain].)":
              [
                "设置自定义域名做为你的邮箱地址。（如果你想要的域名不在列表中，请[registerLink: 注册新域名]或[transferLink: 转入域名]。)",
              ],
            "Audience|Share this Mini Program and see the visitor log here.": [
              "将小程序转发给ta，访问后可在此追踪浏览记录。",
            ],
            "Audience|Share this Mini Program to open a one-on-one conversation.":
              ["将小程序转发给ta，开启一对一专属咨询通道。"],
            "Audience|Shipped order": ["发货订单"],
            "Audience|Show Spam": ["显示垃圾信息"],
            "Audience|Signup Form": ["注册表单"],
            "Audience|Site Audience": ["客户列表"],
            "Audience|Site:": ["网站："],
            "Audience|Sorry! %{firstName} is helping another customer at the moment. Can you write down your questions? %{firstName} will get back to you as soon as possible. Thank you!":
              [
                "抱歉！ %{firstName}目前正在帮助其他客户。你能写下你的问题吗？ %{firstName}会尽快回复您。谢谢！",
              ],
            "Audience|Source:": ["来源："],
            "Audience|Start 7-Day Trial": ["开始7天试用"],
            "Audience|Start one now!": ["开始新建一个！"],
            "Audience|Starting [startDate], [boldText: your Audience Plan will change to $[pricing]/[period]].":
              [
                "开始于 [startDate], [boldText: 你的套餐价格将变为 $[pricing]/[period]].",
              ],
            "Audience|Starting [startDate], [boldText: your Audience Plan will change to [originPrice] [currentPrice][period]] ([percentage]% off!).":
              [
                "开始于 [startDate], [boldText: 你的套餐价格会改变为 [originPrice] [currentPrice][period]] ([percentage]折优惠！).",
              ],
            "Audience|Stats": ["统计"],
            "Audience|Status": ["状态"],
            "Audience|Store Customer": ["商店顾客"],
            "Audience|Subject": ["主题"],
            "Audience|Submit": ["提交"],
            "Audience|Subscribed to blog": ["订阅博客"],
            "Audience|Success! Your Audience Plan now allows for %{contactsNumber} active contacts. Make your users love you!":
              [
                "成功！你的营销套餐现在允许%{contactsNumber}个有效联系人。让你的用户爱上你！",
              ],
            "Audience|Success! Your Audience Plan will allow for %{var2} active contacts when your monthly cycle renews. (It still allows for %{var1} active contacts during the current monthly cycle.)":
              [
                "成功！你的营销套餐将在你的月周期更新后允许%{var2} 个有效联系人。（在当前月周期内仍然允许%{var1}个有效联系人。）",
              ],
            "Audience|Success! Your Audience Plan will allow for %{var2} active contacts when your yearly cycle renews. (It still allows for %{var1} active contacts per month during the current yearly cycle.)":
              [
                "成功！你的营销套餐将在你的年周期更新后允许%{var2} 个有效联系人。（在当前年周期内仍然允许每月%{var1}个有效联系人。）",
              ],
            "Audience|Sure thing!": ["没问题！"],
            "Audience|Tags": ["标签"],
            "Audience|Thank you for your feedback!": ["感谢你的反馈！"],
            "Audience|The Audience Plan is an add-on that unlocks Live Chat for your site, register more site memberships, and send newsletters to a wider audience. You must first upgrade your account to [strong: Limited, Pro, or VIP] to be able to add an Audience Plan.":
              [
                "营销套餐是一个附加套餐，有了它，你的网站就能开启在线聊天功能，拥有更多会员名额，还可以向更多客户发送营销推广邮件。不过，首先你要升级到[strong:基础版，专业版或VIP套餐]，才能够添加营销套餐。",
              ],
            "Audience|The free trial of Audience Plan will end and you will start to be billed.":
              ["你的营销套餐免费试用即将结束，将要开始进行收费。"],
            "Audience|The subject line of the email. Keep it short and clear.":
              ["邮件主题。写得简短清晰点。"],
            "Audience|This contact has unsubscribed.": ["此联系人已取消订阅。"],
            "Audience|This contact's email is unreachable.": [
              "此联系人的邮箱无法触达。",
            ],
            "Audience|This email cannot be activated because we think [link:its content] might contain spam. Please edit your email and try again.":
              [
                "这封邮件的[link:内容]可能包含垃圾信息，因此无法启用。请重新编辑后再尝试发送。",
              ],
            "Audience|This email cannot be sent because we think [link:its content] might contain spam. Please edit your email and try again.":
              [
                "这封邮件的[link:内容]可能包含垃圾信息，因此无法送达。请重新编辑后再尝试发送。",
              ],
            "Audience|This email cannot be sent because we think its content might contain spam. Please edit your email and try again.":
              [
                "这封邮件的内容可能包含垃圾信息，因此无法送达。请重新编辑后再尝试发送。",
              ],
            "Audience|This email seems to be unreachable. Please enter a valid email.":
              ["这个邮箱似乎无法触达，请输入一个有效的邮箱。"],
            "Audience|This newsletter cannot be sent because we think [link:its content] might contain spam. Please edit your newsletter and try again.":
              [
                "这封邮件的[link:内容]可能包含垃圾信息，因此无法送达。请重新编辑后再尝试发送。",
              ],
            "Audience|This newsletter will be delivered to %{num} recipients. This action cannot be undone!":
              ["该邮件将会被分开发送至 %{num} 收件人。该操作不可逆！"],
            "Audience|This newsletter will be sent automatically at the scheduled date & time. (Timezone: [Timezone])":
              ["该邮件将于选定日期和时间自动发送 (时区: [Timezone]）"],
            "Audience|This newsletter will be sent automatically on %{date}. (Timezone: %{Timezone})":
              ["该邮件将于%{date}自动发送 (时区: %{Timezone}）"],
            "Audience|To improve deliverability, we automatically remove duplicate, unreachable, and unsubscribed contacts.":
              [
                "为了提高送达率，我们会自动移除重复的、无法触达的、以及取消订阅的联系人。",
              ],
            "Audience|Total": ["金额"],
            "Audience|Total number of orders": ["全部订单数"],
            "Audience|Total value of all orders": ["全部订单消费总额"],
            "Audience|Total view duration in this Mini Program": [
              "浏览小程序的停留时长",
            ],
            "Audience|Total visits in this Mini Program": [
              "浏览小程序的总次数",
            ],
            "Audience|Transfer domain to Strikingly": ["转入域名到 Strikingly"],
            "Audience|Type a message...": ["输入消息..."],
            "Audience|Unassigned": ["未分配"],
            "Audience|Unlock Live Chat, Membership, and Newsletters": [
              "解锁在线聊天、会员功能、营销邮件",
            ],
            "Audience|Unreachable": ["无法触达"],
            "Audience|Unreachable Contacts": ["无法触达的联系人"],
            "Audience|Unsubscribe": ["取消订阅"],
            "Audience|Unsubscribed": ["取消订阅"],
            "Audience|Unsubscribed Contacts": ["取消订阅的联系人"],
            "Audience|Unsubscribed from blog": ["取消博客订阅"],
            "Audience|Unused time on your current plan will be pro-rated and discounted.":
              ["当前套餐剩余的时间会自动按比例计算并抵扣。"],
            "Audience|Update：": ["跟进概况："],
            "Audience|Upgrade Audience Plan": ["升级营销版套餐"],
            "Audience|Upgrade Plan": ["升级套餐"],
            "Audience|Upgrade audience plan": ["升级营销版套餐"],
            "Audience|Upgrade to Pro": ["升级到专业版"],
            "Audience|Upgrade to an Audience Plan to unlock [strong: Live Chat], open site membership registrations, and send more newsletters to your active contacts.":
              [
                "升级至营销套餐，可解锁 [strong:在线聊天]及网站会员功能，还可以给更多的活跃客户发送营销推广邮件。",
              ],
            "Audience|Upgrade your Audience Plan to allow more.": [
              "请升级营销套餐以增加有效联系人上限。",
            ],
            "Audience|Upgrade your Audience Plan to collect more memberships on your sites. Each membership counts as an active contact. All Audience plans unlock Live Chat on your sites.":
              [
                "升级至营销套餐，吸引更多会员。每位会员都是网站的活跃联系人。营销套餐已附送「在线聊天」功能。",
              ],
            "Audience|Upload Image": ["上传图片"],
            "Audience|Upload a list of contacts into your contact list for a single site. CSV file must be a in a specific format.":
              [
                "上传多个联系人至单个网站的粉丝列表中。CSV文件必须为规定的格式。",
              ],
            "Audience|Use this address": ["使用这个邮箱地址"],
            "Audience|View Duration": ["停留时长"],
            "Audience|View Site Audience": ["查看客戶列表"],
            "Audience|View more": ["查看更多"],
            "Audience|Visitor log": ["来访记录"],
            "Audience|Visits": ["浏览次数"],
            "Audience|We've been hard at work and we're proud to announce our launch! We're always&nbsp;dedicated to serving your needs, so feel free to reply with any questions.":
              [
                "经过不懈努力，我们隆重发布我们的新产品！ 我们将始终竭诚为您服务。如有任何问题，请随时回复。",
              ],
            "Audience|What is one thing we could do to make you more successful with SXL?":
              ["如果 上线了 能给你提供更多价值，它会是什么？"],
            "Audience|What is one thing we could do to make you more successful with Strikingly?":
              ["如果我们能做一件事让 Strikingly 给你更多价值，会是什么？"],
            "Audience|What kind would you like?": ["你想要怎么样的蛋糕？"],
            "Audience|What was missing or disappointing in your experience with us?":
              ["让你觉得不满意或者失望的点都有什么？"],
            "Audience|What's one thing that would make SXL even better?": [
              "我们能做哪一件事让 上线了 更棒？",
            ],
            "Audience|What's one thing that would make Strikingly even better?":
              ["我们能做哪一件事让 Strikingly 更棒？"],
            "Audience|Would you like to save this newsletter as a draft?": [
              "你想要保存邮件为草稿吗？",
            ],
            "Audience|Yearly": ["包年"],
            "Audience|Yesterday": ["昨天"],
            "Audience|You can have up to %{activeContacts} active contacts each month. Please [upgrade: upgrade your Audience Plan] to allow for more.":
              [
                "你每月最多可以有 %{activeContacts} 个有效联系人。请[upgrade:升级你的营销套餐]以增加有效联系人上限。",
              ],
            "Audience|You don't have enough available active contacts or emails on your audience plan to send this newsletter. You can upgrade your audience plan or wait until your monthly cycle renews.":
              [
                "你的营销版套餐中可用的有效联系人数量不足，无法发送营销邮件。你可以升级你的营销版套餐或等待你的月周期更新。",
              ],
            "Audience|You haven't sent any newsletters yet. [startLink]": [
              "你还没发过任何邮件。 [startLink]",
            ],
            "Audience|You must select at least one site and one source.": [
              "你必须至少选择一个网站及其来源。",
            ],
            "Audience|You're currently on the selected Audience Plan.": [
              "这是你目前使用的套餐。",
            ],
            "Audience|You've hit your limit of %{activeContacts} active contacts per month. Please [upgrade: upgrade your Audience Plan] to allow for more.":
              [
                "你已达到每月最多 %{activeContacts} 有效联系人的上限了。请[upgrade:升级你的营销套餐]以增加有效联系人上限。",
              ],
            "Audience|You've reached the limit for contacts this month.": [
              "本月额度已经用完。",
            ],
            "Audience|Your Audience Plan has been cancelled. You can still have %{var} active contacts each month.":
              [
                "你的营销套餐已被取消。 每个月你仍然可以拥有%{var}个有效联系人。",
              ],
            "Audience|Your current plan allows for %{totalQuota} active contacts.":
              ["当前套餐有效联系人为%{totalQuota} 。"],
            "Audience|[New Live Chat]": ["[你有新的聊天信息]"],
            "Audience|[boldText: Please contact us to make this change to your Audience Plan]":
              ["[boldText: 请与我们联系更改套餐]"],
            "Audience|[boldText: You Audience will be canceled and you will no longer be billed for it]. Live Chat will be disabled on your sites.":
              [
                "[boldText: 你的营销版套餐将被取消。取消后，你不会再收到账单]。并且即时聊天功能也会被关闭。",
              ],
            "Audience|[link:Upgrade to an Audience Plan] to enable Live Chat and send more emails.":
              ["[link:升级到营销版套餐]来开启在线聊天和发送更多的营销邮件。"],
            "Audience|[strong: Grow your audience] by collecting signups and forms from your sites.":
              ["通过网站收集注册以及提交表单来[strong: 增长你的客户群]。"],
            "Audience|[strong: Send emails and newsletters] directly to your audience using this dashboard! [link: Learn more.]":
              [
                "在你的控制面板[strong: 直接发送邮件和推广]给你的客户！ [link: 了解更多。]",
              ],
            "Audience|[strong:Grow your audience] by collecting signups and forms from your sites.":
              ["通过网站收集注册以及提交表单来[strong: 增长你的客户群]。"],
            "Audience|[strong:Send emails and newsletters] directly to your audience using this dashboard! [link: Learn more.]":
              [
                "在你的控制面板[strong: 直接发送邮件和推广]给你的客户！ [link: 了解更多。]",
              ],
            "Audience|and %{number} items": ["等 %{number} 件商品"],
            "Audience|blog subscription": ["博客订阅"],
            "Audience|clicked": ["已点击"],
            "Audience|contact form": ["联系表单"],
            "Audience|item": ["件"],
            "Audience|items": ["件"],
            "Audience|more than %{var}": ["超过 %{var}"],
            "Audience|opened": ["已开启"],
            "Audience|reply": ["回复"],
            "Audience|signup form": ["注册表单"],
            "Audience|store": ["商店"],
            "Audience|via": ["来自"],
            "Audience|via email": ["通过邮箱"],
            "Auth/EPP Code": ["Auth/EPP 代码"],
            "Auto Play": ["自动播放"],
            "Auto Popup Greeting Message": ["自动弹窗欢迎语"],
            Automatic: ["自动的"],
            "BLOG POST": ["博客文章"],
            Back: ["返回"],
            "Back to Edit Styles": ["返回至风格设计"],
            Background: ["背景"],
            "Baidu Analytics Tracker": ["百度站长工具验证"],
            "Billed every 10 years": ["按每10年收费"],
            "Billed every 2 years": ["按2年收费"],
            "Billed every 3 years": ["按三年收费"],
            "Billed every 5 years": ["按每五年收费"],
            "Billed monthly": ["按月收费"],
            "Billed yearly": ["按年收费"],
            "Billing ZIP/Postal": ["账单邮编"],
            Biz: ["企业版"],
            "Biz/Pro": ["企业版/专业版"],
            Blog: ["博客"],
            "Blog Manager": ["博客管理"],
            "Blog Posts": ["博客文章"],
            "Blog Settings": ["博客设置"],
            "Blog|%{number} comments pending": ["%{number} 条评论待审核"],
            "Blog|%{number} days ago": ["%{number} 天前"],
            "Blog|%{num} posts": ["%{num} 篇博客"],
            "Blog|%{var1} posts selected": ["已选中%{var1}篇文章"],
            "Blog|1 comment pending": ["1条评论待审核"],
            "Blog|1 post selected": ["已选中1篇文章"],
            "Blog|<em>Simplicity is the ultimate sophistication. - Leonardo da Vinci</em>":
              ["<em>至繁归于至简。 - 达芬奇</em>"],
            "Blog|About": ["关于"],
            "Blog|About content review:": ["请注意内容审核："],
            "Blog|Add Categories": ["添加博客分类"],
            "Blog|Add New Category": ["添加博客分类"],
            "Blog|Add a Blog Post Title": ["添加博客标题"],
            "Blog|Add a Subtitle": ["添加副标题"],
            "Blog|Add a heading here.": ["添加标题"],
            "Blog|Add categories (up to 5)": ["添加博客分类 (最多5个)"],
            "Blog|Add, rename, reorder, and delete blog categories. You can add categories in blog posts in the blog editor as well.":
              [
                "添加、重命名、重新排序以及删除博客分类。你也可以在编辑博客文章时添加博客分类。",
              ],
            "Blog|Address": ["地址"],
            "Blog|All Categories": ["所有博客分类"],
            "Blog|All Posts": ["所有文章"],
            "Blog|Allow visitors to subscribe to this blog": [
              "允许访客通过邮件订阅",
            ],
            "Blog|Almost done…": ["还剩一步！"],
            "Blog|Analytics": ["博客数据"],
            "Blog|Approve": ["允许"],
            "Blog|Approve all": ["全部允许"],
            "Blog|Are you absolutely sure you want to copy %{var1} selected posts to the target blog?":
              ["你确定要复制%{var1}篇文章到另一博客吗？"],
            "Blog|Are you absolutely sure you want to delete %{var1} selected posts? All keyword links in other related posts will be removed. This action cannot be undone!":
              [
                "你确定要删除选中的%{var1}篇文章吗？所有相关文章中的关键词链接将被删除。此操作无法撤回！",
              ],
            "Blog|Are you absolutely sure you want to delete %{var1} selected posts? This action cannot be undone!":
              ["你确定要删除选中的%{var1}篇文章吗？此操作无法撤回！"],
            "Blog|Are you absolutely sure you want to delete 1 selected post? All keyword links in other related posts will be removed. This action cannot be undone!":
              [
                "你确定要删除选中的1篇文章吗？所有相关文章中的关键词链接将被删除。此操作无法撤回！",
              ],
            "Blog|Are you absolutely sure you want to delete the selected post? This action cannot be undone!":
              ["你确定要删除选中的这篇文章吗？此操作无法撤回！"],
            "Blog|Are you absolutely sure you want to move %{var1} selected posts to the target blog? They will be deleted from the current blog.":
              [
                "你确定要移动%{var1}篇文章到另一博客吗？复制完成后当前博客会删除这些文章",
              ],
            "Blog|Are you absolutely sure you want to publish %{var1} selected posts?":
              ["你确定要发布选中的%{var1}篇文章吗？"],
            "Blog|Are you absolutely sure you want to publish %{var1} selected posts? They will be linked from other related posts. If you want to check each link, please publish them separately.":
              [
                "你确定要发布选中的%{var1}篇文章吗？他们将被作为关键词链接插入到其他相关文章中。如果你想检查每个链接，请单独发布他们。",
              ],
            "Blog|Are you absolutely sure you want to unpublish %{var1} selected posts? All keyword links in other related posts will be removed. (They can be added back when you republish.)":
              [
                "你确定要取消发布选中的%{var1}篇文章吗？所有相关文章中的关键词链接将被删除。(你可以在重新发布时把它们添加回来。)",
              ],
            "Blog|Are you absolutely sure you want to unpublish 1 selected post? All keyword links in other related posts will be removed. (They can be added back when you republish.)":
              [
                "你确定要取消发布选中的1篇文章吗？所有相关文章中的关键词链接将被删除。(你可以在重新发布时把它们添加回来。)",
              ],
            "Blog|Are you sure you want to copy the selected post to the target blog?":
              ["你确定要复制这篇文章到另一博客吗？"],
            "Blog|Are you sure you want to copy the selected posts?": [
              "你确定要复制选中的文章吗？",
            ],
            "Blog|Are you sure you want to delete this comment?": [
              "你确定要删除这条评论吗？",
            ],
            "Blog|Are you sure you want to mark this comment as spam?": [
              "你确定要将这条评论标记为垃圾信息吗？",
            ],
            "Blog|Are you sure you want to move the selected post to the target blog? It will be deleted from the current blog.":
              [
                "你确定要移动这篇文章到目标博客吗。复制完成后当前博客会删除这篇文章。",
              ],
            "Blog|Are you sure you want to publish selected post?": [
              "你确定要发布选中的这篇文章吗？",
            ],
            "Blog|Are you sure you want to remove the password for this post? This post will be public for all visitors.":
              ["确定要移除这篇文章的密码？这篇文章将对所有人可见。"],
            "Blog|Are you sure you want to set a password for this post? Visitors must enter the password to see the post content.":
              ["确定要为这篇文章设置密码？访客需要输入密码才能浏览文章内容。"],
            "Blog|Are you sure you wish to delete these subscription entries? Removing a blog subscription entry will delete the subscription":
              [
                "确定删除这些订阅者？确认删除后，这些订阅者不会再收到任何的订阅邮件。",
              ],
            "Blog|BACKGROUND IMAGE": ["博客背景图"],
            "Blog|Back To Blog Settings": ["返回博客设置"],
            "Blog|Batch Manage": ["批量管理博客"],
            "Blog|Be careful! Deleting this category is a permanent and irreversible action! It will be deleted from all posts under this category. Are you sure you still want to delete this category?":
              [
                "注意！删除此博客分类是一个永久的不可逆转的操作！删除后这个分类标签将从该分类下的所有博客文章中移除。仍然确定删除该分类吗？",
              ],
            "Blog|Blog": ["博客"],
            "Blog|Blog Categories": ["博客分类"],
            "Blog|Blog Post Header": ["博文页眉"],
            "Blog|Blog Post Order": ["博文排序"],
            "Blog|Blog Posts": ["博客文章"],
            "Blog|Blog Subscription": ["博客订阅"],
            "Blog|Cancel": ["取消"],
            "Blog|Cancel Reply": ["取消回复"],
            "Blog|Cancel schedule": ["撤销定时上线"],
            "Blog|Categories": ["博客分类"],
            "Blog|Categories can only contain letters, numbers, spaces and dashes.":
              ["博客分类只能包含字母、数字、空格和中划线"],
            "Blog|Change meta description": ["更改网站描述"],
            "Blog|Choose how to show more posts": [
              "选择怎么显示更多的博客文章",
            ],
            "Blog|Comments require approval": ["评论需要审核"],
            "Blog|Confirm subscription in email.": ["请登录邮箱，完成订阅。"],
            "Blog|Contact": ["联系"],
            "Blog|Copy %{var1} posts to another blog": [
              "复制%{var1}篇文章到另一博客",
            ],
            "Blog|Copy post to another blog": ["复制文章到另一博客"],
            "Blog|Copy to": ["复制到"],
            "Blog|Date": ["日期"],
            "Blog|Date Hidden": ["日期已设为隐藏"],
            "Blog|Delete": ["删除"],
            "Blog|Delete %{var1} selected posts from current blog after copying":
              ["复制并在当前博客删除选中的%{var1}篇文章"],
            "Blog|Delete selected": ["删除选中的"],
            "Blog|Delete selected post from current blog after copying": [
              "复制并在当前博客删除选中的文章",
            ],
            "Blog|Disqus Comments": ["Disqus 评论"],
            "Blog|Document": ["文档"],
            "Blog|Drag to reorder": ["拖动进行排序"],
            "Blog|Duplicate": ["复制"],
            "Blog|Edit": ["编辑"],
            "Blog|Edit in blog settings": ["在博客设置里编辑"],
            "Blog|Edit publish date": ["编辑发布日期"],
            "Blog|Email": ["电子邮件"],
            "Blog|Email address": ["邮箱地址"],
            "Blog|Enable Comments": ["允许评论"],
            "Blog|Enable Subscriptions": ["开启博客订阅"],
            "Blog|Enable Subscriptions & Comments": ["允许订阅和评论"],
            "Blog|Enable comments": ["允许评论"],
            "Blog|Enable subscription": ["开启订阅"],
            "Blog|Export all to excel": ["导出所有到Excel"],
            "Blog|Footer Code": ["页脚代码"],
            "Blog|Header Code": ["页眉代码"],
            "Blog|Heading 1": ["标题1"],
            "Blog|Heading 2": ["标题2"],
            "Blog|Heading 3": ["标题3"],
            "Blog|Heading 4": ["标题4"],
            "Blog|Heading 5": ["标题5"],
            "Blog|Home": ["首页"],
            "Blog|If you confirm the copying, some selected posts may not have a category set.":
              ["如果你继续复制，一些选定的文章在目标博客可能会没有博客分类。"],
            "Blog|Invalid email address": ["无效邮箱"],
            "Blog|Keep existing status (published, draft, or scheduled)": [
              "保留当前状态(已发布，草稿或已定时）",
            ],
            "Blog|Let visitors subscribe to this blog. View blog subscriptions in your Audience list.":
              [
                "访客订阅后将收到更新提醒。你可以在“粉丝列表”中查看所有订阅者。",
              ],
            "Blog|Let visitors subscribe using Strikingly’s own subscription service.":
              ["让访客订阅你的简易博客文章更新"],
            "Blog|Link to": ["链接至"],
            "Blog|Manage blog categories": ["管理博客分类"],
            "Blog|Mark as spam": ["标记为垃圾信息"],
            "Blog|Meta Description": ["元描述"],
            "Blog|More Options": ["更多选项"],
            "Blog|More Posts": ["查看更多"],
            "Blog|Most viewed blog posts": ["浏览最多的文章"],
            "Blog|Newer": ["更新"],
            "Blog|Newest to oldest": ["从新到旧"],
            "Blog|Next": ["下一篇"],
            "Blog|Next Post": ["下一篇"],
            "Blog|No posts": ["您还没有博客"],
            "Blog|Normal text": ["正文"],
            "Blog|OK": ["好的"],
            "Blog|Older": ["更早"],
            "Blog|Oldest to newest": ["从旧到新"],
            "Blog|Open in new tab": ["在新标签页中打开"],
            "Blog|Optional. A custom description for SEO and sharing. Keep it short!":
              ["选填：针对 SEO 以及分享所添加的描述，请控制字数，尽量简短"],
            "Blog|Pin this post so it always appears at the top": [
              "置顶这篇文章，这样它就会一直显示在博客的顶部。",
            ],
            "Blog|Pin to top": ["置顶"],
            "Blog|Pinned": ["已置顶"],
            "Blog|Please click the link in the email to confirm your subscription!":
              ["请点击邮件中的确认链接，完成订阅。"],
            "Blog|Please enter a comment.": ["请输入你的评论。"],
            "Blog|Please enter a name.": ["请输入你的名字。"],
            "Blog|Please enter a valid email.": ["请输入有效的邮箱"],
            "Blog|Post Settings": ["博文设置"],
            "Blog|Post Title": ["文章标题"],
            "Blog|Post duplicated.": ["文章已复制。"],
            "Blog|Posts will be reset to draft status after copying": [
              "文章在复制后将被重置为草稿状态",
            ],
            "Blog|Powered by SXL": ["上线了提供技术支持"],
            "Blog|Powered by Strikingly": ["上线了提供技术支持"],
            "Blog|Previous": ["上一篇"],
            "Blog|Previous Post": ["上一篇"],
            "Blog|Publish now": ["立即上线"],
            "Blog|Quote": ["引用"],
            "Blog|RETURN": ["返回"],
            "Blog|Read Instructions": ["流程说明"],
            "Blog|Read more": ["查看更多"],
            "Blog|Rejected": ["审核未通过"],
            "Blog|Remove Document": ["移除文档"],
            "Blog|Remove Email": ["移除电子邮箱"],
            "Blog|Remove Link": ["移除链接"],
            "Blog|Reply": ["回复"],
            "Blog|Reply to %{name}": ["回复%{name}"],
            "Blog|Reply to All": ["回复全部"],
            "Blog|Return to site": ["回到主页"],
            "Blog|SITE NAME": ["网站名称"],
            "Blog|Save": ["保存"],
            "Blog|Schedule": ["定时上线"],
            "Blog|Schedule for later": ["定时上线"],
            "Blog|Scheduled": ["已定时"],
            "Blog|Scheduled for %{var}": ["%{var} 定时上线"],
            "Blog|Select Mini Program...": ["选择小程序..."],
            "Blog|Select date & time": ["选择日期时间"],
            "Blog|Select site...": ["选择网站…"],
            "Blog|Select target Mini Program": ["选择要复制到的小程序"],
            "Blog|Select target site": ["选择要复制到的网站"],
            "Blog|Send to all subscribers": ["发送给所有的订阅者"],
            "Blog|Set all as draft": ["设置所有复制的文章为草稿状态"],
            "Blog|Set all as published": ["设置所有复制的文章为已发布状态"],
            "Blog|Set publish status of copied posts": [
              "设置文章在目标博客中的发布状态",
            ],
            "Blog|Show Date": ["显示日期"],
            "Blog|Show more posts:": ["以哪种方式显示更多博客文章："],
            "Blog|Show site navigation menu": ["显示网站导航菜单"],
            "Blog|Small text": ["小字号"],
            "Blog|Standalone post layout": ["独立博文布局"],
            "Blog|Start writing here...": ["此处输入内容..."],
            "Blog|Status": ["状态"],
            "Blog|Strikingly Subscriptions": ["上线了博客订阅"],
            "Blog|Submit": ["提交"],
            "Blog|Subscribe": ["订阅"],
            "Blog|Subscriptions": ["订阅"],
            "Blog|Subscriptions powered by Strikingly": ["上线了提供技术支持"],
            "Blog|Tags can only contain letters, numbers, spaces, and dashes.":
              ["标签只可以包含字母，数字，空格和横线"],
            "Blog|The destination blog has reached the limit for categories!": [
              "目标博客中的博客分类数量达到上限！",
            ],
            "Blog|The selected Mini Program doesn’t have blog at the moment. You can add a blog section to that site to allow it to receive blog posts":
              [
                "你选择的小程序当前没有博客部分。您需要先为它添加博客部分来接收文章。",
              ],
            "Blog|The selected site doesn’t have blog at the moment. You can add a blog section to that site to allow it to receive blog posts.":
              [
                "你选择的网站当前没有博客部分。您需要先为它添加博客部分来接收文章。",
              ],
            "Blog|There are no published blog posts yet.": [
              "还没有发布任何博客文章。",
            ],
            "Blog|This is an existing category.": ["该博客分类已存在"],
            "Blog|This post is password-protected.": [
              "这篇文章设置了密码保护。",
            ],
            "Blog|This post is scheduled to be published on %{var1}": [
              "文章将于%{var1}自动上线",
            ],
            "Blog|This post is scheduled to be published on %{var1} (Timezone: [Timezone])":
              ["文章将于%{var1}自动上线 (时区: [Timezone])"],
            "Blog|This post will be published automatically on %{var}  (Timezone: %{var2}).":
              ["文章将于%{var}自动上线 (时区: %{var2})"],
            "Blog|To disable Mailchimp subscription, remove the Mailchimp embebed code and save changes.":
              [
                "要停止使用Mailchimp订阅服务，请清除Mailchimp的嵌入代码，然后点击“保存”。",
              ],
            "Blog|To enable Disqus comments, you must register your site with Disqus.com.":
              ["要启用 Disqus 评论，你需要在 Disqus.com 注册你的站点"],
            "Blog|Try different layouts for blog!": ["试试不同的博客布局"],
            "Blog|URL": ["网址"],
            "Blog|Unpin": ["取消置顶"],
            "Blog|View": ["查看"],
            "Blog|We just sent you an email.": ["确认邮件已发至你的邮箱。"],
            "Blog|Web": ["网址"],
            "Blog|Websites and articles that use the second-level domain name 'sxl' need to be reviewed before going online, which takes about 2-3 days. Please allow sufficient time to avoid waiting for the review to affect the on-time launch.":
              [
                "使用二级域名「上线了」的网站&文章上线前需要审核，耗时约2-3天。请预留充足时间，避免等待审核影响准时上线。",
              ],
            "Blog|Write comment...": ["输入评论..."],
            "Blog|Year": ["年"],
            "Blog|You can only add up to 30 categories per site.": [
              "每个网站最多可以添加30个博客分类",
            ],
            "Blog|You don't have any posts tagged under this category yet.": [
              "该分类下还没有博客文章",
            ],
            "Blog|You don't have any posts yet.": ["您还没有任何博客文章"],
            "Blog|You don't have any subscribers yet.": [
              "你还没有任何订阅者。",
            ],
            "Blog|You have no published blog posts in this category yet. Click here to start writing!":
              ["该分类中还没有发布过的博客文章。点击这里开始编辑！"],
            "Blog|You have no published blog posts yet. Click here to start writing!":
              ["您还没有发布过的博客文章。点击这里开始编辑！"],
            "Blog|You've already subscribed to this blog!": [
              "你已订阅这个博客",
            ],
            "Blog|Your Disqus shortname": ["你的 Disqus 缩略名"],
            "Blog|Your comment is pending approval.": ["评论待审核。"],
            "Blog|Your subscribers will get an email to drive traffic to your newly published blog post!":
              ["订阅者会收到你新发布文章的邮件通知"],
            "Blog|[strong: You’re using the new version!] If you’re unsatisfied with the new blog editor, please contact support and we can help you revert to the old one!":
              [
                "[strong: 正在使用最新版本！] 如果你对博客编辑器有任何建议或疑问，欢迎联系客服寻求帮助。如有需要，我们可以帮助你切换回旧版。",
              ],
            "Blog|a day ago": ["1 天前"],
            "Blog|by pagination": ["用分页按钮"],
            "Blog|comments pending approval!": ["待审核的评论！"],
            "Blog|e.g. Entrepreneurship, Creativity. Useful if you have lots of posts! This lets your viewers search by category.":
              [
                "例如：创业，创新。如果你有很多博客文章，这将让你的访客更容易找到他们想要的类别。",
              ],
            "Blog|e.g. http://abc.com OR #2 (section number)": [
              "例如：http://abc.com 或者 #2 (版块号码)",
            ],
            "Blog|e.g. john@example.com": ["例如：jc@example.com"],
            "Blog|in archive popup": ["在弹出框中"],
            "Blog|more comments...": ["更多评论..."],
            Blue: ["天蓝"],
            "Booking|Adding Multiple Events is a Pro feature": [
              "添加多个服务是专业版功能",
            ],
            "Booking|Event Limit": ["服务数量超出限制"],
            "Booking|On the %{var1} plan, you can only add %{var2} %{var3}. Please upgrade to add more events.":
              [
                "在%{var1}套餐中，你只能添加%{var2}个%{var3}。请升级套餐以添加更多服务。",
              ],
            "Booking|Upgrade to add more events": ["升级套餐添加更多服务"],
            "Booking|event": ["服务"],
            "Booking|events": ["服务"],
            "Browse your computer": ["在本地文件中浏览"],
            "Buy Extra %{type} Sites": ["购买额外的%{type}网站"],
            "Buy extra sites": ["购买额外网站"],
            "By continuing, you agree to Strikingly's %{var1} and %{var2}.": [
              "注册即表示你已同意 Strikingly 的%{var1}和%{var2}。",
            ],
            'By continuing, you agree to our <a href="/?open=terms-and-conditions">Terms &amp; Conditions</a> and <a href="/?open=privacy-policy">Privacy Policy</a>.':
              [
                '继续操作即表示您同意我们的<a href="/?open=terms-and-conditions">条款及细则条件</a>和<a href="/?open=privacy-policy">隐私政策</a>。',
              ],
            CANCEL: ["取消"],
            CONNECT: ["绑定"],
            Cancel: ["取消"],
            "Cancel Order": ["取消订单"],
            "Cancel publishing": ["取消上线"],
            "Cancel, stay as single page": ["取消，单页面就好"],
            "Card Number": ["卡号"],
            "Cardholder's First Name": ["持卡人姓名"],
            "Cardholder's Last Name": ["持卡人的姓"],
            Category: ["网站类别"],
            Center: ["居中"],
            Change: ["修改"],
            "Change PayPal Account": ["更改 PayPal 账户"],
            "Change URL": ["更改域名"],
            "Change background color": ["更改背景颜色"],
            "Chat with our Happiness Officers!": ["与我们的客服交流"],
            "Check up on daily, weekly, and monthly pageview stats and more.": [
              "查看每日，每周，每月的页面访客量及更多数据！",
            ],
            "Checking this box will hide your site from all search engines.": [
              "勾选后网站将屏蔽所有搜索引擎",
            ],
            "Cheers!": ["十分感谢！"],
            "Choose A Domain Now": ["立刻挑选域名"],
            "Choose a site": ["选择一个网站"],
            "Choose the Facebook page you'd like to stream posts from:": [
              "请选择你要同步的 Facebook 公共主页：",
            ],
            City: ["城市"],
            "Claim Free Email Account": ["领取免费的邮箱账号"],
            "Claim My Free Domain": ["领取我的免费域名！"],
            Clear: ["简明"],
            "Clear All Spam": ["清除全部垃圾邮件"],
            'Click "Add New Section" in the toolbar to add content!': [
              "点击左侧菜单栏中的“添加新版块”按钮，来添加内容！",
            ],
            "Click here to add social media accounts to your feed!": [
              "点击这里，在频道中添加社交媒体账户",
            ],
            "Click this button to add a new section. There's plenty to choose from &mdash; blog, galleries, contact forms, and even our App Store!":
              ["点击这个按钮添加新的版块，例如商店、博客、相册、联系表单等"],
            "Click this icon if you get stuck! You can search our knowledge base or contact us for support.":
              ["如需帮助，请点击此图标找到问题答案或直接联系我们"],
            "Click to explore the App Store": ["添加 HTML 代码或网站应用"],
            Clone: ["复制"],
            Close: ["关闭"],
            "Close Without Saving": ["退出，不用保存"],
            "Collect emails and send newsletters all in one place! Send unlimited emails to 2000 contacts each month.":
              ["集收发邮件于一处！每月可发送无限邮件给2000个客户。"],
            Comments: ["评论"],
            Confirm: ["确认"],
            "Confirm Payment": ["确认支付"],
            "Congrats on your website! Follow these simple steps to bring more people to your site.":
              ["请按照这些简单步骤操作，吸引更多人访问你的网站"],
            "Congrats! Your site is live at: ": ["太棒了！你的网址是:"],
            "Connect <strong>Custom Domain</strong>": [
              "连接 <strong>自定义域名</strong>",
            ],
            "Connect your social accounts to display your latest posts.": [
              "连接你的社交账户，显示最新博文。",
            ],
            "Connecting with PayPal": ["连接至 PayPal"],
            "Contact Info": ["联系我们"],
            "Contacts|Hide country code selection": ["隐藏国家代码选项"],
            "Contacts|Show country code selection": ["显示国家代码选项"],
            "Contact|Orders": ["订单数"],
            Contain: ["填充"],
            "Continue & add up to %{var1} pages": ["继续，增加到%{var1}个页面"],
            "Continue & publish %{var1} pages": ["继续，发布%{var1}个页面"],
            "Continue Transfer": ["继续转移"],
            Copy: ["复制"],
            "Create New Site": ["创建新网站"],
            "Create Password": ["创建密码"],
            "Create your FREE website today!": ["立即免费拥有一个网站！"],
            "Create yours today!": ["立即免费创建！"],
            "Created Successfully": ["创建成功"],
            "Creating blog posts...": ["正在创建博客文章…"],
            "Creating booking events...": ["正在创建服务预约…"],
            "Creating portfolio items...": ["正在创建展示项目…"],
            "Creating store products...": ["正在创建商品…"],
            "Crossed-out price will display in product page with strikethrough, e.g. [strikethrough: ¥50.00]":
              [
                "划掉的商品原价将显示在商品页面中，例如 [strikethrough: ¥50.00]",
              ],
            "Current Card Number": ["当前卡片号码"],
            "Custom code isn't available during trial.": [
              "自定义代码功能在试用期内暂不开放",
            ],
            "Custom code will only take effect when you view your blog post, not in the editor.":
              [
                "自定义代码仅在预览和访问你的博客时有效，不能在你的博客编辑器中显示。",
              ],
            "Custom footer HTML will be inserted just before the closing <strong>&lt;/body&gt;</strong> tags. Here, you can add custom JavaScript, HTML, etc. Be sure to use <strong>&lt;script&gt;&lt;/script&gt;</strong> tags for JavaScript!":
              [
                "自定义的页脚代码将被插入到 <strong>&lt;/body&gt;</strong> 结束标签之前。你可以在代码中添加自定义的HTML元素，JavaScript脚本等等。请务必将JavaScript代码包含在 <strong>&lt;script&gt;&lt;/script&gt;</strong> 标签对中。",
              ],
            "Custom header HTML will be inserted between the <strong>&lt;head&gt;&lt;/head&gt;</strong> tags. Here, you can add meta tags and include scripts. Be sure to use <strong>&lt;style&gt;&lt;/style&gt;</strong> tags for CSS and <strong>&lt;script&gt;&lt;/script&gt;</strong> tags for JavaScript!":
              [
                "自定义页面 HTML 将被插入 <strong>&lt;head&gt;&lt;/head&gt;</strong> 标记对之间。在此处，你可以添加元标记并加入脚本。请务必对 CSS 使用 <strong>&lt;style&gt;&lt;/style&gt;</strong> 标记对，对 JavaScript 使用 <strong>&lt;script&gt;&lt;/script&gt;</strong> 标记对！",
              ],
            "CustomPath|Cannot be empty.": ["不能留空"],
            "CustomPath|Cannot end with a slash.": ["不能以斜杠结尾。"],
            "CustomPath|Cannot have more than %{quantity} characters.": [
              "不能超过 %{quantity} 个文字",
            ],
            "CustomPath|Only letters, numbers, and hyphens allowed.": [
              "仅支持英文字母，数字，或连字号(-)",
            ],
            "CustomPath|Only letters, numbers, hyphens, and one slash are allowed.":
              ["仅支持英文字母，数字，连字号(-)，或一个斜杠。"],
            'CustomPath|Sorry, this URL slug "%{var1}" is reserved.': [
              '抱歉，此域名段"%{var1}"已被保留。',
            ],
            'CustomPath|The subdirectory "%{var1}" is reserved and not available.':
              ["子目录“%{var1}”已被保留，无法使用。"],
            "CustomPath|This URL is already taken.": ["此域名已被使用"],
            "CustomPath|Use custom URL": ["使用自定义网址"],
            Customize: ["自定义"],
            "Customize your chat window's color.": ["自定义你的聊天窗口颜色"],
            DELETE: ["删除"],
            DESELECT: ["取消选择"],
            "DNS Management": ["打开 DNS 管理界面"],
            "Dark Text": ["深色文本"],
            "Dashboard| + 20% Commission for Recurring Payments Thereafter": [
              "一年后每笔续费20%佣金分成",
            ],
            "Dashboard|%{plan} Sites Publish Limit": ["%{plan} 网站发布限制"],
            "Dashboard|%{var1} requested for payout": ["%{var1} 提现中"],
            "Dashboard|(%{var1} minimum for payout)": [
              "（%{var1} 为最低提现金额）",
            ],
            "Dashboard|(%{var2} minimum for payout)": [
              "（累计引荐至少 %{var2} 个付费用户解锁提现）",
            ],
            "Dashboard|(External site)": ["（外部网站）"],
            'Dashboard|1. Click "Tools" in WordPress dashboard.': [
              "1. 点击WordPress仪表板中的“工具”。",
            ],
            'Dashboard|2. Open "Import WordPress" and select your XML doc to upload.':
              ["2. 打开“导入WordPress”并选择要上传的XML文档。"],
            "Dashboard|50% Commission for First Year Payments": [
              "首年套餐付费可享 50% 佣金分成",
            ],
            "Dashboard|A Strikingly blog": ["Strikingly博客"],
            "Dashboard|A Strikingly site": ["一个Strikingly网站"],
            "Dashboard|A citizen or resident of the United States": [
              "美国公民或居民",
            ],
            "Dashboard|A domestic trust": ["美国国内信托"],
            "Dashboard|A partnership, corporation, company, or association created or organized in the United States or under the laws of the United States":
              [
                "在美国或根据美国法律创建或组织的合伙企业、股份有限公司、公司或协会组织",
              ],
            "Dashboard|AI SEO Writer": ["AI SEO智能写手"],
            "Dashboard|Actions": ["操作"],
            "Dashboard|Add & remove any features on any template. Change templates anytime.":
              ["你可以任意添加或删除模版网站的功能，并且随时替换模版"],
            "Dashboard|Add an article to this project": [
              "在此项目中写一篇新文章",
            ],
            "Dashboard|Add new project": ["添加新项目"],
            "Dashboard|Address (number, street, and apt. or suite no.)": [
              "地址（包括编号、街道、公寓、房间号）",
            ],
            "Dashboard|Affiliate Dashboard": ["联盟分销主页"],
            "Dashboard|Affiliate Feedback": ["联盟分销反馈"],
            "Dashboard|Affiliate Link Clicks": ["分销链接点击量"],
            "Dashboard|Affiliate Link Language": ["分销链接语言"],
            "Dashboard|Affiliate Link Now Active": ["分销链接已可使用"],
            "Dashboard|Affiliate Profile & Tax Forms": [
              "分销伙伴资料与报税表格",
            ],
            "Dashboard|Affiliate Tax Profile": ["分销伙伴税务资料"],
            "Dashboard|All time": ["所有时间"],
            "Dashboard|Ambassador account email": ["Ambassador账号电子邮箱"],
            "Dashboard|Amount": ["金额"],
            "Dashboard|An estate (other than a foreign estate)": [
              "遗产（美国国外遗产除外）",
            ],
            "Dashboard|An external blog": ["外部博客"],
            "Dashboard|An external site": ["外部网站"],
            "Dashboard|Apply to Strikingly Affiliate Program": [
              "申请加入Strikingly联盟分销计划",
            ],
            "Dashboard|Are you a U.S. person? (See definition below.)": [
              "你是否为一名“美国人士”？（请见以下相关定义）",
            ],
            "Dashboard|Are you sure you want to delete this article? You can't undo this action. This will not affect articles in your Strikingly sites or external sites.":
              [
                "你确定要删除这篇文章吗？该操作无法撤销。已经导出到Strikingly网站或其他网站的文章不会受影响。",
              ],
            "Dashboard|Are you sure you want to delete this project? You can't undo this action.":
              ["你确定要删除这个项目吗？该操作无法撤销。"],
            "Dashboard|As a Strikingly Affiliate, you must agree and adhere to the [link1: Strikingly Affiliate Program Agreement], [link2: the Federal Trade Commission Disclosure Guidelines] (or equivalent disclosure guidelines for your region), and the [link3: Strikingly Brand Guidelines]. Please confirm the following:":
              [
                "每个Strikingly分销伙伴都必须同意遵守以下所有条款：[link1: Strikingly联盟分销计划服务条款]、[link2: 美国 FTC 广告披露准则]（或在你所处国家或地区类似的广告披露相关法律或准则）、以及[link3: Strikingly 品牌使用准则]。请认真阅读并确认以下条款：",
              ],
            "Dashboard|As a U.S. based company, Strikingly is required by the U.S. IRS to collect and have on file the necessary tax forms for our affiliates. Please complete your affiliate profile ONLY in English and we'll generate the appropriate tax forms for you.":
              [
                "作为一家美国公司，Strikingly必须遵守美国国税局（IRS）关于收集以及存档联盟分销伙伴税务表格的有关规定。请在此仅用英文完善你的资料，我们会根据你提供的信息自动为你生成你所需要的税务表格。",
              ],
            "Dashboard|Back": ["返回"],
            "Dashboard|Beta": ["测试版"],
            "Dashboard|Blog": ["博客"],
            "Dashboard|By default, your Affiliate Link will detect the visitor's language automatically. You can also choose a specific language version of Strikingly to link to. (Tracking and attribution still work the same way.)":
              [
                "在默认情况下，你的联盟分销链接将自动检测访客的语言。你也可以选择链接到 Strikingly 的特定语言版本（数据追踪和归因方式不变）",
              ],
            "Dashboard|By transferring, this article will be permanently moved to the selected site. You'll be able to find it in the site's blog editor.":
              [
                "文章转移后将被永久移至选定网站，你可以在该网站的博客编辑器中找到它。",
              ],
            "Dashboard|Cancel": ["取消"],
            "Dashboard|Certificate of No U.S. Activities": ["无美国活动证明"],
            "Dashboard|Change account email address...": ["更新账户邮箱地址"],
            "Dashboard|Check out Strikingly! Super easy website & store builder.":
              ["来试试Strikingly吧！超级容易上手的建站工具和电商开店平台。"],
            "Dashboard|Collaborator Site -": ["协作者网站 -"],
            "Dashboard|Commissions Approved": ["已批准佣金"],
            "Dashboard|Commissions Approved: %{var1}": ["可提现佣金：%{var1}"],
            "Dashboard|Commissions Paid": ["已支付佣金"],
            "Dashboard|Commissions Pending": ["待验证佣金"],
            "Dashboard|Confirm PayPal Account": ["请确认 PayPal 账户"],
            "Dashboard|Confirm your project": ["确认项目"],
            "Dashboard|Connect to PayPal": ["绑定 Paypal 账户"],
            "Dashboard|Connect your PayPal account to receive payouts.": [
              "绑定你的PayPal账户来获得提现。",
            ],
            "Dashboard|Continue writing": ["继续写"],
            "Dashboard|Copied!": ["已复制！"],
            "Dashboard|Copy link": ["复制链接"],
            "Dashboard|Corporate Entity Type": ["公司实体类型"],
            "Dashboard|Corporate Name": ["公司名称"],
            "Dashboard|Country/Region of Citizenship": ["国家/地区的公民身份"],
            "Dashboard|Create New Logo": ["创建新的Logo"],
            "Dashboard|Create a new logo using our logo design tool.": [
              "使用我们的Logo设计工具创建新的Logo。",
            ],
            "Dashboard|Create new project": ["创建新项目"],
            "Dashboard|Create project & start writing": ["创建项目并开始写作"],
            "Dashboard|Create your first site here.": [
              "在这里创建你的第一个网站。",
            ],
            "Dashboard|Curated Content Ideas to Make Your First Sale": [
              "有助你第一笔成交的一些点子",
            ],
            "Dashboard|Currently, you have a PayPal account connected for billing.":
              ["目前，你已经关联了一个PayPal帐户进行缴费。"],
            "Dashboard|Delete": ["删除"],
            "Dashboard|Domain Connection Error. [var1: View status].": [
              "域名连接错误，[var1: 查看状态]。",
            ],
            "Dashboard|Don't know where to start? Our agents can build a simple site for you. [link: Contact us via our Kickstart program!]":
              [
                "不知道从哪里开始？我们的代理商可以为您建立一个简单的网站。 [link: 通过我们的Kickstart程序联系我们！]",
              ],
            "Dashboard|Don't want to make your own? We can build your site for a small fee. ($%{var1} for single page, $%{var2} for multiple pages)":
              [
                "想更省心省事？我们全新推出有偿代建站服务！（$%{var1} 美金一个单页面网站, $%{var2}美金一个多页面网站)",
              ],
            "Dashboard|Don't worry, you can change this later. You can add a blog or store to any template.":
              ["请随意选择，模版选择后可随时互换"],
            "Dashboard|Download %{category}": ["下载 %{category}"],
            "Dashboard|Download Pre-filled Tax Form to Sign": [
              "下载自动生成税表进行签名",
            ],
            "Dashboard|Earn more commissions to request a payout.": [
              "赚取更多佣金后即可发起提现",
            ],
            "Dashboard|Edit": ["修改"],
            "Dashboard|Email": ["邮件"],
            "Dashboard|Email is invalid": ["无效的电子邮箱"],
            "Dashboard|Employer Identification Number (EIN)": [
              "雇主身份识别号码 (EIN)",
            ],
            "Dashboard|Enter Ambassador account email": [
              "输入Ambassador账号电子邮箱",
            ],
            "Dashboard|Enter EIN (no spaces, dashes optional)": [
              "输入 EIN（无空格；可写横线）",
            ],
            "Dashboard|Enter SSN/ITIN (no spaces, dashes optional)": [
              "输入 SSN/ITIN（无空格；可写横线）",
            ],
            "Dashboard|Enter a list of recipients' email addresses, separated by commas":
              ["你可以输入收件人们的电子邮件地址，并用逗号将它们隔开"],
            "Dashboard|Enter a valid EIN.": ["请输入有效的EIN"],
            "Dashboard|Enter a valid SSN.": ["请输入有效的SSN"],
            "Dashboard|Enter a valid ZIP code.": ["请填入有效邮政编码"],
            "Dashboard|Enter a valid date.": ["请输入有效日期"],
            "Dashboard|Enter the name of the external site. (This is just to organize your articles.)":
              ["输入外部网站的名称。（这是为了组织你的文章。）"],
            "Dashboard|Enter your PayPal email": ["输入你的PayPal邮箱"],
            "Dashboard|Export": ["导出"],
            "Dashboard|Export this article": ["导出文章"],
            "Dashboard|Exported": ["已导出"],
            "Dashboard|Failed": ["失败"],
            "Dashboard|First Name": ["名字"],
            "Dashboard|First and Last Name": ["姓名（英文）"],
            "Dashboard|Follow Our WeChat Official Account": [
              "关注我们的微信公众号",
            ],
            "Dashboard|Follow our WeChat Official Account to receive important notifications for your site or Mini-Program -- forms, store orders, analytics, and more.":
              [
                "绑定上线了微信公众号，及时获取网站或小程序留言、订单状况、数据分析等信息，享专属优惠！",
              ],
            "Dashboard|Followed": ["关注成功"],
            "Dashboard|Generate a full website for this business in minutes": [
              "几分钟内为这项业务生成一个完整的网站",
            ],
            "Dashboard|Get %{var1}%% off": ["限时 %{var1} 折优惠"],
            "Dashboard|Give feedback about our Affiliate Program": [
              "对联盟分销计划提建议",
            ],
            "Dashboard|Go to Blog Editor to add new article": [
              "去博客编辑器写新文章",
            ],
            "Dashboard|Go to blog editor": ["前往博客编辑器"],
            "Dashboard|Go to blog list": ["前往博客列表"],
            "Dashboard|Go to my sites": ["前往我的网站"],
            "Dashboard|Go to site editor": ["前往网站编辑器"],
            "Dashboard|Go to the editor to add images or publish.": [
              "你可以前往编辑器添加图片或发布文章。",
            ],
            "Dashboard|Hang on, we’re checking and processing your email now.":
              ["请稍等，我们正在检查并处理你的邮件。"],
            "Dashboard|How It Works": ["分销原理"],
            "Dashboard|How to Pitch Strikingly to Your Customers": [
              "如何宣传 Strikingly",
            ],
            "Dashboard|I agree to the Strikingly Affiliate Program [link: terms and conditions]":
              ["我同意Strikingly联盟分销计划的[link: 条款和条件]"],
            "Dashboard|I am at least 18 years old.": ["我已满18周岁。"],
            "Dashboard|I confirm that I understand": ["确认知晓且理解"],
            "Dashboard|I do not perform services in the U.S.": [
              "我不在美国提供服务。",
            ],
            "Dashboard|I have read and agree to the [link: Strikingly Affiliate Program Agreement.]":
              [
                "我已充分阅读、了解并同意遵守 [link: Strikingly联盟分销计划服务条款]。",
              ],
            "Dashboard|I hereby certify and acknowledge that during the term of the agreement, the service I provide to Strikingly, Inc. will be exclusively from outside of the United States.":
              [
                "我在此证明并承认，在协议期限内，我向 Strikingly, Inc. 提供的服务将完全来自美国以外地区。",
              ],
            "Dashboard|I will NOT buy search engine advertising, trademarks or domain names that mention or use “Strikingly” or other Strikingly logos and I will NOT engage in any fraudulent, spam or low quality marketing activities such as those outlined in the [link: Strikingly Affiliate Program Agreement].":
              [
                '我保证将不会购买、提及、使用 "Strikingly "或其他Strikingly标识的搜索引擎广告、商标、域名，我也不会开展任何诈骗、垃圾邮件、或任何低质量的营销活动，如[link: Strikingly联盟分销计划服务条款]中所述。',
              ],
            "Dashboard|I will NOT make deceptive or misleading claims, guarantee earnings, or promise a prospective client success. I will NOT use the following phrases or phrases similar to the following: “Take my course and make money on Strikingly” or “Launch your store and earn money immediately”.":
              [
                "我保证不会做出任何欺骗性或误导性的声明、不会承诺可以赚钱或对潜在客户承诺成功的可能性。 我不会使用以下短语或类似于以下内容的短语：“上我的课并在 Strikingly 上赚钱”或“开店就能立即赚钱”。",
              ],
            "Dashboard|I will NOT use promotional means that contain objectionable content, including but not limited to content that is fraudulent, misleading, libelous, defamatory, obscene, violent, bigoted, hate-oriented, illegal, and/or promoting illegal goods, services or activities.":
              [
                "我保证不会使用包含令人反感的内容的促销手段，包括但不限于欺诈、误导、诽谤、诽谤、淫秽、暴力、煽动仇恨、非法和/或宣传非法商品、服务或活动的内容。",
              ],
            "Dashboard|I will be honest, ethical, and transparent when I talk about Strikingly. As a Strikingly Affiliate, I will follow the [link: Federal Trade Commission Disclosure Guidelines] (or equivalent disclosure guidelines for your region) and make it clear that I am promoting Strikingly as an affiliate.":
              [
                "我保证在跟他人讨论Strikingly时，我将时刻做到诚实、道德、透明的沟通。作为Strikingly分销伙伴，我将遵循[link: 美国 FTC 广告披露准则]或我所处国家或地区类似的广告披露相关法律或准则，明确向他人表示我是以联盟分销伙伴身份推广Strikingly。",
              ],
            "Dashboard|I will use Strikingly’s brand assets according to the [link: Strikingly Brand Guidelines].":
              [
                "我保证将严格遵循[link: Strikingly品牌使用准则]的规定使用Strikingly的品牌资源。",
              ],
            "Dashboard|If you had an account with our legacy affiliate platform, Ambassador, you can use this tool to make sure your old link is still attributed in our new system. Please enter your old Ambassador email address.":
              [
                "如果你在 Ambassador 联盟分销平台上有帐户的话，这个验证流程可以将你以前在 Ambassador 的 Strikingly 分销链接导入到我们的新分销系统中继续使用。请在此输入你的 Ambassador 邮箱地址。",
              ],
            "Dashboard|Import Affiliate Link From Ambassador": [
              "从Ambassador导入分销链接",
            ],
            "Dashboard|Important: If you perform any services within the U.S. and cannot sign this certificate, the IRS requires us to withhold up to 30% of your commission for U.S. tax.":
              [
                "重要提示：如果你在美国境内提供任何服务而不能签署此证明，我们将根据美国国税局（IRS）规定在你的佣金里预扣30%的美国税款。",
              ],
            "Dashboard|In-person seminars & events": ["线下讲课"],
            "Dashboard|Input standard English characters only": [
              "仅输入标准英文",
            ],
            "Dashboard|Invitations successfully sent!": ["邀请已发送！"],
            "Dashboard|Invoice & Payout History": ["请款 / 提现记录"],
            "Dashboard|Invoice Date": ["请款日期"],
            "Dashboard|It appears that this domain is not available.": [
              "似乎该域名不可用。",
            ],
            "Dashboard|Join Affiliate Program": ["加入联盟分销计划"],
            "Dashboard|Language: Auto": ["语言：自动"],
            "Dashboard|Last %{var1} days": ["过去%{var1} 天"],
            "Dashboard|Last Name": ["姓氏"],
            "Dashboard|Learn more in our FAQ.": [
              "阅读常见问题FAQ回答可了解更多详情",
            ],
            "Dashboard|Let's Go!": ["冲冲冲！"],
            "Dashboard|Link invalid. Please resend the confirmation email.": [
              "验证链接已失效。请重发验证邮件。",
            ],
            "Dashboard|Links & Resources": ["链接与资源"],
            "Dashboard|Log in to Strikingly": ["登录Strikingly"],
            "Dashboard|Logo Name": ["Logo名称"],
            "Dashboard|Looking for your [link: free Pro rewards?]": [
              "想要访问以前的[link: 免费的Pro套餐奖励]页面？",
            ],
            "Dashboard|Manage Projects": ["管理项目"],
            "Dashboard|Mobile app": ["手机app"],
            "Dashboard|Move article to project": ["将文章移动到项目"],
            "Dashboard|Move article to site": ["将文章移动到网站"],
            "Dashboard|Move to other project": ["移动到其他项目"],
            "Dashboard|Move to other site": ["移动到其他网站"],
            "Dashboard|Move to this project": ["移动到这个项目"],
            "Dashboard|Move to this site": ["移动到这个网站"],
            "Dashboard|My Projects": ["我的项目"],
            "Dashboard|My site list": ["我的网站列表"],
            "Dashboard|NOTE: The information you provide below must be identical to that in your own tax forms. We will verify this with the IRS, so please make sure this information is accurate!":
              [
                "请注意：你在以下提供的信息必须与你自己的税表中的信息完全相同。我们会与美国国税局（IRS）核实这些信息，所以请确保这些信息的准确性以避免税务纠纷。请使用英文填写",
              ],
            "Dashboard|Name must only include Latin characters. Please enter name in English.":
              ["名字必须只包含英文字母。请用英文输入"],
            "Dashboard|New Offer": ["全新服务"],
            "Dashboard|New Post %{number}": ["新文章%{number}"],
            "Dashboard|No": ["否"],
            "Dashboard|Not applicable — I perform services in the U.S. and cannot sign this certificate.":
              ["不适用 - 我在美国提供服务，无法签署此证书。"],
            "Dashboard|Online seminars & events": ["线上网课"],
            "Dashboard|Open the file with [link: Adobe Reader] and add your signature (free)":
              ["在 [link: Adobe Reader] 里打开该文件并进行电子签名（免费）"],
            "Dashboard|Or add new external site": ["或者添加新的外部网站"],
            "Dashboard|Or create new project": ["或创建一个新项目"],
            "Dashboard|Or go to blog editor to add a new article": [
              "或者去博客编辑器添加新文章",
            ],
            "Dashboard|Or select existing Strikingly site": [
              "或选择一个已有的Strikingly网站",
            ],
            "Dashboard|Or transfer to a Strikingly site": [
              "或迁移到Strikingly网站",
            ],
            "Dashboard|Other": ["其它"],
            "Dashboard|Our AI Site Builder is in beta! If you have any questions or suggestions, please send us any feedback to [link:%{linkUrl}]":
              [
                "我们的AI网站生成器正在测试中！如果你有任何问题或建议，请将任何反馈发送给我们 [link:%{linkUrl}]",
              ],
            "Dashboard|Our AI Writer writes Search Engine Optimized (SEO) articles to help you get more traffic from Google. You can transfer your article to a Strikingly blog, export it to an external blog, or download it onto your device once you’ve finished writing.":
              [
                "我们的AI智能写手可以替你写SEO（搜索引擎优化）博客文章，帮助你从谷歌获得更多流量。文章完成后，你可以将其迁移到一个Strikingly博客，导出到外部博客，或下载到你的设备中。",
              ],
            "Dashboard|Paid Users Referred": ["付款引荐量"],
            "Dashboard|Paid ads": ["付费广告投放"],
            "Dashboard|Paid out on %{var1} to PayPal account %{var2}": [
              "已于 %{var1} 打款至该 Paypal 账户：%{var2}",
            ],
            "Dashboard|PayPal account connected: %{var1}": [
              "PayPal账户已绑定：%{var1}",
            ],
            "Dashboard|PayPal account: %{var1}": ["PayPal 账户：%{var1}"],
            "Dashboard|Payouts": ["提现"],
            "Dashboard|Pending Export": ["待导出"],
            "Dashboard|Please Update Billing Info": ["请更新账单信息"],
            "Dashboard|Please complete the profile below. This information must be accurate, as our administrators will check for validity.":
              [
                "请完善以下资料。请务必确保所提供信息的准确性，我们的有关人员会进行核实。",
              ],
            "Dashboard|Please confirm that this is the correct PayPal account you wish to connect to. You will be able to request commission payouts to this PayPal account.":
              [
                "请确认你想要绑定以下 PayPal 账户。你提现的佣金都将被转入该 PayPal 账户上。",
              ],
            "Dashboard|Please enter a valid PayPal account email.": [
              "请输入一个有效的PayPal账户邮箱。",
            ],
            "Dashboard|Please enter a valid email address.": [
              "请输入一个有效的电子邮箱地址。",
            ],
            "Dashboard|Please enter your email to receive notifications about your site.":
              ["请输入你的邮箱地址，第一时间接收网站通知。"],
            "Dashboard|Please enter your feedback": ["请填写你的反馈"],
            "Dashboard|Print the file, sign it on paper, and scan the signed copy":
              ["打印该文件，在纸张进行签名后扫描签后原件"],
            "Dashboard|Projects are used to organize your articles in an external blog and ensures articles' target keywords do not overlap (since overlapping keywords will hurt SEO rankings).":
              [
                "项目用于在外部博客中组织你的文章，并确保这些文章的目标关键词不重叠（重叠的关键词会损害SEO排名）。",
              ],
            "Dashboard|Receive the latest product updates": [
              "及时接收最新的产品动态",
            ],
            "Dashboard|Refer more paid users to unlock payouts.": [
              "引荐更多付费用户以解锁提现功能",
            ],
            "Dashboard|Refer one  more paid user to reactivate your affiliate account.":
              ["再推荐一位付费用户重新激活您的会员帐户。"],
            "Dashboard|Referred Paid Users: %{var1}": [
              "已引荐付费用户：%{var1}",
            ],
            "Dashboard|Rejected": ["审核未通过"],
            "Dashboard|Remember, you can add and remove sections to any template.":
              ["你可以在自己的网站中任意添加或删除网站版块"],
            "Dashboard|Request Affiliate Payout": ["发起提现"],
            "Dashboard|Request Payout": ["发起提现"],
            "Dashboard|Required field": ["必填"],
            "Dashboard|Resend Confirmation Email": ["重发验证邮件"],
            "Dashboard|Resources from this site (images, internal blog links, etc.) will be used in the new article.":
              ["新文章将使用这个网站的资源（图片、内部博客链接等）。"],
            "Dashboard|Resubmit tax form": ["重新提交税表"],
            "Dashboard|Resubmit tax information...": ["重新提交税务信息"],
            "Dashboard|Retry this card": ["用该付款卡重试"],
            "Dashboard|Retrying...": ["重试中..."],
            "Dashboard|Return to Affiliate Dashboard": ["返回联盟分销首页"],
            "Dashboard|SSL Certificate Error. [link: View status].": [
              "SSL证书错误，[link: 查看状态]。",
            ],
            "Dashboard|Sale ends <span class='time'>within the hour</span>": [
              "打折活动1小时内结束",
            ],
            "Dashboard|Sale ends in <span class='time'>%{var1} days</span>": [
              "打折活动仅剩 <span class='time'>%{var1} </span>天",
            ],
            "Dashboard|Sale ends in <span class='time'>%{var1} hours</span>": [
              "打折活动仅剩 %{var1} 小时",
            ],
            "Dashboard|Sale ends in <span class='time'>1 day</span>": [
              "打折活动仅剩 <span class='time'>1 天</span>",
            ],
            "Dashboard|Sale ends in <span class='time'>1 hour</span>": [
              "打折活动仅剩最后 1 小时",
            ],
            "Dashboard|Sale ends soon": ["打折活动即将结束"],
            "Dashboard|Save and return to article list, where you can export articles later.":
              ["保存并返回到文章列表，之后你可以在文章列表中选择导出文章。"],
            "Dashboard|Save this article": ["保存文章"],
            "Dashboard|Saved %{date}": ["保存于%{date}"],
            "Dashboard|Scan the QR code with WeChat to follow SXL's WeChat Official Account (Chinese only)":
              ["使用微信扫码关注公众号 ⌈上线了⌋"],
            "Dashboard|Scan the QR code with WeChat to follow SXL's WeChat Official Account and receive the latest product updates! (Chinese only)":
              ["微信扫码关注公众号 ⌈上线了⌋ 可以更及时收到最新产品动态哦！"],
            "Dashboard|Search articles": ["搜索文章"],
            "Dashboard|Select Project": ["选择项目"],
            "Dashboard|Select Target Blog": ["选择目标博客"],
            "Dashboard|Select a Strikingly Site": ["选择一个Strikingly网站"],
            "Dashboard|Select a project to move this article [strong: %{projectName}] to:":
              ["选择将文章[strong: %{projectName}]移动到项目："],
            "Dashboard|Select a site": ["选择网站"],
            "Dashboard|Select a site to move this article [strong: %{projectName}] to:":
              ["选择一个网站，将这篇文章[strong: %{projectName}] 移动到："],
            "Dashboard|Select a state": ["选择州"],
            "Dashboard|Select a target site": ["选择目标网站"],
            "Dashboard|Select specific language...": ["选择一个指定语言："],
            "Dashboard|Send Invitations by Email": ["通过邮箱发送邀请"],
            "Dashboard|Send Invoice & Request Payout - %{var1}": [
              "发起提现 - %{var1}",
            ],
            "Dashboard|Send us any feedback or comments": [
              "告诉我们你的意见或建议",
            ],
            "Dashboard|Share via:": ["分享到："],
            "Dashboard|Share your link today to earn your 1st commission!": [
              "立即分享你的链接来赚取第一笔分销佣金吧！",
            ],
            "Dashboard|Sign up or log into your Strikingly account to join the Affiliate Program.":
              ["注册或登录你的Strikingly账户来加入我们的联盟分销计划。"],
            "Dashboard|Sign up to Strikingly": ["注册Strikingly"],
            "Dashboard|Signature (Type your name)": ["签名（请键入你的姓名）"],
            "Dashboard|Signups Referred": ["注册推荐量"],
            "Dashboard|Social Security Number (SSN) or Individual Tax Identification Number (ITIN)":
              ["社会安全号码（SSN）或个人报税识别号码（ITIN）"],
            "Dashboard|Standalone logos": ["独立的Logo"],
            "Dashboard|Start Editing!": ["开始编辑！"],
            "Dashboard|Start a new article in the current project.": [
              "在当前项目中写一篇新文章。",
            ],
            "Dashboard|Start writing": ["开始写作"],
            "Dashboard|State or Province": ["省或洲"],
            "Dashboard|Status": ["状态"],
            "Dashboard|Step 1. Download and ensure the accuracy of the pre-filled tax form we've generated for you.":
              ["1）下载并确保我们为你自动生成的报税表的准确性。"],
            "Dashboard|Step 2. Please add your signature to the PDF, using one of the following methods:":
              ["2）请用以下方式在PDF上签名"],
            "Dashboard|Step 3. Click Submit below, and our admins will verify your information soon.":
              ["3）点击下面的“提交”按钮，我们会尽快对你的信息进行审核。"],
            "Dashboard|Still Writing": ["写作中"],
            "Dashboard|Strikingly Affiliate Program FAQ": [
              "Strikingly联盟分销计划 FAQ",
            ],
            "Dashboard|Strikingly Affiliate Program Policy Overview": [
              "Strikingly联盟分销计划守则概述",
            ],
            "Dashboard|Submission failed. Please try agian.": [
              "提交失败。请重试。",
            ],
            "Dashboard|Submit Application": ["提交申请表格"],
            "Dashboard|Submit Profile & Generate Tax Forms": [
              "提交资料并生成税表",
            ],
            "Dashboard|Submit Tax Form": ["提交税表"],
            "Dashboard|Submit Tax Information": ["提交税务信息"],
            "Dashboard|TIN (Tax Identification Number)": [
              "纳税人识别号码（TIN）",
            ],
            "Dashboard|Target keyword": ["目标关键词"],
            "Dashboard|Tax Withholding Notice": ["预扣税款须知"],
            "Dashboard|Thank you for applying to the Strikingly Affiliate Program. Please confirm your email address (%{var1}) to complete your application.":
              [
                "非常感谢你申请加入Strikingly联盟分销计划！请验证你的邮箱地址（%{var1}）完成你申请的最后一步。",
              ],
            "Dashboard|Thank you for being a Strikingly Affiliate! Please send us any comments or suggestions to make our Affiliate Program better. We read every message!":
              [
                "感谢你成为Strikingly联盟分销伙伴！请告诉我们任何意见或建议，让我们的联盟分销计划做得更好。我们会认真听取每一条反馈！",
              ],
            "Dashboard|Thank you for submitting your tax information and signed tax forms. We'll send you an email (to %{var1}) once your profile is reviewed, which may take a few business days. After approval, you will be able to request payouts for approved commissions.":
              [
                "感谢你提交税务信息以及已签名税表。一旦你的资料通过审核，我们将向你发送一封邮件（至 %{var1}），这个过程可能需要几个工作日。在审核通过后，你就可以申请佣金提现了。",
              ],
            "Dashboard|Thank you for your feedback!": ["感谢你的反馈！"],
            "Dashboard|Thank you for your feedback! We’ll be in touch soon.": [
              "谢谢你的反馈！我们之后会联系你的。",
            ],
            "Dashboard|Thank you for your support!": ["感谢你的厚爱！"],
            "Dashboard|The Strikingly Affiliate Program allows you to earn money by helping to promote Strikingly and refer new users. After your application is approved, you'll be able to use your affiliate link. We'll review your account regularly to ensure you're complying with our guidelines.":
              [
                "Strikingly联盟分销计划旨在通过佣金分成来鼓励用户自发推广Strikingly产品。在申请通过后，你就可以使用你的专属分销链接来开始推广了。我们会定期对你的账户进行检查以确保你遵守我们的规定以及行为准则。",
              ],
            "Dashboard|The TIN is either a SSN/ITIN (for individuals) or an EIN (for businesses).":
              [
                "纳税人识别号码（TIN）可以是你的社会安全号码（SSN）或个人报税识别号码（ITIN）（个人）或雇主身份识别号码 (EIN)（企业）",
              ],
            'Dashboard|The term "United States person" means any one of the following:':
              ["满足以下任一条件即为“美国人士”："],
            "Dashboard|There has been an error retrying this card. Please try a different card using the form below.":
              ["重试此卡时出错。请使用下面的表格尝试其他卡片。"],
            "Dashboard|There is already a project with this name. Please enter a unique name.":
              ["该项目名称已存在，请输入一个新的项目名称。"],
            "Dashboard|This email cannot be sent because its content might contain spam. Please edit your email and try again.":
              [
                "这封邮件的内容可能包含垃圾信息，因此无法发送。请重新编辑后再尝试发送。",
              ],
            "Dashboard|This pre-filled form is only for your convenience. If it is inaccurate, please fill out the [link1: empty form] instead, or [link2: return to edit my tax profile] to regenerate the pre-filled tax form.":
              [
                "为了节省你的时间，我们为你自动生成了这份表格。如果该表格上信息不准确，请通过填写[link1:空白表格]来代替，或[link2: 修改税务资料]来重新生成税务表格。",
              ],
            "Dashboard|This site does not yet have a blog. Go to site editor and add a blog section before writing articles.":
              [
                "这个网站还没有博客。在写文章之前，请先去网站编辑器添加一个博客版块。",
              ],
            "Dashboard|This site does not yet have a blog. Go to site editor and add a blog section to start writing articles.":
              [
                "这个网站还没有博客。请前往网站编辑器，添加一个博客版块并开始写文章。",
              ],
            "Dashboard|This site does not yet have a blog. Go to site editor and add a blog section to transfer this article.":
              [
                "这个网站还没有博客。在导出这篇文章之前，请先去网站编辑器添加一个博客版块。",
              ],
            "Dashboard|This site is secured by SSL. Your information is encrypted.":
              ["此网站受SSL保护，您的信息已加密。"],
            "Dashboard|To receive your affiliate link, please review our terms and click the button below.":
              ["请查阅我们的服务条款后，点击下方的按钮来获得你的分销链接。"],
            "Dashboard|To receive your affiliate link, you must apply to the Strikingly Affiliate Program.":
              [
                "你必须先申请加入Strikingly联盟分销计划才能获得你的专属分销链接",
              ],
            "Dashboard|Transfer to a Strikingly site": ["迁移到Strikingly网站"],
            "Dashboard|Transfer to this site": ["转移到此网站"],
            "Dashboard|Uh-oh! Your site or account is currently blocked. Please contact the site owner to resolve this.":
              [
                "你的网站或帐户目前处于被屏蔽状态。请联系网站所有者来解决这个问题。",
              ],
            "Dashboard|Update Billing Info": ["更新账单信息"],
            "Dashboard|Update Card": ["更新付款卡"],
            "Dashboard|Upload Signed Tax Form": ["上传已签名税表"],
            "Dashboard|Upload the file to [link1: HelloSign] or [link2: DocuSign] and add your signature, then download the signed PDF (free)":
              [
                "在 [link1: HelloSign]  或 [link2: DocuSign] 上传该文件并进行电子签名，然后下载签好名的PDF（免费）",
              ],
            "Dashboard|Upon updating or retrying your card, your current plan will be renewed (%{var1}).":
              ["更新或重试付款卡后，你的当前套餐即可成功续费（%{var1}）。"],
            "Dashboard|Use existing external site": ["使用现有的外部网站"],
            "Dashboard|Use our AI site builder to get your site started as fast as possible!":
              ["AI建站助你快速启动独立站！"],
            "Dashboard|Use our AI site builder to get your site started as fast as possible! Now available for %{var1} users.":
              [
                "使用我们的AI网站生成器尽快启动你的网站！现在供%{var1}用户使用。",
              ],
            "Dashboard|Use your unique affiliate link to earn generous recurring commissions for life.":
              [
                "通过你的专属分销链接注册的用户的每一笔套餐付费都可以为你带来佣金收入（包括续费）。",
              ],
            "Dashboard|Verification email sent. Please check your email!": [
              "验证邮件已发送。请检查你的邮箱！",
            ],
            "Dashboard|Verification failed. Please contact support for more info.":
              ["验证失败。请联系我们的客服以获取更多信息。"],
            "Dashboard|View payout history": ["查看提现记录"],
            "Dashboard|View tax form": ["查看税表"],
            "Dashboard|Voided due to cancelled commission": [
              "因佣金被取消提现已被取消",
            ],
            "Dashboard|We accept all major credit and debit cards": [
              "支持大多数信用卡和储蓄卡",
            ],
            "Dashboard|We do not have the required tax forms on file for your account. Please complete to enable payouts.":
              [
                "我们在你的账户里没有检测到相关税务表格。请提交税表以解锁提现功能",
              ],
            "Dashboard|We do not have the required tax forms on file for your account. [link: Click here to complete tax forms.]":
              [
                "我们在你的账户里没有检测到相关税务表格。[link: 点击此处进行填写]",
              ],
            "Dashboard|We'll build a site for you!": ["我们可以帮你做网站！"],
            "Dashboard|We'll save draft articles in the AI Writer page, and you can publish articles to the selected site when you're ready.":
              [
                "我们将在AI智能写手页面保存文章草稿。当你准备好时，你可以将文章发布到选定的网站。",
              ],
            "Dashboard|We're still processing your email. You can close this popup and we'll continue processing.":
              ["我们仍在处理你的邮件。你可以关闭此弹窗，我们将继续处理。"],
            "Dashboard|We've paid [strong: millions of dollars] to over 6,000 affiliates!":
              ["我们已向6000多位联盟分销伙伴支付了[strong: 数百万美元]！"],
            "Dashboard|Website": ["网站"],
            "Dashboard|What is the URL or ID of your main promotional channel?":
              ["请提供你主要推广渠道的网站链接或者社交账号ID："],
            "Dashboard|What languages do you create content in? Select all that apply.":
              ["你将会用哪些语言创作内容？可多选"],
            "Dashboard|Where do you plan on promoting Strikingly?": [
              "你准备在哪些渠道推广 Strikingly?",
            ],
            "Dashboard|Where do you want to write a new article?": [
              "你想在哪里写一篇新文章？",
            ],
            "Dashboard|Write new article with AI": ["使用AI写新文章"],
            "Dashboard|Yes": ["是"],
            "Dashboard|You already have a tax form on file, so you’re able to request payouts. Are you absolutely sure you want to resubmit your tax form? Only do this if there is an error in your current tax form.":
              [
                "你已有税表在案，可以申请提现了。你是否确定需要重新提交税表？仅在当前税表已有错误的情况下才需要重新提交。",
              ],
            "Dashboard|You can earn over $1000 for a single referral!": [
              "单笔佣金最高可超过1000美金！",
            ],
            "Dashboard|You can edit the downloaded Word doc on your computer or import it to Google Docs.":
              ["你可以在电脑上编辑下载的Word文档，也可以将其导入Google文档。"],
            "Dashboard|You can import the downloaded XML doc to WordPress:": [
              "你可以将下载的XML文档导入到WordPress：",
            ],
            "Dashboard|You can only delete an empty project. Please move articles in this project to another project and then delete it.":
              [
                "只允许删除空项目。请将此项目中的文章移到另一个项目中，然后再删除它。",
              ],
            "Dashboard|You don't have a site yet.": ["你还没有网站。"],
            "Dashboard|You don't have any Strikingly sites. Please create a new site in [strong:My Sites] and add a blog section.":
              [
                "你还没有任何Strikingly网站。请在[strong:我的网站]中创建一个新网站，并添加一个博客版块。",
              ],
            "Dashboard|You don't have any projects yet. To help organize your articles in an external blog, you must create a project to add articles in.":
              [
                "你还没有任何项目。你必须创建一个项目并在其中添加文章，以组织外部博客中的文章。",
              ],
            "Dashboard|You earn 30% of the customer's first payment. For our highest plan, VIP 5-year, this is $619.20.":
              [
                "你可以获得你引荐用户首笔付款的30％作为佣金。比方说，如果用户购买了5年的VIP套餐，你将可赚取$619.20作为佣金。",
              ],
            "Dashboard|You have a site in progress. Continue working on it here.":
              ["你有一个正在创建中的网站。在这里继续工作。"],
            "Dashboard|You have entered your tax profile information. Follow the instructions below to complete and submit the signed version of your tax form.":
              [
                "你已经完成输入了你的税务资料信息。请按照以下指引完成并提交你的签好名的税表。",
              ],
            "Dashboard|You have sent the invoice and your requested payout of %{var1} is now being processed. This will be transferred to your PayPal account at the next scheduled payout date. [link:Learn more about payout frequency.]":
              [
                "我们已经收到并正在处理你的提现请求。你的佣金（%{var1}）将在下一个放款日期打到你提供的 PayPal 账户上。[link: 了解提现周期]",
              ],
            "Dashboard|You have successfully joined the Strikingly Affiliate Program. Your affiliate link is now active — start earning commissions today!":
              [
                "恭喜你成功加入Strikingly联盟分销计划的一份子。你的专属分销链接已经可以正式投入使用了。现在就开始赚钱吧！",
              ],
            "Dashboard|You must agree to the terms and conditions to continue.":
              ["你必须同意条款和条件以继续。"],
            "Dashboard|You must first download the generated tax form to sign":
              ["你必须先下载为你自动生成的税表"],
            "Dashboard|You must provide your real legal name.": [
              "你必须提供你的真实姓名",
            ],
            "Dashboard|You must type your full legal name exactly as it appears above (%{var1}).":
              ["你必须正确输入你的法定全名（%{var1}）。"],
            "Dashboard|You'll be able to publish your sites once you've done this!":
              ["完成这个步骤，你就可以发布你的网站了!"],
            "Dashboard|You've already submitted signed tax forms. Are you absolutely sure you want to regenerate and resubmit these forms? Your current submission will be overridden.":
              [
                "你已经提交过已签名税表了。你确定你要重新生成并提交税表吗？你当前的信息和税表在成功提交后会被覆盖掉。",
              ],
            "Dashboard|Your Date of Birth (YYYY-MM-DD)": [
              "你的出生日期（YYYY-MM-DD）",
            ],
            "Dashboard|Your Full Legal Name": ["你的法定全名"],
            "Dashboard|Your Permanent Residence": ["你的永久居留地"],
            "Dashboard|Your Stats": ["你的数据"],
            "Dashboard|Your affiliate account is disabled. Please contact support for more info.":
              ["你的分销账号已被禁用。请联系客服以获取更多信息。"],
            "Dashboard|Your article [strong:%{articleName}] has been transferred to your Strikingly site [blod:%{siteName}] [boldface:(%{siteUrl})], but has not been published.":
              [
                "你的文章[strong:%{articleName}]已被转移至Strikingly网站[blod:%{siteName}] [boldface:(%{siteUrl})]，但尚未发布。",
              ],
            "Dashboard|Your article has been transferred": ["文章转移成功"],
            "Dashboard|Your article is still in progress! If you leave this page, your article will be saved as a draft and you can resume it from the article list. Are you sure you want to leave this page anyway?":
              [
                "你的文章仍在编辑中！如果离开此页面，你的文章将被保存为草稿，并可从文章列表中恢复编辑。你仍要离开此页面吗？",
              ],
            "Dashboard|Your card was declined. Please change your payment method in your account settings or contact your bank, then retry this payment.":
              [
                "你的信用卡无效。请在账户设置中更改你的付款方式或者与银行确认后，重新尝试付款。",
              ],
            "Dashboard|Your domain renewal failed because your payment method has been declined. Please update your billing info.":
              ["你的域名续费失败，因为付款方式无效。请更新你的支付信息。"],
            "Dashboard|Your old Ambassador link (%{var1}) has been imported, so any referrals from that link will still be attributed to your account. However, we strongly recommend you use your primary link above instead of this legacy link.":
              [
                "Ambassador联盟分销链接（ %{var1}）已导入，该链接的引荐数据将继续归入你的新帐户。但是，我们强烈推荐你优先使用新的分销链接。",
              ],
            "Dashboard|Your payment method has been declined and your sites have been blocked. Please update your billing info to proceed.":
              ["付款失败，你的网站已被关闭。请更新你的账单信息以继续。"],
            "Dashboard|Your payment was rejected. Please update your payment settings.":
              ["您的付款请求被拒绝了。请更新您的付款设置。"],
            "Dashboard|Your tax forms have been submitted and are now undergoing review.":
              ["你的税表已提交并在审核中。"],
            "Dashboard|You’ve made too many attempts connecting PayPal to your account. Please try again in an hour. Contact support@strikingly.com if you have any questions!":
              [
                "PayPal和账户连接次数过多。请 1 小时后再试。如果你有任何问题，请联系support@strikingly.com !",
              ],
            "Dashboard|ZIP/Postal Code": ["邮政编码"],
            "Dashboard|[link:Read more] about our Affiliate Program": [
              "[link:进一步了解]我们的联盟分销计划",
            ],
            "Dashboard|[strong1: IMPORTANT:] If you are not a U.S. person and perform services in the U.S., we will be required to withhold [strong2: up to 30%] of your commissions in accordance with U.S. tax law. By confirming, you indicate that you understand this requirement.":
              [
                "[strong1: 重要提示：]由于你已经声明你不是“美国人士”且你在美国提供服务，基于这一点，我们将根据美国税法规定在你的佣金里预扣[strong2: 最高可达30%]的税款。通过确认，你表示你知晓并理解该规定。",
              ],
            "Dashboard|[strong1:IMPORTANT:] You have indicated that you are not a U.S. person and that you perform services in the U.S. Based on this, we will be required to withhold [strong2: up to 30%] of your commissions in accordance with U.S. tax law.":
              [
                "[strong1: 重要提示：]由于你已经声明你不是“美国人士”且你在美国提供服务，基于这一点，我们将根据美国税法规定在你的佣金里预扣[strong2: 最高可达30%]的税款。通过确认，你表示你知晓并理解该规定。",
              ],
            "Dashboard|[strong:Enter a project name.] We suggest using the same name as your external blog or site.":
              [
                "[strong:输入项目名称。]我们建议使用与你的外部博客/网站相同的名称。",
              ],
            "Dashboard|[strong:Your affiliate account is inactive], as you have not referred any new paid users in the past 365 days. Refer one more paid user to reactivate your affiliate account!":
              [
                "[strong:因为你已365天没有引荐新的付费用户]，你的分销账号目前处于非活跃状态。只要引荐1个新付费用户即可重新激活你的分销账号。",
              ],
            "Dashboard|as a PDF doc": ["为一个PDF文档"],
            "Dashboard|as a Word doc": ["为一个Word文档"],
            "Dashboard|as a XML doc (Import to WordPress)": [
              "为一个XML文档（用于导入到WordPress）",
            ],
            "Dashboard|get your affiliate link": ["获取分销链接"],
            "Dashboard|submit": ["提交"],
            "Dashboard|up to %{var1}": ["最多%{var1}"],
            "Dashboard|your affiliate link": ["你的分销链接"],
            "Dashborad|verify email": ["验证邮箱"],
            Date: ["日期"],
            Delete: ["删除"],
            "Delete this link": ["删除此链接"],
            "Delete this site": ["删除此网站"],
            Description: ["描述"],
            "Designing section layouts...": ["正在设计版块布局…"],
            "Desktop notifications are only supported on Chrome and Firefox. Please use Chrome or Firefox to enable desktop notifications":
              [
                "桌面通知仅支持Chrome和Firefox浏览器。请使用其一来开启通知功能。",
              ],
            "Direct your viewers to a map.": ["将访客引导至相关地图"],
            Disable: ["关闭"],
            "Disable Live Chat": ["关闭在线聊天"],
            "Disable SMS verification": ["关闭短信验证"],
            "Disable SMS verification?": ["确定关闭短信验证？"],
            Disabled: ["未开启"],
            Discover: ["全球精选"],
            "Display a [link: special card] when your site gets tweeted.": [
              "当您的网站被推文提到时，显示[link: 特殊卡片]。",
            ],
            "Display a [link: special card] when your site gets tweeted. To activate your Twitter Card, click [link2: here].":
              [
                "当你的网站被推文提到时，显示[link: 特殊卡片]。要激活您的Twitter卡，请单击[link2: 这里]。",
              ],
            "Display a crossed-out price, e.g. [strikethrough: $599]": [
              "在销售价格旁展示划掉的价格，如 [strikethrough: $599]",
            ],
            "Display a footer at the bottom of the page?": ["显示网站页脚"],
            "Display navigation buttons?": ["显示导航按钮"],
            "Display navigation menu on mobile phones?": [
              "在手机网站上显示导航栏",
            ],
            "Display navigation menu?": ["显示导航栏?"],
            "Display the RSS icon on blog posts for visitors to subscribe to.":
              ["在博客底部显示订阅图标，方便访客订阅你的博客"],
            "Dmain|Make sure your email is correct! You might be required to verify your domain via email after updating your contact info.":
              [
                "请确保你的邮箱正确！更新联络信息后，你可能需要通过邮件验证你的域名。",
              ],
            Document: ["文档"],
            "Domain is locked. Please unlock this domain to continue.": [
              "域名已被锁定。请解锁之后再继续操作。",
            ],
            "Domain is unlocked.": ["域名已解锁。"],
            "DomainEmail|50% OFF EMAIL ACCOUNTS!": ["五折申请自定义邮箱地址!"],
            "DomainEmail|Account Name": ["账号名"],
            "DomainEmail|Account name": ["账号名"],
            "DomainEmail|Add New Email Account": ["添加新邮箱"],
            "DomainEmail|Are you absolutely sure you wish to delete this email account? This action cannot be undone!":
              ["你确定要删除此邮件帐户吗？此操作不可撤消。"],
            "DomainEmail|Are you sure you with to delete this email account? This action is permanent! Upon deletion, all emails in the inbox will be deleted. (You can back up all emails in this inbox after logging into this account.)":
              [
                "你确定要删除这个邮箱账号吗？此操作不可撤销！一旦删除，所有的邮件都将被删除。（你可以在登录此邮箱后备份所有的邮件）",
              ],
            "DomainEmail|CREATE EMAIL ACCOUNT": ["创建新邮箱"],
            "DomainEmail|Delete Email Account": ["删除邮箱账号"],
            "DomainEmail|Domain Name": ["域名名称"],
            "DomainEmail|Each email account costs $25.00 / year and is non-refundable.":
              ["每个邮箱账号需支付 $25.00 / 年，不支持退款。"],
            "DomainEmail|Edit Email Account": ["编辑邮箱账号"],
            "DomainEmail|Email Account": ["邮箱账户"],
            "DomainEmail|Email addresses can only contain letters, numbers, period and hyphens. Other characters are not supported.":
              ["邮箱地址只能包含字母、数字、点号和连字符，不支持其他字符"],
            "DomainEmail|FREE EMAIL ACCOUNT - $25 VALUE": [
              "免费电子邮件帐户 - 价值25美元！",
            ],
            "DomainEmail|Full Name": ["全名"],
            "DomainEmail|If you change the account name, all current emails in the inbox will be kept, but the old email address will no longer receive emails.":
              [
                "如果你修改账号名称，现有的邮件将被保留，旧的邮箱地址将不会再收到邮件。",
              ],
            "DomainEmail|LIMITED TIME OFFER": ["限时优惠"],
            "DomainEmail|No Data": ["无数据"],
            "DomainEmail|Please Choose A Domain Name": ["请选择一个域名"],
            "DomainEmail|Purchase Email Account": ["购买邮箱账号"],
            "DomainEmail|Renew Email": ["邮箱续费"],
            "DomainEmail|Renew Email Account": ["续费邮箱账户"],
            "DomainEmail|Reset Email": ["重设邮箱"],
            "DomainEmail|Send": ["发送"],
            "DomainEmail|Send Login Info To": ["发送登录信息给"],
            "DomainEmail|Send new password to": ["发送新密码至"],
            "DomainEmail|Sorry! That username is already taken.": [
              "抱歉，该用户名已被占用。",
            ],
            "DomainEmail|The domain %{var1} has already expired! Please renew your domain before renewing this email account.":
              ["域名 %{var1} 已过期！请先给域名续费后再为邮箱续费。"],
            "DomainEmail|This email has failed to renew automatically. Please renew this email to prevent service disruptions!":
              ["此邮箱自动续费失败。请为邮箱续费以避免服务中断！"],
            "DomainEmail|This will be billed using the payment method you have on file (last 4 digits [lastFourDigits]).":
              [
                "款项将从你绑定的付款方式中扣除（卡号后四位为 [lastFourDigits]）。",
              ],
            "DomainEmail|This will be billed using the payment method you have on file.":
              ["款项将从你绑定的付款方式中扣除。"],
            "DomainEmail|Transfer a domain now to receive a free email account for a year!":
              ["转移域名可获得一年免费邮箱账号！"],
            "DomainEmail|Update Email Account": ["更新邮箱帐号"],
            "DomainEmail|You will be able to log in, manage emails, and forward emails through our email provider.":
              ["你可以登陆、管理邮箱，并将邮件通过我们的邮件供应商转发出去。"],
            "DomainEmail|Your first email account cost [originPrice: $25.00] [currentPrice: $0.00/year] for the first year!":
              [
                "第一个自定义邮箱地址第一年的费用为[originPrice: $25.00] [currentPrice: $0.00/首年]！",
              ],
            "DomainEmail|Your first email account cost [originPrice: $25.00] [currentPrice: $12.50/year] for the first year!":
              [
                "第一个自定义邮箱地址第一年的费用为[originPrice: $25.00] [currentPrice: $12.50/首年]！",
              ],
            "DomainEmail|active": ["有效"],
            "DomainEmail|e.g.": ["例如"],
            "DomainEmail|failed": ["失败"],
            "DomainEmail|pending": ["待验证"],
            "DomainEmail|suspended": ["中止"],
            "Domains, SEO, header/footer, and lots more.": [
              "设置域名、SEO、页眉/页脚及高级选项",
            ],
            "Domain| %{price} for the first year!": ["%{price}第一年！"],
            "Domain|$%{price}/Year": ["$%{price}/每年"],
            "Domain|%{domain} is available for transfer! Follow the steps below to authorize the transfer.":
              ["%{domain} 可以转移！根据以下步骤授权转移："],
            "Domain|%{domain} is currently locked. Please unlock your domain to make it available for transfer.":
              ["%{domain}目前被锁定。请解锁你的域名，使其可以转移。"],
            "Domain|%{var1} can't be empty.": ["%{var1} 不可为空。"],
            "Domain|%{var1} is invalid. Please enter integers.": [
              "%{var1}无效，请输入阿拉伯数字。",
            ],
            "Domain|%{var1} is not registered. [link:Click here to register your own domain!]":
              ["%{var1}未注册。[link:点击这里注册属于你的域名！]"],
            "Domain|. Return to this page to initiate your domain transfer once the tag change is completed.":
              ["。域名标签完成更改后，您可以返回此页面并开始申请域名转移。"],
            "Domain|... textile factory was established in ... year, the main production of ...":
              ["XXX纺织厂成立于XXXX年，主要生产XXXX……。"],
            "Domain|1. Make sure your domain name supports ICP filing": [
              "1. 确保你的域名支持ICP备案",
            ],
            "Domain|2. Make sure your domain's registrar has been approved by the Ministry of Industry and Information Technology":
              ["2. 确保你的域名注册商已获工信部批复"],
            "Domain|3. Make sure the domain's registration information is the same as the ICP filing applicant's information":
              ["3. 确保你的域名注册信息和即将备案的主体信息一致"],
            "Domain|Address": ["地址"],
            "Domain|Already have a filing number?": ["已有备案号？"],
            "Domain|An error has occurred with your filing service number application, please contact support.":
              ["您的备案服务号申请发生错误，请联系客服"],
            "Domain|And we've already connected it to your site.": [
              "而且我们已经把它连接到你的网站。",
            ],
            "Domain|Application date": ["申请日期"],
            "Domain|Apply for a filing service number": ["申请备案服务号"],
            "Domain|Are you sure you want to delete this DNS record?": [
              "你确定要删除这条DNS记录吗？",
            ],
            "Domain|Are you sure you want to edit this DNS record?": [
              "你确定要编辑这条DNS记录吗？",
            ],
            "Domain|Are you sure you want to unlock this record? Editing or deleting this record may cause your domain email to stop working.":
              [
                "你确定要解锁这条记录吗？编辑或删除这条记录可能会导致你的域名邮箱无法使用。",
              ],
            "Domain|Are you sure you want to unlock this record? Editing or deleting this record may cause your site to stop working.":
              [
                "你确定要解锁这条记录吗？编辑或删除这条记录可能会导致你的网站停止服务。",
              ],
            "Domain|Australian Business Number": ["澳大利亚商业编号"],
            "Domain|Australian Company Number": ["澳大利亚公司编号"],
            "Domain|Auth/EPP Code cannot be empty": ["请填写Auth/EPP授权码"],
            "Domain|Auto renew my domain": ["自动续期域名"],
            "Domain|Auto-renew failed. Please click the button to renew.": [
              "自动续费失败。请点击按钮完成续费。",
            ],
            "Domain|Back": ["返回"],
            "Domain|Based on the registrar's policy, the domain must be renewed before this date to prevent service interruptions":
              [
                "根据域名注册商的政策，为了避免服务中断，域名续费必须在此日期之前完成",
              ],
            "Domain|Be careful! Deleting this may cause your domain email and email sender profile to stop working. Are you absolutely sure you want to delete this record?":
              [
                "小心！删除这条记录可能会导致你的域名邮箱和邮件发件人信息无法使用，你非常确定要删除这条记录吗？",
              ],
            "Domain|Be careful! Deleting this may cause your site to go offline. Are you absolutely sure you want to delete this record?":
              [
                "小心！删除这条记录可能会导致你的网站下线，你非常确定要删除这条记录吗？",
              ],
            "Domain|Be careful! Editing this may cause your domain email and email sender profile to stop working. Are you absolutely sure you want to edit this record?":
              [
                "小心！编辑这条记录可能会导致你的域名邮箱和邮件发件人信息无法使用，你非常确定要编辑这条记录吗？",
              ],
            "Domain|Be careful! Editing this may cause your site to go offline. Are you absolutely sure you want to edit this record?":
              [
                "小心！编辑这条记录可能会导致你的网站下线，你非常确定要编辑这条记录吗？",
              ],
            "Domain|Business registration number": ["商业登记号码"],
            "Domain|Business registration number can't be empty.": [
              "商业登记号码不能为空。",
            ],
            "Domain|By the registrar’s rules, %{var1} domains are auto-renewed by default. To allow the %{var1} domain to expire, you must complete and submit the deletion form at least %{var2} days before renewal.":
              [
                "根据注册商的规则，%{var1}域名是默认自动更新的。如果要让%{var1}域名到期，你必须在续费日期前至少%{var2}天完成并提交删除申请表。",
              ],
            "Domain|By the registrar’s rules, %{var1} domains are auto-renewed by default. [strong:To allow the %{var1} domain to expire, you must [link:complete and submit the deletion form] at least %{var2} days before renewal.]":
              [
                "根据注册商的规则，%{var1}域名是默认自动更新的。 [strong:如果要让%{var1}域名到期，你必须在续费日期前至少%{var2}天[link:完成并提交删除申请表]。]",
              ],
            "Domain|Cancelled": ["已取消"],
            "Domain|Change domain contact email": ["更改域名联系邮箱"],
            "Domain|Charity": ["慈善机构"],
            "Domain|Check Status": ["检查状态"],
            "Domain|Choose a State/Province": ["选择一个州/省"],
            "Domain|Choose a country/region": ["选择一个国家/地区"],
            "Domain|Choose a registrant type": ["选择一个注册者类型"],
            "Domain|Choose a type": ["请选择类型"],
            "Domain|Choose an entity type": ["选择一个实体类型"],
            "Domain|Choose your domain provider": ["请选择你的域名提供商"],
            "Domain|Citizen/Resident": ["公民/居民"],
            "Domain|City": ["城市"],
            "Domain|City, Province": ["XX省XX市"],
            "Domain|Click here to apply for filing": ["点击这里申请备案"],
            "Domain|Click to copy": ["点击复制"],
            "Domain|Club": ["俱乐部"],
            "Domain|Company": ["公司"],
            "Domain|Company/personal name": ["主体名称"],
            "Domain|Configure your domain": ["配置你的域名"],
            "Domain|Confirm Domain Purchase": ["确认购买域名"],
            "Domain|Confirm Domain Renewal": ["确认域名续费"],
            "Domain|Confirm Domain Transfer": ["确认转移域名"],
            "Domain|Confirm Owner Info": ["确认所有者信息"],
            "Domain|Confirm Purchase": ["确认购买"],
            "Domain|Confirm Renewal": ["确认续费"],
            "Domain|Confirm Transfer": ["确认转移域名"],
            "Domain|Confirming": ["确认中"],
            "Domain|Congratulations! [placeholderStrong: %{domain}] is available.":
              ["恭喜！ [placeholderStrong: %{domain}]可用。"],
            "Domain|Connect a Domain You Already Own": ["绑定你已有的域名"],
            "Domain|Contact Information": ["联络信息"],
            "Domain|Contact Support": ["联系客服"],
            "Domain|Continue Transfer": ["继续转移"],
            "Domain|Copy success!": ["复制成功！"],
            "Domain|Country/Region": ["国家/地区"],
            "Domain|DNS Settings for": ["DNS设置"],
            "Domain|Date of birth": ["出生日期"],
            "Domain|Date of birth can't be empty.": ["出生日期不能为空。"],
            "Domain|Disable Anyway": ["仍要禁用"],
            "Domain|Disconnect Domain & Unpublish The Site": [
              "解绑域名下线网站",
            ],
            "Domain|Domain": ["域名"],
            "Domain|Domain Not Connected": ["域名未连接"],
            "Domain|Domain Preparation": ["域名准备"],
            "Domain|Domain Renewal": ["域名续费"],
            "Domain|Domain connected": ["域名已连接"],
            "Domain|Domain contact email updated successfully": [
              "域名联系邮箱更新成功",
            ],
            "Domain|Domain contact info updated successfully": [
              "域名联络信息更新成功",
            ],
            "Domain|Domain is being redeemed. Please wait for updates. (This may take 3-7 business days.)":
              ["域名正在被赎回，请等待更新(可能需要3-7个工作日)。"],
            "Domain|Domain is taken by another Strikingly account.": [
              "域名被另一个Strikingly账号所有。",
            ],
            "Domain|Domain name must not include the following characters:%{var1}":
              ["域名名称中不能包含 “%{var1}” 等字符"],
            "Domain|Domain names can only contain lowercase letters, numbers and hyphens (-).":
              ["域名只能包含小写字母、数字和连字符(-)。"],
            "Domain|Domain names can only contain lowercase letters, numbers and hyphens (-). Please try again or select the following alternates.":
              [
                "域名只能包含小写字母、数字和连字符(-)。请重新输入或选择下列备选域名。",
              ],
            "Domain|Domain renewal failed. Please contact support for further help.":
              ["域名续费失败。请联系客服来获得更多帮助。"],
            "Domain|Domain unlocked": ["域名已解锁"],
            "Domain|Domain verified successfully": ["域名验证成功"],
            "Domain|Domains": ["域名"],
            "Domain|Download deletion form": ["下载删除申请表"],
            "Domain|Edit Domain Contact Info": ["编辑域名联络信息"],
            "Domain|Edit domain contact email": ["编辑域名联系邮箱"],
            "Domain|Eligibility ID": ["域名资格编号"],
            "Domain|Eligibility ID Type": ["域名资格编号类型"],
            "Domain|Eligibility Name": ["域名资格名称"],
            "Domain|Eligibility Type": ["域名资格类型"],
            "Domain|Email": ["邮箱"],
            "Domain|Email address is invalid.": ["邮箱地址无效。"],
            "Domain|Email updated, please verify your domain": [
              "邮箱已更新，请验证你的域名",
            ],
            "Domain|Emails": ["邮箱"],
            "Domain|Ends at": ["结束时间"],
            "Domain|Enter Auth/EPP code": ["输入Auth/EPP授权码"],
            "Domain|Enter ICP/PSB numbers": ["设置备案号"],
            "Domain|Enter a domain to see if it's available.": [
              "输入域名看看是否可以注册。",
            ],
            "Domain|Enter your password": ["输入你的密码"],
            "Domain|Entity type": ["实体类型"],
            "Domain|Example Co., Ltd.": ["XXX有限公司"],
            "Domain|Expired at": ["结束于"],
            "Domain|Expires at": ["结束于"],
            "Domain|FIRST YEAR FREE": ["首年免费"],
            "Domain|Failed": ["失败"],
            "Domain|Filing service number": ["备案服务号"],
            "Domain|Filing service number application success": [
              "备案服务号申请成功",
            ],
            "Domain|Filing success": ["备案成功"],
            "Domain|First name": ["名字"],
            "Domain|Fix Auth Code": ["修改授权码"],
            "Domain|Fix Contact Info": ["修正联系人信息"],
            "Domain|Fix domain contact info": ["修正域名联系人信息"],
            "Domain|Footer must be shown if you have ICP Filing info set.": [
              "网站里有备案信息需显示页脚。",
            ],
            "Domain|Free": ["免费"],
            "Domain|Get a Free Custom Domain": ["获得一个免费的自定义域名"],
            "Domain|Go to Aliyun filing system": ["前往阿里云备案系统"],
            "Domain|Grace period": ["宽限期"],
            "Domain|Have you already successfully applied for ICP filing numbers for this domain from either Aliyun or Tencent Cloud? We only accept ICP filing numbers from these services.":
              [
                "你的域名是否已经在阿里云或腾讯云成功申请了备案？上线了只能接受来自这些服务商的备案号。",
              ],
            "Domain|Hey, you don't have any domains on Strikingly yet!": [
              "嗨！你还没有自定义域名哦！",
            ],
            "Domain|How do I connect my domain to SXL?": [
              "如何将我的域名连接到上线了？",
            ],
            "Domain|I accept the [link: terms] of the domain registration agreements.":
              ["我接受域名注册协议的[link: 条款]。"],
            "Domain|I have read and agree to the terms of the [link:CIRA Registrant Agreement.]":
              ["我已阅读并同意[link:CIRA注册人协议的条款。]"],
            "Domain|I have verified the above and am ready to start filing.": [
              "我已核实上述内容，都准备好了，可以开始备案。",
            ],
            "Domain|I've confirmed, check again": ["我已经确认，再次检查"],
            "Domain|I've unlocked, check again": ["我已经解锁，再次检查"],
            "Domain|I've verified, check again": ["我已经验证，再次检查"],
            "Domain|ICP & PSB Filing for Domain": ["域名备案号"],
            "Domain|ICP Filing Number": ["ICP备案"],
            "Domain|ICP and PSB filing numbers are legal requirements for all custom domains. Follow the instructions below to submit these filing numbers.":
              [
                "根据法律规定需要对所有自定义域名进行备案，请按照以下说明来提交备案号。",
              ],
            "Domain|ICP filing number": ["ICP备案号"],
            "Domain|ID card number": ["身份证号码"],
            "Domain|ID card number can't be empty.": ["身份证号码不能为空。"],
            "Domain|ID card number is invalid.": ["身份证号码无效。"],
            "Domain|If the registrant is an organization, a company stamp must be affixed to the form in the area labeled [strong:Company Chop].":
              [
                "如果注册人是一个组织，则必须在表格上标有公司印章的区域加盖[strong:公司印章]。",
              ],
            "Domain|If you applied for the domain as an individual, please fill in your name; if you applied as a company, please fill in your company name on your business license.":
              [
                "如果你是以个人名义申请的域名，请填写你的姓名；如果你是以企业名义申请，请填写营业执照上的企业名称。",
              ],
            "Domain|If you buy a domain now, you’ll get up to [placeholderStrong: $24.95 credit] on yearly Strikingly plans.":
              [
                "现在购买域名，将在Strikingly包年套餐中获得[placeholderStrong:$24.95 现金抵扣]。",
              ],
            "Domain|If your domain's real-name verification has just approved, it may take some time for the data to be updated, so it is recommended to apply for the filing service number after 2-3 days.":
              [
                "若域名的实名认证才刚通过，域名注册局的数据可能不会立即更新，建议2-3天后再申请备案服务号。",
              ],
            "Domain|Inactive": ["未生效"],
            "Domain|Incorporated Association": ["社团法人"],
            "Domain|Incorrect domain format.Please check again!": [
              "域名格式不正确，请重新检查！",
            ],
            "Domain|Individual": ["个人"],
            "Domain|Invalid Auth/EPP Code": ["无效的Auth/EPP授权码"],
            "Domain|Keep Domain Connection": ["保留域名连接"],
            "Domain|Last Step: Approve the Transfer": ["最后一步：批准转移"],
            "Domain|Last name": ["姓氏"],
            "Domain|Last step: verify your domain": ["最后一步：验证你的域名"],
            "Domain|Latest Renewal Date": ["最晚续费日"],
            "Domain|Location": ["主体所在地域"],
            "Domain|Make sure your domain is connected to SXL domestic servers":
              ["确保你的域名已经连接到「上线了」服务器"],
            "Domain|Make sure your email is correct! You will be required to verify your info via email after the transfer.":
              [
                "请确认你的电子邮件地址是正确的。域名转移过程中，我们需要您通过电子邮件进行转移操作的二次确认",
              ],
            "Domain|Make sure your email is correct! You will be required to verify your info via email after your purchase.":
              ["请确保你的电子邮箱无误！你必须在购买后通过邮件确认你的信息。"],
            "Domain|Make your site look more professional and improve your search engine ranking!":
              ["让你的网站看上去更正规专业，并且在搜索结果中排名更高！"],
            "Domain|Manage Email Accounts": ["管理邮箱账号"],
            "Domain|My Domains on Strikingly": ["我的域名"],
            "Domain|My custom domain is connected to SXL": [
              "我的自定义域名已经连接",
            ],
            "Domain|Next, you will need to apply for filing on Aliyun. Don't worry, we've written detailed instructions for you in the tutorial -- just follow the instructions to complete the process.":
              [
                "接下来你需要前往阿里云，不用担心，我们已经在教程中为你写好了详细的说明，你只需要按照说明完成即可。",
              ],
            "Domain|No, I do not have ICP numbers from Aliyun or Tencent Cloud":
              ["不是，我没有在阿里云或腾讯云备案"],
            "Domain|Non-profit Organization": ["公益组织"],
            "Domain|Not filed yet?": ["没有备案？"],
            "Domain|Not used": ["未使用"],
            "Domain|Note: If you change the email, we are required by policy to impose a 60-day transfer lock. This lock means that you will not be able to transfer this domain (%{var3}) to another registrar for a period of 60 days after the change.":
              [
                "注意：如果你更改了邮箱，根据政策要求，我们将实施60天的转移锁定。此锁定意味着在更改后的60天内，你将无法将该域名（%{var3}）转移给其他注册商。",
              ],
            "Domain|Note: The filing service number is not the ICP filing number! The filing service number is a temporary code required when applying for the ICP filing number.":
              [
                "注意：备案服务号并不是ICP备案号！备案服务号是你申请ICP备案号时需要填写的临时号码。",
              ],
            "Domain|Only letters, numbers, and hyphens are allowed.": [
              "仅支持英文字母，数字，或连字号(-)。",
            ],
            'Domain|Open the [link1:site of the Ministry of Industry and Information Technology "domain name registrar approval"], enter your domain name registrar in the "enterprise name" field and see if your registrar is approved. If not (e.g. overseas domain name registrars), please transfer your domain name to an approved domain name registrar, such as [link2:Aliyun] or [link3:Tencent Cloud].':
              [
                "打开[link1:工信部网站的“域名注册服务机构审批情况”]，在“企业名称”处输入你的域名注册商，查看是否有结果。如果没有（如境外域名注册商），请把你的域名转移到已获批复的域名注册商，比如[link2:阿里云]，[link3:腾讯云]。",
              ],
            'Domain|Open the [link:"China Internet domain name system list" on the site of the Ministry of Industry and Information Technology], and make sure your domain suffix appears in the list. If not, it means that this domain name suffix can not be filed, such as .org, .tw, .io, etc. You can also call our filing provider Aliyun\'s phone service: 95187, and dial 3 to confirm.':
              [
                "打开[link:工信部网站的“中国互联网域名体系列表”]，确认列表中是否有你的域名后缀，如果没有，则表示该域名后缀无法备案，比如 .org，.tw，.io等。你也可以拨打我们的备案接入商“阿里云”的咨询电话：95187转3确认。",
              ],
            "Domain|Organization": ["组织"],
            "Domain|Other": ["其他"],
            "Domain|Others": ["其它"],
            "Domain|Owner Information": ["域名持有者信息"],
            "Domain|PSB Filing Number": ["公安备案"],
            "Domain|Partnership": ["合伙"],
            "Domain|Pay for the plan and get service number for free": [
              "支付套餐，免费获取服务号",
            ],
            "Domain|Pending Owner Approval": ["等待持有人确认"],
            "Domain|Pending Trademark Owner": ["未决商标持有人"],
            "Domain|Period": ["时期"],
            "Domain|Phone": ["电话号码"],
            "Domain|Phone number is invalid.": ["电话号码无效。"],
            "Domain|Please check the box to confirm.": ["请确认并勾选选框"],
            "Domain|Please choose a registrant type.": ["请选择注册者类型。"],
            "Domain|Please choose an entity type.": ["请选择实体类型。"],
            "Domain|Please click the button to renew.": [
              "请点击按钮完成续费。",
            ],
            "Domain|Please contact support if you have any questions.": [
              "如果你有任何问题，请联系客服。",
            ],
            "Domain|Please enter the correct ICP Filing number": [
              "请输入正确的ICP备案号",
            ],
            "Domain|Please enter the correct PSB Filing number": [
              "请输入正确的公安备案号",
            ],
            "Domain|Please enter the domain": ["请输入域名"],
            "Domain|Please enter the location": ["请输入所在地域"],
            "Domain|Please enter the name": ["请输入主体名称"],
            "Domain|Please enter the site description": ["请输入网站描述"],
            "Domain|Please enter your ICP/PSB Filing numbers": [
              "请输入你的备案信息。",
            ],
            "Domain|Please fill in your ICP and PSB filing numbers. This will be displayed in your site's footer.":
              [
                "请填写你的ICP备案号和公安备案号，它们将会显示在你的网站页脚里。",
              ],
            "Domain|Please fill out the form and send the completed form to [email:%{var1}]. We will process it with our registrar partner.":
              [
                "请填写表格，并将填妥的表格发送至[email:%{var1}]。我们将与我们的注册商合作伙伴进行处理。",
              ],
            "Domain|Please make sure that the Auth/EPP code you paste is complete and correct. Paste the code as soon as you get it, before it expires.":
              [
                "请确保你粘贴的Auth/EPP授权码是完整和正确的。在你获得授权码后尽快粘贴，以防止授权码过期。",
              ],
            "Domain|Please make sure the name of the domain owner(company/personal) and the name that is going to apply ICP regulation is consistent, otherwise the ICP filing will not pass.":
              [
                "请确保你所申请的域名的实名认证主体与即将备案的主体是一致的，否则ICP备案将无法通过。",
              ],
            "Domain|Please read and agree to this.": ["请阅读并同意。"],
            "Domain|Policy Reason": ["政策原因"],
            "Domain|Prefecture": ["县"],
            "Domain|Previous step": ["上一步"],
            "Domain|Price": ["价格"],
            "Domain|Processing": ["处理中"],
            "Domain|Province": ["省"],
            "Domain|Province /territory": ["省/地区"],
            "Domain|Purchasing this domain gives you a one-time $24.95 credit for a Strikingly yearly plan.":
              [
                "域名|购买此域名为您提供一次性的24.95美元的折扣，用于Strikingly的年度计划。",
              ],
            "Domain|RENEWING...": ["续费中..."],
            "Domain|Read Aliyun filing tutorial": ["查看阿里云备案教程"],
            "Domain|Recommendations for you:": ["为你推荐："],
            "Domain|Redeem": ["兑换"],
            "Domain|Register": ["注册"],
            "Domain|Register New Domain": ["注册新域名"],
            "Domain|Registering %{domain}": ["正在注册 %{domain} ……"],
            "Domain|Registrant ID": ["注册人编号"],
            "Domain|Registrant ID Type": ["注册人编号类型"],
            "Domain|Registrant Name": ["注册人姓名"],
            "Domain|Registrant type": ["注册者类型"],
            "Domain|Registration number": ["注册编号"],
            "Domain|Remember, you must check your email to validate your domain.":
              ["请注意，您必须检查您的电子邮件以验证您的域名。"],
            "Domain|Renew Now": ["立即续费"],
            "Domain|Renewal payment failed. This domain has been given back to the registry (%{var1}). Please check the email sent to you by the registry for details.":
              [
                "续费付款失败。此域名已经被退回给注册局（%{var1}）。详情请查看注册局给你发送的邮件。",
              ],
            "Domain|Renewing %{var1}": ["正在续费%{var1}"],
            "Domain|Renews at $%{price}/year": ["续费价格为$%{price}/年"],
            "Domain|Resend verification email": ["重新发送验证邮件"],
            "Domain|Restart Transfer": ["重启转移"],
            "Domain|Resubmit": ["重新提交"],
            "Domain|SIREN/SIRET number": ["SIREN/SIRET 号码"],
            "Domain|Search Domain": ["搜索域名"],
            "Domain|Select your registrar": ["选择你的注册商"],
            "Domain|Sole Trader": ["个体经营者"],
            "Domain|Sorry, %{var1} is not available right now.": [
              "抱歉，%{var1} 目前无法使用。",
            ],
            "Domain|Sorry,[placeholderStrong: %{domain}] is already taken.": [
              "对不起，[placeholderStrong: %{domain}]已经被使用了。",
            ],
            "Domain|Sorry,[placeholderStrong: %{domain}] is not available right now.":
              ["抱歉，[placeholderStrong：%{domain}]目前无法使用。"],
            "Domain|Start configuration": ["开始配置"],
            "Domain|Start filing with Aliyun": ["开始向阿里云备案"],
            "Domain|Starts at": ["开始时间"],
            "Domain|State": ["州"],
            "Domain|State/Province": ["州/省"],
            "Domain|Step": ["步骤"],
            "Domain|Strikingly URL:": ["Strikingly网址："],
            "Domain|Submit": ["提交"],
            "Domain|The date format is %{var1}, such as %{var2}.": [
              "日期格式为%{var1}，如%{var2}。",
            ],
            "Domain|The domain name exactly matches the acronym or abbreviation of registrant's company or trading name, organization or association name, or trademark":
              [
                "此域名名字与注册者公司或商号、组织或协会名称或商标的首字母缩略词或缩写完全匹配",
              ],
            "Domain|The domain name is connected closely and substantially to the registrant":
              ["此域名名字与注册者有密切且实质性的联系"],
            "Domain|The filing number is now displayed in your site footer.": [
              "你的备案信息已显示在网站页脚里。",
            ],
            "Domain|The system will automatically save your current progress so that you can continue at any time.":
              ["系统将自动保存你的当前进度，方便你随时继续。"],
            "Domain|The verification email has been send to your domain contact email (%{var1}). [strong:Please click the link in the email to verify your domain.] The domain will be disabled if it is not verified by %{var2}.":
              [
                "验证邮件已经发送到你的域名联系邮箱（%{var1}）。[strong:请点击邮件中的链接验证你的域名。]如果没有在%{var2}前完成验证，你的域名将被暂停。",
              ],
            "Domain|This domain has already been bound to a service number. Please do not repeat the application. If you have any questions, please [link:contact support].":
              [
                "此域名已经绑定了一个服务号，请勿重复申请。如有疑问，请[link:联系客服]。",
              ],
            "Domain|This domain has been reserved or restricted by the registrar. Please try another domain name.":
              ["该域名已被注册局保留或限制注册。请尝试其他域名。"],
            "Domain|This domain is expired, but is still within the grace period. You can reinstate this domain simply by renewing it.":
              [
                "这个域名已经过期，但仍在宽限期内。你可以通过续费来恢复这个域名。",
              ],
            "Domain|This domain is now in its redemption period (the last chance to retain it before it becomes publicly available for purchase). Please contact support to retain this domain.":
              [
                "域名现在正处于赎回期。在域名被公开售卖之前，这是你保留它的最后机会。如果想要保留这个域名，请联系我们。",
              ],
            "Domain|This filing service number will expire within one week! Please [link1:go to Aliyun] and use this filing service number to apply for the ICP filing number as soon as possible. If expired, please [link2:contact support].":
              [
                "这个备案服务号的有效期是一个星期！请尽快[link1:前往阿里云]并使用此备案服务号来申请ICP备案号。如果过期请[link2:联系客服]。",
              ],
            "Domain|This filing service number will expire within one week! Please go to Aliyun and use this filing service number to apply for the ICP filing number as soon as possible. (Additional fees may be charged if expired.)":
              [
                "这个备案服务号的有效期是一个星期！请尽快前往阿里云并使用此备案服务号来申请ICP备案号。（如果过期可能需要额外付费。）",
              ],
            "Domain|This record is locked because it is in use. If you are sure you want to edit or delete it, first click the lock icon to unlock.":
              [
                "这条记录被锁定，因为它正在使用中，如果你确定要编辑或删除它，首先点击锁图标进行解锁。",
              ],
            "Domain|To change this domain's contact info, please enter your account password.":
              ["请输入你的账户密码以修改此域名的联络信息。"],
            "Domain|To delete the %{var1} domain or allow it to expire, the registrant must complete and submit the deletion form at least %{var2} days prior to the expiry date. Upon reviewing the form, our registrar partner disables auto-renewal and sets the domain to expire on its expiry date.":
              [
                "如果要删除一个%{var1}域名或让它到期，注册人必须在到期日前至少%{var2}天完成并提交删除申请表。在审核此表后，我们的注册商合作伙伴会禁用自动续费，并将域名设置为到期日失效。",
              ],
            "Domain|To prevent service interruptions, we'll attempt to renew this domain [strong:7 days before the latest renewal date].":
              [
                "为了避免服务中断，我们将在[strong:最晚续费日的7天前]尝试续费域名。",
              ],
            "Domain|Trade Union": ["贸易联盟"],
            "Domain|Trademark Owner": ["商标持有人"],
            "Domain|Trademark number": ["商标号"],
            "Domain|Transfer": ["转移域名"],
            "Domain|Transfer Cancelled": ["转移被取消"],
            "Domain|Transfer in process": ["正在转移中"],
            "Domain|Unlock this domain": ["解锁此域名"],
            "Domain|Unlock this record": ["解锁这条记录。"],
            "Domain|Update your domain settings to connect %{domain} to your site.":
              ["更新你的域名设置以连接%{domain}到你的网站。"],
            "Domain|Upgrade To Get Free Domain": ["升级以获得免费域名"],
            "Domain|Upgrade to yearly plan or above to get a free domain for 1 year. To connect a domain you already own, you'll also need to upgrade your plan.":
              [
                "升级到包年套餐及以上可以获得一个有效期为一年的免费域名。若要绑定你已有的域名，你也需要升级套餐。",
              ],
            "Domain|Upgrade your plan to connect an existing domain.": [
              "升级你的套餐来绑定已有的域名。",
            ],
            "Domain|Use the filing service number to go to Aliyun for filing": [
              "使用备案服务号前往阿里云备案",
            ],
            "Domain|VAT number": ["增值税税号"],
            "Domain|Verification email sent successfully": ["验证邮件发送成功"],
            "Domain|Verify domain": ["验证域名"],
            "Domain|View guide for getting the Auth/EPP code": [
              "查看获取Auth/EPP授权码的指南",
            ],
            "Domain|View guide for getting the Auth/EPP code on %{var1}": [
              "查看在%{var1}上获取Auth/EPP授权码的指南",
            ],
            "Domain|View guide for unlocking a domain": ["查看解锁域名的指南"],
            "Domain|View guide for unlocking a domain on %{var1}": [
              "查看在%{var1}上解锁域名的指南",
            ],
            "Domain|View your new domain in domain dashboard.": [
              "在域名控制面板查看你新注册的域名。",
            ],
            "Domain|Warning": ["警告"],
            "Domain|We are persistently checking your domain connection. This can take up to 48 hours. We’ll update you the result via email.":
              [
                "我们正在持续地地检查你的域名连接。这可能需要长达48小时。我们将通过电子邮件向您更新结果。",
              ],
            "Domain|We have received the domain deletion form. Your domain is set to expire on its expiry date.":
              ["我们已经收到域名删除申请表，你的域名将在到期日失效。"],
            "Domain|We partner with ICANN accredited registrar OpenSRS.com to make domain registration easy for you. We respect [link: your rights as a domain owner]":
              [
                "我们与ICANN认证的注册商OpenSRS.com合作，为您提供域名注册。我们尊重[link: 你作为域名所有者的权利]。",
              ],
            "Domain|We strongly recommend enabling auto-renewal to avoid losing your domain.":
              ["我们强烈建议你启用自动续费功能避免意外情况发生。"],
            "Domain|We strongly recommend that you enable auto-renewal. Missing a domain’s renewal window will disrupt service for all websites and emails connected to that domain. Are you sure you want to disable auto-renewal for your domain?":
              [
                "我们强烈建议你启用自动续费功能。忘记续费的话，你的所有绑定这个域名的网站和邮件将中断服务。你确定仍要禁用自动续费功能吗？",
              ],
            "Domain|We'll bill this purchase with the card you have on file (last four digits: %{fd})":
              ["我们将使用您绑定的信用卡（后四位：%{fd}）支付本次购买的费用"],
            "Domain|We'll bill this transfer with the card you have on file (last four digits: %{fd})":
              [
                "我们将使用你绑定的银行卡为本次域名转移付款（卡号后四位：%{fd}）",
              ],
            "Domain|When applying for an ICP filing number in the Aliyun ICP filing management system, you will need a filing service number to associate your domain and Aliyun server. The filing service number is only valid for one week.":
              [
                "在阿里云ICP代备案管理系统申请ICP备案号时，你将需要一个备案服务号来关联你的域名和阿里云服务器。备案服务号的有效期只有一个星期。",
              ],
            "Domain|Why is the registrant entitled to use the domain name?": [
              "请选择以下选项以说明为什么注册者有权使用此域名名字",
            ],
            "Domain|Yes, I have ICP numbers from Aliyun or Tencent Cloud": [
              "是的，我已经在阿里云或腾讯云备案",
            ],
            'Domain|You are trying to use an IDN (Internationalized Domain Name). Special characters will be converted to "[domain: %{var}]" to ensure compatibility. You can try again with an English domain name or continue with one of these.':
              [
                "你正在尝试使用IDN(国际化域名)。 特殊字符将被转换为“[domain: %{var}]”以确保兼容性。 你可以使用英文域名再试一次，或选择下列任一域名继续。",
              ],
            "Domain|You are using custom code. If you disconnect your custom domain,[strong: for security reasons, your site will be unpublished.]":
              [
                "你当前正在使用自定义代码。如果你解绑了自定义域名，[strong: 出于网络安全考虑，你的网站会被下线。]",
              ],
            "Domain|You can view the status of your filing service numbers in the list. If the ICP filing is successful, our system will automatically add the filing number to the appropriate site.":
              [
                "你可以在列表中查看你申请的服务号的相关信息和状态，如果ICP备案成功，系统会自动添加备案号到相应的网站。",
              ],
            "Domain|You cannot initiate .uk domain transfer before your domain tag is updated to TUCOWS-CA.":
              [
                "您不符合 .uk 域名转移条件，请将您的域名标签更新为 TUCOWS-CA 。",
              ],
            "Domain|You have exceeded your service number quota. Please contact support to purchase, and our support staff will increase the quota for you.":
              [
                "你已超出你的服务号配额，请联系客服购买，我们的客服会为你增加配额。",
              ],
            "Domain|You may only use alphanumeric characters and simple punctuations.":
              ["你只能使用字母，数字和简单的标点符号。"],
            "Domain|You must [placeholderStrong: validate this domain] through your email (%{email}), or else [placeholderStrong2: it will be disabled in 15 days!] Be sure to check your spam folder.":
              [
                "你必须通过电子邮件(%{email}) [placeholderStrong: 验证此域名]，否则[placeholderStrong2: 将在15天内被禁用！]请务必检查你的垃圾邮件。",
              ],
            "Domain|You need to accept the terms to register the domain.": [
              "注册域名需要接受域名注册协议的条款。",
            ],
            "Domain|You'll need to republish your site to submit your custom code for review. Once it passes review, your site will be live again.[strong: Are you sure you want to disconnect your domain?]":
              [
                "你需要重新发布你的网站以提交自定义代码审核。审核通过后，你的网站就能再次生效，[strong:你确定要解绑域名吗？]",
              ],
            "Domain|You're on a free plan! You'll need to [placeholderStrong: upgrade your plan] to connect a domain to your site.":
              [
                "你当前是免费版套餐！你需要[placeholderStrong:升级套餐]来为你的网站绑定域名。",
              ],
            "Domain|You're on a free plan! You'll need to [placeholderStrong: upgrade your plan] to connect a domain to your site. (If you upgrade to yearly plan or above, you'll get a free domain.)":
              [
                "你当前是免费版套餐！你需要[placeholderStrong:升级套餐]来为你的网站绑定域名。（如果你升级到包年套餐或以上，你将获得一个免费域名。)",
              ],
            "Domain|Your Auth/EPP code is invalid. Please get a valid code from your registrar and try again.":
              [
                "你的Auth/EPP授权码无效。请从你的注册商那里获得有效的授权码，然后再试一次。",
              ],
            "Domain|Your Site Will Be Unpublished": ["你的网站将下线"],
            "Domain|Your domain (%{var3}) is currently suspended due to unverified contact information. This verification email was sent to your domain contact email (%{var1}). [strong:Please click the link in the email to verify your domain.]":
              [
                "你的域名（%{var3}）目前被暂停，因为联系信息尚未验证。此验证邮件已发送到你的域名联系邮箱（%{var1}），[strong:请点击邮件中的链接验证你的域名。]",
              ],
            "Domain|Your domain has been approved for transfer! It takes about 5 days for your registrar to release your domain to us. You don't have to do anything. We'll email you when the transfer is complete.":
              [
                "你的域名已被批准转移！你的注册商需要5天左右的时间来把你的域名释放给我们。你不需要做任何事情。转移完成后我们会给你发邮件。",
              ],
            "Domain|Your domain has been billed and will be renewed before %{var1}. It will continue to work during this time. If you have any question about the renewal process, feel free to contact us.":
              [
                "你的域名已经付款，并且将在 %{var1} 前续费。在这期间，你的域名会一直有效。如果你对续订过程有任何疑问，请随时和我们联系。",
              ],
            "Domain|Your domain has been successfully filed with ICP and our system has automatically added the ICP filing number to your site's footer. Please [link:submit the application for PSB filing] within 30 days from the date of website opening.":
              [
                "你的域名ICP备案成功，系统已自动帮你添加ICP备案号到网站页脚。请在网站开通之日起30日内[link:提交公安联网备案申请]。",
              ],
            "Domain|Your domain is not configured properly for this site because the CNAME record has been edited or deleted. Please contact support if you have any questions.":
              [
                "你的域名没有正确配置到这个网站，因为CNAME记录已被编辑或删除。如果你有任何问题，请联系客服。",
              ],
            "Domain|Your domain is not yet approved for transfer. Please check an email from your registrar and confirm your approval as soon as you can. If you haven’t received the email, please contact your registrar.":
              [
                "你的域名还没有被批准转移。请查看来自你的注册商的邮件，并尽快确认你的批准。如果你还没有收到邮件，请联系你的注册商。",
              ],
            "Domain|Your domain is still locked. It takes a few minutes for registrars to update your domain status. Please check back later.":
              [
                "你的域名仍然被锁定。注册商需要几分钟更新你的域名状态，请稍后再来查看。",
              ],
            "Domain|Your domain is still not verified. It takes a few minutes for our registrar partner to update your domain status. Please check back later.":
              [
                "你的域名仍未验证。我们的注册商合作伙伴需要几分钟来更新你的域名状态，请稍后再来查看。",
              ],
            "Domain|Your domain is suspended": ["你的域名被暂停使用"],
            "Domain|Your domain must be filed with Aliyun.": [
              "你的域名必须在阿里云备案。",
            ],
            "Domain|Your domain must be successfully connected to SXL servers. If you purchased your domain from SXL, it will be connected automatically. If you purchased your domain elsewhere, make sure you complete these instructions to connect your domain to SXL. Even after successfully applying for ICP, if your domain is not connected to SXL servers, your site will not be visible.":
              [
                "你的域名必须成功连接到上线了服务器。如果你是从上线了购买的域名，它将被自动连接。如果你是在其他地方购买的域名，请确保你按照说明将您的域名连接到上线了。即使成功申请了ICP备案号，如果你的域名没有连接到上线了服务器上，你的网站将仍旧无法访问。",
              ],
            "Domain|Your domain registration failed. Please contact support for further assistance.":
              ["你的域名注册失败，请联系我们的客服来帮助你解决问题。"],
            "Domain|Your domain registration/transfer failed because the ZIP/Postal code is invalid. Please enter a valid ZIP/Postal code to continue with the registration/transfer.":
              [
                "你的域名注册/转移失败，因为邮编无效。请输入一个有效的邮编以继续注册/转移。",
              ],
            "Domain|Your domain registration/transfer failed because the phone number is invalid. Please enter a valid number to continue with the registration/transfer.":
              [
                "你的域名注册/转移失败，因为电话号码无效。请输入一个有效的号码以继续注册/转移。",
              ],
            "Domain|Your domain transfer (%{var1}) has been cancelled because the transfer was not approved in time. We will restart your domain transfer request in 24 hours automatically. Or you can restart it now.":
              [
                "你的域名转移(%{var1})已被取消，因为转移没有及时被批准。我们将在24小时内自动重启你的域名转移请求。或者你可以现在就重启。",
              ],
            "Domain|Your domain transfer failed. Please contact support for further help.":
              ["你的域名转移失败。请联系客服来获得更多帮助。"],
            "Domain|Your domain transfer is awaiting confirmation, please check back later.":
              ["你的域名转移正在等待确认，请稍后再来查看。"],
            "Domain|Your domain's [link:real-name verification] must be successful, and the name must be consistent with the name used to file for ICP. If inconsistent, please modify the owner info of your domain first (takes 3-5 working days to review).":
              [
                "请确保你的域名已通过[link:实名认证]，而且域名的实名认证主体必须与即将备案的主体一致。若不一致，则请先修改域名的实名认证（审核时间通常为3-5个工作日）。",
              ],
            "Domain|Your email is not working because the %{var1} record is edited/deleted. Contact support if you have any questions.":
              [
                "你的邮箱无法使用，因为%{var1}记录已被编辑或删除。如果你有任何问题，请联系客服。",
              ],
            "Domain|Your filing service number is %{var} You have already applied for ICP filing number with Aliyun. Once the filing is complete, our system will automatically add the ICP filing number to your site's footer.":
              [
                "你的备案服务号是%{var}，你已经在阿里云申请了备案。若备案成功，系统将会自动帮你添加ICP备案号到网站页脚。",
              ],
            "Domain|Your filing service number is:": ["你的备案服务号是："],
            "Domain|Your plan is in trial so you cannot receive a free service number for now. Please pay for the plan first in order to apply for a service number.":
              [
                "你的套餐还在试用期，暂时无法获取免费的备案服务号。请先支付套餐以申请服务号。",
              ],
            "Domain|Your transfer is still pending owner approval. You may contact your registrar directly and ask them to expedite processing.":
              [
                "你的转移仍在等待域名所有者批准。你可以直接联系你的注册商，要求他们加快处理。",
              ],
            "Domain|Your transfer of [strong:%{var1}] has been paused because the Auth/EPP code is invalid. Please get a valid code from your registrar and try again.":
              [
                "你的[strong:%{var1}]转移已暂停，因为Auth/EPP授权码无效。请从你的注册商处获得有效的授权码，然后再试一次。",
              ],
            "Domain|ZIP/Postal code": ["邮政编码"],
            "Domain|ZIP/Postal code is invalid.": ["邮政编码无效。"],
            "Domain|Zip code": ["邮政编码"],
            "Domain|[placeholderStrong1: You'll be billed $%{price} immediately] for your domain but [placeholderStrong2: will be credited $24.95] for the first payment of your Strikingly %{plan}.":
              [
                "[placeholderStrong1：您将立即为您的域名支付$%{price}]，但[placeholderStrong2：将被记录为24.95美元]，用于您的Strikingly第一次支付%{plan}。",
              ],
            "Domain|[placeholderStrong1: You'll be billed $%{price} immediately] for your domain.":
              ["[placeholderStrong1：您将立即为您的域名支付$%{price}费用]。"],
            "Domain|[placeholderStrong: You just got a new domain!]": [
              "[placeholderStrong：你刚刚获得了一个新的域名！]",
            ],
            "Domain|[strong:Important]: There is no refund when you delete an .AT domain.":
              ["[strong:重要]：删除.AT域名时不予退款。"],
            "Domain|[strong:Note:] If you change the name, organization, or email, we are required by policy to impose a 60-day transfer lock. This lock means that you will not be able to transfer this domain (%{var1}) to another registrar for a period of 60 days after the change.":
              [
                "[strong:注意：]如果你更改了姓名、组织、或邮箱，根据政策要求，我们将实行60天的转移锁定。此锁定意味着在更改后的60天内，你将无法将该域名（%{var1}）转移给其他注册商。",
              ],
            "Domain|[strong:Registrant Requirement:] All registrant information must be correct and accurate. The .UK registry (Nominet) will verify all registrants.":
              [
                "[strong:注册人要求：]所有的注册人信息必须准确无误。.UK注册局（Nominet）将核实所有的注册人。",
              ],
            "Domain|[strong:Registrant Requirement:] For .eu domains, registrant must have a valid address in the European Union.":
              [
                "[strong:注册人要求：]注册人的联系地址必须是在欧盟国家的有效地址。",
              ],
            "Domain|[strong:Registrant Requirement:] Registrant contact address and phone number must be in Japan.":
              ["[strong:注册人要求：]注册人联系地址和电话号码必须在日本。"],
            "Domain|[strong:Registrant Requirement:] Registrant must be a resident in the European Union, Switzerland, Norway, Iceland or Liechtenstein.":
              [
                "[strong:注册人要求：]注册者必须是欧盟、瑞士、挪威、冰岛或列支敦士登的居民。",
              ],
            "Domain|[strong:Registrant Requirement:] The owner must be a Malaysian citizen or a non-Malaysian residing in Malaysia.":
              [
                "[strong:注册人要求：]域名所有者必须是马来西亚公民或居住在马来西亚的非马来西亚人。",
              ],
            "Domain|[strong:Registrant Requirement:] The owner must be a legal entity incorporated in Malaysia.":
              [
                "[strong:注册人要求：]域名所有者必须是在马来西亚注册的法人实体。",
              ],
            "Domain|[strong:Registrant Requirement:] The registrant contact must be based in Malaysia.":
              ["[strong:注册人要求：]注册人必须位于马来西亚。"],
            "Domain|[strong:Registrant Requirement:] You must choose a registrant type and fill in the owner information.":
              ["[strong:注册人要求：]您必须选择注册人类型并填写所有者信息。"],
            "Domain|[strong:Registrant Requirement:] You must choose an Entity Type for the Canadian Presence Requirements and agree to the terms of the CIRA Registrant Agreements.":
              [
                "[strong:注册人要求：]您必须选择符合加拿大存在要求的实体类型并同意 CIRA 注册人协议的条款。",
              ],
            "Domain|[strong:Transfer Requirement:] For .uk domain transfer, you need to contact your existing registrar's support system and send them the following instructions to request a domain tag change:":
              [
                "[strong:.uk域名转移条件:]请联系您当前的域名注册商客服，并向客服发送以下说明以请求进行域名标签更改：",
              ],
            "Domain|[var1:Registrant Requirement:] Registrant must provide eligibility and registrant information in the owner information card and must have a valid Australian address.":
              [
                "[var1:域名注册要求：]注册人必须在所有者信息卡中提供资格和注册人信息，并且必须拥有有效的澳大利亚地址。",
              ],
            "Domain|can't be blank": ["字段不可留空"],
            "Domain|domain deletion": ["域名删除"],
            "Domain|e.g. example.com": ["例如：example.com"],
            "Don't own a domain yet? Grab one here.": [
              "还没有属于自己的域名吗？ 在这里获取一个。",
            ],
            "Don't worry, our engineers are working to fix the problem. Please try again later.":
              ["别担心，您可以稍后再试。"],
            "Donation|A short message after the user donates.": [
              "支持者付款成功后的感谢信息",
            ],
            "Donation|Add Campaign": ["新建筹款"],
            "Donation|Amount": ["金额"],
            "Donation|Choose Payment Method": ["选择付款方式"],
            "Donation|Donate": ["支持一下"],
            "Donation|Donate %{amount}": ["支付 %{amount}"],
            "Donation|Donation Button Text": ["筹款按钮文字"],
            "Donation|Donation Goal": ["筹款目标"],
            "Donation|Donation Info": ["付款信息"],
            "Donation|Donation Settings": ["筹款信息设置"],
            "Donation|Donors": ["支持者"],
            "Donation|Email": ["邮箱"],
            "Donation|Export To Excel": ["导出到Excel"],
            "Donation|Full Name": ["姓名"],
            "Donation|Goal": ["筹款目标"],
            "Donation|Got it!": ["关闭"],
            "Donation|Hide notes": ["隐藏留言"],
            "Donation|Invalid Amount": ["无效的金额"],
            "Donation|Invalid Price": ["无效的金额"],
            "Donation|Name": ["姓名"],
            "Donation|Once those donations start coming in, this is where you can review your donor's details.":
              ["一旦有新的筹款，您将在这里看到支持者和筹款详情。"],
            "Donation|Payment": ["支付"],
            "Donation|Payment Method": ["支付方式"],
            "Donation|Personal Information (optional)": ["个人信息(选填)"],
            "Donation|Phone Number": ["电话"],
            "Donation|Please accept my heartfelt thanks for your gift donations. Our company picnic was a huge success, in part due to your help. The raffle was a hot item with your gifts as the prize. Thank you for your generosity and your quality products!":
              ["感谢您的支持！"],
            "Donation|Raised": ["已筹款"],
            "Donation|Save": ["保存"],
            "Donation|Send us a note": ["留言"],
            "Donation|Set Up Donation": ["编辑筹款信息"],
            "Donation|Show progress bar toward donation goal on your site.": [
              "在筹款版块中显示筹款进度条",
            ],
            "Donation|THANK YOU!": ["十分感谢！"],
            "Donation|Text shows on button": ["筹款按钮文字"],
            "Donation|Thanks message": ["访客付款完成后的感谢信息"],
            "Donation|View notes": ["查看留言"],
            "Donation|You don't have any donations yet": ["您还没有筹款"],
            "Downgrade to %{membership} %{period}": [
              "降级至 %{membership} %{period}",
            ],
            "Download Android App": ["下载 Android 应用"],
            "Download IOS App": ["下载 iOS 应用"],
            'Download our <a href="https://itunes.apple.com/cn/app/strikingly/id892299884?l=en&mt=8">iOS app</a> and enable notifications under Settings → Notifications → Strikingly.':
              [
                '下载<a href="https://itunes.apple.com/cn/app/strikingly/id892299884?l=en&mt=8">iOS app</a> 并开启Strikingly通知提醒。（设置=>通知=>Strikingly）',
              ],
            Draft: ["草稿"],
            "Draft created": ["草稿创建于"],
            "Drag file here": ["把文件拖动到这里"],
            "Drag file(s) here": ["把文件拖动到这里"],
            "Drag to reorder": ["排序请拖动"],
            "Duplicate this site": ["复制该网站"],
            EDIT: ["编辑"],
            "Earn a $24.95 credit!": ["赚取24.95美元的现金抵扣！"],
            "Easily embed maps, forms, and more! Some apps are free to use, and some are Pro only.":
              ["轻松嵌入地图、表单和其他内容。部分应用仅限专业版用户使用。"],
            "Ecomerce|View payment setup…": ["查看收款方式..."],
            "EcommerceButton|Checkout": ["下单结算"],
            "EcommerceCoupon|%{amount} Off": ["减免 %{amount}"],
            "EcommerceCoupon|%{amount} off for all orders": [
              "所有订单减免 %{amount}",
            ],
            "EcommerceCoupon|%{amount} off for orders totaling at %{fee} or more":
              ["%{fee} 以上的订单减免 %{amount}"],
            "EcommerceCoupon|Amount": ["金额"],
            "EcommerceCoupon|Apply": ["使用优惠码"],
            "EcommerceCoupon|COUPON %{coupon}": ["优惠券 %{coupon}"],
            "EcommerceCoupon|Condition": ["适用条件"],
            "EcommerceCoupon|Coupon": ["优惠券"],
            "EcommerceCoupon|Coupon Code": ["优惠码"],
            "EcommerceCoupon|Coupon code should be letters and numbers only.": [
              "请使用字母或数字",
            ],
            "EcommerceCoupon|Created": ["创建日期"],
            "EcommerceCoupon|Description": ["描述"],
            "EcommerceCoupon|Enter coupon code": ["请输入优惠码"],
            "EcommerceCoupon|Expiration Date": ["截止日期"],
            "EcommerceCoupon|Expired": ["已过期"],
            "EcommerceCoupon|Expires": ["截止日期"],
            "EcommerceCoupon|Fee number should be greater than 0.": [
              "金额应该大于 0",
            ],
            "EcommerceCoupon|Flat": ["固定金额"],
            "EcommerceCoupon|Flat fee should be greater than 0.": [
              "固定金额应该大于 0",
            ],
            "EcommerceCoupon|For all orders": ["适用所有订单"],
            "EcommerceCoupon|For orders over": ["最低订单金额"],
            "EcommerceCoupon|Free Shipping": ["免运费"],
            "EcommerceCoupon|Free shipping": ["免运费"],
            "EcommerceCoupon|Free shipping for all orders": ["所有订单免运费"],
            "EcommerceCoupon|Free shipping for orders totaling at %{fee} or more":
              ["%{fee} 以上的订单免运费"],
            "EcommerceCoupon|Invalid coupon code!": ["优惠券无效"],
            "EcommerceCoupon|Maximum Uses": ["兑换上限"],
            "EcommerceCoupon|Maximum Uses is required.": ["兑换上限数为必填"],
            "EcommerceCoupon|Percentage": ["百分比"],
            "EcommerceCoupon|Percentage should be greater than 0.": [
              "百分比应该大于 0",
            ],
            "EcommerceCoupon|Please enter a valid amount.": ["请输入有效金额"],
            "EcommerceCoupon|Please enter a valid flat fee.": [
              "请输入有效金额",
            ],
            "EcommerceCoupon|Please enter a valid percentage.": [
              "请输入有效百分比数",
            ],
            "EcommerceCoupon|Remove": ["删除"],
            "EcommerceCoupon|Set a limit for the number of times this coupon can be redeemed":
              ["设置该优惠券可被兑换的次数上限"],
            "EcommerceCoupon|The coupon code is invalid.": ["优惠券已失效。"],
            "EcommerceCoupon|This code has already been used.": [
              "此优惠券已被使用",
            ],
            "EcommerceCoupon|This coupon code can only be applied to %{name}": [
              "此优惠券只适用于 %{name}",
            ],
            "EcommerceCoupon|This coupon code can only be applied to orders totaling at %{fee} or more.":
              ["此优惠券只适用于 %{fee} 以上的订单"],
            "EcommerceCoupon|This coupon code has expired.": ["优惠券已过期"],
            "EcommerceCoupon|This coupon will apply %{amount} off for orders totaling at %{fee} or more (excluding shipping fee).":
              ["此优惠券将使 %{fee} 以上的订单减免 %{amount} （运费除外）"],
            "EcommerceCoupon|This coupon will apply %{amount} off once per order (excluding shipping fee).":
              ["此优惠券将使总金额减免 %{amount} （运费除外）"],
            "EcommerceCoupon|This coupon will apply free shipping for orders totaling at %{fee} or more.":
              ["此免运费优惠券适用于 %{fee} 以上的订单"],
            "EcommerceCoupon|This coupon will apply free shipping once per order.":
              ["此优惠券将订单免运费"],
            "EcommerceCoupon|Uh oh! There's been an error updating the coupon. Please contact us at support@strikingly.com if this problem persists!":
              ["优惠券更新不成功，请重新尝试"],
            "EcommerceCoupon|Used": ["使用数量"],
            "EcommerceCoupon|You can only create 100 coupons.": [
              "优惠券不能超过 100 个",
            ],
            "Ecommerce| Resend after %{time} seconds": ["%{time} 秒后重发"],
            "Ecommerce|$10.00": ["$10.00"],
            "Ecommerce|$15.00": ["$15.00"],
            "Ecommerce|$5.00": ["$5.00"],
            "Ecommerce|%{count} regions enabled (%{regions})": [
              "已设置%{count}个地区 (%{regions})",
            ],
            "Ecommerce|%{index}. Option Choices (press Enter to save the new option)":
              ["%{index}.  规格选项（按Enter回车键保存）"],
            "Ecommerce|%{index}. Option Name": ["%{index}. 规格名称"],
            "Ecommerce|%{minPrice} to %{maxPrice} depending on weight": [
              "随重量范围 %{minPrice} - %{maxPrice}",
            ],
            "Ecommerce|%{minPrice} to %{maxPrice} depending on weight, %{unitPrice} per %{weightUnit} above %{maxThreshold}%{weightUnit}":
              [
                "随重量范围 %{minPrice} - %{maxPrice}。%{maxThreshold}%{weightUnit} 以上每 %{weightUnit} %{unitPrice}",
              ],
            "Ecommerce|%{num} products": ["%{num} 件商品"],
            "Ecommerce|%{num} products selected": ["已选中 %{num} 个商品"],
            "Ecommerce|%{percent} off for %{amount} categories": [
              "%{amount}个商品分类减免%{percent}",
            ],
            "Ecommerce|%{percent} off for %{amount} products": [
              "%{amount}个商品减免%{percent}",
            ],
            "Ecommerce|%{percent} off for 1 category": [
              "1个商品分类减免%{percent}",
            ],
            "Ecommerce|%{percent} off for 1 product": ["1个商品减免%{percent}"],
            "Ecommerce|%{price} base cost, %{perPrice} per %{weightUnit}": [
              "运费起步价 %{price}, 每 %{weightUnit} %{perPrice}",
            ],
            "Ecommerce|%{price} first item, %{perPrice} per additional item": [
              "首件 %{price}, 每添加一件追加 %{perPrice}",
            ],
            "Ecommerce|%{token} (%{amount} Off)": [
              "%{token} (%{amount}的优惠)",
            ],
            "Ecommerce|%{token} (%{amount} off for %{productCount} %{productName})":
              ["%{token}（%{productCount} %{productName} 折扣 %{amount}）"],
            "Ecommerce|%{token} (Free shipping)": ["%{token} (免运费)"],
            "Ecommerce|%{var1} is already connected and you can already take card payments, Google Pay and Apple Pay on your site.":
              [
                "你已经绑定了 %{var1}。你的网站已经可以接受信用卡/借记卡、Google Pay和Apple Pay的收款。",
              ],
            "Ecommerce|%{var1} must be unique": ["“%{var1}”不能重复"],
            "Ecommerce|%{var1} reviews": ["%{var1}条评价"],
            "Ecommerce|(%{count} regions)": ["(%{count}个地区)"],
            "Ecommerce|(Excluding shipping)": ["（运费除外）"],
            "Ecommerce|+ Add Sale Price": ["+ 添加划掉价格"],
            "Ecommerce|0.6% per successful charge from Alipay": [
              "支付宝平台对每笔交易收取0.6%手续费",
            ],
            "Ecommerce|0.6% per successful charge from WeChat Pay": [
              "微信支付平台对每笔交易收取0.6%手续费",
            ],
            "Ecommerce|1 product": ["1件商品"],
            "Ecommerce|1 review": ["1条评价"],
            "Ecommerce|1. Enter your Midtrans Access Keys below. ": [
              "1.请在下面输入您的 Midtrans 访问密钥",
            ],
            "Ecommerce|2. Add Payment Notification and redirect URLs to your Midtrans account configuration.[link: Learn more]":
              [
                "2.将付款通知和重定向网址添加到您的 Midtrans 帐户配置中 [link: 了解更多]",
              ],
            "Ecommerce|23 Crispin Road": ["原平路758弄"],
            "Ecommerce|A category can have up to 100 products.": [
              "一个商品分类最多可以添加100件商品。",
            ],
            "Ecommerce|A download link (valid for [num] hours) will be shown after purchase, and will be emailed to the customer. [link: Learn more.]":
              [
                "买家下单成功后会看到下载链接（链接有效期  [num]  小时），同时会收到一封附加下载链接的确认邮件。 [link: 更多说明。]",
              ],
            "Ecommerce|A download link has also been sent to your email. This link is only valid for the next %{number} hours!":
              ["下载链接已同步发送到你的邮箱。该链接有效期为%{number}小时！"],
            "Ecommerce|A message to be shown when the customer begins checkout.":
              ["买家确认订单前，将显示此注意事项。"],
            "Ecommerce|A pop-up message to be shown when the customer begins checkout. (Optional)":
              ["买家确认订单前，将弹窗显示此注意事项。（选填）"],
            "Ecommerce|Accept PayPal and credit/debit cards.": [
              "接受 PayPal 以及信用卡/借记卡",
            ],
            "Ecommerce|Accept card payment, bank transfer, direct debit, e-wallet, over the counter":
              ["接受银行卡付款，银行转账，直接付款，电子钱包，柜台支付。"],
            "Ecommerce|Accept credit/debit cards and more!": [
              "接受信用卡/储蓄卡以及更多支付方式！",
            ],
            "Ecommerce|Accept credit/debit cards, great for online & offline businesses.":
              ["接受信用卡/借记卡，适合有线上及线下业务的公司"],
            "Ecommerce|Accepts: [link]": ["接受：[link]"],
            "Ecommerce|Account Balance": ["账户金额"],
            "Ecommerce|Account connected:": ["绑定账户："],
            "Ecommerce|Action needed! Sample product out of stock.": [
              "需要补充库存！示例产品已无库存。",
            ],
            "Ecommerce|Actions": ["操作"],
            "Ecommerce|Activate Filter": ["开启筛选功能"],
            "Ecommerce|Activate Product Filter": ["开启商品筛选功能"],
            "Ecommerce|Add Image": ["添加图片"],
            "Ecommerce|Add More Products": ["添加更多商品"],
            "Ecommerce|Add New Category": ["添加商品分类"],
            "Ecommerce|Add New Product": ["添加新的商品"],
            "Ecommerce|Add Option": ["添加商品规格"],
            "Ecommerce|Add Product": ["增加商品"],
            "Ecommerce|Add Region": ["添加地区"],
            "Ecommerce|Add Shipping Option": ["添加配送方式"],
            "Ecommerce|Add Store": ["添加商店"],
            "Ecommerce|Add Subcategory": ["添加子分类"],
            "Ecommerce|Add Video URL (YouTube, Vimeo, etc)": [
              "添加视频链接（腾讯、优酷、爱奇艺、哔哩哔哩）",
            ],
            "Ecommerce|Add Weight Range": ["添加重量范围"],
            "Ecommerce|Add categories (optional).": ["添加商品分类 (可选)"],
            "Ecommerce|Add images": ["添加图片"],
            "Ecommerce|Add images/videos": ["添加图片/视频"],
            "Ecommerce|Add product description. Keep it short and sweet! (Optional)":
              ["简单描述下你的商品吧。（选填）"],
            "Ecommerce|Add to cart": ["加入购物车"],
            "Ecommerce|Add two dimensions of options. For example, if you’re selling a shirt, you can add both color variants and size variants.":
              [
                "添加两个规格选项。比如，如果你在卖衣服，你可以添加颜色和尺寸两个选项。",
              ],
            "Ecommerce|Add up to %{var1} custom fields to collect extra info from customer during checkout based on your business needs (e.g. gift messages, company name, date of birth).":
              [
                "基于业务需要，下单时向买家收集更多信息（譬如礼品寄语、公司名称、生日），最多可添加%{var1}项字段。",
              ],
            "Ecommerce|Add up to two dimensions of options": [
              "增加多至2种规格",
            ],
            "Ecommerce|Add variation": ["增加种类"],
            "Ecommerce|Add, rename, reorder, and delete product categories. You can tag products under categories when you edit products.":
              [
                "添加新的商品分类，为商品分类排序，删除商品分类。你可以在编辑商品时添加商品分类。",
              ],
            "Ecommerce|Additional Info": ["附加信息"],
            "Ecommerce|Address": ["地址"],
            "Ecommerce|After continuing, you will be redirected to UnionPay to to complete your purchase.":
              ["点击继续会将您导向银联以完成购买。"],
            "Ecommerce|Agree to our [link: Terms & Conditions] for selling digital downloads":
              ["我同意[link: 下载类商品售卖的全部条款]"],
            "Ecommerce|Alipay": ["支付宝"],
            "Ecommerce|Alipay Mobile Web Payment": ["支付宝移动网页支付"],
            "Ecommerce|All": ["所有分类"],
            "Ecommerce|All Categories": ["所有商品分类"],
            "Ecommerce|All options are out of stock": ["所有商品库存不足"],
            "Ecommerce|All orders": ["全部订单"],
            "Ecommerce|All time": ["全部时间"],
            "Ecommerce|Allow customers to choose pickup instead of shipping.": [
              "顾客可以选择到店自提，此方式不收取运费。",
            ],
            "Ecommerce|Allow products to show video as the cover thumbnail. If unchecked, only show image as cover thumbnail.":
              [
                "允许产品以视频作为封面缩略图显示。如果未选中，只显示图片作为封面缩略图。",
              ],
            "Ecommerce|Already a member?": ["有会员账号？"],
            "Ecommerce|AppId": ["应用ID"],
            "Ecommerce|AppSecret": ["应用密钥"],
            "Ecommerce|Applies a %{taxes} tax to all orders in your store (excluding shipping).":
              ["对商城中的每笔订单的总金额（不包括运费）设置%{taxes}的税。"],
            "Ecommerce|Apply": ["使用"],
            "Ecommerce|Apply a rate to all states": [
              "为所有的地区设置统一税率",
            ],
            "Ecommerce|Approve": ["批准"],
            "Ecommerce|Approve all": ["全部批准"],
            "Ecommerce|Approved": ["已批准"],
            "Ecommerce|Are you absolutely sure you want to delete %{num} selected products? This action cannot be undone!":
              ["确定要删除已选中的 %{num} 个商品？此操作无法撤回。"],
            "Ecommerce|Are you absolutely sure you want to delete this file? You must upload a new file, and customers will be able to download the new file instead.":
              [
                "确定要删除这个文件吗？删除后您必须上传一个新文件以供买家下载，买家再次下载将得到新文件。",
              ],
            "Ecommerce|Are you absolutely sure you want to delete this product? Customers who purchased this file will lose access to this product immediately.":
              ["确定要删除该「下载类」商品吗？已下单的买家将无法下载。"],
            "Ecommerce|Are you sure to exit checkout? This order will be cancelled.":
              ["确定要退出吗？本次下单将自动取消。"],
            "Ecommerce|Are you sure you want to cancel? These products will not be imported!":
              ["确定要取消导入吗？商品导入还没完成！"],
            "Ecommerce|Are you sure you want to change your site's currency to %{var1}?":
              ["你确定要将网站的收款货币改为%{var1}吗？"],
            "Ecommerce|Are you sure you want to delete this region?": [
              "确实要删除这个重量范围？",
            ],
            "Ecommerce|Are you sure you want to delete this review?": [
              "你确定要删除这条评价吗？",
            ],
            "Ecommerce|Are you sure you want to disable all filters? The filter menu will be removed from your store section.":
              ["确定要停用筛选功能吗？停用后筛选菜单将从商店板块中移除。"],
            "Ecommerce|Are you sure you want to disable offline payments?": [
              "你确定要停用线下支付吗？",
            ],
            "Ecommerce|Are you sure you want to disable product reviews? After disabling, customers will not be able to submit new reviews, and existing reviews will be hidden on your site. You can re-enable this later.":
              [
                "你确定要停用商品评价吗？停用之后，顾客将无法提交新评价，网站上已有的评价也都会被隐藏。今后，你还可以重新启用。",
              ],
            "Ecommerce|Are you sure you want to disconnect %{payment}?": [
              "你确定要解绑%{payment}吗？",
            ],
            "Ecommerce|Are you sure you want to disconnect Alipay?": [
              "你确定要解绑支付宝吗？",
            ],
            "Ecommerce|Are you sure you want to disconnect Midtrans?": [
              "你确定要解绑 Midtrans 吗？",
            ],
            "Ecommerce|Are you sure you want to disconnect Paypal?": [
              "你确定要解绑 PayPal 吗？",
            ],
            "Ecommerce|Are you sure you want to disconnect WeChat Pay?": [
              "你确定要解绑微信支付吗？",
            ],
            "Ecommerce|Are you sure you want to disconnect this Strikingly Taiwan Payments account? You will no longer be able to view transaction details, withdraw balance and process refunds related to this Strikingly Taiwan Payments account.":
              [
                "你确定要解绑此Strikingly台湾金流帐户吗？你将无法进行与此账户有关的交易明细查看，请款和订单退款处理。",
              ],
            "Ecommerce|Are you sure you want to disconnect your custom domain?":
              ["您确定要解绑自定义域名吗？"],
            "Ecommerce|Are you sure you want to exit? Unsaved changes will be lost.":
              ["你确定要退出？未保存的更改将丢失。"],
            "Ecommerce|Are you sure you want to import these products?": [
              "你确定要导入这些商品吗？",
            ],
            "Ecommerce|Are you sure you want to remove this shipping option? This change cannot redo!":
              ["确定要删除此配送方式吗？此操作不可撤销！"],
            "Ecommerce|Are you sure you want to remove this weight range?": [
              "确定要删除这个重量范围？",
            ],
            "Ecommerce|Are you sure you want to restore the default email template?":
              ["你确定要恢复到默认的邮件模板吗？"],
            "Ecommerce|As a %{plan} user, you can sell up to %{product_sell_limit} products. If you enable this product, another enabled product will be disabled. Are you sure you want to enable this product?":
              [
                "作为%{plan}用户，你最多可以销售%{product_sell_limit}件商品。如果你启用该商品，另一个商品将被禁用。你确定你要启用该商品吗？",
              ],
            "Ecommerce|As a %{plan} user, you can sell up to 1 product.  If you enable this product, all other products will be disabled. Are you sure you want to enable this product?":
              [
                "作为%{plan}用户，你最多可以销售1件商品。如果你启用该商品，其他所有商品将被禁用。你确定你要启用该商品吗？",
              ],
            "Ecommerce|As a VIP user, you can add unlimited products.": [
              "作为企业版用户，你可以添加无限数量的商品。",
            ],
            "Ecommerce|Auto withdraw balance to your connected bank account every week (Monday, 12pm GMT+8:00)":
              ["每周一中午12点自动请款到绑定的银行账户（GMT+8:00）"],
            "Ecommerce|Auto withdraw my balance": ["自动请款"],
            "Ecommerce|Available for %{regions}": ["适用地区：%{regions}"],
            "Ecommerce|Average Rating": ["平均星级"],
            "Ecommerce|Average revenue per order in the selected time": [
              "所选日期内的平均订单金额",
            ],
            "Ecommerce|Avg Order Value": ["客单价"],
            "Ecommerce|Awaiting Delivery": ["正在准备发货"],
            "Ecommerce|Back": ["返回"],
            "Ecommerce|Back to home page.": ["返回主页"],
            "Ecommerce|Back to orders list": ["返回订单列表"],
            "Ecommerce|Back to site": ["返回网站"],
            "Ecommerce|Balance Withdrawn": ["已请款"],
            "Ecommerce|Bank card validation": ["银行卡验证"],
            "Ecommerce|Base cost": ["运费起步价"],
            "Ecommerce|Based on %{totalCount} reviews": [
              "基于%{totalCount}条评价",
            ],
            "Ecommerce|Based on 1 review": ["基于1条评价"],
            "Ecommerce|Batch Manage": ["批量管理商品"],
            "Ecommerce|Be careful! Deleting this category is a permanent and irreversible action! It will be deleted from all products under this category. Are you sure you still want to delete this category?":
              [
                "注意！删除此商品分类是一个永久的不可逆转的操作！删除后这个分类标签将从该分类下的所有商品中移除。仍然确定删除该分类吗？",
              ],
            "Ecommerce|Best selling (by quantity sold)": ["销售数量最多"],
            "Ecommerce|Billing Email": ["账单邮箱"],
            "Ecommerce|Browser": ["浏览器"],
            "Ecommerce|Buy Now Button Text": ["立即购买按钮文本"],
            "Ecommerce|Buy now": ["立即购买"],
            "Ecommerce|By Order Weight": ["按订单重量"],
            "Ecommerce|COUPON %{token} (%{amount} off)": [
              "优惠券 %{token} (直减%{amount})",
            ],
            "Ecommerce|COUPON %{token} (%{amount}%% off)": [
              "优惠券 %{token} (直减%{amount}%%)",
            ],
            "Ecommerce|COUPON %{token} (Free shipping)": [
              "优惠券 %{token} (免运费)",
            ],
            "Ecommerce|Cambridge, MA 48323": ["上线大厦，200436"],
            "Ecommerce|Can not be empty": ["不可为空"],
            "Ecommerce|Cancel": ["取消"],
            "Ecommerce|Cancel Order": ["取消订单"],
            "Ecommerce|Cancel import": ["取消导入"],
            "Ecommerce|Cancel notification email has been sent to the customer.":
              ["订单取消通知邮件已发送到买家邮箱。"],
            "Ecommerce|Canceled": ["已取消"],
            "Ecommerce|Cancelled": ["已退款"],
            "Ecommerce|Cannot be empty.": ["不能留空"],
            "Ecommerce|Cannot be repeated": ["内容不能重复"],
            "Ecommerce|Cannot set a past date": ["无法设置为过去的日期"],
            "Ecommerce|Cannot set a past date!": ["设置日期无效"],
            "Ecommerce|Card": ["银行卡"],
            "Ecommerce|Card Info": ["银行卡信息"],
            "Ecommerce|Card expired. Please try another card.": [
              "银行卡已过期，请尝试其他卡。",
            ],
            "Ecommerce|Card not supported. Please try another card.": [
              "银行卡不支持，请尝试其他卡。",
            ],
            "Ecommerce|Card number": ["银行卡号"],
            "Ecommerce|Categories can only contain letters, numbers, spaces and dashes.":
              ["商品分类名称只能包含字母、数字、空格和横线。"],
            "Ecommerce|Cell phone number": ["手机号码"],
            "Ecommerce|Change to your preferred currency in Settings > Payment.":
              ["修改货币请前往：设置>收款方式"],
            "Ecommerce|Charging": ["收费"],
            "Ecommerce|Check account balance": ["查看账户余额"],
            "Ecommerce|Checkout": ["结算"],
            "Ecommerce|Checkout Form": ["下单结账页"],
            "Ecommerce|Checkout Form Settings": ["下单结账设置"],
            "Ecommerce|Checkout Notice Message": ["下单前须知"],
            "Ecommerce|Cheers!\nStrikingly Team": ["顺祝商祺！\n上线了 团队"],
            "Ecommerce|Cheers, \nStrikingly Team": ["顺祝商祺！ \n上线了 团队"],
            "Ecommerce|Choose Payment Method": ["请选择付款方式"],
            "Ecommerce|Choose a payment method": ["请选择付款方式"],
            "Ecommerce|Choose a region": ["选择地区"],
            "Ecommerce|Choose regions where pickup is available, or just keep “The World” to allow all customers to see this pickup option.":
              [
                "选择到店自提的适用地区。如选择“全世界”，任意地区的买家下单都可以选择到店自提。",
              ],
            "Ecommerce|Choose where you ship and set shipping fees. Fees are automatically applied to Physical Products. If multiple options apply to a customer, they will be able to choose their shipping option.":
              [
                "在此自定义配送范围和对应运费来形成配送方案。运费会自动在实物类商品订单生效。如果买家购买时同时适用多种配送方案，则买家下单时可以选择其中任意一种。",
              ],
            "Ecommerce|City": ["市"],
            "Ecommerce|Click here to start selling!": ["点击添加商品"],
            "Ecommerce|Click on each order to complete and/or refund them. Your customers will receive email notifications once you've completed or refunded their orders.":
              ["点击选择订单，进行完成操作，您的顾客将会收到邮件提醒。"],
            "Ecommerce|Click to learn how to activate in Stripe.": [
              "点击了解如何在 Stripe 中激活",
            ],
            "Ecommerce|Click to view more images": ["点击浏览更多图片"],
            "Ecommerce|Client Key": ["客户端密钥"],
            "Ecommerce|Collect Customer Note": ["收集买家留言"],
            "Ecommerce|Collect Email Address": ["收集电子邮箱"],
            "Ecommerce|Collect Phone Number": ["收集手机号"],
            "Ecommerce|Color, Size, etc.": ["颜色、尺寸等等"],
            "Ecommerce|Coming soon": ["即将发布"],
            "Ecommerce|Comment is required": ["评价不能为空"],
            "Ecommerce|Complete": ["完成"],
            "Ecommerce|Complete Order": ["完成订单"],
            "Ecommerce|Completed": ["已完成"],
            "Ecommerce|Configure checkout message...": ["配置下单前须知"],
            "Ecommerce|Confirm": ["确认"],
            "Ecommerce|Confirm Refund": ["确认退款"],
            "Ecommerce|Confirm Withdraw %{var1}": ["确认请款%{var1}"],
            "Ecommerce|Confirm enable": ["确定启用"],
            "Ecommerce|Confirmation failed. Please try again.": [
              "确认失败。请再试一次。",
            ],
            "Ecommerce|Connect": ["连接"],
            "Ecommerce|Connect a payment gateway to accept payments on your site.":
              ["设置网站的收款方式，实现顾客线上交易。"],
            "Ecommerce|Connect to Square": ["连接到 Square"],
            "Ecommerce|Connect to Stripe": ["前往 Stripe 连接账户"],
            "Ecommerce|Connect your custom domain": ["连接您的自定义域名"],
            "Ecommerce|Connection failed. Please try again.": [
              "绑定失败。请重试。",
            ],
            "Ecommerce|Continue": ["下一步"],
            "Ecommerce|Continue Shopping": ["继续购物"],
            "Ecommerce|Continue as a guest": ["以游客身份继续访问"],
            "Ecommerce|Continue to payment": ["继续付款"],
            "Ecommerce|Continue to validate": ["继续验证"],
            "Ecommerce|Copied!": ["已复制到剪贴板！"],
            "Ecommerce|Copy Product URL": ["复制商品链接"],
            "Ecommerce|Country": ["国家"],
            "Ecommerce|Country/Region": ["国家/地区"],
            "Ecommerce|Coupon": ["优惠券"],
            "Ecommerce|Coupon Code": ["优惠券"],
            "Ecommerce|Coupons": ["优惠券"],
            "Ecommerce|Cover Image": ["封面图片"],
            "Ecommerce|Cover image set!": ["封面图片设置成功"],
            "Ecommerce|Create Coupon": ["添加优惠券"],
            "Ecommerce|Create an account to track your order after checkout.": [
              "注册成为会员，随时查看您的订单状态。",
            ],
            "Ecommerce|Created First": ["最先创建"],
            "Ecommerce|Created Last": ["最后创建"],
            "Ecommerce|Crossed-out Price": ["划掉价格"],
            "Ecommerce|Custom Domain Connection": ["连接自定义域名"],
            "Ecommerce|Custom Form Fields": ["自定义表单字段"],
            "Ecommerce|Custom form title:": ["表单标题："],
            "Ecommerce|Customer": ["买家"],
            "Ecommerce|Customer Info": ["客户信息"],
            "Ecommerce|Customer Reviews": ["客户评价"],
            "Ecommerce|Customer-facing Emails: Sent-from": [
              "给顾客的邮件：来自",
            ],
            "Ecommerce|Customers can register with phone number before completing their order. Or, they can skip it and complete the order as a guest.":
              [
                "访客完成订单前提示使用手机注册成为会员，非强制注册，访客可以跳过该步骤以继续完成订单。",
              ],
            "Ecommerce|Customers must register with phone number before completing their order! Beware, this may turn away potential customers.":
              [
                "访客在完成订单前必须使用手机注册成为会员。注意: 该选项可能会降低访客的购买意愿。",
              ],
            "Ecommerce|Customers purchase products without signing up.": [
              "访客无需注册成为会员即可购买商品。",
            ],
            "Ecommerce|Customers will skip payment while placing the order. You must set up offline payment yourself!":
              ["客户购买商品时无需在线上付款。你需要自己设置线下付款方式！"],
            "Ecommerce|Customer’s name, email and phone number are required at checkout for Strikingly Taiwan Payments.":
              ["Strikingly台湾金流要求买家必须填写姓名，邮箱和电话号码。"],
            "Ecommerce|Customize the button text that appears in your store section and individual product pages.":
              ["自定义显示在商店版块和商品详情页中的按钮文本。"],
            "Ecommerce|Customize your customer checkout experience. Add fields to collect more info from customers.":
              ["自定义买家的下单体验。支持添加字段、收集更多客户信息。"],
            "Ecommerce|DELETE": ["删除"],
            "Ecommerce|DUPLICATE": ["复制"],
            "Ecommerce|Data Type": ["数据类型"],
            "Ecommerce|Date": ["下单日期"],
            "Ecommerce|Date format is wrong!": ["日期格式错误"],
            "Ecommerce|Dear [user name], \n\nCongratulations on your new order! An invoice to the buyer has been sent on your behalf.":
              [
                "你好， [user name]！\n\n恭喜你，收到新订单了！我们已经自动替你向买家发送了收款证明。",
              ],
            "Ecommerce|Dear [user name], \n\nWe wanted to let you know that the following product(s) is/are out of stock.":
              ["你好， [user name]！\n\n请知悉以下商品已无库存。"],
            "Ecommerce|Default": ["默认"],
            "Ecommerce|Delete": ["删除"],
            "Ecommerce|Description": ["描述"],
            "Ecommerce|Desktop": ["电脑"],
            "Ecommerce|Details": ["详细信息"],
            "Ecommerce|Different weights for each option": ["不同规格不同重量"],
            "Ecommerce|Digital Download": ["下载类商品"],
            "Ecommerce|Digital Downloads are only available to Pro users! Please upgrade to Pro to sell digital products.":
              [
                "「下载类」商品仅适用于专业版或以上。请升级至专业版后使用此功能。",
              ],
            "Ecommerce|Digital files for download — e.g. e-books, docs, music":
              ["需要下载的电子文件 如电子书、文档、音乐"],
            "Ecommerce|Disable": ["停用"],
            "Ecommerce|Disable reviews": ["停用评价"],
            "Ecommerce|Disabled": ["禁用"],
            "Ecommerce|Disconnect": ["解绑"],
            "Ecommerce|Disconnect Account": ["解绑账户"],
            "Ecommerce|Disconnection failed. Please try again.": [
              "解绑失败。请重试。",
            ],
            "Ecommerce|Discount Type": ["优惠类型"],
            "Ecommerce|District/County": ["县、区"],
            "Ecommerce|Don't have an account?": ["没有会员账号?"],
            "Ecommerce|Done": ["完成"],
            "Ecommerce|Download": ["下载"],
            "Ecommerce|Download failed. This might be caused by too many products or an internal error. Please try again or ask customer service for export.":
              [
                "下载失败。或因商品数量过多或其他原因导致。请再次尝试或联系在线客服导出。",
              ],
            "Ecommerce|Drag to reorder": ["拖动进行排序"],
            "Ecommerce|E.G. NEWYEAR26": ["例如 NEWYEAR26"],
            "Ecommerce|E.g. delivery times, customer requirements, or any other important notifications for the customer":
              ["如有必要请简要说明发货时间、备注信息、表单填写要求等。"],
            "Ecommerce|E.g. delivery times, customer requirements, or any other important notifications for the customer.":
              ["例：发货时间、备注信息、表单填写要求等。"],
            "Ecommerce|Each Additional Item Fee": ["每添加一件的费用"],
            "Ecommerce|Each transaction takes up to 10 days to be approved and available to withdraw":
              ["每笔交易需要最多10天才会被批准并允许请款"],
            "Ecommerce|Edit": ["编辑"],
            "Ecommerce|Edit Coupon": ["编辑优惠券"],
            "Ecommerce|Edit Filter": ["编辑筛选"],
            "Ecommerce|Edit Product Variants": ["编辑商品规格"],
            "Ecommerce|Edit image": ["编辑图片"],
            "Ecommerce|Edit option combinations": ["编辑商品规格"],
            "Ecommerce|Edit weight ranges": ["设置首重续重范围"],
            "Ecommerce|Email": ["邮箱"],
            "Ecommerce|Email Address": ["邮箱"],
            "Ecommerce|Email Notifications": ["邮件提醒设置"],
            "Ecommerce|Email Templates": ["邮件模板"],
            "Ecommerce|Email address for order confirmation (optional)": [
              "电子邮箱（用于接收订单信息，选填)",
            ],
            "Ecommerce|Email for order confirmation": [
              "邮箱地址（用于接收订单确认邮件）",
            ],
            "Ecommerce|Email header is required.": ["请填写邮件标题。"],
            "Ecommerce|Enable": ["启用"],
            "Ecommerce|Enable Product Reviews": ["启用商品评价"],
            "Ecommerce|Enabled": ["已启用"],
            "Ecommerce|Enter API Key": ["请输入API密钥"],
            "Ecommerce|Enter AppId": ["请输入应用ID"],
            "Ecommerce|Enter AppSecret": ["请输入应用密钥AppSecret"],
            "Ecommerce|Enter MD5 Key": ["请输入MD5密钥"],
            "Ecommerce|Enter Mch_Id": ["请输入微信支付商户号Mch_Id"],
            "Ecommerce|Enter PID": ["请输入PID"],
            "Ecommerce|Enter a percentage to apply to all states. This will override all existing values!":
              ["输入一个百分比数值应用到所有的地区。这将覆盖已有的设置！"],
            "Ecommerce|Enter a price": ["输入价格"],
            "Ecommerce|Enter a weight for each option in": ["请把重量填写在"],
            "Ecommerce|Enter your PID and MD5 Key to enable your Alipay account.[link: Learn more about how to get PID and MD5 Key from Alipay manage platform.]":
              [
                "输入你的PID和MD5密钥以开启支付宝账户。[link:了解如何从支付宝开放平台获取PID和MD5密钥。]",
              ],
            "Ecommerce|Enter your Private Key (please read the tutorial carefully":
              ["输入获取的密钥（具体步骤查看上方蓝色字链接）"],
            "Ecommerce|Enter your WeChat Pay account info below to enable your Alipay account.[link: Learn more about how to get WeChat Pay account info.]":
              [
                "输入你的微信公众号支付账户信息以开启微信支付账号。[link: 了解如何从微信支付公众平台获取账户信息。]",
              ],
            "Ecommerce|Error": ["报错信息"],
            "Ecommerce|Error Position": ["报错位置"],
            "Ecommerce|Estimated delivery": ["预计发货日期"],
            "Ecommerce|European VAT": ["欧洲增值税"],
            "Ecommerce|Except for subscriptions of %{var1} paid members managed by %{var2}, you are using  %{var3} to accept future credit/debit card payments, Google Pay and Apple Pay.":
              [
                "除%{var1}位会员的付费订阅由 %{var2} 收款外，你目前正在使用 %{var3} 来接受信用卡/借记卡、Google Pay和Apple Pay收款。",
              ],
            "Ecommerce|Exiting now will not save your edited content, are you sure to quit?":
              ["现在关闭弹窗将不会保存你编辑过的内容。你确定要退出吗？"],
            "Ecommerce|Expiration date": ["到期日期"],
            "Ecommerce|Export": ["确认导出"],
            "Ecommerce|Export Orders": ["导出订单"],
            "Ecommerce|Export Products": ["批量导出商品"],
            "Ecommerce|Exporting...": ["导出中..."],
            "Ecommerce|Express Checkout": ["快速结账"],
            "Ecommerce|Felicity Meyers": ["韩梅梅"],
            "Ecommerce|Field Instructions": ["填写提示文字"],
            "Ecommerce|File": ["文件"],
            "Ecommerce|File Upload Policy": ["上传文件政策"],
            "Ecommerce|Filter Products": ["筛选商品"],
            "Ecommerce|First Item Fee": ["首件运费"],
            "Ecommerce|First Name": ["名字"],
            "Ecommerce|Flat Rate Per Item": ["固定运费"],
            "Ecommerce|Flat Tax Rate": ["统一税率"],
            "Ecommerce|Forgot password?": ["忘记密码？"],
            "Ecommerce|Format should be MM/YYYY": ["格式应为MM/YYYY"],
            "Ecommerce|Free shipping": ["免运费"],
            "Ecommerce|Free shipping for orders of %{amount} or more": [
              "订单满 %{amount} 包邮",
            ],
            "Ecommerce|Fulfillment cost": ["履行成本"],
            "Ecommerce|Generate WMP code and WeChat Official Account path": [
              "获取小程序码，公众号路径地址",
            ],
            "Ecommerce|Generate new download link": ["生成新的下载链接"],
            "Ecommerce|Get Verification Code": ["发送验证码"],
            "Ecommerce|Get funds immediately after payment": [
              "交易完成后钱款立即到账",
            ],
            "Ecommerce|Get funds in 1-2 business days": [
              "交易于 1-2 个工作日内到账",
            ],
            "Ecommerce|Get funds in about 7 days": ["于七个工作日内退款"],
            "Ecommerce|Get funds in just a few minutes": [
              "交易完成后钱款几分钟后到账",
            ],
            "Ecommerce|Get more time to pay with Klarna": [
              "通过Klarna支付，以获得更多时间付款",
            ],
            "Ecommerce|Go To Membership": ["前往会员功能"],
            "Ecommerce|Go To Promotion": ["前往营销中心"],
            "Ecommerce|Go To Settings": ["前往设置"],
            "Ecommerce|Got it!": ["好的！"],
            "Ecommerce|Grant [strong: free shipping] to orders of at least a certain amount (before tax)":
              [
                "[strong: 满包邮] 订单满一定金额后免运费。(按税前商品合计价计算)",
              ],
            "Ecommerce|HIDE": ["下架"],
            "Ecommerce|Handling fee: NT$30 per withdrawal": [
              "请款手续费：新台币30元/次",
            ],
            "Ecommerce|Hello, %{member}": ["你好, %{member}"],
            "Ecommerce|Hi there! \n\nThank you for your order at [page name]. Your order details are below.":
              ["你好！\n\n感谢你在[网站名称]的订单。订单详情如下。"],
            "Ecommerce|Hi there! \n\nYour order from [page name] has been cancelled.":
              ["你好！\n\n你在 [page name] 的订单已被取消。"],
            "Ecommerce|Hi there! \n\nYour order from [page name] has been fulfilled.":
              ["你好！\n\n你在 [page name] 的订单已完成。"],
            "Ecommerce|Hi there! \n\nYour order from [page name] has been refunded.":
              ["你好！\n\n你在 [page name] 的订单已退款。"],
            "Ecommerce|Hi, there! \n\nA customer submitted a product review on your site [page name]. [link:Log into your Strikingly account] approve or reject it.":
              [
                "你好!  \\n\\n有顾客在你的网站[page name]上提交了新的商品评价。请[link:登录你的上线了账号]来审核此评价。",
              ],
            "Ecommerce|Hi, there! \n\nThank you for your order. Your opinion matters to us. We'd love it if you could leave a review!":
              [
                "你好！\\n\\n感谢你的购买。 你的意见对我们很重要，期待能够收到你的评价！",
              ],
            "Ecommerce|Hidden": ["已隐藏"],
            "Ecommerce|Hide": ["下架"],
            "Ecommerce|Hide advanced options": ["隐藏高级选项"],
            "Ecommerce|Hide optional payment sources": ["收起可选支付方式"],
            "Ecommerce|Hide transaction details": ["隐藏交易详情"],
            "Ecommerce|Highest Price": ["价格由高到低"],
            "Ecommerce|Historical Sales": ["初始销量"],
            "Ecommerce|History": ["历史"],
            "Ecommerce|I have a coupon code": ["我有优惠券"],
            "Ecommerce|I understand, continue": ["我明白了，请继续"],
            "Ecommerce|I've already done this, enable %{paymentName} now": [
              "我已完成配置，立即启用 %{paymentName}",
            ],
            "Ecommerce|If checked, a plain text field will be visible at checkout. You can use this to request additional customer info.":
              ["勾选后，你可以利用留言字段来收集额外的客户信息。"],
            "Ecommerce|If checked, email will be collected at checkout for order confirmation .":
              ["勾选后，买家下单时需填写邮箱地址，用于接收系统订单信息。"],
            "Ecommerce|If checked, phone number will be collected at checkout.":
              ["勾选后，买家下单时需要填写手机号。"],
            "Ecommerce|If you have many products, you can activate filters to let the customer find products more easily. The filter function will appear in a sidebar in the store section.":
              [
                "如果你的商品数量比较多，开启筛选功能可以帮助买家更快速地找到符合条件的商品，加速成交。筛选功能将显示在商店板块的左侧。",
              ],
            "Ecommerce|If you opened this site in WeChat, long press the QR code to scan it. Or save this image to scan the QR code from your album.":
              [
                "若你当前在微信内打开网站，可长按识别二维码支付，或保存图片后，从相册内打开图片使用微信扫一扫识别。",
              ],
            "Ecommerce|Image": ["图片"],
            "Ecommerce|Image URLs": ["商品图片"],
            "Ecommerce|Image upload failed": ["图片上传失败"],
            "Ecommerce|Images": ["图片"],
            "Ecommerce|Import products": ["批量导入商品"],
            "Ecommerce|Importing new Digital Products is not currently supported.":
              ["暂不支持导入新的下载类商品"],
            "Ecommerce|Importing...": ["导入中..."],
            "Ecommerce|In-App Web-based Payment": ["公众号支付"],
            "Ecommerce|Incorrect 3D-Secure code. Please check and retry.": [
              "3D密码输入错误，请检查后重试。",
            ],
            "Ecommerce|Incorrect PIN. Please check and retry.": [
              "PIN错误，请检查后重试。",
            ],
            "Ecommerce|Incorrect login information": ["登录信息错误"],
            "Ecommerce|Indicate address, phone number, hours available, and any other info needed for pickup":
              ["请说明提货地址、联系方式、自提时间范围等必要信息。"],
            "Ecommerce|Instant Payment": ["即时到账"],
            "Ecommerce|Insufficient funds. Please check and retry.": [
              "卡内余额不足，请检查后重试。",
            ],
            "Ecommerce|Invalid": ["无效的"],
            "Ecommerce|Invalid %{fileName}": ["请输入有效的%{fileName}"],
            "Ecommerce|Invalid CVV. Please check and retry.": [
              "安全码错误，请检查后重试。",
            ],
            "Ecommerce|Invalid Option Name.": ["无效的选项名称"],
            "Ecommerce|Invalid Price": ["无效价格"],
            "Ecommerce|Invalid Stock": ["无效库存"],
            "Ecommerce|Invalid ZIP/postal code. Please check and retry.": [
              "无效的邮政编码，请检查后重试。",
            ],
            "Ecommerce|Invalid card. Please check and retry.": [
              "无效的银行卡，请检查后重试。",
            ],
            "Ecommerce|Invalid city": ["城市不能为空"],
            "Ecommerce|Invalid district/county": ["县、区不能为空"],
            "Ecommerce|Invalid email.": ["邮箱无效"],
            "Ecommerce|Invalid phone number": ["无效号码"],
            "Ecommerce|Invalid phone number, please try again.": [
              "无效的手机号码，请修改。",
            ],
            "Ecommerce|Invalid province": ["省份不能为空"],
            "Ecommerce|Invalid security code. Please check and retry.": [
              "安全码错误，请检查后重试。",
            ],
            "Ecommerce|Invalid value.": ["无效内容"],
            "Ecommerce|Invalid verification code, please try again.": [
              "无效的验证码，请重试。",
            ],
            "Ecommerce|Invalid weight": ["无效重量"],
            "Ecommerce|Invalid weight range. Weight ranges must be increasing.":
              ["无效输入。重量范围必须递增。"],
            "Ecommerce|Inventory": ["库存"],
            "Ecommerce|It may take up to 5 business days for your refund to be processed.":
              ["你会在5个工作日内收到退款。"],
            "Ecommerce|It seems you have a large number of products! Please [link:contact support] and we'll help you add more products.":
              [
                "看起来你有大量的商品！请[link:联系客服]，我们会帮你添加更多商品。",
              ],
            "Ecommerce|It seems you have a large number of products! Please contact support and we'll help you add more products.":
              ["看起来你有大量的商品！请联系客服，我们会帮你添加更多商品。"],
            "Ecommerce|It seems you have a lot of products, so it may take a long time to export. We'll email you a download link when the export is completed. Please enter your email address.":
              [
                "你的商品较多，可能需要较长时间导出。我们会在导出完成后通过邮件给你发送CSV文件的下载链接。请输入你的邮箱。",
              ],
            "Ecommerce|It seems you have a lot of products, so it may take a long time to import. We will notify you by email when the import is completed. Please enter your email address.":
              [
                "你的商品较多，可能需要较长时间导入。我们会在导入完成后通过邮件通知你。请输入你的邮箱。",
              ],
            "Ecommerce|It seems you have a lot of products, so it may take a long time to import. You can close this dialog and continue working, or even close the editor. We'll send you an email when the import is complete!":
              [
                "你的商品较多，可能需要较长时间导入。你可以关闭本窗口，甚至关闭编辑器，无需守候等待。导入完成后，我们会给你发送邮件通知！",
              ],
            "Ecommerce|It takes 2-3 business days to validate your registration files. [strong:You'll receive an email notification when the verification is complete.]":
              [
                "注册档案资料审核结果将在2-3个工作日内发送到你的邮箱，[strong:请注意查收]。",
              ],
            "Ecommerce|Item": ["商品"],
            "Ecommerce|Item weight (all options)": ["不同规格相同重量"],
            "Ecommerce|Items without shipping — e.g. consulting, training, coaching":
              ["无需寄出的商品 如咨询、培训、健身课"],
            "Ecommerce|Last 30 days": ["近 30 天"],
            "Ecommerce|Last 7 days": ["近 7 天"],
            "Ecommerce|Last Name": ["姓氏"],
            "Ecommerce|Learn more": ["了解更多"],
            "Ecommerce|Learn more about orders": ["了解更多关于订单信息"],
            "Ecommerce|Learn more.": ["了解更多。"],
            "Ecommerce|Leave any comments…": ["写点评价吧…"],
            "Ecommerce|Limit the quantity of items this discount can apply to in a single order. If this coupon applies to multiple items with different prices, the highest-price items will be discounted first.":
              [
                "限制此折扣适用于单个订单的商品数量。如果此优惠券适用于多个不同价格的商品，则价格最高的商品将优先获得折扣。",
              ],
            "Ecommerce|Link to Privacy Policy: %{url}": [
              "链接到隐私政策：%{url}",
            ],
            "Ecommerce|Link to Terms and Conditions: %{url}": [
              "使用条款链接：%{url}",
            ],
            "Ecommerce|Log In": ["登录"],
            "Ecommerce|Log Out": ["退出"],
            "Ecommerce|Log in": ["登录"],
            "Ecommerce|Log in to checkout": ["会员登录以继续购买"],
            "Ecommerce|Log into Strikingly Taiwan Payments account": [
              "登录Strikingly台湾金流",
            ],
            "Ecommerce|Login to your Strikingly account to finish processing the order.\n\nCheers!\nStrikingly Team":
              [
                "立刻登录 上线了 账户处理你的新订单吧！\\n\\n顺祝商祺！ \\n上线了 团队",
              ],
            "Ecommerce|Looks like there is an error with your payment! Please contact the website owner.":
              ["抱歉，付款出现了错误！请联系一下网站的管理员。"],
            "Ecommerce|Lowest Price": ["价格由低到高"],
            "Ecommerce|MD5 Key": ["MD5密钥"],
            "Ecommerce|MD5 Key must be 32 characters": [
              "MD5密钥必须是32位字符",
            ],
            "Ecommerce|Manage Categories": ["管理商品分类"],
            "Ecommerce|Manage Product": ["管理商品"],
            "Ecommerce|Manage Products": ["管理商品"],
            "Ecommerce|Manage Reviews": ["管理评论"],
            "Ecommerce|Manage categories in Store > Categories.": [
              "管理商品分类请前往商城>商品分类。",
            ],
            "Ecommerce|Manage which reviews are displayed in your store": [
              "你可以决定在商店里展示哪些评价",
            ],
            "Ecommerce|Max %{fieldsLimit} form fields accepted. Please contact online customer service if you need more.":
              [
                "最多支持%{fieldsLimit}个表单字段。如需添加更多，请联系在线客服。",
              ],
            "Ecommerce|Max %{number} shipping options accepted. Please contact online customer service if you need more.":
              ["最多支持%{number}种配送方式。如需更多请联系在线客服。"],
            "Ecommerce|Max %{var1} categories": ["最多支持%{var1}个商品分类"],
            "Ecommerce|Max %{var1} characters": ["超过最大%{var1}字数限制"],
            "Ecommerce|Max %{var1} choices per product option": [
              "每种规格名称最多支持%{var1}个规格选项",
            ],
            "Ecommerce|Max %{var1} image only per product option": [
              "每个商品规格最多添加%{var1}张图",
            ],
            "Ecommerce|Max %{var1} images only per product": [
              "每个商品最多添加%{var1}张图",
            ],
            "Ecommerce|Max %{var1} options per product": [
              "每个商品最多支持%{var1}种规格名称",
            ],
            "Ecommerce|Mch_Id": ["商户号Mch_Id"],
            "Ecommerce|Member": ["会员列表"],
            "Ecommerce|Membership": ["商城会员"],
            "Ecommerce|Merchant ID": ["商家 ID"],
            "Ecommerce|Mobile": ["手机"],
            "Ecommerce|Monthly Available Transaction Balance": [
              "本月月交易余额",
            ],
            "Ecommerce|More Details": ["更多详情"],
            "Ecommerce|Move to bottom": ["移到最后"],
            "Ecommerce|Move to top": ["置顶"],
            "Ecommerce|Multiple Pages": ["多页面功能"],
            "Ecommerce|Must be greater than the sale price!": [
              "必须大于销售价格",
            ],
            "Ecommerce|Must enter 0 or 1": ["必须输入1或0"],
            "Ecommerce|My Orders": ["我的订单"],
            "Ecommerce|Name": ["名称"],
            "Ecommerce|Name cannot be empty.": ["商品名称不能为空"],
            "Ecommerce|Name cannot be repeated": ["名称不能重复"],
            "Ecommerce|Name is required": ["名字不能为空"],
            "Ecommerce|Nationwide": ["全国"],
            "Ecommerce|Needs business bank account and ICP license": [
              "需要真实有效的营业执照且网站已备案",
            ],
            "Ecommerce|Never expires": ["永远不失效"],
            "Ecommerce|New download URL has been copied!": [
              "新下载链接复制成功！",
            ],
            "Ecommerce|New order from [BUYER NAME]! Order #10056241": [
              "来自 [BUYER NAME]! 的新订单！订单 #10056241",
            ],
            "Ecommerce|No Category": ["没有分类"],
            "Ecommerce|No categories found. [span: Add category]": [
              "没有找到商品分类，[span: 请添加商品分类]",
            ],
            "Ecommerce|No payment method available": ["无可用的支付方式"],
            "Ecommerce|No products": ["没有商品"],
            "Ecommerce|No products found. [span: Add product]": [
              "没有找到商品，[span: 请添加商品]",
            ],
            "Ecommerce|No products in this shop now!": ["还没有商品！"],
            "Ecommerce|No redirection, stay on same page": [
              "不跳转，保持在相同页面",
            ],
            "Ecommerce|No results found": ["未找到结果"],
            "Ecommerce|No transaction fees from Strikingly": [
              "上线了不收取任何手续费",
            ],
            "Ecommerce|No valid products": ["无有效商品"],
            "Ecommerce|No, publish anyway": ["不用了，继续发布"],
            "Ecommerce|Not exists. Please delete this item.": [
              "商品不存在，请删除。",
            ],
            "Ecommerce|Not ready to sell yet? Hide this product in the live site":
              ["还没准备好出售吗？那先隐藏起来"],
            "Ecommerce|Note about Stripe & Square": [
              "关于 Stripe 与 Square 的说明",
            ],
            "Ecommerce|Notes from seller:": ["卖家留言："],
            "Ecommerce|Notes: This is a gift!": ["备注：这是礼物"],
            "Ecommerce|Notice": ["注意"],
            "Ecommerce|Notifications sent to customer": ["买家提示"],
            "Ecommerce|Notifications sent to you": ["卖家提示"],
            "Ecommerce|Offering your customers coupons to increase orders.": [
              "为你的客户提供优惠券能够帮你增加订单。",
            ],
            "Ecommerce|Offline Payment Instructions for Customers": [
              "给买家的线下支付说明",
            ],
            "Ecommerce|Offline Payments": ["线下支付"],
            "Ecommerce|Ok": ["确认"],
            "Ecommerce|Once sales start coming in, this is where you can review order details and complete orders. ":
              ["买家下单后，你将在这里看到订单详情以及管理订单状态"],
            "Ecommerce|Only %{quantity} in stock": ["库存仅剩%{quantity}件"],
            "Ecommerce|Only for physical products": ["仅适用于实物类商品"],
            "Ecommerce|Oops, a network issue occurred, please refresh and try again.":
              ["糟糕，遇到网络问题，请刷新重试。"],
            "Ecommerce|Oops, payment failed!": ["抱歉，支付失败"],
            "Ecommerce|Option": ["商品规格"],
            "Ecommerce|Option Choice %{var1}": ["规格选项%{var1}"],
            "Ecommerce|Option Name %{var1}": ["规格名称%{var1}"],
            "Ecommerce|Option choices cannot be empty": ["规格选项不能为空"],
            "Ecommerce|Option is required.": ["请填写商品规格"],
            "Ecommerce|Optional": ["可选"],
            "Ecommerce|Or": ["或者"],
            "Ecommerce|Order #10056241": ["订单 #10056241"],
            "Ecommerce|Order Cancelled!": ["订单已被取消！"],
            "Ecommerce|Order Complete": ["订单完成"],
            "Ecommerce|Order History": ["订单历史"],
            "Ecommerce|Order Info": ["订单信息"],
            "Ecommerce|Order No.": ["订单序号."],
            "Ecommerce|Order Placed": ["下单日期"],
            "Ecommerce|Order Refunded!": ["订单已成功退款"],
            "Ecommerce|Order Status": ["订单状态"],
            "Ecommerce|Order Summary": ["订单摘要"],
            "Ecommerce|Order cancelled": ["订单已被取消"],
            "Ecommerce|Order completed": ["订单完成"],
            "Ecommerce|Order confirmed": ["订单确认"],
            "Ecommerce|Order data will be exported as CSV file (.csv) Please wait 10s for exporting.":
              [
                "订单数据将导出为 CSV 格式文件 (.csv)，若订单量过大，请耐心等待10秒左右导出。",
              ],
            "Ecommerce|Order details will be emailed to you after completing payment.":
              ["在银联完成付款后，订单详情将通过电子邮件发送给您。"],
            "Ecommerce|Order details will be emailed to you shortly.": [
              "订单详情将会稍后发送至您的邮箱。",
            ],
            "Ecommerce|Order fulfilled": ["订单完成"],
            "Ecommerce|Order placed": ["新订单"],
            "Ecommerce|Order refunded": ["订单退款"],
            "Ecommerce|Orders": ["订单"],
            "Ecommerce|Out of Stock": ["无库存"],
            "Ecommerce|Out of stock": ["无库存"],
            "Ecommerce|Overview": ["订单详情"],
            "Ecommerce|PID": ["合作伙伴身份PID "],
            "Ecommerce|PID must be 16 digital numbers": ["ID必须是16位数字"],
            "Ecommerce|Page Description": ["详情页描述"],
            "Ecommerce|Page Redirection After Checkout": ["结账后的页面跳转"],
            "Ecommerce|Pay": ["付款"],
            "Ecommerce|Pay %{total}": ["支付 %{total}"],
            "Ecommerce|Pay in 4 interest-free payments of %{amount} each": [
              "分4期免息付款，每期支付%{amount}",
            ],
            "Ecommerce|Pay with Alipay": ["使用支付宝支付"],
            "Ecommerce|Pay with Midtrans (Credit Card/Bank Transfer/e-Wallet/etc)":
              ["使用 Midtrans 支付（信用卡/银行转帐/电子钱包等）"],
            "Ecommerce|Pay with PayPal or Card": ["使用 PayPal 或银行卡支付"],
            "Ecommerce|Pay with WeChat Pay": ["微信支付"],
            "Ecommerce|Pay with card": ["使用银行卡支付"],
            "Ecommerce|PayPal Account Email": ["PayPal 账户邮箱"],
            "Ecommerce|PayPal account connected: [var1]": [
              "PayPal 账号已连接：[var1]",
            ],
            "Ecommerce|PayPal or Card": ["PayPal 或银行卡"],
            "Ecommerce|Payment Details": ["付款明细"],
            "Ecommerce|Payment Gateway": ["收款方式"],
            "Ecommerce|Payment Method Name": ["支付方式名称"],
            "Ecommerce|Payment has been disabled for your account due to invalid registration documents. Please check your email for more details and [link:click here to resubmit.]":
              [
                "你的账号收款功能已关闭，请查看邮件了解详情，并[link:点击此处重新提交审核]。",
              ],
            "Ecommerce|Payment limit exceeded. Please check and retry.": [
              "交易金额达到上限，请检查后重试。",
            ],
            "Ecommerce|Payment method": ["付款方式"],
            "Ecommerce|Payment secured by Alipay": ["由支付宝提供安全支付保障"],
            "Ecommerce|Payment secured by WeChat": ["由微信提供安全支付保障"],
            "Ecommerce|Payments & Currency": ["收款方式与货币"],
            "Ecommerce|Pending": ["待处理"],
            "Ecommerce|Per %{unit}": ["每 %{unit} 运费"],
            "Ecommerce|Per %{weightUnit} cost": ["每 %{weightUnit} 的费用"],
            "Ecommerce|Personal ID/Tax ID": ["身份证/公司统一编号"],
            "Ecommerce|Phone": ["电话"],
            "Ecommerce|Physical": ["实物类商品"],
            "Ecommerce|Physical Products Only": ["仅支持实物类商品"],
            "Ecommerce|Pickup Guidelines": ["自提说明"],
            "Ecommerce|Pickup Option Name": ["自提方式显示名称"],
            "Ecommerce|Pickup Regions": ["自提适用地区"],
            "Ecommerce|Place order": ["下单"],
            "Ecommerce|Please Select": ["请选择"],
            "Ecommerce|Please check your email format": ["请检查邮箱格式"],
            "Ecommerce|Please email us at [user email] if you have any questions. \n\nCheers! \n[page name]":
              [
                "如果有任何问题，请发送邮件至 [user email] 咨询。 \\n\\n顺祝商祺！  \\n[page name]",
              ],
            "Ecommerce|Please enter API Key": ["请输入API密钥"],
            "Ecommerce|Please enter AppId": ["请输入应用ID"],
            "Ecommerce|Please enter AppSecret": ["请输入应用密钥AppSecret"],
            "Ecommerce|Please enter Client Key.": ["请输入客户端密钥"],
            "Ecommerce|Please enter MD5 Key!": ["请输入MD5密钥"],
            "Ecommerce|Please enter Mch Id": ["请输入微信支付商户号Mch_Id"],
            "Ecommerce|Please enter Merchant ID.": ["请输入商家 ID"],
            "Ecommerce|Please enter RSA Private Key!": ["请填写RSA密钥"],
            "Ecommerce|Please enter Server Key.": ["请输入服务器密钥"],
            "Ecommerce|Please enter a URL.": ["请输入一个链接"],
            "Ecommerce|Please enter a valid percentage.": [
              "请输入有效百分比数",
            ],
            "Ecommerce|Please enter option name": ["请输入规格名称"],
            "Ecommerce|Please enter payment instruction for your customers.": [
              "请为你的客户输入付款说明。",
            ],
            "Ecommerce|Please enter payment method for your customers.": [
              "请为你的客户输入付款方式说明。",
            ],
            "Ecommerce|Please enter your PayPal account": [
              "请输入PayPal账户邮箱",
            ],
            "Ecommerce|Please enter your PayPal account email": [
              "请输入PayPal 账户邮箱",
            ],
            "Ecommerce|Please enter your account and password": [
              "请输入你的账户和密码",
            ],
            "Ecommerce|Please fix all errors in your CSV file and reupload.": [
              "请修正CSV文件里报错的所有问题后再进行上传导入。",
            ],
            "Ecommerce|Please follow the instructions below to activate your Midtrans account.":
              ["请按照以下说明激活您的 Midtrans 账户"],
            "Ecommerce|Please reconnect your PayPal account.": [
              "请重新绑定你的 Paypal 账号。",
            ],
            "Ecommerce|Please refresh the page after you've completed the payment.":
              ["支付成功后请刷新页面。"],
            "Ecommerce|Please upload a CSV file size under %{var1}.": [
              "请上传低于%{var1}的CSV文件",
            ],
            "Ecommerce|Please upload a CSV file with at least 1 product.": [
              "CSV文件中应至少包含1个商品",
            ],
            "Ecommerce|Please use %{deviceDescription} %{suffix} to make a payment":
              ["请使用%{deviceDescription} %{suffix}进行支付"],
            "Ecommerce|Please use the scan Function in WeChat: [Discovery]-[Scan]":
              ["请打开微信扫一扫功能：[发现] - [扫一扫]"],
            "Ecommerce|Please use the scan function in Alipay": [
              "请打开支付宝点击扫一扫",
            ],
            "Ecommerce|Popular": ["最受欢迎"],
            "Ecommerce|Pre-Order": ["预购"],
            "Ecommerce|Pre-Order: Add to cart": ["预订：添加到购物车"],
            "Ecommerce|Preparing Order": ["订单处理中"],
            "Ecommerce|Preview": ["预览"],
            "Ecommerce|Preview Product": ["预览商品"],
            "Ecommerce|Price": ["价格"],
            "Ecommerce|Print Details": ["打印订单详情"],
            "Ecommerce|Processing payment...": ["支付处理中..."],
            "Ecommerce|Product": ["商品"],
            "Ecommerce|Product Categories": ["商品分类"],
            "Ecommerce|Product Filter": ["商品筛选"],
            "Ecommerce|Product ID": ["商品ID"],
            "Ecommerce|Product Info": ["商品信息"],
            "Ecommerce|Product Limit": ["商品数量超出限制"],
            "Ecommerce|Product Name": ["商品名称"],
            "Ecommerce|Product Options": ["商品规格"],
            "Ecommerce|Product Page Description": ["商品详情页描述"],
            "Ecommerce|Product Quantity Limit Per Order": ["每单限用商品数量"],
            "Ecommerce|Product Quantity Limit Per Order is required.": [
              "每单限用商品数量为必填",
            ],
            "Ecommerce|Product Review": ["商品评价"],
            "Ecommerce|Product Reviews": ["商品评价"],
            "Ecommerce|Product Type": ["商品类型"],
            "Ecommerce|Product data missing for Option row": [
              "商品规格缺少对应商品数据",
            ],
            "Ecommerce|Product name": ["商品名称"],
            "Ecommerce|Product no.": ["商品号"],
            "Ecommerce|Product quantity limit": ["商品数量限制"],
            "Ecommerce|Product review request": ["商品评价邀请"],
            "Ecommerce|Product review submitted": ["收到新的商品评价"],
            "Ecommerce|Product reviews are currently disabled. Customers cannot submit new reviews, and previous reviews will not be shown on your site.":
              [
                "当前已停用商品评价。顾客不能提交新评价，以前的评价也不会显示在网站上。",
              ],
            "Ecommerce|Products": ["商品"],
            "Ecommerce|Products Per Page": ["每页商品数量"],
            "Ecommerce|Promote": ["推广"],
            "Ecommerce|Province": ["省"],
            "Ecommerce|Qty": ["数量"],
            "Ecommerce|Quantity": ["数量"],
            "Ecommerce|RSA Private Key": ["RSA(SHA1)密钥"],
            "Ecommerce|RSA Private Key is invalid": [
              "RSA(SHA1)密钥不符合填写规范",
            ],
            "Ecommerce|Rate this product": ["给商品打分"],
            "Ecommerce|Ready to sell? Show this product in the live site": [
              "准备好出售了吗？那就上架吧",
            ],
            "Ecommerce|Recommended": ["推荐"],
            "Ecommerce|Redirect customers to another page (e.g. thank you page) after their order payment is complete. This applies to all orders.":
              [
                "订单完成支付后，顾客将跳转到另一个指定页面（例如感谢页面）。所有订单都会触发该跳转。",
              ],
            "Ecommerce|Redirect to a specific page on this site": [
              "跳转到此网站中的一个指定页面",
            ],
            "Ecommerce|Redirect to an external URL": ["跳转到一个外部链接"],
            "Ecommerce|Redirecting you to payment platform...": [
              "跳转到支付平台",
            ],
            "Ecommerce|Refund": ["退款"],
            "Ecommerce|Refund Amount: $15.00": ["退款金额：$15.00"],
            "Ecommerce|Refund Failed": ["退款失败"],
            "Ecommerce|Refund Failed Due To Payment Gateway Error": [
              "支付端口错误导致退款失败",
            ],
            "Ecommerce|Refund Order": ["退款提示"],
            "Ecommerce|Refund notification email has been sent to the customer.":
              ["退款提醒电子邮件已发往买家邮箱。"],
            "Ecommerce|Region": ["地区"],
            "Ecommerce|Regions grouped by shipping carrier conventions.": [
              "地区根据物流公司运营习惯进行划分",
            ],
            "Ecommerce|Register Strikingly Taiwan Payments account": [
              "注册Strikingly台湾金流账户",
            ],
            "Ecommerce|Registration Complete": ["注册完成"],
            "Ecommerce|Registration Disabled": ["访客无需注册成为会员"],
            "Ecommerce|Registration Failed": ["注册失败"],
            "Ecommerce|Registration Optional": ["访客可以选择是否注册会员"],
            "Ecommerce|Registration Required": ["访客必须注册成为会员"],
            "Ecommerce|Reject": ["拒绝"],
            "Ecommerce|Rejected": ["已拒绝"],
            "Ecommerce|Remove": ["移除"],
            "Ecommerce|Request reviews from customers after purchase": [
              "邀请购买后的顾客写评价",
            ],
            "Ecommerce|Request reviews from customers and manage which reviews are displayed in your store.":
              ["邀请顾客写评价，同时你可以决定商店里展示哪些评价。"],
            "Ecommerce|Required field cannot be blank": ["必填字段不能为空"],
            "Ecommerce|Reset": ["清空"],
            "Ecommerce|Rest of the World": ["世界其他地区"],
            "Ecommerce|Restore default": ["恢复默认"],
            "Ecommerce|Restore defaults": ["重置模板"],
            "Ecommerce|Revenue": ["营业额"],
            "Ecommerce|Review Order": ["确认信息"],
            "Ecommerce|Review submitted!": ["评价已提交！"],
            "Ecommerce|Reviews": ["客户评价"],
            "Ecommerce|Row %{var1}": ["第%{var1}行"],
            "Ecommerce|SHIPPING": ["运费"],
            "Ecommerce|SUBTOTAL": ["小计"],
            "Ecommerce|Sale Price": ["促销价格"],
            "Ecommerce|Sample product": ["产品（例子）"],
            "Ecommerce|Save": ["保存"],
            "Ecommerce|Save QR Code": ["保存二维码"],
            "Ecommerce|Scan QR code using WeChat": ["请打开微信扫码支付"],
            "Ecommerce|Scan with %{title} to make payment": [
              "%{title}扫码支付",
            ],
            "Ecommerce|Scan with Alipay to make payment": ["支付宝扫码支付"],
            "Ecommerce|Scan with WeChat to make payment": ["微信扫码支付"],
            "Ecommerce|Schedule": ["定时"],
            "Ecommerce|Search category name...": ["请搜索商品分类名称..."],
            "Ecommerce|Search product name...": ["请搜索商品名称..."],
            "Ecommerce|Secure Payment": ["安全支付通道"],
            "Ecommerce|Security code": ["安全码"],
            "Ecommerce|Select": ["选择"],
            "Ecommerce|Select Categories": ["选择商品分类"],
            "Ecommerce|Select Dates": ["选择日期"],
            "Ecommerce|Select Display Order": ["选择展示顺序"],
            "Ecommerce|Select Products": ["选择商品"],
            "Ecommerce|Select Shipping Option:": ["选择配送方式："],
            "Ecommerce|Select a category": ["选择商品分类"],
            "Ecommerce|Select a category for this section.": [
              "为该版块选择一个商品分类。",
            ],
            "Ecommerce|Select an option": ["请选择商品规格"],
            "Ecommerce|Select which parameters site visitors can filter by.": [
              "选择需要给买家提供的筛选条件。",
            ],
            "Ecommerce|Seller has not connected his/her payment gateway. Can not buy now.":
              ["由于卖家尚未设定支付方式，目前无法购买。"],
            "Ecommerce|Selling Digital Download products requires a custom domain. If you disconnect your custom domain, all Digital Download products will be hidden automatically.":
              [
                "售卖「下载类」商品需拥有自定义域名。解绑自定义域名后，全部「下载类」商品将自动隐藏下架。",
              ],
            "Ecommerce|Selling Digital Download products requires a custom domain. Please connect your custom domain in [strong: Settings].":
              [
                "售卖「下载类」商品需拥有自定义域名。请先前往[strong: 设置]完成自定义域名连接。",
              ],
            "Ecommerce|Send a note to your customer. We'll include it in the order confirmation email.":
              ["以下留言将会连同订单确认信息一起发送至买家电子邮箱"],
            "Ecommerce|Send automated emails to your customers to keep them informed about the status of their orders.":
              ["给你的客户自动推送邮件，让他们能够随时了解订单状态。"],
            "Ecommerce|Send us a note": ["给卖家留言"],
            "Ecommerce|Send us a note (optional)": ["给卖家留言（选填）"],
            "Ecommerce|Sent to customer 7 days after order fulfilled.": [
              "订单完成7天后发送给买家。",
            ],
            "Ecommerce|Sent to you when a customer has submitted a review which may need approval.":
              ["当顾客提交了待审核的评价时，向卖家发送提醒。"],
            "Ecommerce|Sent when new order is placed.": [
              "向卖家发送新订单提醒",
            ],
            "Ecommerce|Sent when order has been completed": [
              "订单完成后向买家发送提醒",
            ],
            "Ecommerce|Sent when order has been fulfilled": [
              "订单完成后向买家发送提醒",
            ],
            "Ecommerce|Sent when payment has been received.": [
              "收到付款后向买家发送提醒",
            ],
            "Ecommerce|Sent when product is out of stock.": [
              "商品无库存时向卖家发送提醒",
            ],
            "Ecommerce|Sent when you issue a refund.": [
              "订单退款后发送邮件通知",
            ],
            "Ecommerce|Sent when you issue an order cancellation.": [
              "订单取消后发送邮件通知",
            ],
            "Ecommerce|Server Key": ["服务器密钥"],
            "Ecommerce|Service": ["服务类商品"],
            "Ecommerce|Set a shipping fee based on the total order weight. Set item weights in product settings.":
              [
                "该设置下，订单会根据商品重量计算运费（商品重量在编辑商品时填写）",
              ],
            "Ecommerce|Set a shipping fee for every order and a flat fee for each additional item.":
              ["向每件商品单独征收运费，并根据买家增加商品而追加运费。"],
            "Ecommerce|Set as Required": ["设置为必填项"],
            "Ecommerce|Set as cover image": ["将图片设为封面图片"],
            "Ecommerce|Set the cover image, you can also modify the individual product specification image separately.":
              ["设置规格图片，你可以分别对不同的商品规格设置单独的图片。"],
            "Ecommerce|Set up at least one payment gateway to start receiving money!":
              ["请设置至少一种收款方式！"],
            "Ecommerce|Set up payments": ["前往设置收款方式"],
            "Ecommerce|Setup shipping rate in Settings > Shipping.": [
              "在“设置>运费”里修改运费收取方式",
            ],
            "Ecommerce|Ship Date": ["预计发货时间"],
            "Ecommerce|Ship to:": ["发货至"],
            "Ecommerce|Shippable items — e.g. clothing, jewelry, electronics": [
              "能够寄出的商品 如服装、首饰、电器",
            ],
            "Ecommerce|Shipping": ["配送"],
            "Ecommerce|Shipping Address": ["收货地址"],
            "Ecommerce|Shipping Details": ["收货信息"],
            "Ecommerce|Shipping Fee": ["运费"],
            "Ecommerce|Shipping Guidelines": ["关于快递"],
            "Ecommerce|Shipping Info": ["配送"],
            "Ecommerce|Shipping Option Name": ["配送方式显示名称"],
            "Ecommerce|Shipping Options": ["配送方式"],
            "Ecommerce|Shipping Rule": ["运费模板"],
            "Ecommerce|Shipping and tax will be calculated at checkout.": [
              "运费和税费将在结账时计算。",
            ],
            "Ecommerce|Shipping info": ["配送"],
            "Ecommerce|Shipping info required from your customers?": [
              "买家需要填写快递信息吗？",
            ],
            "Ecommerce|Shipping will be calculated at checkout.": [
              "运费将在结账时计算。",
            ],
            "Ecommerce|Ships %{date}": ["预计%{date}发货"],
            "Ecommerce|Ships %{delivery}.": ["预计发货时间：%{delivery}"],
            "Ecommerce|Show advanced options": ["显示高级选项"],
            "Ecommerce|Show as pre-order and set shipping date.": [
              "显示为需要预订并设置预计发货时间。",
            ],
            "Ecommerce|Show filter": ["显示筛选功能"],
            "Ecommerce|Show more": ["显示更多"],
            "Ecommerce|Show more details on the product page.": [
              "在商品详情页上显示更多详情",
            ],
            "Ecommerce|Show more reviews": ["展示更多评价"],
            "Ecommerce|Show optional payment sources": ["展开可选支付方式"],
            "Ecommerce|Show transaction details": ["显示交易详情"],
            "Ecommerce|Sign Up": ["注册"],
            "Ecommerce|Sign up": ["注册"],
            "Ecommerce|Sign up to continue your order": ["注册会员以继续购买"],
            "Ecommerce|Something went wrong. Please try again later. %{var1}": [
              "出错了。请稍后再试。%{var1}",
            ],
            "Ecommerce|Sorry! The item in your shopping cart has just sold out. Please refresh your page!":
              ["很抱歉，此商品已缺货。请刷新页面。"],
            "Ecommerce|Sorry, product reviews cannot be submitted at this time. Please contact us if you have any questions.":
              ["抱歉，目前无法提交商品评价。如果你有任何疑问，请联系我们。"],
            "Ecommerce|Sorry, the comment may contain illegal content. Please check and modify it and submit it again.":
              ["抱歉，评论可能包含违规内容，请检查修改后再次提交。"],
            "Ecommerce|Sorry, this product is currently unavailable for review. Please contact us if you have any questions.":
              ["抱歉，此商品目前不支持评价。如果你有任何疑问，请联系我们。"],
            "Ecommerce|Sorry, we had a problem processing your payment. Please try another payment method.":
              [
                "抱歉，我们在处理你的支付时遇到了点问题，请稍后重试或尝试使用其他支付方式。",
              ],
            "Ecommerce|Sort Products": ["商品排序"],
            "Ecommerce|Specific categories": ["特定商品分类"],
            "Ecommerce|Specific date range": ["特定日期范围"],
            "Ecommerce|Specific products": ["特定商品"],
            "Ecommerce|Square account connected: %{account}": [
              "Square 账户已连接：%{account}",
            ],
            "Ecommerce|Square connected!": ["Square 账号已连接！"],
            "Ecommerce|Standard Shipping": ["标准快递"],
            "Ecommerce|Start Uploading": ["开始上传"],
            "Ecommerce|Start import": ["开始导入商品"],
            "Ecommerce|State/Province": ["州/省"],
            "Ecommerce|State/Region": ["州/地区"],
            "Ecommerce|Status": ["订单状态"],
            "Ecommerce|Stock": ["库存"],
            "Ecommerce|Stock level": ["库存等级"],
            "Ecommerce|Store": ["商城"],
            "Ecommerce|Store Categories": ["商品分类"],
            "Ecommerce|Store Currency": ["收款货币"],
            "Ecommerce|Store Pickup": ["到店自提"],
            "Ecommerce|Store Settings": ["商店设置"],
            "Ecommerce|Street Address": ["详细地址"],
            "Ecommerce|Strikingly Taiwan Payment": ["Strikingly台湾金流"],
            "Ecommerce|Strikingly Taiwan Payments account:": [
              "Strikingly台湾金流账户：",
            ],
            "Ecommerce|Strikingly Taiwan Payments does not support pre-ordering":
              ["Strikingly台湾金流不支持商品预定"],
            "Ecommerce|Strikingly Taiwan Payments only supports physical products":
              ["Strikingly台湾金流仅支持实物类商品"],
            "Ecommerce|Strikingly Taiwan Payments only supports physical products and does not support pre-ordering":
              ["Strikingly台湾金流仅支持实物类商品，且不支持商品预定"],
            "Ecommerce|Strikingly Taiwan Payments only supports physical products and does not support pre-ordering. Non-physical products and pre-order products will be hidden on your site.":
              [
                "Strikingly台湾金流仅支持实物类商品，且不支持商品预定。非实物类商品和预定商品从你的网站下架。",
              ],
            "Ecommerce|Strikingly Taiwan Payments only supports physical products and does not support pre-ordering. To enable service products, digital products, and pre-orders, you must activate another payment gateway.":
              [
                "Strikingly台湾金流仅支持实物类商品，且不支持商品预定。你必须启用另外的收款方式来销售服务类商品或下载类商品，以及提供商品预定。",
              ],
            "Ecommerce|Stripe account connected:": ["Stripe 账户已连接："],
            "Ecommerce|Stripe will no longer accept payment in HRK due to Croatia joining the EU. Please select another currency type.":
              [
                "由于克罗地亚加入欧盟，Stripe不再处理HRK币种的支付。请选择其他币种。",
              ],
            "Ecommerce|Submission Success!": ["提交成功！"],
            "Ecommerce|Submit Registration Documents": ["提交注册档案"],
            "Ecommerce|Submit Review": ["提交评价"],
            "Ecommerce|Subtotal": ["小计"],
            "Ecommerce|Successfully confirmed!": ["确认成功！"],
            "Ecommerce|Successfully connected!": ["绑定成功！"],
            "Ecommerce|Successfully imported %{var1} products!": [
              "成功导入%{var1}个商品！",
            ],
            "Ecommerce|Successfully refund %{totalPrice}": [
              "已成功退款 %{totalPrice}",
            ],
            "Ecommerce|Supports": ["支持"],
            "Ecommerce|Switch to grid view": ["方块视图"],
            "Ecommerce|Switch to list view": ["列表视图"],
            "Ecommerce|TAX": ["税"],
            "Ecommerce|TOTAL": ["总计"],
            "Ecommerce|Taiwan Payments": ["台湾金流"],
            "Ecommerce|Tax": ["税"],
            "Ecommerce|Tax Calculation": ["税额计算"],
            "Ecommerce|Tax Mode": ["税费模式"],
            "Ecommerce|Tax Rate": ["税率"],
            "Ecommerce|Tax included": ["已含税额"],
            "Ecommerce|Tax will be calculated at checkout.": [
              "税费将在结账时计算。",
            ],
            "Ecommerce|Taxes": ["税"],
            "Ecommerce|Taxes are added to product prices and will be shown as an additional line item at checkout.":
              [
                "商品价格不含税（税额会在付款时在账单上额外单列出来并加到最后付款金额中）",
              ],
            "Ecommerce|Taxes are already included in product prices and will be shown as included at checkout.":
              ["商品价格已经含税（付款时会根据税率自动计算并显示已含税额）"],
            "Ecommerce|Taxes should be less than %{taxRate}.": [
              "税率应该少于 %{taxRate}",
            ],
            "Ecommerce|Thank you for your order!": ["感谢您的订单！"],
            "Ecommerce|Thank you for your review!": ["感谢你的评价！"],
            "Ecommerce|Thank you!": [" 非常感谢！"],
            "Ecommerce|Thanks for your order! Your order has been shipped and will arrive in 5 business days.":
              ["感谢你的订单！你的订单已发货，将在5个工作日内到达。"],
            "Ecommerce|The World": ["全世界"],
            "Ecommerce|The acquiring bank's system has reported an error. Please try again later.":
              ["收单行系统功能异常，请稍后重试。"],
            "Ecommerce|The content format of this CSV file is incorrect. Please use CSV template and do not change any structure.":
              [
                "CSV文件中内容格式错误。请使用我们提供的CSV模板，切忌更改内部结构。",
              ],
            "Ecommerce|The content format of this CSV is incorrect": [
              "CSV文件内容格式不正确",
            ],
            "Ecommerce|The field is not valid": ["该字段输入无效"],
            "Ecommerce|The first option will be the default selected option during checkout. To change this, drag another option to be first.":
              ["首项为默认配送方式。拖拽卡片到首项以更改配送方式。"],
            "Ecommerce|The issuing bank has refused the transaction. Please contact the issuing bank.":
              ["发卡银行拒绝交易，请联络发卡银行。"],
            "Ecommerce|The issuing bank requires a response (call bank).": [
              "发卡银行要求回复(call bank)。",
            ],
            "Ecommerce|The minimum transaction amount of each order is NT$30": [
              "每笔订单的最低交易额为新台币30元",
            ],
            "Ecommerce|The order cannot be placed due to payment error. Payments in HRK are no longer accepted. Please wait for store owner to update store currency.":
              [
                "支付问题导致无法下单。由于网页不再处理HRK币种的支付，请等待店家更换支付货币。",
              ],
            "Ecommerce|The payment is being settled. Please try again later.": [
              "银行系统结算中，请稍后重试。",
            ],
            "Ecommerce|The product review feature is only available for sites with custom domains. [link:Go to connect Custom Domains]":
              [
                "商品评价功能仅开放给自定义域名的网站。[link:前往绑定自定义域名]",
              ],
            "Ecommerce|The refund has failed due to an error from your payment gateway (%{var1}). Please check your payment account for more information. (Error: %{var2})":
              [
                "由于%{var1}支付出错，导致订单退款失败。请检查你的支付账户了解详情。（错误代码：%{var2}）",
              ],
            "Ecommerce|The refund has failed due to an error from your payment gateway (Strikingly Taiwan Payments). Please contact support for more assistance. (Error: %{var1})":
              [
                "由于Strikingly台湾金流支付出错，导致订单退款失败。请联系我们的客服来帮助你解决问题。（错误代码：%{var1}）",
              ],
            "Ecommerce|The refund has failed due to an internal error. Please contact support for more assistance.":
              [
                "由于内部错误导致订单退款失败。请联系我们的客服来帮助你解决问题。",
              ],
            "Ecommerce|The registration documents below have failed validation. Please check your email for more instructions and resubmit these required documents.":
              [
                "你的注册档案资料审核未通过，请查看邮件了解详情，并于此处重新提交审核。",
              ],
            "Ecommerce|The server of the National Credit Card Center of R.O.C. is unavailable. Please try again later.":
              ["联合卡中心主机断线，请稍后重试。"],
            "Ecommerce|The transaction was either declined by the processor or bank, or it can't be used for this payment. Please check the payment account for abnormalities.":
              [
                "交易被处理商或银行拒绝，或者不能用于此笔支付。请检查支付账户是否有异常。",
              ],
            "Ecommerce|There are no products under this category yet.": [
              "还没有为此分类添加任何商品。",
            ],
            "Ecommerce|There has been an error processing your payment. Please check and retry.":
              ["支付遇到问题，请检查后重试。"],
            "Ecommerce|There has been an error. Our engineers are looking into it now. Please retry!":
              ["对不起，请求暂时无法被完成，请稍后再试，我们深表歉意"],
            "Ecommerce|This             field is only needed if you activate by-weight shipping prices.             Otherwise, you can leave it blank. The customer will not see these             values.":
              ["该字段仅针对设置了【按重量计费】的商家。买家不会看到该字段"],
            "Ecommerce|This Square account only accepts %{var1} and cannot accept %{var2}. Please disconnect this account first and then connect to another Square account or select %{var1} as your currency.":
              [
                "当前 Square 账户仅支持%{var1}，不支持%{var2} 收款。请先断开当前账户后连接新的 Square 账户，或选择%{var1}作为收款货币。",
              ],
            "Ecommerce|This Strikingly Taiwan Payments account has been connected to another store. Please disconnect this account first, or use a different account.":
              [
                "此Strikingly台湾金流账户已经绑定了另一个商店。请先解绑这个账户，或者使用一个不同的账户。",
              ],
            "Ecommerce|This action will reorder the display of all products in this category. These changes will be visible to visitors on your live site after you publish the site. Are you sure you want to change the display order for all products in this category?":
              [
                "此操作将重新排列此类别中所有商品的显示顺序。新的展示顺序在你发布网站后才会对访客可见。你确定要更改此商品类别中所有商品的显示顺序吗？",
              ],
            "Ecommerce|This category has already been added to this product.": [
              "这个分类中已经有该商品了。",
            ],
            "Ecommerce|This cell phone number is not registered, please sign up first.":
              ["该手机号尚未注册，请先注册。"],
            "Ecommerce|This coupon is no longer valid.": ["此优惠券已失效"],
            "Ecommerce|This coupon will apply %{percent} off for %{amount} categories.":
              ["此优惠券将使%{amount}个商品分类减免%{percent}"],
            "Ecommerce|This coupon will apply %{percent} off for %{amount} products.":
              ["此优惠券将使%{amount}个商品减免%{percent}"],
            "Ecommerce|This coupon will apply %{percent} off for 1 category.": [
              "此优惠券将使1个商品分类减免%{percent}",
            ],
            "Ecommerce|This coupon will apply %{percent} off for 1 product.": [
              "此优惠券将使1个商品减免%{percent}",
            ],
            "Ecommerce|This feature is only available for Pro or VIP users. Please upgrade your account plan.":
              ["该功能仅限专业版或企业版版用户。请升级账户套餐后使用。"],
            "Ecommerce|This field is only needed if you activate by-weight shipping prices. Otherwise, you can leave it blank. The customer will not see these values.":
              ["该字段仅针对设置了【按重量计费】的商家。买家不会看到该字段"],
            "Ecommerce|This includes [strong: %{var1} products] that already exist, and will be replaced!":
              [
                "其中包括已创建的[strong: %{var1}个商品]，系统将覆盖更新它们的商品信息。",
              ],
            "Ecommerce|This is an existing category.": ["此商品分类已经存在。"],
            "Ecommerce|This is an existing subcategory.": ["该子分类已经存在"],
            "Ecommerce|This is an irreversible action! An email notification will be sent to your customer about the cancellation. Are you sure you want to cancel this order?":
              [
                "取消订单后将无法恢复！并且你的顾客会收到一封取消订单的通知邮件。你确定要取消这个订单吗？",
              ],
            "Ecommerce|This is an irreversible action! Processing the refund will take 7-14 business days. Confirm refund of %{price} ?":
              [
                "订单退款操作完成后将无法撤销！处理退款将需要7-14个工作日。确认退款%{price}？",
              ],
            "Ecommerce|This is an irreversible action! Processing the refund will take up to 7-10 business days. Confirm refund of %{price}?":
              [
                "订单退款操作完成后将无法撤销！处理退款将需要7-10个工作日。确认退款%{price}？",
              ],
            "Ecommerce|This is the maximum amount your payment account can process each month":
              ["这是你每个月可收取的金额上限"],
            "Ecommerce|This option is out of stock": ["此种类已无库存"],
            "Ecommerce|This order is expired, can not be charged. Please refresh!":
              ["订单过期，请刷新网站后付费。"],
            "Ecommerce|This product is currently not available.": [
              "该商品目前已下架。",
            ],
            "Ecommerce|This product is not available anymore.": [
              "该商品不存在。",
            ],
            "Ecommerce|This registration message will be shown to your customers before checkout. (Optional)":
              ["设置提示信息，访客在注册时会看到该条提示信息 (选填)。"],
            "Ecommerce|This will change the weight units for all shipping options and products across your entire site. Are you sure you want to use %{var1}?":
              [
                "该重量单位将应用于此网站中的所有配送方式和商品。你确定你想要使用%{var1} 吗？",
              ],
            'Ecommerce|To enable %{paymentName}, you must activate it in your Stripe dashboard and make sure the status is "live."':
              [
                "要开启 %{paymentName}，请确保你已经在 Stripe 中激活，且状态为“生效”状态。",
              ],
            "Ecommerce|Total": ["总计"],
            "Ecommerce|Total Approved Balance": ["已批准金额"],
            "Ecommerce|Total Pending Balance": ["处理中金额"],
            "Ecommerce|Total number of orders in the selected time": [
              "所选日期内的订单数",
            ],
            "Ecommerce|Total value of all orders in the selected time": [
              "所选日期内的全部订单实际支付金额",
            ],
            "Ecommerce|Total: %{mount}": ["总计: %{mount}"],
            "Ecommerce|Transaction Approved": ["已批准"],
            "Ecommerce|Transaction Pending": ["处理中"],
            "Ecommerce|Transaction Refunded": ["已退款"],
            "Ecommerce|Transaction Status": ["交易状态"],
            "Ecommerce|Transaction failed. Please try again later or contact the merchant.":
              ["交易失败，请重新下单或与商家联系。"],
            "Ecommerce|Transaction failure due to the incomplete shipping address!":
              ["由于送货地址不完整导致交易失败！"],
            "Ecommerce|Transaction fee varies with different payment methods": [
              "交易手续费因不同的付款方式而异",
            ],
            "Ecommerce|UNHIDE": ["上架"],
            "Ecommerce|UPDATE": ["更新"],
            "Ecommerce|URL is invalid.": ["链接是无效的"],
            "Ecommerce|US State Sales Tax": ["美国州销售税"],
            "Ecommerce|Uh-oh! Digital products must be purchased individually and separately. (%{digital_product_name})":
              [
                "下载类商品必须单独下单，请分开购买结算（%{digital_product_name}）",
              ],
            "Ecommerce|Uncategorized": ["未分类"],
            "Ecommerce|Unhide": ["上架"],
            "Ecommerce|UnionPay": ["银联"],
            "Ecommerce|Units in kg": ["单位为 kg (千克)"],
            "Ecommerce|Units in lb": ["单位为 lb (磅)"],
            "Ecommerce|Unlimited": ["不设限"],
            "Ecommerce|Up to 500 MB": ["最大支持500MB"],
            "Ecommerce|Update": ["更新"],
            "Ecommerce|Update Your Stripe Settings": ["更新你的 Stripe 配置"],
            "Ecommerce|Upgrade to Pro": ["升级套餐"],
            "Ecommerce|Upgrade to Pro to edit email templates": [
              "升级至专业版来更改你的邮件模板",
            ],
            "Ecommerce|Upgrade to Pro to set a flat tax rate to apply to all of your store's orders.If you need to set a sales tax, please consult a tax professional to comply with all applicable tax laws. <a href='http://support.strikingly.com/hc/en-us/articles/218093418' target='_blank'>Learn more.</a>":
              [
                "升级到专业版设置统一的税率，应用到商店的所有订单。如果你需要设置销售税，请向税务专业人士咨询相关税法。<a href='http://support.strikingly.com/hc/en-us/articles/218093418' target='_blank'>了解更多。</a>",
              ],
            "Ecommerce|Upgrade to add categories": ["升级至企业版添加商品分类"],
            "Ecommerce|Upgrade to add more products": [
              "升级套餐以添加更多商品",
            ],
            "Ecommerce|Upgrade to edit email templates!": [
              "升级套餐来更改你的邮件模板",
            ],
            "Ecommerce|Upgrade to enable custom URL": [
              "升级到企业版以启用自定义URL",
            ],
            "Ecommerce|Upgrade to enable product page description and custom product URL":
              ["升级到企业版以添加商品详情页描述和自定义商品URL"],
            "Ecommerce|Upgrade to pro": ["升级为企业版套餐"],
            "Ecommerce|Upload CSV File": ["上传CSV文件"],
            "Ecommerce|Upload File": ["上传文件"],
            "Ecommerce|Upload Image": ["上传图片"],
            "Ecommerce|Use this tool to export all your current products to a CSV file. You can then edit the CSV and re-import them, to easily update many products at once.":
              [
                "此功能可以导出商品为CSV文件。你可以修改CSV文件中的商品信息，然后上传此CSV文件进行商品导入，以实现快速批量编辑。",
              ],
            "Ecommerce|Useful if you have a lot of products.": [
              "可以使您的访客更方便的找到所需商品。",
            ],
            "Ecommerce|VISA/MasterCard/JCB": ["VISA/MasterCard/JCB"],
            "Ecommerce|Variant name is required.": ["规格是必填项。"],
            "Ecommerce|Variants": ["商品规格"],
            "Ecommerce|Verification Code": ["短信验证码"],
            "Ecommerce|View Cart": ["浏览购物车"],
            "Ecommerce|View Customer": ["查看顾客"],
            "Ecommerce|View More Reviews": ["查看更多评价"],
            "Ecommerce|View Order": ["查看订单"],
            "Ecommerce|View Pricing and upgrade": ["查看定价并升级"],
            "Ecommerce|View all members": ["查看所有会员"],
            "Ecommerce|View all orders": ["查看所有的订单"],
            "Ecommerce|View all products": ["查看所有商品"],
            "Ecommerce|View details and withdraw from your Strikingly Taiwan Payments account balance.":
              ["查看账户详情，发起Strikingly台湾金流请款。"],
            "Ecommerce|View email templates": ["查看邮件模板"],
            "Ecommerce|View guide to activate %{paymentName}": [
              " 查看激活 %{paymentName} 的步骤说明 ",
            ],
            "Ecommerce|View more details...": ["查看更多详情..."],
            "Ecommerce|View stats": ["查看数据"],
            "Ecommerce|View tutorial.": ["查看操作指引"],
            "Ecommerce|View tutorials.": ["查看操作指引"],
            "Ecommerce|Visible": ["上架状态"],
            "Ecommerce|We are unable to authenticate your payment method. Please choose a different payment method and try again.":
              ["该付款方式未通过验证，请尝试其他方式付款。"],
            "Ecommerce|We have received your registration documents. You'll receive an email notification when the verification is complete.":
              [
                "你已成功提交审核。注册档案审核结果将发送至你的邮箱，请注意查收。",
              ],
            "Ecommerce|We ship to the following countries:": [
              "我们发货至下列国家：",
            ],
            "Ecommerce|WeChat": ["微信"],
            "Ecommerce|WeChat Pay": ["微信支付"],
            "Ecommerce|Wechat Pay": ["微信支付"],
            "Ecommerce|Weight": ["重量"],
            "Ecommerce|We’ll switch to %{var1} to process card payments, Google Pay, and Apple Pay for future purchases and subscriptions.":
              [
                "我们将改用%{var1}来接受未来的银行卡、Google Pay和Apple Pay收款。",
              ],
            "Ecommerce|We’ve upgraded our PayPal API. Please reconnect your PayPal account to ensure your payouts are not interrupted.":
              [
                "我们最近升级了 Paypal API 接口。为确保你的打款提现不受影响，请尽快重新绑定你的 Paypal 账号。",
              ],
            "Ecommerce|When approved, this review will be displayed on the product page.":
              ["批准后，这条评价就会显示在商品页面中。"],
            "Ecommerce|When rejected, this review won’t be displayed on the product page.":
              ["拒绝后，这条评价将不会显示在商品页面中。"],
            "Ecommerce|Will you give us a review?": ["可以给我们一个好评吗？"],
            "Ecommerce|Withdraw Date": ["请款日期"],
            "Ecommerce|Withdraw Entire Balance": ["全部请款"],
            "Ecommerce|Withdrawing this balance to your connected bank account will take up to 3 business days to process. Do you want to withdraw your entire approved balance?":
              [
                "全部请款到你绑定的银行账户需要最多3个工作日。你是否想进行全部请款？",
              ],
            "Ecommerce|You agree that you will not upload or sell any products or content which may be deemed hazardous, counterfeit, stolen, fraudulent, offensive or abusive.":
              [
                "你确保你不会上传或出售任何危险、伪造、盗版、欺诈、攻击性或侮辱性的产品或内容。",
              ],
            "Ecommerce|You are currently set up not to collect email addresses from customers at checkout. Your customers will not be able to receive review request emails and will not be able to submit product reviews. Please go to 'Checkout Form Settings' and check the box for collecting emails and set as required.":
              [
                "你当前未设置在客户下单时收集电子邮箱，你的客户将无法收到评价邀请邮件，也将无法提交商品评价。请前往「下单结账设置」中勾选收集电子邮箱并设置为必填项。",
              ],
            "Ecommerce|You can accept payments in KRW but Stripe will convert to a supported payout currency.[link: Learn more]":
              [
                "您可以设置韩元为收款货币，但是 Stripe 将会自动转换为您账户支持的支付货币。[link: 了解更多]",
              ],
            "Ecommerce|You can add a maximum of 10 images.": [
              "最多可增加十张图片",
            ],
            "Ecommerce|You can add up to %{limit} weight ranges to ship to.": [
              "你最多可以添加 %{limit} 个重量范围。",
            ],
            "Ecommerce|You can add up to %{maxRanges} weight ranges.": [
              "最多设置%{maxRanges}个重量范围",
            ],
            "Ecommerce|You can add up to 10 images to the product page.": [
              "您最多可以上传10张图片到产品详情页。",
            ],
            "Ecommerce|You can close this dialog and continue working. A notification will appear once the import is complete!":
              [
                "你可以关闭本窗口，无需守候等待。导入完成后，编辑器会自动弹出完成提示信息。",
              ],
            "Ecommerce|You can close this dialog and continue working. The file will auto-download once the export is complete!":
              ["你可以关闭本窗口，无需守候等待。导出完成后会自动下载文件。"],
            "Ecommerce|You can drag to reorder or drag out to create new category.":
              ["你可以通过拖动来重新排序，或者拖出以创建新类别。"],
            "Ecommerce|You can drag to reorder.": [
              "你可以通过拖动来重新排序。",
            ],
            "Ecommerce|You can manually switch to %{var2} to process card payments, Google Pay, and Apple Pay instead.":
              [
                "你可以手动切换成 %{var2} 来处理银行卡、Google Pay和Apple Pay收款。",
              ],
            "Ecommerce|You can only add a maximum of 20 regions.": [
              "最多可增加20个地区",
            ],
            "Ecommerce|You can only add up to 10 choices": [
              "最多仅支持添加10个规格选项",
            ],
            "Ecommerce|You can only add up to 50 categories per site.": [
              "一个网站最多可以添加50种商品分类。",
            ],
            "Ecommerce|You can only create 100 coupons.": [
              "优惠券不能超过 100 个",
            ],
            "Ecommerce|You can only upload files up to 500MB.": [
              "上传文件最大支持500MB",
            ],
            "Ecommerce|You can tag up to 5 categories for this product. ": [
              "你最多可以为该商品添加5种商品分类。",
            ],
            "Ecommerce|You can use this tool to add or update multiple products at once. You’ll need to upload a CSV file, which must be in a specific format.":
              [
                "此功能可以帮你批量添加、修改商品。请使用我们提供的CSV模板，按格式录入商品信息，然后上传此CSV文件进行导入。",
              ],
            "Ecommerce|You can't change the visibility status for products with an active campaign!":
              ["活动中的商品不可以修改发布状态！"],
            "Ecommerce|You currently have product reviews enabled, if you do not collect email addresses, your customers will not receive review request emails. Are you sure you don't want to collect emails?":
              [
                "你当前已开启商品评价，若不收集电子邮箱，你的客户将无法收到评价邀请邮件。确定不收集电子邮箱吗？",
              ],
            "Ecommerce|You don't have any orders yet!": ["还没有订单，加油！"],
            "Ecommerce|You don't have enough storage space in your account to upload this file. Please chat with us to see options for increasing your file storage limit.":
              ["账户的储存空间不足。请联系我们在线客服，了解如何升级扩容。"],
            "Ecommerce|You have already submitted a review for this product.": [
              "你已经提交了对该商品的评价。",
            ],
            "Ecommerce|You have successfully created a Strikingly Taiwan Payments account. You can now accept NT$ payments from your customers.":
              [
                "你已成功创建了Strikingly台湾金流账户。现在你可以接受来自顾客的新台币付款了。",
              ],
            "Ecommerce|You haven’t set up a payment gateway for your store! You must activate at least one payment method to enable checkout.":
              [
                "你还没有为你的店铺设置好收款方式！必须激活至少一种收款方式才能启用结账功能。",
              ],
            "Ecommerce|You must authorize permissions to connect your Square account. Please try again.":
              ["你必须先同意授权以连接到 Square 账号，请重试。"],
            "Ecommerce|You must select at least one category": [
              "必须至少选择一个商品分类",
            ],
            "Ecommerce|You must select at least one product": [
              "必须至少选择一件商品",
            ],
            "Ecommerce|You must upload a file.": ["您必须上传文件"],
            "Ecommerce|You will be importing [strong: %{var1} products] with a total of [strong1: %{var2} options].":
              [
                "即将导入[strong: %{var1}个商品]，共[strong1: %{var2}个商品规格]。",
              ],
            "Ecommerce|You will be redirected to PayPal to complete payment.": [
              "你将跳转至 PayPal 完成付款",
            ],
            "Ecommerce|You'll get an order confirmation email after the payment is successfully completed.":
              ["付款成功后，您会收到订单确认邮件。"],
            "Ecommerce|You'll get an order confirmed email notification after you successfully complete payment at ATM/Bank.":
              ["在ATM / 银行付款成功后，您将收到确认订单的电子邮件通知。"],
            "Ecommerce|You'll have options to show signup dialog to your customer before checkout. Your customers will have the opportunity to create an account and track their orders after completing their checkout.":
              [
                "商城会员功能将允许您的访客在购买商品的同时注册成为您的会员。商城会员可以随时查看订单状态及历史。",
              ],
            "Ecommerce|You're using %{var1} to accept credit/debit card payments, Google Pay and Apple Pay.":
              [
                "你目前正在使用 %{var1} 来接受信用卡/借记卡、Google Pay和Apple Pay收款。",
              ],
            "Ecommerce|You've got a new product review submitted": [
              "你收到了一个新的商品评价",
            ],
            "Ecommerce|You've reached the product limit for your plan, and your visitors will not be able to add this to cart. Upgrade to sell more products!":
              [
                "你已经达到了该套餐商品数量限额，访问者将无法将其添加到购物车。升级套餐以销售更多的商品！",
              ],
            "Ecommerce|Your Cart": ["购物车"],
            "Ecommerce|Your Cart is empty.": ["您的购物车为空。"],
            "Ecommerce|Your Items": ["订单信息"],
            "Ecommerce|Your Order": ["你的订单"],
            "Ecommerce|Your bank card requires 3D-Secure validation before payment. Please follow the validation steps on the new page to finish the purchase.":
              [
                "您的银行卡需要通过3D验证后才能付款。请按照即将打开的页面上的验证步骤完成购买。",
              ],
            "Ecommerce|Your cart is empty": ["你的购物车为空"],
            "Ecommerce|Your cart is empty. Continue shopping.": [
              "您的购物车还是空的，赶快去挑选商品吧！",
            ],
            "Ecommerce|Your current plan only allows for %{var1} products. Please upgrade or chat with customer support for more.":
              [
                "当前套餐仅支持添加%{var1}件商品。请升级套餐或咨询在线客服以增加商品数额上限。",
              ],
            "Ecommerce|Your customers will see this option at checkout.": [
              "顾客确认订单时可以看到此名称。",
            ],
            "Ecommerce|Your download link is also included in the email. This download link will only be valid for %{number} hours!":
              ["该下载链接会附加在邮件内。注意链接有效期为%{number}小时！"],
            "Ecommerce|Your existing service products, digital products, and pre-order products will be hidden.":
              ["你现有的服务类商品，下载类商品和商品预定将被下架。"],
            "Ecommerce|Your membership details will also be emailed to you shortly.":
              ["会员详情邮件稍后将发送至你的邮箱。"],
            "Ecommerce|Your message at customer signup": ["注册提示信息"],
            "Ecommerce|Your name": ["你的名字"],
            "Ecommerce|Your note will be shown to customers during the checkout process. (Optional)":
              ["买家在结账时将能看到你的留言（选填）。"],
            "Ecommerce|Your notes": ["留言"],
            "Ecommerce|Your order has been cancelled!": ["您的订单已被取消！"],
            "Ecommerce|Your order has been fulfilled!": ["您的订单已完成！"],
            "Ecommerce|Your order has been refunded!": ["您的订单已退款！"],
            "Ecommerce|Your order total is %{total}": [
              "你的订单总价是 %{total}",
            ],
            "Ecommerce|Your order will be reserved for 10 minutes.": [
              "您的订单将在10分钟后被取消。",
            ],
            "Ecommerce|Your registration document has failed validation. Please check your email for more details and [link:click here to resubmit.]":
              [
                "你的注册档案资料审核未通过，请查看邮件了解详情，并[link:点击此处重新提交审核]。",
              ],
            "Ecommerce|Your registration document is being reviewed. You’ll receive an email notification when the verification is complete.":
              [
                "你的注册档案资料正在审核中。审核结果将会发送至你的邮箱，请注意查收。",
              ],
            "Ecommerce|Your store offers these shipping options:": [
              "商店提供的配送方式：",
            ],
            "Ecommerce|Your total approved balance is [strong: %{var1}].": [
              "你的已批准金额为[strong:%{var1}]。",
            ],
            "Ecommerce|Your transaction is on hold. You’ll get an email notification after your transaction is reviewed. Please contact the store owner if you have any questions.":
              [
                "您的交易正在审核中，审核成功交易完成后，您会收到一封电子邮件通知。如有任何问题，请联系卖家。",
              ],
            "Ecommerce|Your transaction is secure and encrypted.": [
              "您的交易是安全且加密的。",
            ],
            "Ecommerce|You’re selecting a currency that your Square account does not support. Stripe will be used to accept payments in this currency. The curency change and payment gateway change will only apply to your future subscribers.":
              [
                "当前 Square 账户不支持你所选择的货币。我们切换至 Stripe 来接受所选货币的收款。收款货币和收款方式的变动仅适用于你未来的商店顾客和付费会员订阅者。",
              ],
            "Ecommerce|You’ve reached your product limit! Please upgrade your plan to add more products.":
              ["你的商城已经到达产品上限了。请升级套餐以增加更多的产品。"],
            "Ecommerce|ZIP/Postal": ["邮编"],
            "Ecommerce|[link: How to get your PID and keys]": [
              "[link: 了解如何获取PID和RSA密钥]",
            ],
            "Ecommerce|[link: Learn more about PayPal.]": [
              "[link:了解更多关于Paypal的信息]",
            ],
            "Ecommerce|[link: Learn more about Stripe.]": [
              "[link:了解更多关于Stripe的信息]",
            ],
            "Ecommerce|[link: Learn more]": ["[link:了解更多]"],
            "Ecommerce|[link:Download CSV template] to see an example of the format.":
              ["[link:下载CSV模板]查看参考格式。"],
            "Ecommerce|[link:Learn more about Square.]": [
              "[link:了解更多关于 Square 的信息]",
            ],
            "Ecommerce|e.g. Cash on Delivery (customers will see this as a payment option)":
              ["例如: 货到付款  (客户会在购买商品是看到该支付方式)"],
            "Ecommerce|e.g. Color": ["比如：颜色"],
            "Ecommerce|e.g. Large, Medium, Small": ["比如：大号，中号，小号等"],
            "Ecommerce|e.g. Pickup in Store": ["例如：到店自提"],
            "Ecommerce|e.g. Red, Green, Blue": ["比如：红色、绿色、蓝色"],
            "Ecommerce|e.g. Size": ["比如：尺寸"],
            "Ecommerce|e.g. Standard Shipping, Expedited Shipping": [
              "例如：标准快递、次日达特快",
            ],
            "Ecommerce|e.g. The shipping company will accept payment upon delivery. Pay with cash or credit card when the package arrives at your door!":
              [
                "例如: 物流公司将在商品送达您填写的收货地址时收取订单费用，您可以使用现金或信用卡支付订单。",
              ],
            "Ecommerce|e.g. You'll have the opportunity to create an account and track your orders once you complete your checkout.":
              ["例如：注册成为会员后可随时查看您的订单状态。"],
            "Ecommerce|e.g. international shipping policy, estimated delivery date":
              ["例如：快递信息、预计发货或到达日期等"],
            "Ecommerce|e.g. tracking information, estimated delivery date, personal thank you, etc.":
              ["比如：快递公司、快递单号、快递预计到达日期等"],
            "Ecommerce|item": ["商品"],
            "Ecommerce|items": ["件"],
            "Ecommerce|or": ["或者"],
            "Ecommerce|or 4 payments of %{amount} with [image]": [
              "或使用 [image]可分4期付款，每期支付%{amount}",
            ],
            "Ecommerce|payment instructions — %{method}": [
              "付款说明 — %{method}",
            ],
            "Ecommerce|product options": ["商品规格"],
            Edit: ["编辑"],
            "Edit Consent Message": ["编辑同意信息"],
            "Edit Image": ["编辑图片"],
            "Editing custom code (header and footer code) is only available for Pro users.":
              ["编辑自定义代码（页眉和页脚代码）仅限专业／企业版用户使用"],
            "EditorSettings|Accept Payments": ["收款方式"],
            "EditorSettings|Activate GDPR compliance for user submitted data from web forms.":
              ["启用以保证用户通过网站表单提交的数据遵守GDPR规范"],
            "EditorSettings|Add Ads.txt & App-ads.txt": [
              "添加Ads.txt 与 App-ads.txt",
            ],
            "EditorSettings|Add a CNAME record pointing from <strong>%{subDomain}</strong> to <strong>dns.strikingly.com</strong>":
              [
                "添加一个 CNAME 记录，把  <strong>%{subDomain}</strong> 指向上线了的服务器",
              ],
            "EditorSettings|Add a CNAME record pointing from <strong>www</strong> to <strong>%{rootDomain}</strong>":
              [
                "你需要添加一个 CNAME 记录，把  <strong>www</strong> 指向 <strong>%{rootDomain}</strong>",
              ],
            "EditorSettings|Add a button": ["添加按钮"],
            "EditorSettings|Add a search button in your site navigation. This will open a search page where the visitor can search all pages, products, and blog posts on your site. This is useful if you have many pages, products, or blog posts!":
              [
                "在您的网站导航中添加搜索按钮。点击搜索按钮将打开一个搜索页面，您的访客可以搜索您网站上的页面、商品和博客文章。如果您有很多页面、商品或博客文章，这个功能会很有帮助！",
              ],
            "EditorSettings|Add an A record pointing from <strong>@</strong> to <strong>54.183.102.22</strong>":
              [
                "添加一个 CNAME 记录，把  <strong>%{subDomain}</strong> 指向上线了的服务器",
              ],
            "EditorSettings|Add up to 4 action buttons on your mobile site.": [
              "在手机网站上可设置至 4 个操作按钮。",
            ],
            "EditorSettings|Administrator": ["管理员"],
            "EditorSettings|Affiliate Program": ["联盟分销计划"],
            "EditorSettings|Almost done! You still need to configure your domain settings.":
              ["自定义域名保存成功！请选择域名注册商，完成域名解析。"],
            "EditorSettings|Analytics": ["数据分析"],
            "EditorSettings|Basic Info": ["基本资料"],
            "EditorSettings|Basic Information": ["基本资料"],
            "EditorSettings|Biz / Pro / Limited": ["企业版/专业版/基础版"],
            "EditorSettings|Blogger": ["博客作者"],
            "EditorSettings|Call Us": ["联系我们"],
            "EditorSettings|Changes in domain settings usually take effect in a few hours, but can take up to 2 days.":
              ["域名设置变动一般需要几个小时生效，最长可达2天。"],
            "EditorSettings|Claim your Domain": ["领取我的域名"],
            "EditorSettings|Collaboration": ["协作"],
            "EditorSettings|Complete": ["完成"],
            "EditorSettings|Connect Domain": ["绑定自定义域名"],
            "EditorSettings|Contact": ["联系我们"],
            "EditorSettings|Cookie Use": ["Cookie的使用"],
            "EditorSettings|Custom Code": ["自定义代码"],
            "EditorSettings|Display your Privacy Policy in the footer.": [
              "在页脚中显示您的隐私政策。",
            ],
            "EditorSettings|Display your Privacy Policy in the site footer, store checkout, and membership registration.":
              ["将你的隐私政策显示在页脚、会员注册页面及简易商店的结账流程中"],
            "EditorSettings|Display your Terms & Conditions in the footer and Simple Store checkout flow.":
              ["将条款及条件显示在页脚及简易商店的结账流程中。"],
            "EditorSettings|Display your Terms & Conditions in the site footer, store checkout, and membership registration.":
              [
                "将你的条款及条件显示在页脚、会员注册页面及简易商店的结账流程中。",
              ],
            "EditorSettings|Domain": ["域名"],
            "EditorSettings|Domains": ["域名"],
            "EditorSettings|Editor": ["网站编辑"],
            "EditorSettings|Email": ["电子邮箱"],
            "EditorSettings|Email Notifications": ["通知提醒设置"],
            "EditorSettings|Enable Site Search": ["启用站内搜索"],
            "EditorSettings|Enter your Contact Info": [
              "输入电话、邮箱等联系方式",
            ],
            "EditorSettings|Enter your Privacy Policy": ["请输入你的隐私政策"],
            "EditorSettings|Enter your Terms & Conditions": [
              "请输入你的条款及条件",
            ],
            "EditorSettings|Enter your email address": ["输入邮箱地址"],
            "EditorSettings|Enter your location": ["输入地址"],
            "EditorSettings|Enter your phone number": ["输入电话号码"],
            "EditorSettings|Enter your website URL": ["输入网址"],
            "EditorSettings|Find Us": ["地址"],
            "EditorSettings|Forward %{rootDomain} to <strong>http://%{wwwSubdomain}</strong>":
              [
                "把 %{rootDomain} 跳转至 <strong>http://%{wwwSubdomain}</strong>",
              ],
            "EditorSettings|Forward %{rootDomain} to <strong>http://%{wwwSubdomain}</strong> <br> <strong>OR</strong> Add an A record pointing from <strong>@</strong> to <strong>54.183.102.22</strong>":
              [
                "把 %{rootDomain} 跳转至 <strong>http://%{wwwSubdomain}</strong>",
              ],
            "EditorSettings|General Data Protection Regulation (GDPR) Compliance":
              ["通用资料保护规则（GDPR）规范遵守"],
            "EditorSettings|Header & Footer": ["页眉和页脚"],
            "EditorSettings|Header & Footer Display": ["页眉和页脚显示"],
            "EditorSettings|Hey, we’ve updated Mobile Actions with new functionality!":
              ["我们更新了移动端操作，添加了新功能！"],
            "EditorSettings|Hide Ads.txt & App-ads.txt": [
              "隐藏Ads.txt 与 App-ads.txt 配置",
            ],
            "EditorSettings|Hide Advanced": ["隐藏高级选项"],
            "EditorSettings|Home": ["首页"],
            "EditorSettings|Home Page": ["首页"],
            "EditorSettings|Instant Apps": ["一键生成应用"],
            "EditorSettings|Invalid domain!": ["无效域名！"],
            "EditorSettings|Join our Affiliate Program and get paid up to $1000 per referral.":
              ["加入我们的联盟分销计划即可赚取最多每单$1000美金的佣金。"],
            "EditorSettings|Learn More": ["了解更多"],
            "EditorSettings|Legal": ["法务"],
            "EditorSettings|Let your visitors know that your site uses cookies.":
              ["让你的访客知道你的网站正在使用 Cookies。"],
            "EditorSettings|Let your visitors quickly call a phone number, get directions, and more!":
              ["让你的访客更容易拨打电话、购物、查看地图以及更多定制性操作！"],
            "EditorSettings|Live Chat": ["在线聊天"],
            "EditorSettings|Manage your authorized ad sellers (e.g. if using AdSense).":
              ["管理你的授权广告商（如 AdSense 等）。"],
            "EditorSettings|Map": ["地图"],
            "EditorSettings|Membership": ["会员功能"],
            "EditorSettings|Mobile Actions": ["移动端操作"],
            "EditorSettings|Mobile Nav bar": ["移动端菜单栏"],
            "EditorSettings|Multi-language": ["多语言"],
            "EditorSettings|Multiple Pages": ["多页面网站"],
            "EditorSettings|Name": ["栏目名"],
            "EditorSettings|No Thanks": ["取消"],
            "EditorSettings|Notifications": ["通知提醒"],
            "EditorSettings|Optional": ["选项"],
            "EditorSettings|Paste your Ads.txt below.": [
              "在此处粘贴你的 ads.txt 内容：",
            ],
            "EditorSettings|Paste your App-ads.txt below if you display ads in mobile apps tied to your current domain name.":
              [
                "在此处粘贴你的 App-ads.txt 内容（如果你有关联当前网站域名的移动端app展示广告）：",
              ],
            "EditorSettings|Pending": ["待定"],
            "EditorSettings|Phone": ["电话"],
            "EditorSettings|Physical Address": ["实体地址"],
            "EditorSettings|Please check your apple develop account.": [
              "请确认您的开发者账号信息。",
            ],
            "EditorSettings|Portfolio": ["产品展示"],
            "EditorSettings|Posts": ["文章"],
            "EditorSettings|Privacy": ["隐私设置"],
            "EditorSettings|Privacy & Legal": ["隐私与法务"],
            "EditorSettings|Privacy Policy": ["隐私政策"],
            "EditorSettings|Pro / Limited": ["基础版 / 专业版"],
            "EditorSettings|Read Tutorial": ["查看教程"],
            "EditorSettings|Sender Profile": ["发件人信息"],
            "EditorSettings|Seo": ["搜索引擎优化"],
            "EditorSettings|Seo Checklist": ["SEO 优化"],
            "EditorSettings|Services": ["服务与验证"],
            "EditorSettings|Set Ads.txt & App-ads.txt": [
              "配置Ads.txt 与 App-ads.txt文件",
            ],
            "EditorSettings|Set a meta description for each page": [
              "为二级页面设置元描述",
            ],
            "EditorSettings|Set a meta description for home page": [
              "为主页设置元描述",
            ],
            "EditorSettings|Settings": ["设置"],
            "EditorSettings|Sharing Info": ["网站分享"],
            "EditorSettings|Sharing Information": ["分享信息"],
            "EditorSettings|Show Advanced": ["显示高级选项"],
            "EditorSettings|Show European Union Cookie Notification": [
              "根据欧盟(EU) 法律显示“使用 Cookie”的信息",
            ],
            "EditorSettings|Show Privacy Policy": ["显示隐私政策"],
            "EditorSettings|Show Terms & Conditions": ["显示条款及条件"],
            "EditorSettings|Show Terms & Conditions and Privacy Policy to activate GDPR Compliance.":
              ["显示使用条款及隐私政策以遵守GDPR规范"],
            "EditorSettings|Simple Blog": ["简易博客"],
            "EditorSettings|Simple Store": ["简易商店"],
            "EditorSettings|Site Language": ["网站语言"],
            "EditorSettings|Site Search": ["站内搜索"],
            "EditorSettings|Store": ["商店"],
            "EditorSettings|Terms & Conditions": ["条款及条件"],
            "EditorSettings|This Sender Profile is used to communicate with your audience & customers. Recipients will see the name and email in the “From” field of all emails sent by your site. [link:Send a test email.]":
              [
                "此发件人信息将被用于与你的粉丝和顾客交流。收件人将在来自此网站的所有邮件的“发件人”字段中看到相应的姓名和邮箱。[link:发送测试邮件。]",
              ],
            "EditorSettings|This domain is not registered yet!": [
              "域名还未注册",
            ],
            "EditorSettings|This domain is not registered yet! You can register it now.":
              ["域名还未注册"],
            'EditorSettings|This setting affects some system text visitors see in your site\'s blog, store, and social feed (e.g. "Previous" and "Next" buttons). This will not translate any site content you\'ve entered!':
              [
                '切换"简易博客"、"简易商店"等版块里的系统语言（如：按钮名称等）。提示：不会影响网站内容。',
              ],
            "EditorSettings|To add Ads.txt and App-ads.txt, you must have a custom domain connected to your site.":
              ["你必须绑定自定义域名才能够对网站添加Ads.txt 与 App-ads.txt。"],
            "EditorSettings|To comply with [link:anti-spam regulations] and ensure deliverability, a physical address is required for all email campaigns.":
              [
                "为遵守[link:反垃圾邮件法规]并确保邮件的到达率，所有邮箱中都必须添加你的实体地址。",
              ],
            "EditorSettings|Try these out:": ["试试这些："],
            "EditorSettings|UPDATE": ["更新"],
            "EditorSettings|URL": ["网址"],
            "EditorSettings|View Site Stats": ["数据流量"],
            "EditorSettings|Where did you register this domain?": [
              "这个域名是在哪里注册的呢？",
            ],
            "EditorSettings|You have %{script} tags in header code; it's recommended that you put these in the footer.":
              [
                "你的页眉代码中含有 %{script} 标签，建议你将它们放在页脚代码中。",
              ],
            "EditorSettings|You must enter your Privacy Policy": [
              "隐私政策不能为空",
            ],
            "EditorSettings|You must enter your Terms & Conditions": [
              "条款及条件不能为空",
            ],
            "EditorSettings|You must use %{strkLink} to be able to use jQuery in custom code.":
              ["你必须使用 %{strkLink} 才能使 jQuery 代码生效。"],
            "EditorSetting|A short message to display when the form is submitted.":
              ["表单提交后将显示一段简短的提示。"],
            "EditorSetting|Action Buttons": ["操作按钮"],
            "EditorSetting|Add a button": ["添加一个按钮"],
            "EditorSetting|Age Verification": ["年龄鉴定"],
            "EditorSetting|Announcement": ["宣传公告"],
            "EditorSetting|Are you sure you want to disable the Pop-Up on this site?":
              ["你确定想要停用当前网站的弹窗功能吗？"],
            "EditorSetting|Are you sure you want to try Pop-Ups? The pop-ups won't be shown on your published site until you upgrade your account, but you'll be able to see how it works.":
              [
                "您确定要试用推广弹窗功能吗？ 在您升级帐户之前，推广弹窗不会在您发布的网站中生效。但您将能够看到推广弹窗的运作方式。",
              ],
            "EditorSetting|Blog Section": ["博客版块"],
            "EditorSetting|Button Text": ["按钮文字"],
            "EditorSetting|Categories will appear in site navigation if at least one post is published.":
              ["分类菜单仅在发布过至少一篇博客时显示。"],
            "EditorSetting|Categories will appear in site navigation if at least one product is visible.":
              ["分类菜单仅在至少有一个产品可见时显示。"],
            "EditorSetting|Collect emails": ["收集邮箱地址"],
            "EditorSetting|Disable Pop-Up": ["停用弹窗功能"],
            "EditorSetting|Display Category Menu in Navigation": [
              "在导航栏中显示分类菜单",
            ],
            "EditorSetting|Drag to adjust position of blog category menu in navigation. You can also change the display name.":
              [
                "拖动可调整博客分类菜单在导航栏中的位置。你也可以更改菜单的显示名称。",
              ],
            "EditorSetting|Drag to adjust position of product category menu in navigation. You can also change the display name.":
              [
                "拖动可调整商品分类菜单在导航栏中的位置。你也可以更改菜单的显示名称。",
              ],
            "EditorSetting|Email": ["邮箱"],
            "EditorSetting|Email Form": ["邮箱表单"],
            "EditorSetting|Email Notification": ["邮件提醒"],
            "EditorSetting|Email address": ["邮箱地址"],
            "EditorSetting|Enable Pop-Ups": ["开启弹窗功能"],
            "EditorSetting|Enter Blog": ["进入博客"],
            "EditorSetting|Enter Button Text": ["进入按钮文字"],
            "EditorSetting|Enter Store": ["进入商店"],
            "EditorSetting|Enter site URL": ["输入网址链接"],
            "EditorSetting|Enter website": ["浏览网站"],
            "EditorSetting|Exit Button Text": ["退出按钮文字"],
            "EditorSetting|For illustrative purposes only. Please consult an attorney for any legal requirements.":
              ["内容仅供参考。请咨询律师了解具体的法律要求。"],
            "EditorSetting|Form Fields": ["表单字段"],
            "EditorSetting|Grab visitors’ attention with a beautiful pop-up.": [
              "用精美漂亮的弹窗吸引访客的目光。",
            ],
            "EditorSetting|Home Page": ["首页"],
            "EditorSetting|Image": ["图片"],
            "EditorSetting|Layout": ["布局"],
            "EditorSetting|Make an announcement": ["发布宣传公告"],
            "EditorSetting|Mobile phone number": ["手机号"],
            "EditorSetting|More options": ["更多选项"],
            "EditorSetting|Name": ["姓名"],
            "EditorSetting|Phone Number Form": ["收集访客手机号"],
            "EditorSetting|Pop-Up Type": ["弹窗类型"],
            "EditorSetting|Pop-Ups": ["推广弹窗"],
            "EditorSetting|Pop-Ups feature is currently disabled.": [
              "弹窗功能当前已停用。",
            ],
            "EditorSetting|Preview": ["预览"],
            "EditorSetting|Prompt visitors to leave their phone numbers": [
              "引导访客留下联系方式",
            ],
            "EditorSetting|Remind visitors to leave their email": [
              "提醒访客留下他们的邮箱联系方式",
            ],
            "EditorSetting|Show blog category menu in site navigation to let visitors quickly view categories.":
              ["在网站导航中显示博客分类菜单，让访客快速查看分类。"],
            "EditorSetting|Show news or offers with images/text": [
              "使用配图和文字来宣传新闻动态、优惠活动等",
            ],
            "EditorSetting|Show product category menu in site navigation to let visitors quickly view categories.":
              ["在网站导航中显示商品分类菜单，让访客快速查看分类。"],
            "EditorSetting|Store Section": ["商店版块"],
            "EditorSetting|Submit": ["提交"],
            "EditorSetting|Success Message": ["提交后提示文案"],
            "EditorSetting|Text": ["文字"],
            "EditorSetting|This URL has already been taken.": [
              "此域名已被占用。",
            ],
            "EditorSetting|This will only take effect in the live site, not in the editor.":
              ["语言切换只会在发布网站生效，编辑器里的语言不会改变。"],
            "EditorSetting|URL": ["网址"],
            "EditorSetting|Upgrade to Business plan to use Pop-Ups": [
              "升级至企业版使用弹窗功能",
            ],
            "EditorSetting|Upgrade to Pro to re-enable": [
              "升级至专业版以重新启用",
            ],
            "EditorSetting|Upgrade to Pro to use Pop-Ups": [
              "升级至专业版使用弹窗功能",
            ],
            "EditorSetting|Upload image": ["上传图片"],
            "EditorSetting|Use pop-ups to collect emails, promote special offers, or verify age.":
              ["使用弹窗收集访客的邮箱地址、推广优惠活动或鉴定访客年龄。"],
            "EditorSetting|Use pop-ups to collect phone numbers or make announcements.":
              ["使用弹窗来收集访客的手机号、宣传活动或公告"],
            "EditorSetting|Visitors who land on your site will see the pop-up once.":
              ["访客进入你的网站后会看到一次弹窗。"],
            "EditorSetting|You can add a simple banner or graphic. (Optional)":
              ["你可以添加一个简单的广告图或者插画，（可选）"],
            "EditorSetting|You can add a simple banner or graphic. Recommended size: 760x960px. (Optional)":
              [
                "你可以添加一个简单的广告图或者插画，推荐尺寸：760*960像素（可选）",
              ],
            "EditorSetting|You'll receive an email at this address when a visitor submits this form.":
              ["当访客提交表单后，此邮箱将收到一封邮件提醒。"],
            "Editor|%{articlesNum} related article will link to this article.":
              ["%{articlesNum}篇相关文章将链接到本文。"],
            "Editor|%{articlesNum} related articles will link to this article.":
              ["%{articlesNum}篇相关文章将链接到本文。"],
            "Editor|%{count} item altered": ["%{count} 个项目变更"],
            "Editor|%{count} items altered": ["%{count} 个项目变更"],
            "Editor|%{names} and %{number} more": [
              "%{names} 和其余 %{number} 个",
            ],
            "Editor|%{name} is currently editing %{postTitle}. Their unsaved changes may be lost if you start editing! If you'd like to edit this post, please ask your teammate to exit first.":
              [
                "%{name}正在编辑《%{postTitle}》，如果你开始编辑，他们未保存的更改可能会丢失！如果你想编辑这篇文章，请先让你的团队成员退出编辑。",
              ],
            "Editor|%{pageNum} page selected.": ["%{pageNum}页已被选中。"],
            "Editor|%{pageNum} pages selected.": ["%{pageNum} 页已被选中。"],
            "Editor|%{var1} / %{var2} site storage used": [
              "%{var1} / %{var2} 已用网站容量",
            ],
            "Editor|%{var1} characters max": ["最多 %{var1} 个字符"],
            "Editor|%{var1} discount": ["%{var1} 折扣"],
            "Editor|%{var1} has been successfully cloned. You can now manually translate the site.":
              ["已成功复制%{var1}。你现在可以手动翻译新的网站。"],
            "Editor|%{var1} has been successfully translated into %{var2}! This new site is still unpublished. Please review its content before publishing.":
              [
                "已成功将%{var1}自动翻译出%{var2}版本！新网站还没有发布。请在发布前查阅其内容。",
              ],
            "Editor|%{var1} hour": ["%{var1} 小时"],
            "Editor|%{var1} hours": ["%{var1} 小时"],
            "Editor|%{var1} images": ["%{var1}张图片"],
            "Editor|%{var1} images max to upload": ["最多上传 %{var1} 张图片"],
            "Editor|%{var1} is already connected and you can already take credit/debit card payments on your site.":
              ["%{var1}已经绑定为你网站的银行卡收款方式。"],
            "Editor|%{var1} minutes": ["%{var1} 分钟"],
            "Editor|%{var1} product(s) selected": ["已选中%{var1}个商品"],
            "Editor|%{var1} tier(s) selected": ["已选中%{var1}个等级"],
            "Editor|%{var1}/%{var2} completed": ["%{var1}/%{var2} 已完成"],
            "Editor|& much, much more!": ["以及一大波这里列不下的功能！"],
            "Editor|(Current)": ["(目前效果)"],
            "Editor|(Default)": ["（默认）"],
            "Editor|(If your domain has not yet been filed, please complete the filing first.)":
              ["（如果你的域名还未备案，请先完成备案。）"],
            "Editor|(Samples will be removed after you add your own events)": [
              "(在你添加自己的服务后，示例服务将被移除)",
            ],
            "Editor|(Samples will be removed after you add your own items)": [
              "(在你添加自己的展示项目后，示例项目将被移除)",
            ],
            "Editor|(Samples will be removed after you add your own posts)": [
              "(在你添加自己的博客文章后，示例文章将被移除)",
            ],
            "Editor|(Samples will be removed after you add your own products)":
              ["(在你添加自己的商品后，示例商品将被移除)"],
            "Editor|(all sites).": ["所有网站"],
            "Editor|(default)": ["（默认）"],
            "Editor|1-on-1": ["1对1"],
            "Editor|A 6-digit verification code has been sent to %{var1}. Please check your inbox and input the code here.":
              [
                "六位数验证码已发送至%{var1}。请查看验证邮件，在此处输入验证码。",
              ],
            "Editor|A 6-digit verification code will shortly be sent to the applicant’s email address %{var1}. Please check the verification email and put the code here.":
              [
                "一个六位数的验证码将很快发送到申请人的%{var1}邮箱中。请查看验证邮件，然后在此处输入验证码。",
              ],
            "Editor|A big button to an external link.": [
              "指向外部链接的大按钮。",
            ],
            "Editor|A custom description for SEO and sharing. Keep it short!": [
              "添加自定义描述来优化SEO和分享内容。尽量保持简洁哦！",
            ],
            "Editor|A description or instruction for this field": [
              "一段对这项字段的描述或指导",
            ],
            "Editor|A dropdown is a container! Drag pages & links into this dropdown.":
              [
                "下拉菜单是个集合！你可以将页面和链接拖到这个下拉菜单里成为子页面",
              ],
            "Editor|A list of small icons. Good for social media.": [
              "添加一排社交媒体图标",
            ],
            "Editor|A logo for Business Name": ["适用于企业名称的Logo"],
            "Editor|A numbered list of steps. Explain how your service works!":
              ["用带编号的步骤，向用户解释你的服务流程！"],
            "Editor|A pop-up window will only appears once in each visit session. You can select multiple pages, and visitors will see the pop-up window only on the page which is visited first among these selected pages.":
              [
                "弹窗在每次网站访问中只出现一次。您可以选择多个页面，在这些页面中，访问者仅会在他们最先浏览的页面上看到弹窗。",
              ],
            "Editor|A sentence or two describing this item. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.":
              [
                "简介你的项目或成员。夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。",
              ],
            "Editor|A short message to prompt your visitors, e.g. Members Only Section!":
              ["简要提醒访客网站用途。例如：仅限会员浏览！"],
            "Editor|A small tagline": ["小标语"],
            "Editor|A specific keyword that your post aims to rank for in search engine results pages.":
              [
                "你的文章将围绕这个关键词撰写，争取在这个词的搜索引擎结果页面中获得高排名。",
              ],
            "Editor|A subscription plan is required for Logo, so that you can experience all the features in your new site. You will be billed $%{discountPrice} for the plan and $%{originalPrice} per %{planTime} after that.":
              [
                "使用Logo需要订阅套餐，以便你在新网站中体验所有功能。你将被收取 %{discountPrice} 的套餐费用，之后每 %{planTime} 收取 $%{originalPrice}。",
              ],
            "Editor|A subscription plan is required for Logo, so that you can experience all the features in your new site. You will be billed $%{originalPrice} per %{planTime} for the plan.":
              [
                "使用Logo需要订阅套餐，以便你在新网站中体验所有功能。你将被收取 %{originalPrice} 每 %{planTime} 的套餐费用。",
              ],
            "Editor|A subscription plan is required for Logo. You are now in a 14-day free trial. Starting %{paymentDate}, You will be billed $%{originalPrice} per %{planTime} for the plan.":
              [
                "使用Logo需要订阅套餐。你现在处于14天免费试用期。从 %{paymentDate} 开始，你将被收取 %{originalPrice} 每 %{planTime} 的套餐费用。",
              ],
            "Editor|A subscription plan is required for Logo. You are now in a 14-day free trial. Starting %{paymentDate}, you will be billed $%{discountPrice} for the plan and $%{originalPrice} per %{planTime} after that.":
              [
                "使用Logo需要订阅套餐。你现在处于14天免费试用期。从 %{paymentDate} 开始，你将被收取 %{discountPrice} 的套餐费用，之后每 %{planTime} 收取 $%{originalPrice}。",
              ],
            "Editor|A verified owner is someone who proves they own a site by adding a verification token to it. If you remove their ownership here, we'll remove their verification token to unverify them.":
              [
                "已验证的拥有者是通过向网站添加验证令牌来证明他们拥有网站的人。如果你在此处移除他们的拥有者权限，我们将同时删除他们的验证令牌以取消验证。",
              ],
            "Editor|ADD A LINK": ["添加链接"],
            "Editor|AI Edit": ["AI编辑"],
            "Editor|AI Logo Maker": ["AI Logo生成器"],
            "Editor|AI Site Builder - Basic Info": ["AI网站生成器 - 基本信息"],
            "Editor|AI Site Builder - Content Settings": [
              "AI网站生成器 - 内容设置",
            ],
            "Editor|AI Site Builder Feedback:": ["AI网站生成器反馈："],
            "Editor|AUTO-TRANSLATION COMPLETED": ["自动翻译成功"],
            "Editor|Abandoned Cart": ["弃置购物车"],
            "Editor|Abandoned Cart Recovery": ["弃置购物车挽回"],
            "Editor|Abandons a shopping cart": ["弃置购物车"],
            "Editor|Accent Dark": ["品牌主色"],
            "Editor|Accent Light": ["品牌浅色"],
            "Editor|Accepted file types:": ["支持文件类型："],
            "Editor|Accepted file types: txt, pdf, doc, xls, ppt, pages, key, numbers, wps, jpg, png, gif, mp3, mp4, wav, flac, m4a, docx, xlsx, pptx, odt, odp, epub, zip, zipx, 7z, rar":
              [
                "支持文件类型：txt, pdf, doc, xls, ppt, pages, key, numbers, wps, jpg, png, gif, mp3, mp4, wav, flac, m4a, docx, xlsx, pptx, odt, odp, epub, zip, zipx, 7z, rar",
              ],
            "Editor|Activate": ["启用"],
            "Editor|Activate Live Chat": ["开启在线聊天"],
            "Editor|Activate Multiple Pages": ["开启多页面网站"],
            "Editor|Activating": ["开启中"],
            "Editor|Active": ["生效中"],
            "Editor|Add %{articlesNum} link into related posts": [
              "在相关文章中添加%{articlesNum}个链接",
            ],
            "Editor|Add %{linksNum} link into this post": [
              "在本文中添加%{linksNum}个链接",
            ],
            "Editor|Add %{linksNum} links into this post": [
              "在本文中添加%{linksNum}个链接",
            ],
            "Editor|Add Another Page": ["添加多页面"],
            "Editor|Add Button": ["添加按钮"],
            "Editor|Add Contact Info": ["添加联系方式"],
            "Editor|Add Content": ["添加内容"],
            "Editor|Add Content Below": ["在下方添加内容"],
            "Editor|Add Custom Commands": ["添加自定义指令"],
            "Editor|Add Date": ["添加日期"],
            "Editor|Add Dropdown Menu": ["添加下拉菜单"],
            "Editor|Add Element": ["增加元素"],
            "Editor|Add Element Block": ["增加元素组合"],
            "Editor|Add Event Type": ["添加服务类型"],
            "Editor|Add Events": ["添加服务"],
            "Editor|Add Field": ["添加字段"],
            "Editor|Add Image Alt Text": ["添加图片描述文字"],
            "Editor|Add Images": ["添加图片"],
            "Editor|Add Item": ["添加项目"],
            "Editor|Add Links Into Related Posts": ["在相关文章中添加链接"],
            "Editor|Add Live Chat Collaborators": ["添加在线聊天的协作队员"],
            "Editor|Add Logo": ["添加Logo"],
            "Editor|Add Logo Image": ["添加Logo图片"],
            "Editor|Add Map": ["添加地址"],
            "Editor|Add More Content": ["添加内容"],
            "Editor|Add New Language": ["添加新语言"],
            "Editor|Add New Page": ["添加新页面"],
            "Editor|Add New Section": ["添加新版块"],
            "Editor|Add Option": ["添加选项"],
            "Editor|Add Page": ["添加页面"],
            "Editor|Add Store Section": ["添加商店板块"],
            "Editor|Add Text": ["添加文本"],
            "Editor|Add Videos": ["添加视频"],
            "Editor|Add Your Event Type": ["添加服务类型"],
            "Editor|Add Your First Product": ["添加第一个商品"],
            "Editor|Add a DNS record for DKIM authentication to improve your email delivery rate.":
              ["添加DNS记录以完成DKIM身份验证，从而提高你的邮件送达率。"],
            "Editor|Add a Store section to your site & start taking payments! You'll be able to add products, set shipping options, set coupons, and much more!":
              [
                "为你的网站添加商店版块，日进斗金吧！你可以添加商品、设置邮费、创建优惠券，以及更多功能等你发现！",
              ],
            "Editor|Add a Store section to your site & start taking payments! You’ll be able to add products, set shipping options, set coupons, and much more! We’ll bring back the products and settings you had before.":
              [
                "为你的网站添加商店版块，日进斗金吧！你可以添加商品，设置公告，创建优惠券，以及更多功能等你发现！添加后我们将恢复你之前创建的商品、设置信息。",
              ],
            "Editor|Add a blog section to make your blog visible in your site!":
              ["给你的网站添加一个简易博客版块来展示你的博客文章！"],
            "Editor|Add a button.": ["添加按钮"],
            "Editor|Add a logo or video.": ["添加 logo 或视频"],
            "Editor|Add a slide using the Slider controls.": [
              "使用滑块控制面板来添加滑块。",
            ],
            "Editor|Add alt text for each image": ["添加图片描述文字"],
            "Editor|Add alt text here": ["在这里添加描述文字"],
            "Editor|Add an auto-responder": ["添加自动回复"],
            "Editor|Add an event and set your availability": [
              "添加服务并设置可预约时间",
            ],
            "Editor|Add and update more sections!": ["添加 & 探索更多版块!"],
            "Editor|Add answer.": ["添加回答。"],
            "Editor|Add details and descriptions to each product.": [
              "为每个产品添加详情和描述。",
            ],
            "Editor|Add dropdown menus to organize pages and links.": [
              "添加下拉菜单来整理页面和链接。",
            ],
            "Editor|Add e-commerce to your site!": ["为网站添加商店板块!"],
            "Editor|Add elements": ["添加更多组件"],
            "Editor|Add event description, keep it short and sweet! (Optional)":
              ["简单描述下预约内容吧。（选填）"],
            "Editor|Add image": ["添加图片"],
            "Editor|Add image description (optional)": ["添加图片描述（选填）"],
            "Editor|Add image title (optional)": ["添加图片标题（选填）"],
            "Editor|Add image.": ["添加图片"],
            "Editor|Add image/video.": ["添加图片或视频"],
            "Editor|Add multiple pages": ["添加多个网站页面"],
            "Editor|Add new content here": ["在这里添加新内容"],
            "Editor|Add new item": ["添加展示项目"],
            "Editor|Add new physical address": ["添加新的实体地址"],
            "Editor|Add new recipient": ["添加收件人"],
            "Editor|Add new region options": ["添加地区选项"],
            "Editor|Add new verified owner": ["添加新的已验证的拥有者"],
            "Editor|Add paragraph text here.": ["在此处添加文本段落"],
            "Editor|Add product": ["添加商品"],
            "Editor|Add question.": ["添加问题。"],
            "Editor|Add section": ["添加版块"],
            "Editor|Add subtitle.": ["添加副标题"],
            "Editor|Add text.": ["添加文本"],
            "Editor|Add title": ["添加标题"],
            "Editor|Add title here.": ["在此处添加标题"],
            "Editor|Add title.": ["添加标题"],
            "Editor|Add up to %{maxPages} pages on a single site.": [
              "您可以在一个网站上添加最多 %{maxPages}个页面",
            ],
            "Editor|Add video.": ["添加视频"],
            "Editor|Add your address": ["填写你的地址"],
            "Editor|Add your email": ["填写你的地址"],
            "Editor|Add your phone number": ["填写你的电话号码"],
            "Editor|Add your service! You can set up appointments, courses, trainings, parties, concerts, and more.":
              [
                "添加一项服务吧！你可以配置课程、培训、派对、音乐会等服务预约。",
              ],
            "Editor|Add/remove/rename pages and links": [
              "添加／删除／重命名页面及链接",
            ],
            "Editor|Adding Multiple Products is a Pro feature": [
              "销售多款商品属于专业版功能",
            ],
            "Editor|Adding Page...": ["正在添加页面..."],
            "Editor|Address": ["地址"],
            "Editor|Adjust image corner radius": ["调整图片圆角弧度"],
            "Editor|Adjust image size to cover the space": [
              "调整图像大小以覆盖空间",
            ],
            "Editor|Adjust layout for mobile": ["调整手机端布局"],
            "Editor|Advanced": ["高级功能"],
            "Editor|Advanced options": ["高级选项"],
            "Editor|Advanced showcase for creative. Each item has more details":
              ["创意的高级展示。每个项目有更多细节"],
            "Editor|Advanced showcase for products, without e-commerce": [
              "产品的高级展示，无电子商务",
            ],
            "Editor|After expiration, you need to register this Mini Program again to continue the experience":
              ["过期后，你需重新注册该小程序才能继续体验"],
            "Editor|Agent First Name": ["客服昵称"],
            "Editor|Agent Profile Image": ["客服头像"],
            "Editor|Alignment": ["对齐方式"],
            "Editor|Aliyun": ["阿里云"],
            "Editor|All": ["全部"],
            "Editor|All Set! Import to Blog Editor": [
              "全部完成！导入博客编辑器",
            ],
            "Editor|All common file types accepted": ["支持所有通用文件格式"],
            "Editor|All fonts list": ["所有字体列表"],
            "Editor|All images": ["所有图片"],
            "Editor|All logos": ["所有Logo"],
            "Editor|All sizes": ["所有尺寸"],
            "Editor|Almost done! Select a list where form submissions will be sent to.":
              ["马上就好！请选择期望接收表单的粉丝列表。"],
            "Editor|Already own a domain? [link:Click here to connect]": [
              "已经拥有一个域名？[link:点击此处去绑定]",
            ],
            "Editor|Alt Tag": ["图片描述文字"],
            "Editor|Alternating": ["图文交替"],
            "Editor|Always display shopping cart icon?": ["显示购物车图标？"],
            "Editor|Always show a shopping cart icon in header, even when the visitor's cart is empty.":
              ["购物车图标在网站顶部常驻显示（购物车为空时仍然显示）。"],
            "Editor|An advanced portfolio where each item has its own page with more details.":
              ["配备独立详情页，详细介绍产品特点。"],
            "Editor|An error occurred, please try again later. If the issue recurs, please contact our customer service.":
              ["发生错误，请稍后重试。若问题再次出现，请联系我们的客服。"],
            "Editor|And much, much more!": ["更多功能等你探索"],
            "Editor|Any form": ["任何表单"],
            "Editor|Any new member of the selected tier(s) will receive this email (in addition to the membership notifications).":
              [
                "每位注册该等级的新会员都将收到这封邮件（此外，会员通知仍会正常发送）。",
              ],
            "Editor|Any product": ["任何商品"],
            "Editor|Any tier": ["任何会员等级"],
            "Editor|Anyone who becomes a member will receive this email (in addition to the membership notifications).":
              [
                "每位新注册的会员都将收到这封邮件（此外，会员通知仍会正常发送）。",
              ],
            "Editor|Anyone who has added items into their cart but has not yet purchased will receive this email.":
              [
                "每位添加商品至购物车后长时间未完成结账的顾客都将收到这封邮件。",
              ],
            "Editor|Anyone who purchases a product will receive this email (in addition to the order notifications).":
              [
                "每位下单的用户都将收到这封邮件（此外，订单通知仍会正常发送）。",
              ],
            "Editor|Anyone who purchases the selected product(s) will receive this email (in addition to the order notifications).":
              [
                "每位下单该商品的用户都将收到这封邮件（此外，订单通知仍会正常发送）。",
              ],
            "Editor|Anyone who submits a form with an email address will receive this email.":
              ["每位提交邮箱地址的用户都会收到这封邮件。"],
            "Editor|Anyone who subscribes to the blog on this site will receive this email.":
              ["每位新的博客订阅人都将收到这封邮件。"],
            "Editor|App Store": ["应用商店"],
            "Editor|App Store & HTML": ["应用商店及 HTML 代码"],
            "Editor|Appears in search results and the browser's title bar. If empty, we'll use '%{title} - %{siteTitle}'":
              [
                "显示在搜索结果中和浏览器的标题栏。如此项为空，则显示为'%{title} - %{siteTitle}'",
              ],
            "Editor|Are you absolutely sure you want to delete these region options? This action cannot be undone!":
              ["你确定要删除这些地区选项吗？此操作无法撤消！"],
            "Editor|Are you absolutely sure you want to delete this file? This action cannot be undone, and the file will be deleted forever!":
              ["你确定要删除这个文件吗？此操作不可撤回，文件将会被永久删除！"],
            "Editor|Are you absolutely sure you want to delete this file? This file is sent by visitor, it will be deleted forever.":
              [
                "你确定要删除这个文件吗？（该文件是访客发送的内容）文件将会被永久删除！",
              ],
            "Editor|Are you absolutely sure you want to delete this logo? This action cannot be undone!":
              ["你确定要删除此Logo吗？ 此操作无法撤消！"],
            "Editor|Are you absolutely sure you want to disable reCAPTCHA? This may allow spammers and bots to submit information on your site! We strongly recommend keeping this setting active.":
              [
                "你真的确定要禁用人机验证吗？这可能会让垃圾信息发送者和机器人在你的网站上提交信息！我们强烈建议将此设置保持开启。",
              ],
            "Editor|Are you absolutely sure you want to regenerate this entire site structure? This current site structure will be lost.":
              ["你确定要重新生成整个网站结构吗？当前的网站结构将会丢失。"],
            "Editor|Are you absolutely sure you want to reset this section? You may lose any content you’ve added!":
              ["你确定要重置此版块吗？你之前增添的内容可能会丢失！"],
            "Editor|Are you sure you want to delete %{var1} selected images?": [
              "确定要删除已选中的 %{var1} 张图片么？",
            ],
            "Editor|Are you sure you want to delete this element?": [
              "你确定要删除这个元素吗？",
            ],
            "Editor|Are you sure you want to delete this entire section?": [
              "你确定要删除这整个板块吗？",
            ],
            "Editor|Are you sure you want to delete this event type?": [
              "你确定要删除这个服务类型吗？",
            ],
            "Editor|Are you sure you want to delete this field? (Existing responses for this field will still be kept.)":
              ["你确定要删除这个字段吗？（这个字段的已有回复将会继续保留）"],
            "Editor|Are you sure you want to delete this file?": [
              "你确定要删除这个文件吗？",
            ],
            "Editor|Are you sure you want to delete this headline? You can't undo this action.":
              ["你确定要删除这条段落标题吗？该操作无法撤销。"],
            "Editor|Are you sure you want to delete this item rule?": [
              "你确定要删除这条项目规则吗？",
            ],
            "Editor|Are you sure you want to delete this post? All keyword links in other related posts will be removed. This action cannot be undone.":
              [
                "你确定要删除此文章吗？所有相关文章中的关键词链接将被删除。此操作无法撤消。",
              ],
            "Editor|Are you sure you want to delete this section?": [
              "你确定要删除这个板块吗？",
            ],
            "Editor|Are you sure you want to delete this subheading? You can't undo this action.":
              ["你确定要删除这条段落小节标题吗？该操作无法撤销。"],
            "Editor|Are you sure you want to delete whole section? You can't undo this action.":
              ["你确定要删除整个章节吗？该操作无法撤销。"],
            "Editor|Are you sure you want to disconnect this domain? Your site will no longer be visible at %{domain}":
              ["您确定要解绑此域名吗？您的网站将无法通过%{domain}访问"],
            "Editor|Are you sure you want to disconnect? This form will no longer be submitted to Mailchimp.":
              ["确定要取消连接吗？该表单数据将不再同步发送给Mailchimp。"],
            "Editor|Are you sure you want to hide this section? Hidden sections will not appear on your live site!":
              [
                "请确定你是否需要隐藏这个版块？隐藏的版块不会在你发布后的网站出现。",
              ],
            "Editor|Are you sure you want to reduce the number of grid items? Some grid items will be deleted.":
              ["您确定要减少网格数量吗？ 某些网格项目将被删除。"],
            "Editor|Are you sure you want to regenerate the entire outline?": [
              "你确定要重新生成整个大纲吗？",
            ],
            "Editor|Are you sure you want to remove a column? The last two columns will be merged.":
              ["你确定要删除这列吗？剩下的2列会被合并。"],
            "Editor|Are you sure you want to remove the Bookings section from your site? All of your events and settings will be kept. Just add the section back to bring them back!":
              [
                "确定要移除预约版块吗？所有预约服务和设置数据将被保留，你未来可以重新添加预约版块再启用。",
              ],
            "Editor|Are you sure you want to remove this image from the article? The image will be saved in Uploaded Images to reuse elsewhere.":
              [
                "你确定要从文章中移除此图片吗？图片将保存在已上传的图片中，以便你在其他地方再使用。",
              ],
            "Editor|Are you sure you want to remove this item from your gallery? This change will update your live site immediately.":
              ["你确定要移除吗？移除后将你的网站内容会即时更新。"],
            "Editor|Are you sure you want to remove this upload?": [
              "你确定要删除此上传内容吗？",
            ],
            "Editor|Are you sure you want to remove this upload? You'll have to upload the ZIP file again if you want to use custom images.":
              [
                "你确定要删除此上传内容吗？如果你想使用自定义图片，将必须再次上传ZIP文件。",
              ],
            "Editor|Are you sure you want to remove this verified owner? After removing, %{var1} (%{var2}) won't have access to site data until they are re-added as an user or a verified owner.":
              [
                "你确定要删除此已验证的拥有者吗？删除后，%{var1}（%{var2}）将无法访问数据，直到他们被重新添加为用户或已验证的拥有者。",
              ],
            "Editor|Are you sure you want to restore this version?": [
              "你确定要恢复到这个版本吗？",
            ],
            "Editor|Are you sure you want to set this site's language to Arabic? All site content will switch to RTL (right-to-Left) layout.":
              [
                "您确定要将此网站的语言设置为阿拉伯语吗？ 所有网站内容将切换为 RTL（从右到左）布局。",
              ],
            "Editor|Are you sure you want to show this section only on desktop?":
              ["您确定只想在PC端上显示此部分吗？"],
            "Editor|Are you sure you want to show this section only on mobile?":
              ["您确定只想在移动设备上显示这一部分吗？"],
            "Editor|Are you sure you want to show this section? Remember to publish your site to make this section visible to the world!":
              ["请确定你是否要取消隐藏这个版块？记得要发布你的网站使其生效！"],
            "Editor|Are you sure you want to take over in this editor? Unsaved changes in other editors will be lost.":
              [
                "你确定你想要在这个编辑器中接手网站吗？其他编辑器中未被保存的更改将会丢失。",
              ],
            "Editor|Are you sure you want to try the Site Membership feature? Your published site won't be able to register new members until you upgrade your account, but you'll be able to see how Membership works.":
              [
                "您确定要试用网站会员功能吗？ 在您升级帐户之前，您发布的网站将无法注册新会员，但您将能够看到会员资格的运作方式。",
              ],
            "Editor|Are you sure you want to unpublish this post? All keyword links in other related posts will be removed. (They can be added back when you republish.)":
              [
                "你确定要撤销发布此文章吗？所有相关文章中的关键词链接将被删除。(你可以在重新发布时把它们添加回来。)",
              ],
            'Editor|Are you sure you wish to delete the "%{title}" dropdown? All your pages will be kept!':
              ['是否确定删除下拉菜单"%{title}"？你的所有页面仍会被保留！'],
            'Editor|Are you sure you wish to delete the "%{title}" page? ALL PAGE CONTENT WILL BE REMOVED.':
              ['确定删除 "%{title}" 这个页面吗？所有页面内容将会被删除'],
            'Editor|Are you sure you wish to duplicate the "%{title}" page? ALL PAGE CONTENT WILL BE DUPLICATED.':
              ['你确定要复制 "%{title}" 页吗？页面内的所有内容都将被复制。'],
            "Editor|Are you sure you wish to switch back to the old version of the editor menu?":
              ["你确定要切换回旧版编辑器吗？"],
            "Editor|Arrow": ["箭头"],
            "Editor|As a %{plan} user, you can add up to %{product_sell_limit} items.":
              [
                "作为%{plan}用户，你最多可以添加%{product_sell_limit} 个展示项目。",
              ],
            "Editor|As a %{plan} user, you can add up to 1 item.": [
              "作为%{plan}用户，你最多可以添加1个展示项目。",
            ],
            "Editor|As a %{plan} user, you can sell up to %{product_sell_limit} products.":
              ["作为%{plan}用户，你最多可以销售%{product_sell_limit}件商品。"],
            "Editor|As a %{plan} user, you can sell up to %{product_sell_limit} products. Upgrade to VIP to sell unlimited products.":
              [
                "作为%{plan}用户，你最多可以销售%{product_sell_limit}件商品。升级到VIP以销售无限数量的商品。",
              ],
            "Editor|As a %{plan} user, you can sell up to %{product_sell_limit} products. You can add more products to set up your store, but visitors will not be able to add them to cart.":
              [
                "作为%{plan}用户，你最多可以销售%{product_sell_limit}件商品。你可以继续添加商品并设置你的商店，但是访问者将无法将其添加到购物车。",
              ],
            "Editor|As a %{plan} user, you can sell up to 1 product.": [
              "作为%{plan}用户，你最多可以销售1件商品。",
            ],
            "Editor|As a %{plan} user, you can sell up to 1 product. Upgrade to VIP to sell unlimited products.":
              [
                "作为%{plan}用户，你最多可以销售1件商品。升级到VIP以销售无限数量的商品。",
              ],
            "Editor|As a %{plan} user, you can sell up to 1 product. You can add more products to set up your store, but visitors will not be able to add them to cart.":
              [
                "作为%{plan}用户，你最多可以销售1件商品。你可以继续添加商品并设置你的商店，但是访问者将无法将其添加到购物车。",
              ],
            "Editor|As a Pro user, you can add up to 1 tier membership. Upgrade to VIP to add more tiers.":
              [
                "作为专业版用户，你最多可以添加1个会员等级。升级至VIP套餐解锁多个会员等级",
              ],
            "Editor|Attendee": ["参与者"],
            "Editor|Attendees": ["参与者"],
            "Editor|Audience": ["粉丝运营"],
            "Editor|Audio": ["音频"],
            "Editor|Authenticate Domain": ["验证邮件域名"],
            "Editor|Authenticate Email Domain": ["验证邮箱域名"],
            "Editor|Authenticate Your Domain": ["验证你的邮件域名"],
            "Editor|Auto": ["自动"],
            "Editor|Auto-responder is active. Click to edit.": [
              "自动回复生效中。点击这里编辑。",
            ],
            "Editor|Auto-responder is inactive. Click to edit.": [
              "自动回复未生效。点击这里编辑。",
            ],
            "Editor|Auto-responder requires an email field.": [
              "设置自动回复表单必须填写邮箱。",
            ],
            "Editor|Automatically send an email to a visitor who submits this form.":
              ["向提交表单的访客自动发送一封邮件"],
            "Editor|Automatically send this form’s responses to an external service.":
              ["访客提交的表单将同步发送给第三方服务商。"],
            "Editor|Automatically translate the current site into a new language (powered by Google Translate)":
              ["自动翻译当前网站为新的语言（由谷歌翻译支持）"],
            "Editor|Availability": ["可预约时间"],
            "Editor|Away Message": ["离线消息"],
            "Editor|Back": ["返回"],
            "Editor|Back to Editor": ["返回编辑器"],
            "Editor|Back to Preview": ["返回预览"],
            "Editor|Back to Site Design": ["返回至网站设计"],
            "Editor|Back to preset": ["返回预设"],
            "Editor|Back to select a new template": ["返回至选择新的模板"],
            "Editor|Background": ["背景颜色"],
            "Editor|Background Color": ["背景色"],
            "Editor|Basic Element": ["基础组件"],
            'Editor|Be sure to modify the name of the Mini Program and remove the suffix "Trial Version"!':
              ["请务必修改小程序名称，把后缀”的试用小程序“去除！"],
            "Editor|Becomes a member": ["成为会员"],
            "Editor|Becomes a member of": ["成为会员"],
            "Editor|Big Arrow": ["大箭头型"],
            "Editor|Big Media": ["大尺寸媒体"],
            "Editor|Billing ZIP/Postal": ["账单邮政编码"],
            "Editor|Black Minimal": ["黑色简约"],
            "Editor|Block": ["区块"],
            "Editor|Block & Structure": ["组件块 & 结构"],
            "Editor|Block Background": ["区块背景"],
            "Editor|Block Shape": ["区块形状"],
            "Editor|Block Text": ["区块文字"],
            "Editor|Block disposable emails": ["阻止一次性邮箱"],
            "Editor|Blog": ["博客"],
            "Editor|Blog Categories": ["博客分类"],
            "Editor|Blog posts": ["博客文章"],
            "Editor|Body": ["正文"],
            "Editor|Bold": ["大胆"],
            "Editor|Book Now": ["立刻预约"],
            "Editor|Booking": ["预约活动"],
            "Editor|Booking ID": ["预约 ID"],
            "Editor|Booking accepted": ["已接受预约"],
            "Editor|Booking cancelled": ["已取消预约"],
            "Editor|Booking confirmed": ["已确认预约"],
            "Editor|Bookings": ["服务预约"],
            "Editor|Border": ["边框"],
            "Editor|Border & Card": ["边框&卡片"],
            "Editor|Border & card settings": ["边框&卡片设置"],
            "Editor|Border Color": ["边框颜色"],
            "Editor|Bottom": ["底部"],
            "Editor|Bottom Center": ["底部居中"],
            "Editor|Bottom Left": ["底部居左"],
            "Editor|Bottom Right": ["底部居右"],
            "Editor|Bottom Space": ["下边距"],
            "Editor|Bottom only": ["仅底部"],
            "Editor|Browse": ["浏览"],
            "Editor|Build a logo & brand in minutes": [
              "在几分钟内构建Logo和品牌",
            ],
            "Editor|Build your audience by collecting signups, forms, and customers on this site.":
              ["通过在网站上收集注册、表单和顾客来建立你的粉丝列表。"],
            "Editor|Business Description": ["企业描述"],
            "Editor|Business/Organization Description": ["业务/组织介绍"],
            "Editor|Button": ["按钮"],
            "Editor|Button size": ["按钮大小"],
            "Editor|Button style": ["按钮风格"],
            "Editor|Buttons": ["按钮"],
            "Editor|Can't find a good image? [link: Update the description] and search for more.":
              ["找不到你想要的图片？[link: 更新图片描述]可以搜索更多图片。"],
            "Editor|Can't find a good logo? Change the description and regenerate.":
              ["找不到合适的Logo？更改描述并重新生成。"],
            "Editor|Can't find a good palette? [link:Customize the colors.]": [
              "找不到合适的配色？[link:自定义颜色吧。]",
            ],
            "Editor|Can't send emails due to domain authentication failure. [link:View details].":
              ["由于域名认证失败，无法发送电子邮件。[link:查看详情]。"],
            "Editor|Cancel": ["取消"],
            "Editor|Cancel Generation": ["取消生成"],
            "Editor|Cancel generation": ["取消生成"],
            "Editor|Capacity": ["容纳人数"],
            "Editor|Capitalize": ["首字母大写"],
            "Editor|Card": ["卡片"],
            "Editor|Card Number": ["卡号"],
            "Editor|Cart": ["购物车"],
            "Editor|Casual": ["轻松"],
            "Editor|Categories failed to load.": ["类型加载失败"],
            "Editor|Center": ["居中"],
            "Editor|Center Left": ["中部居左"],
            "Editor|Center Right": ["中部居右"],
            "Editor|Centered": ["居中"],
            "Editor|Change": ["修改"],
            "Editor|Change Fonts": ["更改字体"],
            "Editor|Change Password step %{var1}/3": [
              "修改密码（第%{var1}步，共3步）",
            ],
            "Editor|Change Style": ["更改风格"],
            "Editor|Change Template": ["更改模板"],
            "Editor|Change URL": ["更改网址"],
            "Editor|Change page URL": ["更改网址"],
            "Editor|Change template": ["更改模板"],
            "Editor|Change text background color": ["更改文本背景颜色"],
            "Editor|Change theme": ["更改主题"],
            "Editor|Changes are auto-saved.": ["网站编辑将自动保存"],
            "Editor|Changes are auto-saved. ": ["网站编辑将自动保存"],
            "Editor|Check out this awesome website.": ["瞧瞧这个网站"],
            'Editor|Check the application message sent by the "Public Platform Security Assistant", and please complete the certification within 24 hours (the legal person’s face certification and the Mini Program administrator’s confirmation are both required and indispensable)':
              [
                "微信查收「公众平台安全助手」发来的创建申请，请于24小时内完成认证（需法人本人人脸认证和小程序管理员授权确认两个环节，缺一不可）",
              ],
            "Editor|Check your keyword for typos.": [
              "检查关键词是否有错别字。",
            ],
            "Editor|Checkbox": ["多选"],
            "Editor|Checking": ["检查中"],
            "Editor|Cheers! \nBooking Scheduling Bot": ["感谢！ \n预约管家"],
            "Editor|Choose A Domain": ["选择域名"],
            "Editor|Choose a perfect domain for your site!": [
              "为你的网站选择一个独特的域名！",
            ],
            "Editor|Choose from existing addresses": ["从已有地址中选择"],
            "Editor|Circle Icon": ["圆形图标"],
            "Editor|Classic": ["经典"],
            "Editor|Click any text, image, or button on the site to edit. All changes are auto-saved.":
              [
                "点击网站内任意文本、图片、按钮即可进行编辑。我们会自动保存你的编辑操作。",
              ],
            "Editor|Click here to add events!": ["点击这里添加服务!"],
            "Editor|Click here to add your own events!": [
              "点击此处添加你的服务！",
            ],
            "Editor|Click here to add your own posts!": [
              "点击此处添加你的博客文章！",
            ],
            "Editor|Click here to add your own products!": [
              "点击此处添加你的商品！",
            ],
            "Editor|Click here to manage pages": ["点击管理页面"],
            "Editor|Click this button to edit sections and add elements to your site.":
              ["点击此按钮进行编辑版块，给网站添加更多元素。"],
            "Editor|Click to change layouts": ["点击更改布局"],
            "Editor|Click to continue generating": ["点击继续完成"],
            "Editor|Click to retry": ["点击重试"],
            "Editor|Click to select, drag to reorder.": [
              "选择请点击，排序请拖拽",
            ],
            "Editor|Clickable": ["可点击"],
            "Editor|Clone completed": ["复制成功"],
            "Editor|Clone current site & auto-translate": [
              "复制当前网站并自动翻译",
            ],
            "Editor|Clone current site & manually translate": [
              "复制当前网站并手动翻译",
            ],
            "Editor|Clone failed": ["复制失败"],
            "Editor|Collaborate and edit with your team in real-time!": [
              "与你的团队实时协作编辑！",
            ],
            "Editor|Color": ["颜色"],
            "Editor|Color Scheme": ["选择样式"],
            "Editor|Color Theme": ["配色方案"],
            "Editor|Color theme": ["色彩主题"],
            "Editor|Colors": ["配色"],
            "Editor|Columns": ["纵向布局"],
            "Editor|Columns Per Row": ["每行显示列数"],
            "Editor|Compact": ["紧凑"],
            "Editor|Complete": ["完成"],
            "Editor|Completes a purchase from your store": ["在你的商店下单"],
            "Editor|Completes a purchase from your store of": [
              "在你的商店下单",
            ],
            "Editor|Confirm & Clone Current Site": ["确认并复制当前网站"],
            "Editor|Confirm & Generate Page": ["确认并生成页面"],
            "Editor|Confirm & Generate Site": ["确认并生成网站"],
            "Editor|Confirm & generate content": ["确认并生成内容"],
            "Editor|Confirm & generate site logos": ["确认并生成网站Logo"],
            "Editor|Confirm & generate site structure": ["确认并生成网站结构"],
            "Editor|Confirm & go to content settings": ["确认 & 前往内容设置"],
            "Editor|Confirm & start translation": ["确认并开始翻译"],
            "Editor|Confirm & start writing outline": ["确认并开始撰写大纲"],
            "Editor|Confirm & start writing titles": ["确认并开始生成标题"],
            "Editor|Confirm Outline": ["确认大纲"],
            "Editor|Confirm Style & Edit": ["确认风格并编辑"],
            "Editor|Confirm Your Style": ["确认你的风格"],
            "Editor|Confirm the new password": ["确认新密码"],
            "Editor|Confirm topic, let's go": ["确认主题，开始"],
            "Editor|Confirmed": ["已确认"],
            "Editor|Congratulations on successfully connecting your own domain! Don’t forget to publish your site.":
              ["恭喜你成功绑定了你的自定义域名！不要忘记发布你的网站哦。"],
            "Editor|Connect": ["绑定"],
            "Editor|Connect Custom Domain": ["绑定自定义域名"],
            "Editor|Connect Custom Domain?": ["绑定自定义域名？"],
            "Editor|Connect External Services": ["绑定第三方服务"],
            "Editor|Connect a custom domain": ["绑定自定义域名"],
            "Editor|Connect an existing URL": ["绑定一个已有网站"],
            "Editor|Connect this site to Google Search Console": [
              "连接此网站至Google Search Console",
            ],
            "Editor|Connect to Google": ["连接至Google"],
            "Editor|Connect your account": ["点击进行绑定"],
            "Editor|Connected": ["已连接"],
            "Editor|Connected as %{var}": ["账号 %{var}"],
            "Editor|Contact": ["联系我们"],
            "Editor|Contact Form": ["留言表单"],
            "Editor|Contact Info": ["联系方式"],
            "Editor|Contact Support": ["联系客服"],
            "Editor|Contact info required": ["需要联系方式"],
            "Editor|Contacts imported successfully!": ["联系人已成功导入！"],
            "Editor|Content": ["内容"],
            "Editor|Content Align": ["内容对齐"],
            "Editor|Content Alignment": ["内容对齐"],
            "Editor|Content Position": ["内容位置"],
            "Editor|Content Width": ["内容宽度"],
            "Editor|Content too long. Please reduce the length.": [
              "内容过长，请减少长度。",
            ],
            "Editor|Continue": ["继续"],
            "Editor|Continue to finalize certification info": [
              "继续完善认证信息",
            ],
            "Editor|Copied": ["已复制"],
            "Editor|Copy": ["复制"],
            "Editor|Copy Item URL": ["复制项目链接"],
            "Editor|Copy URL": ["复制链接"],
            "Editor|Core features that will be included in your site. You can always add more features later.":
              ["核心功能将被包含在你的网站中，你可以稍后再添加更多功能。"],
            "Editor|Correct": ["正确"],
            "Editor|Create New Automation": ["创建自动回复邮件"],
            "Editor|Create Your Site": ["创建网站"],
            "Editor|Create a newsletter": ["创建营销邮件"],
            "Editor|Create members-only content.": ["创建会员专属内容。"],
            "Editor|Create membership tiers and allow registrations.": [
              "创建会员等级并开放用户注册。",
            ],
            "Editor|Create new coupon": ["添加优惠券"],
            "Editor|Creative": ["创意"],
            "Editor|Creative Portfolio": ["创意作品集"],
            "Editor|Current": ["当前版本"],
            "Editor|Current Template": ["当前模版"],
            "Editor|Current saved version": ["当前编辑中版本"],
            "Editor|Current text": ["当前文本"],
            "Editor|Currently editing this Mini Program! Changes already made may be lost if you start editing at the same time. Are you sure you'd like to start editing?":
              [
                "目前正在编辑中。如果你开始编辑，他所做的更改可能会丢失。你确定要开始编辑吗？请确保已跟他进行沟通。",
              ],
            "Editor|Custom": ["自定义"],
            "Editor|Custom Color": ["自定义颜色"],
            "Editor|Custom Command (Article)": ["自定义指令（正文）"],
            "Editor|Custom Command (Outline)": ["自定义指令（大纲）"],
            "Editor|Custom Command (Title)": ["自定义指令（标题）"],
            "Editor|Custom Commands": ["自定义指令"],
            "Editor|Custom Form": ["自定义表单"],
            "Editor|Custom Forms": ["自定义表单"],
            "Editor|Custom Images (Optional)": ["自定义图像（选填）"],
            "Editor|Custom Logo Prompt": ["自定义Logo提示"],
            "Editor|Custom Logo Prompt (Optional)": ["自定义Logo提示（选填）"],
            "Editor|Custom Prompt": ["自定义提示语"],
            "Editor|Custom Prompt...": ["自定义提示语……"],
            "Editor|Custom Title Tag": ["自定义标题标签"],
            "Editor|Custom URL": ["自定义链接"],
            "Editor|Custom code only takes effect in live site and preview, not in the editor.":
              [
                "自定义代码只在发布后的网站以及预览网站中生效，不会在编辑器中生效。",
              ],
            "Editor|Custom form instructions for visitors:": [
              "给访客的自定义表单的说明：",
            ],
            "Editor|Custom form title:": ["自定义表单标题："],
            "Editor|Customize": ["自定义"],
            "Editor|Customize Domain": ["自定义域名"],
            "Editor|Customize Logo": ["自定义Logo"],
            "Editor|Customize More": ["自定义更多"],
            "Editor|Customize Your Domain": ["自定义你的域名"],
            "Editor|Customize portfolio form fields": [
              "自定义产品展示表的字段",
            ],
            "Editor|Customize selected logo": ["自定义所选Logo"],
            "Editor|Customize the automatic email": ["自定义邮件内容"],
            "Editor|Dark Overlay": ["黑色透明遮罩"],
            "Editor|Dark mode": ["暗色模式"],
            "Editor|Date Created": ["创建日期"],
            "Editor|Deactivate": ["停用"],
            "Editor|Decoration Color": ["装饰颜色"],
            "Editor|Default": ["默认"],
            "Editor|Delete": ["删除"],
            "Editor|Delete %{var1} Images": ["删除 %{var1} 张图片"],
            "Editor|Delete Entire Section": ["删除整章"],
            "Editor|Delete Image": ["移除图片"],
            "Editor|Delete Images": ["删除图片"],
            "Editor|Delete Section": ["删除版块"],
            "Editor|Delete Selected Images": ["删除选定图片"],
            "Editor|Delete this dropdown": ["删除下拉菜单"],
            "Editor|Delete this page": ["删除页面"],
            "Editor|Delete this section": ["删除该版块"],
            "Editor|Describe the image you'd like": ["描述你想要的图片"],
            "Editor|Describe the page you want": ["描述你想要的页面"],
            "Editor|Describe the section you want": ["描述你想要的版块"],
            "Editor|Describe what kind of text you want to generate…": [
              "描述你希望生成的文本类型...",
            ],
            "Editor|Describe what text you want.": ["描述你想要的文本。"],
            "Editor|Describe your business or industry in a sentence": [
              "用一句话描述你的业务或行业。",
            ],
            "Editor|Describe your specific business or industry in a sentence or two.":
              ["用一两句话描述你的特定业务或行业。"],
            "Editor|Description": ["描述"],
            "Editor|Design": ["设计"],
            "Editor|Didn't receive? Resend email": ["没有收到邮件？重新发送"],
            "Editor|Different URL for each item": ["每个项目使用不同的链接"],
            "Editor|Discard changes": ["放弃更改"],
            "Editor|Disconnect domain": ["解绑域名"],
            "Editor|Display a set of images/videos.": ["显示一组图像/视频。"],
            "Editor|Display a set of images/videos. Great for photos and portfolios.":
              ["批量展示图片/视频，适合制作相册和作品集。"],
            "Editor|Display latest posts from Instagram or Facebook.": [
              "显示来自Instagram或Facebook的最新帖子。",
            ],
            "Editor|Do you want to finalize certification and submit your Mini Program for review to fully publish it?":
              ["是否继续完成认证和审核，将小程序正式发布到线上？"],
            "Editor|Document": ["文档"],
            "Editor|Domain Settings": ["管理域名"],
            "Editor|Domains, header & footer and lots more!": [
              "域名、页眉与页脚以及更多设置！",
            ],
            "Editor|Donate button": ["捐赠按钮"],
            "Editor|Done": ["完成"],
            "Editor|Download Logo": ["下载Logo"],
            "Editor|Download Logo Package": ["下载Logo文件"],
            "Editor|Draft": ["草稿"],
            "Editor|Draft saved!": ["草稿已保存！"],
            "Editor|Drag & Drop": ["拖拽位置"],
            "Editor|Drag pages & links here!": ["将页面和链接拖至此处！"],
            "Editor|Drag to reorder": ["拖动以重新排序"],
            "Editor|Draw": ["画笔"],
            "Editor|Drop Shadow": ["投影阴影"],
            "Editor|Dropdown Menu": ["下拉菜单"],
            "Editor|Dropdown Select": ["下拉选择"],
            "Editor|Dropdown name cannot be empty": ["下拉菜单名不能为空"],
            "Editor|Due to email regulatory requirements, you must complete DKIM authentication for your email domain to prevent your emails from being marked as spammed or bouncing.":
              [
                "根据邮件监管要求，你必须为你的域名完成DKIM身份验证，以防止你的邮件被标记为垃圾邮件或被退回。",
              ],
            "Editor|Due to high user demand and usage, this processing is delayed. Please try again later. Thank you for your patience!":
              [
                "鉴于当前排队用户较多，该请求暂被延迟，请稍后再试。感谢你的耐心等待！",
              ],
            "Editor|Due to industry standards, domain names with underscores (_) cannot receive public SSL certificates, which means they can't be accessed over HTTPS. We strongly recommend using a domain name without underscores.":
              [
                "根据行业标准，带有下划线(_)的域名无法获得公共SSL证书，这意味着它们无法通过HTTPS访问。我们强烈建议使用没有下划线的域名。",
              ],
            "Editor|Duplicate": ["复制"],
            "Editor|Duplicate this page": ["复制此页"],
            "Editor|Duplicating this page will duplicate the blog section, which will show the same blog posts. You can use categories to organize your blog posts.":
              [
                "复制此页将复制博客板块，将会显示重复的文章。你可以使用分类功能来归纳文章。",
              ],
            "Editor|Duplicating this page will duplicate the store section, which will show the same products. You can use categories to organize your products.":
              [
                "复制此页将复制电商板块，将会显示重复的商品。可以使用分类功能来归纳商品。",
              ],
            "Editor|Duration": ["时长"],
            "Editor|Each page works the same way — just add any sections you want.":
              ["每个页面的使用方法是一样的，请随意添加版块"],
            "Editor|Edit": ["编辑"],
            "Editor|Edit Columns": ["编辑列"],
            "Editor|Edit Fonts": ["编辑字体"],
            "Editor|Edit Form": ["编辑表单"],
            "Editor|Edit Heading": ["编辑段落标题"],
            "Editor|Edit Logo": ["编辑Logo"],
            "Editor|Edit Logo Image": ["编辑Logo图片"],
            "Editor|Edit Page Name": ["编辑页面名称"],
            "Editor|Edit Section Name": ["编辑版块名称"],
            "Editor|Edit Site": ["编辑网站"],
            "Editor|Edit Site Content": ["编辑网站内容"],
            "Editor|Edit Site Info": ["编辑网站信息"],
            "Editor|Edit Text": ["编辑文本"],
            "Editor|Edit Your Site": ["编辑网站"],
            "Editor|Edit auto-responder": ["编辑自动回复"],
            "Editor|Edit custom commands": ["修改自定义指令"],
            "Editor|Edit in Drag & Drop": ["拖拽模式编辑中"],
            "Editor|Edit theme colors...": ["修改配色方案..."],
            "Editor|Editing Layout": ["编辑布局"],
            "Editor|Editing in mobile view also affects the desktop site.": [
              "手机端视角与电脑端视角的编辑内容一致。",
            ],
            "Editor|Editing will be enabled when article is fully generated.": [
              "请在文章全部完成后再编辑。",
            ],
            "Editor|Editor": ["编辑者"],
            "Editor|Email": ["邮箱"],
            "Editor|Email Automations": ["邮件自动化"],
            "Editor|Email Domain Authentication": ["邮箱域名认证"],
            "Editor|Email Domain Authentication Failed. Please read [link1:these detailed instructions] and ensure the correct [link2:CNAME records] have been created. If you need more help, you can send this tutorial to your registrar's customer service or reach out to us for support!":
              [
                "邮箱域名认证失败。请参考[link1:这些文章]以确保[link2:CNAME记录]创建正确。如果你需要更多的帮助，可以把这些指导文章发给你的域名商客服或者联系我们的客服团队！",
              ],
            "Editor|Email Verification": ["邮箱验证"],
            "Editor|Email domain has been authenticated! Your emails will no longer show “via strikingly.com” in the From Name. [link:Learn more]":
              [
                '邮件域名已认证成功！你的邮件发件人信息处不会再显示“via strikingly.com"。[link:了解更多]',
              ],
            "Editor|Email domain has been authenticated. You can now send email campaigns.":
              ["电子邮件域名已通过验证。现在可以发送电子邮件了。"],
            "Editor|Email sent (%{var1}s)": ["邮件已发送（%{var1}s）"],
            "Editor|Emails Sent": ["已发送邮件数"],
            'Editor|Emails that are sent from our platform but labeled with a free email address (Gmail, Yahoo, Hotmail, etc) are more likely to be marked as spam or junk. Instead, we recommend using a custom domain email for "From Email."':
              [
                "从Strikingly发送但使用免费邮箱服务的域名（如Gmail、Yahoo、Hotmail等）的邮件有更大风险被识别为垃圾邮件。因此我们建议使用自定义邮箱地址作为“发件人邮箱”。",
              ],
            "Editor|Embed a map, a calendar, a document, a form or any HTML code!":
              ["嵌入地图、留言板、或任意 HTML 代码"],
            "Editor|Empty space won't be shown in the published site": [
              "上线的网站将不显示空白",
            ],
            "Editor|Empty to remove password": ["清空以移除密码"],
            "Editor|Enable invisible reCAPTCHA to all forms, which is a basic safeguard to protect your web forms from spammers. The invisible reCAPTCHA won't affect your form style and only triggers the test when a suspicious visitor (e.g. robot) submits a form.":
              [
                "对所有表单启用隐形的人机验证，这是防止你的网站表单被垃圾信息攻击的基本保护措施。隐形的人机验证不会影响你的表单样式，只有在可疑的访客（如机器人）提交表单时才会触发测试。",
              ],
            "Editor|Enable strong anti-bot verification": [
              "启用更强的反机器人验证",
            ],
            "Editor|End time must be after start time": [
              "结束时间必须晚于开始时间",
            ],
            "Editor|Engage your audience & promote your business by sending newsletters.":
              ["通过发送营销邮件吸引你的观众并促进业务。"],
            "Editor|Engaging": ["引人入胜"],
            "Editor|Enter 8 to 20 letters or numbers": [
              "请填入8～20字符的英文数字",
            ],
            "Editor|Enter URL": ["输入链接"],
            "Editor|Enter URLs of similar reference sites, one per line": [
              "输入类似网站的URL，每行一个",
            ],
            "Editor|Enter URLs of similar reference sites, one per line (Optional)":
              ["输入相似参考网站的URL，每行一个（可选）。"],
            "Editor|Enter a custom location (optional)": [
              "输入自定义地点（选填）",
            ],
            "Editor|Enter a list of email addresses to get notified upon a new form submission. Enter ; to separate email addresses.":
              [
                "请输入需要接收新表单回复通知的邮箱地址。输入 ; （英文分号）来区分不同的邮箱。",
              ],
            "Editor|Enter a new command or select from history:": [
              "输入新指令或从历史记录中选择：",
            ],
            "Editor|Enter a page title": ["填写网页标题"],
            "Editor|Enter a simple prompt to describe your logo (Optional)": [
              "输入一个简单的提示来描述你的Logo（可选）",
            ],
            "Editor|Enter a size between 6 and 120.": [
              "输入介于6和120之间的字体大小。",
            ],
            "Editor|Enter a title for this dropdown": ["输入下拉菜单标题"],
            "Editor|Enter a valid number greater than 1": [
              "输入一个大于1的有效数字",
            ],
            "Editor|Enter applicant’s/contact’s email": [
              "请填入申请人/联络人邮箱",
            ],
            "Editor|Enter applicant’s/contact’s number": [
              "请填入申请人/联络人电话号码",
            ],
            "Editor|Enter business type or industry": ["输入业务类型或行业"],
            "Editor|Enter drag & drop mode to add, move, or remove any elements you want!":
              ["进入拖拽模式，添加、移动、删除组件吧！"],
            "Editor|Enter maximum Attendees per time slot. This event allows multiple bookings in a single time slot.":
              ["输入每个时间段的最多参与人数。此服务支持多人预约。"],
            "Editor|Enter new email address": ["请输入新邮箱"],
            "Editor|Enter password": ["请输入密码"],
            "Editor|Enter your company name": ["输入你的公司名称"],
            "Editor|Enter your keywords and continue to get titles.": [
              "输入关键词后，点击“确认并开始生成标题”获得博客标题。",
            ],
            "Editor|Enter your site's name": ["输入你的网站名称"],
            "Editor|Error: File exceeds maximum file size limit of %{storageSize}MB.":
              ["错误：文件超过最大文件大小限制%{storageSize}MB。"],
            "Editor|Error: This ZIP file contains more than %{maxLength} images.":
              ["错误：此ZIP文件包含超过%{maxLength}张图片。"],
            "Editor|Error: This ZIP file does not contain valid images.": [
              "错误：此ZIP文件不包含有效的图片。",
            ],
            "Editor|Error: This ZIP file is invalid and cannot be opened.": [
              "错误：此ZIP文件无效，无法打开。",
            ],
            "Editor|Estimated number of times this term is searched on Google each month. Higher is better for getting traffic.":
              [
                "该词语每月在谷歌上被搜索次数的估计值。越高意味着越有利于获得流量。",
              ],
            "Editor|Event": ["预约服务"],
            "Editor|Event Date & Time": ["预约日期&时间"],
            "Editor|Event Details": ["预约详情"],
            "Editor|Event Name": ["项目名称"],
            "Editor|Event Types": ["服务类型"],
            "Editor|Event time zone:": ["所在时区:"],
            "Editor|Events are up to the limit! Please contact our customer service to add more.":
              ["服务数量已达上限！如需添加更多，请联系在线客服"],
            "Editor|Existing Site": ["已有网站"],
            "Editor|Exit": ["退出"],
            "Editor|Exit & return to dashboard": ["退出并返回控制面板"],
            "Editor|Exit Editor": ["退出编辑器"],
            "Editor|Expand to Fill": ["扩展至填充"],
            "Editor|Export CSV": ["导出CSV"],
            "Editor|External URL": ["外部网站"],
            "Editor|External links are disabled in this preview": [
              "预览模式不支持链接外跳",
            ],
            "Editor|Extra Keywords": ["额外关键词"],
            "Editor|Extra Keywords (Optional, up to 7)": [
              "额外关键词（可选，最多7个）",
            ],
            "Editor|Extra Large": ["超级大"],
            "Editor|Extra keywords are terms related to your topic and target keywords, they can be added in your post to get bonus traffic.":
              [
                "额外关键词是与你的文章主题和目标关键词相关的词语，你可以添加它们到你的文章中以获取额外流量。",
              ],
            "Editor|FAQs": ["常见问题"],
            "Editor|FRI": ["星期五"],
            "Editor|Failed to connect to Google Search Console. Please make sure your site has been connected to a valid domain.":
              [
                "连接至Google Search Console失败。请确保你的网站绑定了有效的域名。",
              ],
            "Editor|Failed to delete images, please try again.": [
              "图片删除失败，请重试。",
            ],
            "Editor|Feature": ["专题"],
            "Editor|Feature List": ["列表布局"],
            "Editor|Feedback": ["反馈"],
            "Editor|Feeds are updated automatically, but updates may be limited by the source platform.":
              ["社交内容会自动更新，但更新速度可能会被源平台限制。"],
            "Editor|File Deleted": ["文件已删除"],
            "Editor|File Upload": ["上传文件"],
            "Editor|File exceeds maximum file size limit of %{storageSize}MB.":
              ["文件超过了%{storageSize}MB的最大文件大小限制。"],
            "Editor|File exceeds maximum file size limit of %{var1}MB.": [
              "文件不可超过 %{var1}MB。",
            ],
            "Editor|Fill": ["填充设置"],
            "Editor|Filter:": ["筛选："],
            "Editor|Finish writing using this outline": ["用这个大纲写完全文"],
            "Editor|First Name": ["名"],
            "Editor|First Section Height": ["第一个版块的高度"],
            "Editor|First Section Shape": ["第一个版块的形状"],
            "Editor|Fixed": ["固定背景"],
            "Editor|Fixed Date Overrides": ["特定时间段覆盖"],
            "Editor|Font Size": ["字体大小"],
            "Editor|Fonts": ["字体"],
            "Editor|For Generating Article": ["生成文章"],
            "Editor|For Generating Outline": ["生成大纲"],
            "Editor|For Generating Title": ["生成标题"],
            "Editor|For multiple-page sites, the site navigation is shown so visitors can find other pages. In the page manager, you can set whether each page should be visible in the navigation.":
              [
                "对于多页面网站，导航栏将默认显示以便访问者可以找到其他页面。在页面管理器中，你可以设置每个页面在导航栏中是否可见。",
              ],
            "Editor|For security reasons, you need to connect a domain to have your custom code take effect immediately!":
              ["出于安全性考虑，你需要绑定域名来使你的自定义代码立即生效。"],
            "Editor|Form Info": ["表单内容"],
            "Editor|Form Name": ["表单名称"],
            "Editor|Form submission is disabled in this preview. Please try on your live site.":
              ["预览模式暂不支持表单提交功能。请前往实际网站进行体验。"],
            "Editor|Formal": ["正式"],
            "Editor|Found a style to start with? Confirm the style to access the full editor.":
              ["找到要开始使用的风格了吗？确认风格以进入完整编辑器。"],
            "Editor|Free Membership": ["免费会员"],
            "Editor|Free SXL URL": ["免费的上线了网址"],
            "Editor|Free Strikingly URL": ["免费的Strikingly网址"],
            "Editor|Free domain (w/ yearly)": ["免费域名（任意包年套餐）"],
            "Editor|Free domain name": ["免费域名"],
            "Editor|Free with site plan package": ["网站套餐免费赠送"],
            "Editor|From Email": ["发件人邮箱"],
            "Editor|From Name": ["发件人姓名"],
            "Editor|Full": ["全屏"],
            "Editor|Full Height": ["全屏"],
            "Editor|Full e-commerce": ["强大电商系统"],
            "Editor|Full size logo PNG (transparent)": [
              "全尺寸Logo PNG（透明）",
            ],
            "Editor|Full size logo PNG (with background)": [
              "全尺寸Logo PNG（带背景）",
            ],
            "Editor|Full width": ["全宽"],
            "Editor|Fully Publish my Mini Program": ["正式发布小程序"],
            "Editor|Funny": ["搞笑"],
            "Editor|GOT IT!": ["知道了！"],
            "Editor|Gallery": ["图册"],
            "Editor|Generate": ["生成"],
            "Editor|Generate %{maxLength} More Icon Options": [
              "生成 %{maxLength} 更多图标选项",
            ],
            "Editor|Generate %{maxLength} More Logo Options": [
              "生成 %{maxLength} 更多Logo选项",
            ],
            "Editor|Generate %{var1} More Icons": ["生成 %{var1} 更多图标"],
            "Editor|Generate %{var1} More Palettes": [
              "再生成%{var1}组配色方案",
            ],
            "Editor|Generate Icon": ["生成图标"],
            "Editor|Generate Logo": ["生成Logo"],
            "Editor|Generate Logos": ["生成Logo"],
            "Editor|Generate a new batch of text options to replace the current options.":
              ["将生成一组新的文本选项，当前选项会被替换。"],
            "Editor|Generate an SEO blog post in a minute": [
              "开始写一篇新的SEO博客文章，当前文章将被保存为草稿。",
            ],
            "Editor|Generate content with AI": ["使用AI生成内容"],
            "Editor|Generate extra keywords": ["生成额外关键字"],
            "Editor|Generate more": ["生成更多"],
            "Editor|Generate more layouts": ["生成更多布局"],
            "Editor|Generate new logo": ["生成新Logo"],
            "Editor|Generate new options": ["生成新选项"],
            "Editor|Generating (%{percent}%%)... Please wait.": [
              "正在生成 %{percent}%%… 请稍后",
            ],
            "Editor|Generating article (%{percent}%%)... Please wait.": [
              "正在生成正文 %{percent}%%… 请稍候",
            ],
            "Editor|Generating extra keywords...": ["正在生成额外关键词..."],
            "Editor|Generating logos, please wait...": [
              "生成Logo中，请稍等...",
            ],
            "Editor|Generating more logos...": ["正在生成更多的Logo..."],
            "Editor|Generating options...": ["正在生成选项..."],
            "Editor|Generating outline... Please wait.": [
              "正在生成大纲… 请稍候",
            ],
            "Editor|Generating sections to choose from…": [
              "正在生成可供选择的版块…",
            ],
            "Editor|Generating site logos, please wait...": [
              "正在生成网站Logo，请稍候...",
            ],
            "Editor|Generating site structure, please wait...": [
              "正在生成网站结构，请稍候...",
            ],
            "Editor|Generating site, Please wait... %{var1}": [
              "正在生成网站，请稍等... %{var1}",
            ],
            "Editor|Generating site, please wait... %{var1}": [
              "正在生成网站，请稍等…%{var1}",
            ],
            "Editor|Generating titles... Please wait.": [
              "正在生成标题… 请稍候",
            ],
            "Editor|Generating...": ["生成中…"],
            "Editor|Get Found On Search Engine": ["被搜索引擎检测到"],
            "Editor|Get a Quote": ["询求报价"],
            "Editor|Get a [strong:free domain] with Pro Yearly and up!": [
              "升级到专业版包年套餐及以上，即可获得[strong:免费域名]！",
            ],
            "Editor|Get a link to the Desktop Editor": ["获取桌面编辑器的链接"],
            "Editor|Get a more professional look with your own branded domain name.  (e.g. www.yourbrand.com)":
              [
                "使用自选的品牌域名可以让你的网站给访客留下更加正规专业的印象。（例如www.yourbrand.com)",
              ],
            "Editor|Get color from logo": ["获取logo的颜色"],
            "Editor|Get free domain": ["获取免费域名"],
            "Editor|Get in Touch with Nadia!": ["快来联系Nadia吧！"],
            "Editor|Get visitors to buy products online": [
              "让访客在线购买产品",
            ],
            "Editor|Ghost": ["透明"],
            "Editor|Give your site a more professional look with your unique branded domain name.":
              [
                "使用自选的品牌域名可以让你的网站给访客留下更加正规专业的印象。",
              ],
            "Editor|Go Back": ["返回"],
            "Editor|Go Back to Dashboard & Preview": ["返回控制面板 & 预览"],
            "Editor|Go To Automation": ["前往邮件自动化"],
            "Editor|Go To Set My Own Domain": ["设置我自己的域名"],
            "Editor|Go back & modify content": ["返回并修改内容"],
            "Editor|Go back to edit sections": ["返回至版块编辑"],
            "Editor|Go to Authenticate": ["前往认证"],
            "Editor|Go to Google Search Console": ["前往Google Search Console"],
            "Editor|Go to the editor and explore sections!": [
              "前往编辑器，探索更多版块!",
            ],
            "Editor|Go to verify": ["前往验证。"],
            "Editor|Google Maps": ["Google 地图"],
            "Editor|Google Search Console": ["Google Search Console"],
            "Editor|Great for the top of a page. Add images, a button, or even a sign-up form.":
              ["适合用于网站首屏，可以添加图片，按钮，甚至报名表单"],
            "Editor|Greeting Message": ["欢迎消息"],
            "Editor|Grid": ["网格"],
            "Editor|Grid Height": ["网格高度"],
            "Editor|Grid Layout": ["网格布局"],
            "Editor|HIDE/SHOW": ["隐藏/显示"],
            "Editor|Has taken over editing. Please exit the editor now to ensure changes can be saved":
              ["目前已开始接管编辑。请退出编辑器，避免后续更改无法及时保存。"],
            "Editor|Header & Navigation": ["标题和导航"],
            "Editor|Heading": ["段落标题"],
            "Editor|Height": ["高度"],
            "Editor|Here are the top ranked search results for your target keyword. To achieve high ranking potential, we recommend your title to imitate these to best match the search intent.":
              [
                "以下是你的目标关键词排名最靠前的搜索结果。为了获得更高的排名潜力，我们建议你在标题中模仿它们的写法，以更好地匹配搜索意图。",
              ],
            "Editor|Hero": ["头条"],
            "Editor|Hi, there! \n\n Congratulations on your new booking! The booking details to the attendee has been sent on your behalf.":
              [
                "你好！\n\n恭喜你，收到新的预约了！我们已经自动替你向参与人发送了预约详情。",
              ],
            "Editor|Hi, there! \n\nThank you for your booking at [page name]. Your booking details are below.":
              ["你好！感谢你在[page name]上进行预约，预约详情如下。"],
            "Editor|Hi, there! \n\nYour booking from [page name] has been cancelled.":
              ["你好！\n\n你在 [page name] 的预约已经被取消。"],
            "Editor|Hidden for all": ["全部隐藏"],
            "Editor|Hidden for desktop": ["在电脑端隐藏显示"],
            "Editor|Hidden for desktop & mobile": ["电脑&手机端均隐藏显示"],
            "Editor|Hidden for mobile": ["在手机端隐藏显示"],
            "Editor|Hide": ["隐藏"],
            "Editor|Hide Advanced Settings": ["隐藏高级设置"],
            "Editor|Hide for all": ["隐藏"],
            "Editor|Hide section": ["隐藏版块"],
            "Editor|Hide settings above": ["隐藏上述设置"],
            "Editor|Hide the editor panel": ["隐藏编辑器面板"],
            "Editor|Hide/show section...": ["隐藏/显示版块..."],
            "Editor|Highlight Color": ["高亮颜色"],
            "Editor|Highlight this item": ["突出显示此项"],
            "Editor|Highlighted": ["已突出显示"],
            "Editor|Hint Text": ["提示文字"],
            "Editor|Home": ["首页"],
            "Editor|Horizontal Align": ["水平对齐"],
            "Editor|Hours": ["工作时间"],
            "Editor|How It Works": ["如何使用"],
            "Editor|How backgrounds appear when scrolling": [
              "页面滚动时背景的展示方式",
            ],
            "Editor|How page content is revealed when scrolling": [
              "页面滚动时内容的展现方式",
            ],
            "Editor|However, we strongly recommend using a custom domain email (e.g. hello@yourdomain.com) for From Email, which builds trust with recipients and looks more professional. [link:Get a custom email].":
              [
                "然而，我们强烈建议使用自定义域名邮箱（如hello@yourdomain.com）作为发件人邮箱，这样可以与收件人建立信任，而且看起来更专业。 [link:获取自定义邮箱]。",
              ],
            "Editor|I already have a site in this language": [
              "我已经有了一个该语言的网站",
            ],
            "Editor|I already have some keywords": ["我已经有一些关键词"],
            "Editor|I don't have keywords — generate from scratch": [
              "我不知道要用什么关键词，请给我生成。",
            ],
            "Editor|I understand that all collected info is the responsibility of the site owner, and that the platform has right to remove the illegal content.":
              [
                "我已知晓收集信息归属于网站所属用户，平台会审查并清除违规内容。",
              ],
            "Editor|I'll update all the content myself": [
              "我会自己更新所有内容",
            ],
            "Editor|I've Added, Start Checking": ["我已添加，开始检查"],
            "Editor|Icon": ["图标"],
            "Editor|If empty, we'll fill it in with the category name.": [
              "如此项为空，则自动填写为分类名称。",
            ],
            "Editor|If not, your blog post with your custom HTML code will be reviewed by our system before going live. (Before submitting, please [link:preview your blog post] to make sure your code works.)":
              [
                "如果不绑定域名，你的博客和HTML自定义代码需要由我们的系统审核后才能生效。（代码提交前，请[link:预览博客]来确保你的代码能正常生效。）",
              ],
            "Editor|If not, your custom code will be reviewed by our system before going live. (Before submitting, please [link:go to Blog Posts] and preview them to make sure your code works.)":
              [
                "如果不绑定域名，你的自定义代码需要由我们的系统审核后才能生效。（代码提交前，请[link:前往博客文章]预览博客来确保你的代码能正常生效。）",
              ],
            "Editor|If not, your custom code will be reviewed by our system before going live. (Before submitting, please [link:preview your site] to make sure your code works.)":
              [
                "如果不绑定域名，你的自定义代码需要由我们的系统审核后才能生效。（代码提交前，请[link:预览网站]来确保你的代码能正常生效。）",
              ],
            "Editor|If not, your site with your custom HTML code will be reviewed by our system before going live. (Before submitting, please [link:preview your site] to make sure your code works.)":
              [
                "如果不绑定域名，你的网站和HTML自定义代码需要由我们的系统审核后才能生效。（代码提交前，请[link:预览网站]来确保你的代码能正常生效。）",
              ],
            "Editor|If you already own a domain, [link:click here to connect.]":
              ["如果你已经拥有域名，[link:点击这里将域名转入Strikingly。]"],
            "Editor|If you already own a domain, enter it here.": [
              "如果你已经拥有一个域名，请在此输入。",
            ],
            "Editor|If you choose to include custom images, please make sure all images are relevant to your site content. We'll use these images in your site where appropriate.":
              [
                "如果你要使用自定义图片，请确保所有图片都与你的网站内容相关。我们会在你的网站中适当使用这些图片。",
              ],
            "Editor|If you have a set of custom images you'd like to use, please include them in a Zip file and upload them here. (Max filesize: %{storageSize}MB total, up to %{maxLength} images)":
              [
                "如果你有一组自定义图片需要使用，请将它们打包成ZIP文件并在此处上传。 （最大文件大小：总共%{storageSize}MB，最多 %{maxLength}张图片）",
              ],
            "Editor|If you have specific requirements for generating content, add custom commands here. Otherwise, we recommend leaving this blank for best results.":
              [
                "如果你对生成内容有特定的要求，请在这里添加自定义指令。如果没有特定要求，我们建议你留空以获得最佳结果。",
              ],
            "Editor|If you want to set all item buttons uniformly, go to [link:Portfolio Settings].":
              ["如果你想要统一设置所有项目按钮，请前往[link:项目设置]。"],
            "Editor|If you're using a third-party domain to send emails, you must authenticate your domain before you can send from this address.":
              [
                "若你使用第三方域名邮箱，必须通过身份验证之后才能从这个地址发送电子邮件。",
              ],
            "Editor|If your domain is hosted on Strikingly, your domain is automatically authenticated -- no action needed.":
              ["托管在Strikingly的所有域名都已完成认证，无需手动操作。"],
            "Editor|Ignore & use mobile browser": ["继续使用手机编辑"],
            "Editor|Image": ["图片"],
            'Editor|Image "alt text" help search engines identify the content of images and help screen-reading tools describe images to visitors':
              [
                "图片描述文字可帮助搜索引擎识别图片内容，并帮助屏幕阅读工具向访客描述图片",
              ],
            'Editor|Image "alt text" helps search engines identify the content of images and help screen-reading tools describe images to visitors. Try to add short, human-readable terms for each image from the site pages and sections.':
              [
                "图片描述文字可帮助搜索引擎识别图片内容，并帮助屏幕阅读工具向访客描述图片。试着为网页和各个版块的图像添加易于阅读的简短术语。",
              ],
            "Editor|Image & Link": ["图片与链接"],
            "Editor|Image & Video": ["图片 & 视频"],
            "Editor|Image Alignment": ["配图对齐"],
            "Editor|Image Link Hover": ["超链接图片鼠标悬停效果"],
            "Editor|Image Name": ["图片名称"],
            "Editor|Image Shape": ["配图样式"],
            "Editor|Image Size": ["图片尺寸"],
            "Editor|Image Title": ["图片标题"],
            "Editor|Image and video thumbnails that open in a full view.": [
              "可以全屏浏览的图片和视频",
            ],
            "Editor|Images from your site pages and sections will be listed here.":
              ["你的网站页面和版块中的图片会列在这里。"],
            "Editor|Immediately": ["立即发送"],
            "Editor|Import Image/Video": ["导入图片/视频"],
            "Editor|Importing & verifying contacts from CSV... (%{var1})": [
              "正在从CSV导入并验证联系人… (%{var1})",
            ],
            "Editor|In an Instant": ["就在弹指之间"],
            "Editor|Inactive": ["未生效"],
            "Editor|Including page URLs, titles, meta descriptions & image alt texts":
              ["包括页面地址，标题，元描述和图片描述文字"],
            "Editor|Increase orders by offering customers special coupons and discounts.":
              ["通过向客户提供优惠券和折扣来增加订单。"],
            "Editor|Input field title": ["输入字段标题"],
            "Editor|Input option name": ["输入选项内容"],
            "Editor|Inquiry Sent Successfully!": ["已成功发送询盘！"],
            "Editor|Invalid Resident ID Card number": ["法人身份证号无效"],
            "Editor|Invite Teammates to Edit Together": [
              "邀请团队成员一起编辑",
            ],
            "Editor|Invite your friends and colleagues to co-edit your website together seamlessly.":
              ["邀请你的朋友和同事们一起无缝编辑你的网站。"],
            "Editor|Issues with cloning site": ["网站复制问题"],
            "Editor|It looks like your editor content has changed in another tab or window. To avoid losing your changes, please reload to sync the latest version before editing.":
              [
                "看起来你的编辑器内容已经在另一个页面或窗口中发生过更改。为了避免更改内容的丢失，请在编辑前重新加载编辑器以同步最新版本。",
              ],
            "Editor|It's free for %{var1} days, and you can cancel any time.": [
              "%{var1}天免费，你可以随时取消。",
            ],
            "Editor|Item": ["项目"],
            "Editor|Item Color": ["内容颜色"],
            "Editor|Item Highlight": ["内容高亮色"],
            "Editor|Item Rules": ["项目规则"],
            "Editor|Item Spacing": ["间距"],
            "Editor|Item Subtitle": ["项目副标题"],
            "Editor|Item Title": ["项目标题"],
            "Editor|Item prices will be applied to visitors from this country/region. These settings will override default settings.":
              [
                "项目价格会应用到来自不同国家/地区的访客。这些设置将覆盖默认设置。",
              ],
            "Editor|Item settings will be applied to visitors from this country/region. These settings will override default settings.":
              [
                "项目设置会应用到来自不同国家/地区的访客。这些设置将覆盖默认设置。",
              ],
            "Editor|Items & Structure": ["项目 & 结构"],
            "Editor|Just Publish Free Site": ["直接发布免费网站"],
            "Editor|Keep Editing": ["继续编辑"],
            "Editor|Keep navigation visible while scrolling": [
              "滚动页面时，导航栏固定在顶部",
            ],
            "Editor|Keyword Censorship Failed": ["审核未通过"],
            "Editor|Keyword Difficulty": ["关键词难度"],
            "Editor|Keyword difficulty (KD) is the difficulty of ranking high on search results for a specific keyword. We recommend prioritizing keywords with 0-14 KD and avoiding keywords with KD above 50.":
              [
                "关键词难度（KD）是指在特定关键词的搜索结果中排名靠前的难度。我们建议优先考虑KD为0-14的关键词，避免KD高于50的关键词。",
              ],
            "Editor|L": ["大"],
            "Editor|LET'S GO!": ["开始吧！"],
            "Editor|Landscape": ["横向"],
            "Editor|Landscape (16:9)": ["横向 (16:9)"],
            "Editor|Landscape (4:1)": ["横向 (4:1)"],
            "Editor|Landscape (4:3)": ["横向 (4:3)"],
            "Editor|Landscape - 4:3": ["横向 - 4:3"],
            "Editor|Language": ["语言"],
            "Editor|Language label (optional)": ["语言标签（可选）"],
            "Editor|Large": ["宽距"],
            "Editor|Large Shadow": ["较强阴影"],
            "Editor|Last Name": ["姓"],
            "Editor|Last Step: Link to Your Related Posts": [
              "最后一步：链接到相关文章",
            ],
            "Editor|Last Step: Set up DNS record": ["最后一步：添加DNS记录"],
            "Editor|Last Step: Set up host records": ["最后一步：设置主机记录"],
            "Editor|Last read": ["上次读取"],
            "Editor|Last step: Select style": ["最后一步：选择风格"],
            "Editor|Last submitted": ["上次提交"],
            "Editor|Launch Guide": ["上线指南"],
            "Editor|Layout": ["布局"],
            "Editor|Learn More": ["了解更多内容"],
            "Editor|Learn more": ["了解更多"],
            "Editor|Left": ["居左"],
            "Editor|Left Sidebar": ["左侧栏"],
            "Editor|Legal Person's Resident ID Card Number": ["法人身份证号"],
            "Editor|Less": ["折叠"],
            "Editor|Let viewers drop their name, email, and message.": [
              "用于让访客填写姓名、电子邮件和评论的留言表",
            ],
            "Editor|Let visitors drop their name and email.": [
              "让访客留下姓名和电子邮件。",
            ],
            "Editor|Let visitors leave a message.": ["让访客留言。"],
            "Editor|Let visitors schedule appointments.": ["让访客预约。"],
            "Editor|Light Minimal": ["浅色简约"],
            "Editor|Light Overlay": ["白色透明遮罩"],
            "Editor|Light mode": ["亮色模式"],
            "Editor|Link": ["链接"],
            "Editor|Link To": ["链接到"],
            "Editor|Link URL": ["链接地址"],
            "Editor|Link sent to %{email}! Please check your email on desktop.":
              ["链接已发送至%{email}! 请在电脑上打开此邮件。"],
            "Editor|List": ["列表"],
            "Editor|Load %{var1} more": ["再看%{var1}个"],
            "Editor|Location": ["地点"],
            "Editor|Log in again": ["重新登录"],
            "Editor|Log into %{provider}, then add the record below into the DNS settings for %{domain}. [link:Here’s a step-by-step guide].":
              [
                "登录%{provider}，然后将下面的记录添加到%{domain}的DNS设置中。[link:点击查看逐步指南]。",
              ],
            "Editor|Log into %{provider}, then add the records below into the DNS settings for %{domain}. [link:Here’s a step-by-step guide].":
              [
                "登录%{provider}，然后将下面的记录添加到%{domain}的DNS设置中。[link:点击查看逐步指南]。",
              ],
            "Editor|Log into %{provider}, then enter the records below into your DNS settings. [var1: Here’s a step-by-step guide.]":
              [
                "登录%{provider}，然后在你的DNS设置中输入以下记录。[var1: 点击查看逐步指南。]",
              ],
            "Editor|Log into your domain provider, then add the record below into the DNS settings for %{domain}. [link:Here’s a step-by-step guide].":
              [
                "登录你的域名提供商，然后将下面的记录添加到%{domain}的DNS设置中。[link:点击查看逐步指南]。",
              ],
            "Editor|Log into your domain provider, then add the records below into the DNS settings for %{domain}. [link:Here’s a step-by-step guide].":
              [
                "登录你的域名提供商，然后将下面的记录添加到%{domain}的DNS设置中。[link:点击查看逐步指南]。",
              ],
            "Editor|Log into your domain provider, then enter the records below into your DNS settings. [var1: Here’s a step-by-step guide.]":
              [
                "登录到你的域名提供商，然后在你的DNS设置中输入以下记录。[var1: 点击查看逐步指南。]",
              ],
            "Editor|Logo & Title": ["Logo & 标题"],
            "Editor|Logo Only": ["仅Logo"],
            "Editor|Logo Title": ["Logo标题"],
            "Editor|Logo icon PNG": ["Logo 图标 PNG"],
            "Editor|Logo included for free!": ["免费包含Logo！"],
            "Editor|Logo package": ["Logo文件"],
            "Editor|Logo package download.": ["Logo文件下载。"],
            "Editor|Long Text": ["长文本"],
            "Editor|Long snippet": ["长导语"],
            "Editor|Lowercase": ["全部小写"],
            "Editor|M": ["中"],
            "Editor|MON": ["星期一"],
            "Editor|Magazine": ["杂志排版"],
            "Editor|Mailchimp": ["Mailchimp"],
            "Editor|Main Text": ["主文本"],
            "Editor|Main Text Color": ["主文本颜色"],
            "Editor|Make A Logo": ["制作Logo"],
            "Editor|Make Your Own Section": ["自定义版块"],
            "Editor|Make a logo for an existing site": ["为已有网站做一个Logo"],
            "Editor|Make a standalone logo": ["做一个独立的Logo"],
            "Editor|Make sure you enter your keyword in the correct language.":
              ["确保用正确的语言输入关键词。"],
            "Editor|Make this page accessible to:": [
              "允许这些用户访问本页面：",
            ],
            "Editor|Manage": ["管理"],
            "Editor|Manage Blog Posts": ["管理博客文章"],
            "Editor|Manage Event": ["前往管理"],
            "Editor|Manage Events": ["前往管理"],
            "Editor|Manage Gallery": ["图册管理"],
            "Editor|Manage Pages": ["管理页面"],
            "Editor|Manage account": ["管理账户"],
            "Editor|Manage ownership": ["管理拥有权"],
            "Editor|Manage verified owners": ["管理已验证的拥有者"],
            "Editor|Manage your portfolio items.": ["管理你的展示项目。"],
            "Editor|Manage your scheduled bookings in the editor": [
              "在编辑器后台管理你的服务预约",
            ],
            "Editor|Manage your store's products.": ["管理你的商品。"],
            "Editor|Manual": ["手动"],
            "Editor|Manually translate the site": ["手动翻译网站"],
            "Editor|Map": ["地图"],
            "Editor|Max 10 override dates": ["最多添加10天"],
            "Editor|Max file size must be between 1MB and 100MB": [
              "支持输入范围1MB至100MB",
            ],
            "Editor|Max file size: %{var1} MB": ["文件大小不超过：%{var1} MB"],
            "Editor|Maximum region limit reached. (%{limit})": [
              "已达到最大的地区数量限制（%{limit}）",
            ],
            "Editor|Media Position": ["配图位置"],
            "Editor|Media Size": ["配图大小"],
            "Editor|Media on Left": ["图片居左"],
            "Editor|Media on Right": ["图片居右"],
            "Editor|Medium": ["中等"],
            "Editor|Medium Rounded": ["中等圆角"],
            "Editor|Medium Shadow": ["中等阴影"],
            "Editor|Member Registration Info Required": ["会员注册信息"],
            "Editor|Membership": ["会员功能"],
            "Editor|Membership settings": ["会员设置"],
            "Editor|Membership-only access!": ["仅限会员访问！"],
            "Editor|Message": ["留言"],
            "Editor|Meta Description": ["文章元描述"],
            "Editor|Middle": ["居中"],
            "Editor|Mini-Program owner": ["小程序所有者"],
            "Editor|Minimum": ["最小"],
            "Editor|Mobile Layout": ["手机端布局"],
            "Editor|Modern": ["现代"],
            "Editor|Monitor & improve SEO performance of your site on Google.":
              ["在Google上监测并改善你的网站的SEO性能。"],
            "Editor|Monthly Search Volume": ["月搜索量"],
            "Editor|More actions": ["更多操作"],
            "Editor|More layout options!": ["更多布局方式！"],
            "Editor|More...": ["更多..."],
            "Editor|Mouse hover effect on image links": [
              "鼠标悬停于超链接图片的效果",
            ],
            "Editor|Move this section to another page": [
              "移动此版块至另一个页面",
            ],
            "Editor|Move to page": ["转移到"],
            "Editor|Multi-language settings are only available for the site owner.":
              ["多语言设置仅网站所有者可用。"],
            "Editor|Multiple Attendees": ["多人"],
            "Editor|Multiple Editors Open": ["同时开启多个编辑器"],
            "Editor|Multiple-Page Site": ["多页面网站"],
            "Editor|My Sites": ["我的网站"],
            "Editor|N/A": ["暂无"],
            "Editor|NEW FOR MOBILE": ["移动端新功能"],
            "Editor|Name": ["名字"],
            "Editor|Name this email for your reference, Recipients won't see this.":
              ["该邮件命名对收件人不可见，仅用于后台管理参考。"],
            "Editor|Narrow": ["窄"],
            "Editor|Nav Dropdown": ["导航下拉菜单"],
            "Editor|Nav Item": ["导航栏"],
            "Editor|Navigation text color": ["导航栏字体颜色"],
            "Editor|New": ["新增"],
            "Editor|New Dropdown": ["新下拉菜单"],
            "Editor|New Language": ["新语言"],
            "Editor|New Page %{num}": ["新网页 %{num}"],
            "Editor|New booking from [attendee] on [Date Time]": [
              "新预约 [网站访客] 预约时间 [日期时间]",
            ],
            "Editor|New password": ["新密码"],
            "Editor|Newest": ["最新"],
            "Editor|Next": ["下一步"],
            "Editor|No": ["无"],
            "Editor|No Icon, Text Only": ["无图标，仅文本"],
            "Editor|No Image": ["不显示图片"],
            "Editor|No Internet": ["无网络连接"],
            "Editor|No Media": ["不显示图片"],
            "Editor|No Shadow": ["无阴影"],
            "Editor|No button": ["不显示按钮"],
            "Editor|No contact info required, visitors can view product directly":
              ["不需要联系方式，访客可以直接浏览商品。"],
            "Editor|No image": ["纯本文"],
            "Editor|No logo": ["不需要Logo"],
            "Editor|No past bookings": ["暂无过期的预约"],
            "Editor|No result": ["无结果"],
            "Editor|No snippet": ["无导语"],
            "Editor|No thumbnail": ["无缩略图"],
            "Editor|No upcoming bookings": ["暂时没有预约"],
            "Editor|None": ["无"],
            "Editor|Normal": ["正常"],
            "Editor|Not available": ["不可预约"],
            "Editor|Not connected": ["未连接"],
            "Editor|Not now, continue using trial version": [
              "暂时不用，我想继续体验",
            ],
            "Editor|Note about card payments": ["有关银行卡收款的注意事项"],
            "Editor|Note: East Asian fonts may increase your site’s load time.":
              ["注意：东亚字体可能会增加您网站的加载时间。"],
            "Editor|Note: Some computers may only display the system default fonts due to the font library. In mobile devices such as mobile phones/tablets, the selected font will be displayed as the system default font":
              [
                "注意：部分电脑由于字体库原因，或导致极细、圆体仅显示为系统默认字体。在手机/平板等移动设备中，所选字体会显示为系统默认字体",
              ],
            "Editor|Notifications sent to booking attendee": [
              "给服务预订参与者发送邮件通知",
            ],
            "Editor|Now it's your turn. Click anything on this to get started - Build your brand. Conquer the world.":
              ["现在交给你了。点击页面任意部分，开始自由编辑你的网站吧！"],
            "Editor|OK": ["确认"],
            "Editor|OK, GOT IT": ["好的"],
            "Editor|Off": ["关闭"],
            "Editor|Oldest": ["最旧"],
            "Editor|On": ["开启"],
            "Editor|On any page": ["在任何页面"],
            "Editor|On exit": ["离开页面时弹出"],
            "Editor|On the %{var1} plan, you can only add %{var2} %{var3}. Please upgrade to add more %{var4}.":
              [
                "在%{var1}套餐中，你只能添加%{var2}个%{var3}。请升级套餐以添加更多%{var4}。",
              ],
            "Editor|Once you add the records, it takes up to 48 hours for the authentication to complete.":
              ["添加记录后，身份验证最多需要48小时才能完成。"],
            "Editor|One-time payment.": ["一次性付款。"],
            "Editor|One-time, non-refundable fee.": ["一次性支付，不可退款。"],
            "Editor|Only images not used on this page": [
              "仅包括在此页面上未使用的图片。",
            ],
            "Editor|Only images not used on this site": [
              "仅包括在此网站上未使用的图片。",
            ],
            "Editor|Only letters (from any language), numbers, and hyphens are allowed.":
              ["仅支持字母（任何语言）、数字和连字号(-)。"],
            "Editor|Only on selected pages": ["仅在选中页面"],
            "Editor|Opacity": ["透明度"],
            "Editor|Open in new tab": ["在新标签中打开"],
            "Editor|Open sitemap": ["打开网站地图"],
            "Editor|Opens in new tab": ["在新标签页中打开"],
            "Editor|Optional": ["选填"],
            "Editor|Options": ["选项"],
            "Editor|Or add a new physical address": ["或添加一个新地址"],
            "Editor|Or click anywhere to continue.": ["点击其它区域继续"],
            "Editor|Or generate extra keywords": ["或去生成额外关键字"],
            "Editor|Or select an email from your custom domain": [
              "或者选择一个你的自定义域名邮箱",
            ],
            "Editor|Or transfer your domain to us!": ["转移域名给我们！"],
            "Editor|Or try membership for free.": [
              "或你可免费试用会员系统功能",
            ],
            "Editor|Or try pop-ups for free": ["或你可免费试用推广弹窗功能"],
            "Editor|Or use your own extra keywords": [
              "或使用你自己的额外关键字",
            ],
            "Editor|Original": ["原始"],
            "Editor|Other": ["其他"],
            "Editor|Other recommended sections": ["其他推荐版块"],
            "Editor|Others": ["其他"],
            'Editor|Our AI SEO writer will finish your article in a few minutes. Make any changes you\'d like to each paragraph. Once you’re satisfied, click "All set! Import to blog editor" to add images or publish.':
              [
                "我们的AI智能写手将在几分钟内完成博客全文。你可以修改每个段落。如果你对文章感到满意，可以点击“全部完成！导入博客编辑器”，在那里添加图片或发布。",
              ],
            "Editor|Our AI Site Builder will create your site in a few minutes, optimized for your business needs — whether making sales, collecting leads, or just displaying information.":
              [
                "我们的AI网站生成器将在几分钟内为你创建网站，针对你的商业需求进行优化 — 无论是销售、收集潜在客户，还是仅展示信息。",
              ],
            "Editor|Our AI Writer writes Search Engine Optimized (SEO) articles to help you get more traffic from Google.":
              [
                "我们的AI智能写手可以替你写SEO（搜索引擎优化）博客文章，帮助你从谷歌获得更多流量。",
              ],
            "Editor|Our AI writes Search Engine Optimized (SEO) articles to help you get more traffic from Google.":
              [
                "我们的AI智能写手可以替你写SEO（搜索引擎优化）博客文章，帮助你从谷歌获得更多流量。",
              ],
            "Editor|Output Language": ["输出语言"],
            "Editor|Overlay": ["遮罩"],
            "Editor|PURCHASE": ["购买"],
            "Editor|Padding": ["内边距"],
            "Editor|Page & Section": ["页面和版块"],
            "Editor|Page & Sections": ["页面和板块"],
            "Editor|Page Description": ["页面描述"],
            "Editor|Page Scroll": ["页面滚动"],
            "Editor|Page URL": ["页面URL"],
            "Editor|Page name cannot be empty": ["请输入名称"],
            "Editor|Page sections content": ["页面版块内容"],
            "Editor|Pages": ["页面"],
            "Editor|Paid": ["已支付"],
            "Editor|Paragraph": ["段落"],
            "Editor|Parallax": ["视差滚动"],
            "Editor|Password": ["密码"],
            "Editor|Password Prompt": ["密码页面提示"],
            "Editor|Password incorrect": ["密码错误"],
            "Editor|Password settings": ["密码设置"],
            "Editor|Past": ["已过期"],
            "Editor|Payment Method": ["付款方式"],
            "Editor|Permission": ["权限"],
            "Editor|Personal ID/Tax ID": ["身份证/公司统一编号"],
            "Editor|Phone": ["电话"],
            "Editor|Phone number": ["电话号码"],
            "Editor|Pick for me": ["帮我选个"],
            "Editor|Pill": ["胶囊状"],
            "Editor|Playful": ["俏皮"],
            "Editor|Please <a class='pricing-link' href='/s/pricing' target='blank'>upgrade to Pro</a> to sync your latest Tweets.":
              [
                "请<a class='pricing-link' href='/s/pricing' target='blank'>升级到Pro套餐</a>以同步你的最新推文。",
              ],
            "Editor|Please Try Again Tomorrow": ["请明天再试"],
            "Editor|Please choose your domain registrar and configure your domain settings.":
              ["请选择域名注册商，完成域名解析"],
            "Editor|Please complete the verification.": ["请完成验证。"],
            "Editor|Please confirm you're a human.": ["请完成人机验证"],
            "Editor|Please describe your business/blog/product in a few keywords (up to 5).":
              ["请用几个关键词(最多5个)描述你的业务/博客/产品。"],
            "Editor|Please email us at [user email] if you have any questions. \n\nCheers! \nBooking Scheduling Bot":
              [
                "如果你有任何疑问，欢迎邮件咨询[user email] 。 \n\n感谢！ \n预约管家",
              ],
            "Editor|Please enter a number from 1 to 48.": [
              "请输入1到48之间的数字。",
            ],
            "Editor|Please enter a valid email": ["请输入一个有效的邮箱地址"],
            "Editor|Please enter a valid number": ["请输入一个有效的数字"],
            "Editor|Please enter a valid number from 1 to 48.": [
              "请输入1到48之间的有效数字。",
            ],
            "Editor|Please enter a valid phone number": [
              "请输入一个有效的电话号码",
            ],
            "Editor|Please enter an email address": ["请输入邮箱地址"],
            "Editor|Please enter certification information": ["请填写认证信息"],
            "Editor|Please enter registration information": ["请填写注册信息"],
            "Editor|Please enter the site URL": ["请输入网站地址"],
            "Editor|Please fill in your contact information to get a quote.": [
              "请填写你的联系方式以询求报价。",
            ],
            "Editor|Please fill in your contact information to view price.": [
              "请填写你的联系方式以查看价格。",
            ],
            "Editor|Please fill this field": ["请填写此字段"],
            "Editor|Please make sure you have at least one field.": [
              "请确保至少有一个字段。",
            ],
            "Editor|Please modify your code to remove restricted content, or [link:contact us if you have any questions.]":
              [
                "请修改你的代码，删除不合规的内容。如果你有任何疑问，[link:请联系我们。]",
              ],
            "Editor|Please note that your saved content contains sensitive words that are not allowed by the censorship requirement. Please modify and try again.":
              [
                "请注意，根据相关部门审查要求，你保存的内容中包含敏感词汇，请修改后再试。",
              ],
            "Editor|Please note that your updated content contains sensitive words that are not allowed by the censorship requirement. Please modify and try again.":
              [
                "请注意，根据相关部门审查要求，你更新的内容中包含敏感词汇，请修改后再试。",
              ],
            "Editor|Please select a list.": ["请选择列表。"],
            "Editor|Please select at least one file type.": [
              "请至少选择一种文件类型。",
            ],
            "Editor|Please select only one file.": ["仅支持单个文件上传。"],
            "Editor|Please send us your thoughts on our new AI workflow! We welcome any comments, suggestions, or feedback.":
              [
                "请跟我们分享你对我们AI建站流程的建议和看法！ 我们欢迎任何意见、建议或反馈。",
              ],
            "Editor|Please set a new password. Must be between 8 and 20 characters, letters and numbers only.":
              ["请设置一个新密码。必须为8～20字符的英文数字。"],
            "Editor|Please upgrade to a premium plan to continue using AI features for this logo.":
              ["请升级到付费套餐，以继续在此Logo中使用AI功能。"],
            "Editor|Please upgrade to a premium plan to generate more logos.": [
              "请升级到付费套餐，以生成更多Logo。",
            ],
            "Editor|Please upgrade to a premium plan to generate more sites.": [
              "请升级到付费套餐，以生成更多网站。",
            ],
            "Editor|Please upload a file.": ["请上传一个文件。"],
            "Editor|Please verify to send this email.": [
              "请验证以发送此邮件。",
            ],
            "Editor|Please verify your Strikingly account password, and provide Personal ID/Tax ID, email, and phone number to reset your password.":
              [
                "请验证你的Strikingly账号密码，并提供身份证/公司统一编号，邮箱和电话号码来重置密码。",
              ],
            "Editor|Please wait for the current import to complete before importing another CSV file.":
              ["请等待当前的导入完成后再导入另一个CSV文件。"],
            "Editor|Please wait until your custom domain SSL is complete before connecting to Google Search Console. This might take a few hours.":
              [
                "请等待自定义域名的SSL验证完成后再连接到Google Search Console。这可能需要几个小时。",
              ],
            "Editor|Please wait while we're connecting your site to Google...":
              ["请稍等，我们正在将你的网站连接至Google..."],
            "Editor|Points to": ["指向"],
            "Editor|Pop-Up Form": ["弹窗表单"],
            "Editor|Pop-ups is a Pro feature": [
              "推广弹窗等级属于专业版套餐功能",
            ],
            "Editor|Popup form": ["推广弹窗表单"],
            "Editor|Portfolio Currency": ["项目展示中的币种"],
            "Editor|Portfolio Form Custom Fields": ["产品展示表的自定义字段"],
            "Editor|Portfolio Item Button": ["产品展示项目按钮"],
            "Editor|Portfolio Visitor Form": ["产品展示访客表"],
            "Editor|Portrait": ["纵向"],
            "Editor|Portrait (4:5)": ["纵向 (4:5)"],
            "Editor|Portrait - 3:4": ["纵向 - 3:4"],
            "Editor|Position": ["位置"],
            "Editor|Posts Per Page": ["每页显示的文章数"],
            "Editor|Premium Features In Use": ["正在使用的付费功能"],
            "Editor|Prevent visitors from submitting disposable/temporary email addresses. This helps ensure that visitors submit real emails and can receive replies by email.":
              [
                "阻止访客提交一次性/临时邮箱。这有助于确保访客提交真实的邮箱，并可以通过邮件收到回复。",
              ],
            "Editor|Preview": ["预览"],
            "Editor|Preview Item": ["预览项目"],
            "Editor|Preview search results in Google": ["预览 Google 搜索结果"],
            "Editor|Preview site": ["预览网站"],
            "Editor|Previous": ["上次版本"],
            "Editor|Price": ["价格"],
            "Editor|Pricing Table": ["定价表"],
            "Editor|Pro & VIP yearly plans": ["专业版 & 企业版 包年特别优惠"],
            "Editor|Pro Subscription": ["专业会员"],
            "Editor|Process": ["流程"],
            "Editor|Processing: %{fileName}": ["处理中: %{fileName}"],
            "Editor|Product Catalog": ["产品目录"],
            "Editor|Product Showcase": ["产品展示"],
            "Editor|Professional": ["专业"],
            "Editor|Profile": ["介绍"],
            "Editor|Promote & grow your site": ["营销 & 帮助网站增长"],
            "Editor|Protect Site Forms From Bot Submissions": [
              "保护网站表单，避免机器人提交垃圾信息",
            ],
            "Editor|Publish Your Site": ["发布网站"],
            "Editor|Publish as a free site": ["上线免费版网站"],
            "Editor|Publish limit hit": ["你已达到专业版上线限额上限"],
            "Editor|Published": ["已上线"],
            "Editor|Published by %{var1}": ["由%{var1}发布"],
            "Editor|Purchase is disabled in this preview. Please try on your live site.":
              ["预览模式暂不支持下单功能。请前往实际网站进行体验。"],
            "Editor|Quit Editing": ["退出编辑"],
            "Editor|Radio": ["单选"],
            "Editor|Radius": ["方形"],
            "Editor|Reach out to your audience with branded newsletters.": [
              "通过品牌营销邮件接触你的观众。",
            ],
            "Editor|Read our SEO guide to improve your ranking even more": [
              "阅读我们的SEO指南以进一步提高网站排名",
            ],
            "Editor|Recommended": ["推荐"],
            "Editor|Recommended fonts": ["推荐字体"],
            "Editor|Recommended format: Transparent PNG. (Max filesize: %{storageSize}MB)":
              ["推荐格式：透明PNG（最大文件大小：%{storageSize}MB）。"],
            "Editor|Reconnect & Save": ["重新连接并保存"],
            "Editor|Reconnecting...": ["重试中"],
            "Editor|Recurring Weekly Hours": ["每周固定时间段"],
            "Editor|Recurring payment for site hosting.": [
              "为网站托管定期付款",
            ],
            "Editor|Redo": ["重做"],
            "Editor|Reference URLs": ["参考网址"],
            "Editor|Reference URLs (Optional)": ["参考网址（可选）"],
            "Editor|Reference URLs (up to %{maxLength})": [
              "参考网址（最多%{maxLength}个）",
            ],
            "Editor|Reference URLs will only be used as guidelines. The content/design of references will not be copied.":
              ["参考网址仅用作指导。不会复制参考的内容/设计"],
            "Editor|Reference URLs will only be used to help learn the best structure for your site. The content/design of references will not be copied.":
              [
                "参考网址仅用于帮助学习您网站的最佳结构，不会复制参考的内容/设计。",
              ],
            "Editor|Regenerate": ["AI改写"],
            "Editor|Regenerate 5 titles": ["重写5个标题"],
            "Editor|Regenerate Content": ["重写内容"],
            "Editor|Regenerate Entire Page": ["重新生成整个页面"],
            "Editor|Regenerate Heading": ["重写段落标题"],
            "Editor|Regenerate Image": ["重新生成图片"],
            "Editor|Regenerate Section": ["重新生成版块"],
            "Editor|Regenerate Sections": ["重新生成版块"],
            "Editor|Regenerate Subheading": ["重写段落小节标题"],
            "Editor|Regenerate Subheadings": ["重写所有段落小节标题"],
            "Editor|Regenerate a new image description.": [
              "重新生成新的图片描述",
            ],
            "Editor|Regenerate a new page description": [
              "重新生成新的页面描述",
            ],
            "Editor|Regenerate a new section description": [
              "重新生成新的版块描述",
            ],
            "Editor|Regenerate all headings and subheadings": [
              "重新生成所有的段落标题和段落小节标题",
            ],
            "Editor|Regenerate site structure": ["重新生成网站结构"],
            "Editor|Regenerate text": ["AI改写文本"],
            "Editor|Regenerate the entire outline": ["重新生成大纲"],
            "Editor|Region Options": ["地区选项"],
            "Editor|Region Price": ["地区价格"],
            "Editor|Region Rules": ["地区规则"],
            "Editor|Region price, e.g. $15.00": ["地区价格，例如：$15.00"],
            "Editor|Register a new domain from Namecheap": [
              "从Namecheap注册一个新的域名。",
            ],
            "Editor|Rejected": ["未通过"],
            "Editor|Related keyword to be included in your post for bonus traffic.":
              ["用于包含在文章里以获取额外流量的相关关键词。"],
            "Editor|Reload Captcha": ["重新加载验证码"],
            "Editor|Reload Editor": ["重新加载编辑器"],
            "Editor|Reload Your Editor": ["请重新加载你的编辑器"],
            "Editor|Remember, you can add all kinds of content to your site!": [
              "别忘记，你可以在你的网站上添加各种内容!",
            ],
            "Editor|Remember, you can connect a custom domain to skip this review step and publish immediately!":
              ["别忘记你可以通过绑定自定义域名来跳过审核，立即发布！"],
            "Editor|Remove": ["移除"],
            "Editor|Remove SXL branding": ["移除“上线了”广告标识"],
            "Editor|Remove Strikingly branding": ["移除Strikingly广告标识"],
            "Editor|Remove all current titles and regenerate 5 titles.": [
              "移除所有当前标题并重新生成5个标题。",
            ],
            "Editor|Remove ownership": ["移除拥有权"],
            "Editor|Remove title": ["删除标题"],
            "Editor|Removing the title, you will not be able to continue generating new content.":
              ["删除标题后，你将无法继续生成新的内容。"],
            "Editor|Rename": ["重命名"],
            "Editor|Rename this dropdown": ["重命名下拉菜单"],
            "Editor|Rename this page": ["重命名页面"],
            "Editor|Repeated Elements": ["重复元素组合"],
            "Editor|Replace the current site’s content and styles with this previous version":
              ["使用该历史版本替换当前版本的内容与样式"],
            "Editor|Request quote button": ["询盘按钮"],
            "Editor|Request quote for item: %{var1}": ["询求项目报价：%{var1}"],
            "Editor|Require country code": ["要求国家/地区代码"],
            "Editor|Requires certification from Legal Person and Mini Program administrator":
              ["等待法人和小程序管理员认证"],
            "Editor|Requiring country code helps ensure your visitors are reachable worldwide.":
              ["要求国家/地区代码有助于确保您的访客可以在全球范围内访问。"],
            "Editor|Reset": ["重置"],
            "Editor|Reset Space": ["重置边距"],
            "Editor|Resident ID Card number is incorrect. It must match the real-name information of the WeChat account owner":
              [
                "身份证号不正确。填写的身份证号信息需要与微信号的实名信息对应上",
              ],
            "Editor|Responses will automatically be sent to [listName]": [
              "表单数据将发送到 [listName]",
            ],
            "Editor|Restore": ["恢复"],
            "Editor|Restore version from %{var1}? Note: Store products and blog posts will not be restored! You can show/hide store products separately, and publish/unpublish blog posts separately.":
              [
                "确定要恢复到%{var1}这个版本吗？请注意：商店产品和博客文章将不会被恢复！你可单独显示/隐藏商店产品，并单独发布/取消发布博客文章。",
              ],
            "Editor|Restoring the site is only available for Pro users.": [
              "恢复至历史版本仅限专业版用户使用",
            ],
            "Editor|Restrict your visitors from seeing these details until they submit the form.":
              ["限制访客在提交表单之前不能看到这些详细信息。"],
            "Editor|Restricted Details": ["限制详细信息"],
            "Editor|Retry": ["重试"],
            "Editor|Return to Add Images": ["返回添加图片"],
            "Editor|Revert to Single Page": ["恢复至单页面网站"],
            "Editor|Reverting": ["恢复中"],
            "Editor|Review & Select Logo": ["检查并选择Logo"],
            "Editor|Review Site Results": ["查看网站结果"],
            "Editor|Review Site Structure": ["检查网站结构"],
            "Editor|Review full article": ["查看全文"],
            "Editor|Review the site": ["查阅网站内容"],
            "Editor|Reviewing": ["审核中"],
            "Editor|Right": ["居右"],
            "Editor|Round": ["圆弧型"],
            "Editor|Rounded": ["圆角"],
            "Editor|Rows": ["横排"],
            "Editor|S": ["小"],
            "Editor|SAT": ["星期六"],
            "Editor|SEO Settings": ["SEO设置"],
            "Editor|SEO related content": ["搜索引擎优化相关内容"],
            "Editor|SEO settings": ["SEO 设置"],
            "Editor|SSL certificate installed. %{currentDomain} is now served via HTTPS.":
              ["SSL证书已安装。%{currentDomain} 现在可以通过HTTPS协议访问。"],
            "Editor|STYLES lets you plan with the look and feel of the site.": [
              "在 “风格” 里你可以改变网站的外观和整体样式。",
            ],
            "Editor|SUN": ["星期日"],
            "Editor|Same URL for all items": ["所有项目使用相同链接"],
            "Editor|Sample": ["示例"],
            "Editor|Save": ["保存"],
            "Editor|Save & Go To Set Up": ["保存并前往设置"],
            "Editor|Save & Regenerate": ["保存并重新生成"],
            "Editor|Save Changes?": ["保存更改？"],
            "Editor|Save Layout": ["保存布局"],
            "Editor|Save Logo": ["保存Logo"],
            "Editor|Save draft": ["保存草稿"],
            "Editor|Save now": ["立即保存"],
            "Editor|Save the current logo design as draft? You can find it again in your site's navigation bar.":
              [
                "是否要保存当前的logo设计为草稿？你可以在你网站的导航栏中再次找到它。",
              ],
            "Editor|Saved %{minutes} min ago.": ["%{minutes}分钟前保存"],
            "Editor|Saved 1 min ago.": ["1分钟前保存"],
            "Editor|Saved just now.": ["已保存"],
            "Editor|Scan the QR code using WeChat, follow the official account,":
              ["使用微信扫码并关注公众号，"],
            "Editor|Scan to Preview": ["扫码预览"],
            "Editor|Scan to preview my Mini Program": ["扫码试用小程序"],
            "Editor|Scanned successfully. Please continue your process on WeChat.":
              ["扫描成功。请在微信端继续完成操作。"],
            "Editor|Scheduled": ["预约列表"],
            "Editor|Section": ["版块"],
            "Editor|Section Height": ["版块高度"],
            "Editor|Section Type:": ["版块类型"],
            "Editor|Section Width": ["版块宽度"],
            "Editor|Sections": ["版块"],
            "Editor|See More Images": ["查看更多图片"],
            "Editor|See how your site's page will appear in Google. (The format and content may vary depending on the search terms.)":
              [
                "查看你的网站主页将如何在Google中显示（搜索结果的格式和内容可能会根据搜索词而有所不同。）",
              ],
            "Editor|Select & View": ["选择并查看"],
            "Editor|Select All": ["选中所有页面"],
            "Editor|Select Color Scheme": ["选择配色方案"],
            "Editor|Select Decoration": ["选择装饰"],
            "Editor|Select Font": ["选择字体"],
            "Editor|Select Icon": ["选择图标"],
            "Editor|Select Icon & Design": ["选择图标和设计"],
            "Editor|Select Icon & Style": ["选择图标和样式"],
            "Editor|Select Keyword Difficulty": ["选择关键词难度"],
            "Editor|Select Layout": ["选择布局"],
            "Editor|Select Logo Design": ["选择Logo设计"],
            "Editor|Select Main Font": ["选择主字体"],
            "Editor|Select New Language": ["选择要新增的语言"],
            "Editor|Select Page": ["选择页面"],
            "Editor|Select Section": ["选择版块"],
            "Editor|Select Site Features": ["选择网站功能"],
            "Editor|Select Tagline Font": ["选择标语字体"],
            "Editor|Select Text Position": ["选择文本位置"],
            "Editor|Select Text Style": ["选择文本样式"],
            "Editor|Select Theme": ["选择主题"],
            "Editor|Select Trigger": ["选择触发条件"],
            "Editor|Select a Domain": ["选择一个域名"],
            "Editor|Select a Site": ["选择网站"],
            "Editor|Select a color scheme": ["选择配色方案"],
            "Editor|Select a domain": ["选择一个域名"],
            "Editor|Select a logo design, then continue to generate your site structure.":
              ["选择一个Logo设计，然后继续生成你的网站结构。"],
            "Editor|Select a package. Once your purchase is complete, you'll be able to download the full logo package.":
              ["选择套餐。购买完成后，你将能够下载完整的Logo文件。"],
            "Editor|Select a style to edit & publish. You can change this later.":
              ["选择要编辑和发布的风格。你可以稍后更改。"],
            "Editor|Select a target keyword": ["选择目标关键词"],
            "Editor|Select a title": ["选择标题"],
            "Editor|Select an option": ["选择一个选项"],
            "Editor|Select column structure": ["选择列布局"],
            "Editor|Select country/region": ["选择国家/地区"],
            "Editor|Select extra keywords": ["选择额外关键词"],
            "Editor|Select here": ["选择语言"],
            "Editor|Select how to add the %{var1} version:": [
              "选择添加%{var1}版本的方式：",
            ],
            "Editor|Select how to add the new language version:": [
              "选择添加新语言版本的方式：",
            ],
            "Editor|Select images to delete:": ["选择要删除的图片："],
            "Editor|Select item": ["选择项目"],
            "Editor|Select one to replace the current text:": [
              "选择下列文本替换当前文本：",
            ],
            "Editor|Select pages": ["选择页面"],
            "Editor|Select pages...": ["选择页面..."],
            "Editor|Select products": ["选择商品"],
            "Editor|Select the %{var1} version from your existing sites or add an external URL:":
              ["从已有的网站中选择一个，或添加一个外部的网站作为%{var1}版本："],
            "Editor|Select tiers": ["选择会员等级"],
            "Editor|Select which fields to collect when registering as a new member.":
              ["选择会员注册时要收集的信息。"],
            "Editor|Select...": ["选择"],
            "Editor|Sell paid membership subscriptions.": [
              "销售付费会员订阅。",
            ],
            "Editor|Sell products or services online.": [
              "在线销售产品或服务。",
            ],
            "Editor|Sell products right on your site! Manage orders, payments, and more.":
              ["在你的网站上轻松销售商品，管理订单、收款方式，等等。"],
            "Editor|Send Inquiry": ["发送询盘"],
            "Editor|Send Inquiry Now": ["立即发送询盘"],
            "Editor|Send Time After Trigger": ["触发后的发送时机"],
            "Editor|Send an email when a user…": [
              "当访客做以下动作时发送邮件：",
            ],
            "Editor|Send automated emails to customers who have added items into their cart but have not yet purchased.":
              ["给购物车里有未结账商品的顾客自动发送挽回邮件。"],
            "Editor|Send me a link": ["发链接给我"],
            "Editor|Sending from a free email address is likely to be marked as spam. To improve deliverability, we will change your From Email to %{var1}. Replies from the recipient still go to your original email address. [link:Learn more].":
              [
                "使用免费邮箱发送邮件很可能被标记为垃圾邮件。为了提高送达率，我们会将您的发件人邮箱改为%{var1}。收件人的回复仍会发送到你原本的邮箱中。[link:了解更多]。",
              ],
            "Editor|Sent when attendee’s booking is confirmed": [
              "在已预约后发送",
            ],
            "Editor|Sent when you have a new booking": ["在有新的预约时发送"],
            "Editor|Sent when you issue a booking cancellation": [
              "在你取消预约后发送",
            ],
            "Editor|Separate fields for First and Last Name": [
              "使用独立的字段分别收集姓氏和名字",
            ],
            "Editor|Separator": ["分割线"],
            "Editor|Set a name to distinguish this form from other forms. This will not be shown to your site visitors!":
              [
                "通过设置标题来帮你区分识别多个不同的表单。表单标题不会展示给网站的访客！",
              ],
            "Editor|Set a password": ["设置密码"],
            "Editor|Set a trigger and send automated emails to your site audience.":
              ["设置触发条件并向网站粉丝发送自动回复邮件。"],
            "Editor|Set a trigger for email automation.": [
              "为自动回复邮件设置触发条件",
            ],
            "Editor|Set as Required": ["设置为必填项"],
            "Editor|Set as members-only": ["设置为仅限会员"],
            "Editor|Set buttons individually for each item in [link:Portfolio - Items].":
              ["在[link:项目展示 - 项目]中为每个项目单独设置按钮。"],
            "Editor|Set how long the event lasts (up to 4 hours).": [
              "设置单个预约占用的时长（最大支持4小时）",
            ],
            "Editor|Set the focus of the image:": ["设置图片的焦点位置"],
            "Editor|Set up Payment Methods": ["设置支付方式"],
            "Editor|Set which currency to display your item prices in.": [
              "设置以什么货币展示你的项目价格。",
            ],
            "Editor|Set your availability for each day of the week.": [
              "设置每周每天的可预约时间",
            ],
            "Editor|Set your availability for specific dates.": [
              "不重复，设置某些特定时间",
            ],
            "Editor|Settings": ["设置"],
            "Editor|Shape": ["形状"],
            "Editor|Share": ["分享"],
            "Editor|Shipping Info": ["收货信息"],
            "Editor|Short Text": ["短文本"],
            "Editor|Short snippet": ["短导语"],
            "Editor|Show Advanced Settings": ["显示高级设置"],
            "Editor|Show Button": ["显示按钮"],
            "Editor|Show Buttons": ["显示按钮"],
            "Editor|Show Mobile Notifications When Receiving a Chat": [
              "收到聊天时显示手机通知",
            ],
            "Editor|Show On Pages": ["在下列页面显示"],
            "Editor|Show Titles": ["显示标题"],
            "Editor|Show a button for each item. Customize the button URL, or use the Request Quote button to collect contact info from visitors interested in a specific item.":
              [
                "为每个项目显示一个按钮。可以自定义按钮链接，或使用“询盘”按钮以收集对特定项目感兴趣的访客的联系方式。",
              ],
            "Editor|Show after 10 seconds": ["10秒钟后弹出"],
            "Editor|Show after 20 seconds": ["20秒钟后弹出"],
            "Editor|Show after 5 seconds": ["5秒钟后弹出"],
            "Editor|Show all": ["显示全部"],
            "Editor|Show category tabs": ["显示分类导航"],
            "Editor|Show for all": ["显示"],
            "Editor|Show for all visitors": ["展示给所有访客"],
            "Editor|Show immediately": ["立即弹出"],
            "Editor|Show in navigation": ["在导航栏中显示此页面"],
            "Editor|Show less": ["显示更少"],
            "Editor|Show more": ["显示更多"],
            "Editor|Show only for EU visitors": ["仅展示给欧盟访客"],
            "Editor|Show only on desktop": ["只在电脑端显示"],
            "Editor|Show only on mobile": ["只在手机端显示"],
            "Editor|Show price as text": ["显示文本形式的价格"],
            "Editor|Show price with currency": ["显示带有币种的价格"],
            "Editor|Show product rating": ["展示商品评分"],
            "Editor|Show text in an accordion format.": [
              "以手风琴格式显示文本。",
            ],
            "Editor|Show the editor panel": ["显示编辑器面板"],
            "Editor|Show video covers": ["显示视频封面"],
            "Editor|Show when scroll to end of page": ["滚动到页面底部时弹出"],
            "Editor|Show when scroll to middle of page": [
              "滚动到页面中间时弹出",
            ],
            "Editor|Show your address and location.": ["显示你的地址和位置。"],
            "Editor|Show your plans, prices, and benefits.": [
              "展示你的套餐、价格和优势。",
            ],
            "Editor|Shown only on desktop": ["只在电脑端显示"],
            "Editor|Shown only on mobile": ["仅在移动设备上显示"],
            "Editor|Sign Up": ["报名"],
            "Editor|Sign Up Form": ["报名表单"],
            "Editor|Sign up Form": ["注册表单"],
            "Editor|Sign up for a creative consultation": ["注册创意咨询"],
            "Editor|Signup Form": ["注册表"],
            "Editor|Simple Blog": ["简易博客"],
            "Editor|Simple Blog %{var}": ["简易博客 %{var}"],
            "Editor|Simple Store": ["简易商店"],
            "Editor|Simple store and portfolio": ["简易商店和产品展示"],
            "Editor|Simultaneous Editing": ["同步编辑"],
            "Editor|Single field for Name": ["使用一个字段收集姓名"],
            "Editor|Single-Page Site": ["单页面网站"],
            "Editor|Site Category (Optional)": ["网站类别（可选）"],
            "Editor|Site Description": ["网站描述"],
            "Editor|Site Format": ["网站格式"],
            "Editor|Site Hosting Plan": ["网站托管套餐"],
            "Editor|Site Keywords": ["网站关键词"],
            "Editor|Site Keywords (Optional)": ["网站关键词（可选）"],
            "Editor|Site Language": ["网站语言"],
            "Editor|Site Logo": ["网站Logo"],
            "Editor|Site Membership & members-only pages": [
              "会员功能 & 会员页",
            ],
            "Editor|Site Membership is a Pro feature": [
              "网站会员属于专业版功能",
            ],
            "Editor|Site Membership with Multiple Tiers is a VIP feature": [
              "多等级会员系统属于VIP版功能",
            ],
            "Editor|Site Name": ["网站名称"],
            "Editor|Site Name or Business/Organization Name": [
              "网站名称或企业/组织名称",
            ],
            "Editor|Site Search is only available for Pro users and above . Please upgrade to unlock this feature.":
              ["站内搜索属于专业版及以上套餐功能，请升级以解锁此功能。"],
            "Editor|Site Title": ["网站标题"],
            "Editor|Site URL": ["网站地址"],
            "Editor|Site membership, form responses, live chat, and more": [
              "会员功能，表单回复，在线聊天，还有更多功能",
            ],
            "Editor|Site name is too short": ["网站名称太短了"],
            "Editor|Site plan package - $%{priceText}/Year": [
              "网站套餐 - $%{priceText}/年",
            ],
            "Editor|Site title, e.g. your business/organization name": [
              "网站标题，例如：你的企业/组织名称",
            ],
            "Editor|Sitemap is pending to be fetched. This may take anywhere from several minutes to a few days. You can also submit it to Google again.":
              [
                "网站地图正在等待被读取。这可能需要几分钟或几天的时间，请耐心等待。你也可以再次将其提交给Google。",
              ],
            "Editor|Sitemap submitted successfully.": ["网站地图成功提交。"],
            "Editor|Skip adding links": ["跳过添加链接"],
            "Editor|Skip for Now & Send Email Directly": [
              "暂时跳过 & 直接发送邮件",
            ],
            "Editor|Slant": ["斜线型"],
            "Editor|Slide": ["滑块"],
            "Editor|Slide In": ["滑入"],
            "Editor|Slideshow": ["幻灯片"],
            "Editor|Small": ["小"],
            "Editor|Small Rounded": ["小圆角"],
            "Editor|Small Shadow": ["弱阴影"],
            "Editor|Small circle": ["圆形"],
            "Editor|Small square": ["方形"],
            "Editor|Snippet": ["导语"],
            "Editor|Social feed": ["社交动态"],
            "Editor|Solid": ["填充颜色"],
            "Editor|Some information is incorrect. Please check it and try again.":
              ["某些信息不正确。请检查并重试。"],
            "Editor|Something went wrong. Please try again later.": [
              "出现了一些问题。请稍后重试。",
            ],
            "Editor|Sorry, something went wrong. Please try again.": [
              "对不起，出了一些问题。请重试。",
            ],
            "Editor|Sorry, we couldn't find any target keywords based on your input. Please back to previous page and try one of the following:":
              [
                "很抱歉，根据你的输入，我们没有找到任何目标关键词。请返回上一页并尝试以下方法：",
              ],
            "Editor|Sort:": ["排序"],
            "Editor|Spacer": ["空白间隔"],
            "Editor|Spacing": ["间距"],
            "Editor|Specific form": ["指定表单"],
            "Editor|Specific product": ["指定商品"],
            "Editor|Specific tier": ["指定会员等级"],
            "Editor|Spreadsheet": ["电子表格"],
            "Editor|Square": ["方形"],
            "Editor|Square - 1:1": ["方形 - 1:1"],
            "Editor|Standard - 3:2": ["标准 - 3:2"],
            "Editor|Standard Portrait - 2:3": ["标准纵向 - 2:3"],
            "Editor|Start 7-Day Audience Plan Trial": [
              "开启营销套餐7天免费试用吧",
            ],
            "Editor|Start Editing": ["开始编辑"],
            "Editor|Starter Subscription": ["入门会员"],
            "Editor|Sticky Nav": ["吸顶效果"],
            "Editor|Store - Product Categories is a Pro feature": [
              "商城—商品分类属于专业版功能",
            ],
            "Editor|Store / E-commerce": ["商店/电子商务"],
            "Editor|Strikingly account password": ["Strikingly账号密码"],
            "Editor|Strikingly's branding appears at the bottom of the page and in the footer of emails sent to visitors.":
              ["上线了的品牌标示显示在页面底部以及发送给访客的邮件的页脚。"],
            "Editor|Structure": ["结构"],
            "Editor|Style": ["样式"],
            "Editor|Styles": ["风格"],
            "Editor|Styles (Optional)": ["风格（选填）"],
            "Editor|Subheading": ["段落小节标题"],
            "Editor|Submit": ["提交"],
            "Editor|Submit & View": ["提交并查看"],
            "Editor|Submit Button Text": ["提交按钮的文本"],
            "Editor|Submit a sitemap to let Google crawl all the pages of your site. If you add or delete pages, the sitemap will be automatically updated.":
              [
                "提交网站地图以让Google爬取网站的所有页面。如果添加或删除页面，网站地图将自动更新。",
              ],
            "Editor|Submit again": ["重新提交"],
            "Editor|Submit button text:": ["提交按钮文本："],
            "Editor|Submit sitemap": ["提交网站地图"],
            "Editor|Submit your site to Google and get indexed faster": [
              "将你的网站提交给Google并更快地建立索引",
            ],
            "Editor|Submits a form response": ["提交一个表单"],
            "Editor|Submits a form response to": ["提交表单"],
            "Editor|Subscribes to your blog": ["订阅你的博客"],
            "Editor|Subscription is disabled in this preview. Please try on your live site.":
              ["预览模式暂不支持订阅功能。请前往实际网站进行体验。"],
            "Editor|Subtitle": ["副标题"],
            "Editor|Successfully connected to Google Search Console!": [
              "你已成功连接到Google Search Console!",
            ],
            "Editor|Swap Layout": ["更换布局"],
            "Editor|Swap primary/secondary": ["调换主色调／副色调"],
            "Editor|Switch Templates": ["切换模版"],
            "Editor|Switch layout for this section": ["更改此版块的布局"],
            "Editor|Switch to desktop editor to edit the custom form": [
              "编辑自定义表单需切换至电脑端编辑器",
            ],
            "Editor|Switch to the new editor!": ["切换至新版！"],
            "Editor|Switch to the old version": ["切换回旧版"],
            "Editor|Switch to this template!": ["切换至此模板"],
            "Editor|Switching...": ["切换中"],
            "Editor|THU": ["星期四"],
            "Editor|TUE": ["星期二"],
            "Editor|Tagline Text": ["标语文本"],
            "Editor|Tagline Text Color": ["标语文本颜色"],
            "Editor|Tall - 9:16": ["高瘦 - 9:16"],
            "Editor|Target Audience Location": ["目标受众所在地"],
            "Editor|Target Keyword": ["目标关键词"],
            "Editor|Target Keyword (only one)": ["目标关键词（仅限一个）"],
            "Editor|Target Keywords": ["目标关键词"],
            "Editor|Target keyword is the focus of the entire blog post, and it's the topic we'll use to generate all of the text content.":
              [
                "目标关键词是整篇博客文章的焦点，也是我们用来生成所有文本内容的主题。",
              ],
            "Editor|Tech": ["科技"],
            "Editor|Tell us a bit about your business and we'll do the rest.": [
              "告诉我们你的业务，其余都交给我们。",
            ],
            "Editor|Tell us a bit about your business and we'll generate logos for you to choose from.":
              ["向我们介绍一下你的业务，我们将生成Logo供你选择。"],
            "Editor|Tell us what you want to write about, and our AI will find the best search keywords for getting traffic. Then we'll write an original SEO-optimized article (up to 3000 words) in minutes.":
              [
                "告诉我们你想写什么内容，我们的AI智能写手会根据算法给你推荐最佳的搜索关键词，帮你获得流量，并在几分钟内写出一篇原创的SEO博客文章(3000字封顶)。",
              ],
            "Editor|Templates failed to load.": ["模板加载失败"],
            "Editor|Templates, fonts, colors and more": [
              "模板、字体、颜色以及更多",
            ],
            "Editor|TencentYun": ["腾讯云"],
            "Editor|Text": ["文本"],
            "Editor|Text & Fonts": ["文案 & 字体"],
            "Editor|Text Alignment": ["文本对齐"],
            "Editor|Text Case": ["文本大小写"],
            "Editor|Text Format": ["文本格式"],
            "Editor|Text Format...": ["文本格式……"],
            "Editor|Text Highlight Color": ["文本高亮颜色"],
            "Editor|Text Highlight Selection": ["文本高亮适用范围"],
            "Editor|Text In Box": ["信息框"],
            "Editor|Text Size & Color": ["文字大小和颜色"],
            "Editor|Thank you for signing up! Please feel free to contact us if you have any questions.":
              ["感谢你注册成为会员！如果你有任何问题，请随时与我们联系。"],
            "Editor|Thank you for your booking!": ["感谢你的预约！"],
            "Editor|Thank you for your order! If you have any questions about the products, please feel free to contact us.":
              ["感谢你的订单！如果你对商品有任何问题，请随时与我们联系。"],
            "Editor|Thanks for subscribing to our blog! Please feel free to contact us if you have any questions.":
              ["感谢你订阅我们的博客！如果你有任何问题，请随时与我们联系。"],
            "Editor|Thanks for your submission!": ["感谢你的留言"],
            "Editor|The %{var1} version of this site will be created by cloning the current site and auto-translating its text content. Select which parts of the site to auto-translate.":
              [
                "这个网站的%{var1}版本将以复制当前网站并自动翻译其文本内容的方式创建。请选择要自动翻译的部分。",
              ],
            "Editor|The Mini Program is being edited!": ["小程序正在被编辑中"],
            "Editor|The SSL certificate for this domain could not be installed due to a problem with the DNS CAA records. To resolve this, please either [link: read these detailed instructions] or reach out to us for support.":
              [
                "由于证书颁发机构认证（CAA）出现问题，SSL证书无法安装。要解决此问题，请[link: 参考本说明]或联系我们的客服团队。",
              ],
            "Editor|The SSL certificate for this domain could not be installed due to an error. Please reach out to us for support.":
              ["由于发生错误，SSL证书无法安装。请联系我们的客服团队。"],
            "Editor|The [bold:target keyword] is the search term that you want to focus on getting traffic from. Each post can only have one target keyword, and we'll write your post about this keyword. We've generated 10 low-difficulty keywords with quality traffic for you pick from.":
              [
                "[bold:目标关键词]是你希望在搜索引擎中获得高流量的词语。每篇文章只能专注于一个目标关键词，我们会围绕该关键词为你撰写文章。我们提供了10个低难度且能带来高流量的关键词供你选择。",
              ],
            "Editor|The above methods not working? [link: Authenticate manually via WeChat platform] (300RMB/year).":
              [
                "以上方法都不行？[link:前往微信公众平台注册]，手动进行微信认证（认证费用300元/年）",
              ],
            "Editor|The address already exists.": ["地址已经存在"],
            "Editor|The cart icon will appear if you have connected a valid payment gateway and you have multiple products for sale.":
              [
                "只有设置了支付方式并有多个商品在售卖中，才会显示购物车图标哦。",
              ],
            "Editor|The cloning process for current site has failed. Please try again later or [link:contact support] for help.":
              ["复制当前网站失败。请稍后再试或[link:联系客服]。"],
            "Editor|The current site will be cloned, and you must manually translate it into %{var1}. The clone process can take up to several minutes if you have a lot of content. We will notify you once it is done.":
              [
                "当前网站会被复制，然后你需要手动把它翻译成%{var1}。如果你的网站有很多内容，这个过程可能会花费几分钟的时间。复制完成后我们会通知你。",
              ],
            "Editor|The difficulty of ranking high on search results for this keyword. Scale from 1-100, and lower the easier.":
              [
                "该关键词在搜索结果中排名靠前的难度。从1-100，越低越容易排名靠前。",
              ],
            "Editor|The event is cancelled successfully!": ["该预约已取消成功"],
            "Editor|The new password cannot be the same as the existing password.":
              ["新密码不可与现用密码相同。"],
            "Editor|The passwords you entered do not match": [
              "两次输入的密码不一致",
            ],
            "Editor|The previous connection is no longer valid since your site address has changed. Please click the button below to reconnect your site and submit a new sitemap.":
              [
                "由于你的网站地址已更改，之前的连接已不再有效。请点击下面的按钮重新连接你的网站并提交新的网站地图。",
              ],
            "Editor|The site version from %{var1} has been restored.": [
              "已经恢复到 %{var1} 版本。",
            ],
            "Editor|The time when this sitemap was last submitted to Google. We automatically resubmit the sitemap whenever it's updated.":
              [
                "此网站地图最近一次提交给Google的时间。每当网站地图有更新时，我们都会自动重新提交。",
              ],
            "Editor|The title of your site. We suggest using your business/organization name.":
              ["网站的标题。我们建议使用你的企业/组织名称。"],
            "Editor|The value of this record is incorrect. The current value is %{current_record_value}, and you need to replace it with %{value}.":
              [
                "该记录的值不正确。当前的值是%{current_record_value} ，你需要用%{value}替换它。",
              ],
            "Editor|The values of this record is incorrect. The current values are %{wrong_value}. You need to replace one of them with %{value} and delete all others records with incorrect values.":
              [
                "该记录的值不正确。当前的值是%{wrong_value}。你需要用%{value}替换其中一个，并删除其他记录。",
              ],
            "Editor|There are conflicting values for this record. Please delete the records with values of %{wrong_value}, Keep %{value} as the only value for this record.":
              [
                "这条记录的数值有冲突。请删除那些值为%{wrong_value}的记录。请确保%{value}为该类记录的唯一值。",
              ],
            "Editor|There are no domains in your Namecheap account.": [
              "你的Namecheap帐户中没有域名。",
            ],
            "Editor|These fixed date hours will override any recurring weekly hours. On these dates, attendees can only select these override hours.":
              [
                "将覆盖每周固定时间段。添加日期后，你的访客将只能选择特定时间段进行预约。",
              ],
            "Editor|These sample events won’t be shown on your live site. And the samples will be removed when you add your own events.":
              [
                "这些示例不会显示在你的发布后的网站上。当你添加自己的服务后，这些示例服务将被删除。",
              ],
            "Editor|These sample posts won’t be shown on your live site. And the samples will be removed when you add your own posts.":
              [
                "这些示例不会显示在你的发布后的网站上。当你添加自己的博客文章后，这些示例文章将被删除。",
              ],
            "Editor|These sample products won’t be shown on your live site. And the samples will be removed when you add your own products.":
              [
                "这些示例不会显示在你的发布后的网站上。当你添加自己的商品后，这些示例商品将被删除。",
              ],
            "Editor|Thickness": ["粗细度"],
            "Editor|Thin": ["细"],
            "Editor|This URL is already taken": ["对不起，此域名已被使用了"],
            "Editor|This action is blocked for now. Please contact your Mini-Program owner to grant you permission to publish site changes.":
              [
                "暂时不可以进行此操作，请联系你的小程序所有者为你开通发布权限。",
              ],
            "Editor|This action is blocked for now. Please contact your site owner to grant you permission to publish site changes.":
              ["暂时不可以进行此操作，请联系你的网站所有者为你开通发布权限。"],
            "Editor|This article will link to %{articlesNum} related article.":
              ["本文将链接到%{articlesNum}篇相关文章。"],
            "Editor|This article will link to %{articlesNum} related articles.":
              ["本文将链接到%{articlesNum}篇相关文章。"],
            "Editor|This blog is hidden for now.": ["这篇博客文章已被隐藏。"],
            "Editor|This blog post is being edited": ["这篇博文正在被编辑"],
            "Editor|This button will open the Portfolio Visitor Form.": [
              "此按钮会打开产品展示访客表",
            ],
            "Editor|This command will only take effect when generating post body.":
              ["该指令仅在生成文章正文时生效。"],
            "Editor|This command will only take effect when generating post outline.":
              ["该指令仅在生成文章大纲时生效。"],
            "Editor|This command will only take effect when generating post title.":
              ["该指令仅在生成文章标题时生效。"],
            "Editor|This domain name format is incorrect. Please check again!":
              ["此域名格式不正确。请再次检查!"],
            "Editor|This domain seems to be connected to a different service or site. To connect this domain to this site, we’ll automatically update your DNS records, but this may affect existing connected services. Are you sure you want to connect this domain to this site?":
              [
                "这个域名似乎已连接到一个不同的服务或网站。要把这个域名连接到这个网站，我们会自动更新你的DNS记录，但这可能会影响现有的连接服务。你确定你要把这个域名连接到这个网站吗？",
              ],
            "Editor|This element is only available for Pro sites. Upgrade your account to unlock this element!":
              [
                "只有企业版/专业版用户能使用此元素。升级你的账号即可解锁此元素！",
              ],
            "Editor|This event was cancelled": ["此预约已被取消"],
            "Editor|This field is required": ["该字段为必填字段"],
            "Editor|This file format is not accepted.": ["不支持的文件格式。"],
            "Editor|This form will be shown when the visitor: [var1]. Add up to [var2] custom fields to collect email, phone, or other info from potential customers. (Visitors only need to fill form once.)":
              [
                "当访客：[var1]时，此表单会显示。你最多可以添加 [var2] 个自定义字段，用于收集潜在客户的邮箱、电话或其他信息。（访客只需要填写表单一次）",
              ],
            "Editor|This helps us set the right the calls-to-action on your site.":
              ["这有助于我们在你的网站上设置正确的CTA。"],
            "Editor|This image is too tall! Please upload a banner with a wider aspect ratio.":
              ["这张图片太高了！请上传宽高比为8:3的图片。"],
            "Editor|This is a Pro feature. You can try it out but will need to remove it before you publish the site.":
              ["仅限专业版使用，你可以试用，但是要在上线前删除掉"],
            "Editor|This is a legacy feature. Please set buttons uniformly for all items in [var3].":
              ["这是一个旧版功能。请在[var3]中为所有项目统一设置按钮。"],
            "Editor|This is an irreversible action! An email notification will be sent to this registered attendee about the cancellation. Are you sure you want to cancel this event?":
              [
                "取消预约后将无法恢复！已预约的参与人将收到一封取消预约的通知邮件。确定要取消这项预约吗？",
              ],
            "Editor|This is only a preview. Actual Google search results may differ from what is shown here.":
              ["预览仅供效果参考。实际搜索结果可能存在细微差异。"],
            "Editor|This is the description that displayed in the search result.":
              ["该描述将显示在搜索结果中。"],
            "Editor|This is the home page": ["网站的首页"],
            "Editor|This is used for SEO. Enter a list of your intended keywords (up to %{maxLength}).":
              [
                "输入你希望使用的关键词列表（最多 %{maxLength} 个）以用于搜索引擎优化。",
              ],
            "Editor|This is useful if you need to export this data in a format that requires separate first and last names.":
              [
                "如果您需要将这些数据导出到需要单独的名字和姓氏的格式中，请选择此项。",
              ],
            "Editor|This page is being edited": ["该页面正在被编辑"],
            "Editor|This page is hidden in the navigation menu": [
              "已在导航栏中隐藏此页面",
            ],
            "Editor|This page is only accessible to members who purchased a specific product.":
              ["本页面仅对购买了个别产品的会员开放"],
            "Editor|This page is only accessible to paid members.": [
              "本页面仅对付费会员开放",
            ],
            "Editor|This page is only accessible to site members.": [
              "本页面仅对本站会员开放",
            ],
            "Editor|This page is only accessible to specific membership tiers.":
              ["本页面仅对个别等级的会员开放"],
            "Editor|This page is password-protected.": ["本页面设有密码保护。"],
            "Editor|This record doesn’t exist. In your DNS settings, you must add a CNAME record with the correct name and value.":
              [
                "此记录不存在。在你的DNS设置中，你必须添加一个具有正确名称和值的CNAME记录。",
              ],
            "Editor|This record doesn’t exist. In your DNS settings, you must add an A record with the correct name and value.":
              [
                "此记录不存在。在你的DNS设置中，你必须添加一个具有正确名称和值的A记录。",
              ],
            "Editor|This record is setup correctly already!": [
              "这条记录已经设置正确了!",
            ],
            "Editor|This record was not found in the DNS settings for %{domain}. You must add a TXT record with the correct name and value. (If you've already added this, click the button to check again.)":
              [
                "在%{domain}的DNS设置中没有找到此记录。你必须添加具有正确名称和值的TXT记录。（如果你已经添加，点击按钮再次检查。）",
              ],
            "Editor|This section does not include online payments. If you want to take payments, please use the Store section instead.":
              ['该版块不包含支付功能。如果您想接受付款，请使用 "商店"版块。'],
            "Editor|This section has been customized! Reset this section to start over with the original layout and content.":
              ["此板块已经被自定义设置！重置此板块以恢复原始布局和内容。"],
            "Editor|This section is hidden for desktop & mobile view.": [
              "该版块在电脑&手机端均已隐藏。",
            ],
            "Editor|This section is hidden.": ["该版块已隐藏显示。"],
            "Editor|This section is only available for Pro sites. Upgrade your account to unlock this section!":
              [
                "只有企业版/专业版用户能使用此版块。升级你的账号即可解锁此版块！",
              ],
            "Editor|This section is only visible in desktop view and is hidden on mobile view.":
              ["该版块仅在电脑端可见，在手机端网站已隐藏显示。"],
            "Editor|This section is only visible in mobile view and is hidden on desktop view.":
              ["该版块仅在手机端可见，在电脑端网站已隐藏显示。"],
            "Editor|This site already has a Store section. Are you sure you want to add another Store section?":
              ["这个网站已经存在一个商城板块了。确定再添加其他商城板块吗？"],
            "Editor|This site editor is currently opened on another browser tab of yours. If you start editing here, the unsaved changes on the other tab will be lost! [strong:Are you sure you want to take over?]":
              [
                "此网站编辑器目前在你的另一个浏览器窗口中打开。如果在这里开始编辑，其他窗口中未保存的更改将丢失！[strong:确定要在这个窗口中接管吗？]",
              ],
            "Editor|This site has been deleted.": ["网站已删除"],
            "Editor|This site is currently using the following premium features:":
              ["该网站正在使用的付费功能如下："],
            "Editor|This site's logos": ["这个网站的Logo"],
            "Editor|This title will be displayed in search results.": [
              "该标题将显示在搜索结果中。",
            ],
            "Editor|This usually takes a few minutes. Large imports can take longer.":
              ["这通常会在几分钟内完成，较大的导入可能会需要更长时间。"],
            "Editor|Thumbnail": ["缩略图"],
            "Editor|Tiled": ["瀑布流"],
            "Editor|Time": ["时间"],
            "Editor|Time Delay": ["弹窗延时"],
            "Editor|Time delay will be applied to these pages.": [
              "弹窗延时将应用于下列页面。",
            ],
            "Editor|Time range must be at least as long as event duration (%{var1})":
              ["时间范围不可小于可预约时长 (%{var1})"],
            "Editor|Times overlap with another set of time": ["时间段存在重叠"],
            "Editor|Tip: Add mobile actions": ["Tip: Add mobile actions"],
            "Editor|Title": ["标题"],
            "Editor|Title Tag": ["博客元标题"],
            "Editor|Title Text": ["标题文本"],
            "Editor|To authenticate [italic:%{var1}] with Strikingly, you must [strong:log into your domain management console and add these entries to your DNS records.] [link:Read detailed instructions here].":
              [
                "如需认证域名[italic:%{var1}]，请登录[strong:进入你的域名管理中心并将下方的这些条目添加至你的DNS记录中。][link:点击阅读详细说明]。",
              ],
            "Editor|To comply with email regulations and avoid having your emails marked as spam or bounced, it's important to use a domain email address authenticated with DKIM. We highly recommend completing DKIM authentication before sending emails to ensure successful delivery.":
              [
                "为了遵守邮件法规并避免你的电子邮件被标记为垃圾邮件或被退回，使用经过DKIM身份验证的域名电子邮件地址很重要。我们强烈建议在发送电子邮件之前完成DKIM身份验证，以确保邮件成功发送。",
              ],
            "Editor|To edit your From Email, please go to [link:Settings - Email Notification].":
              ["要编辑你的发件人邮箱，请进入[link:设置-邮件提醒]。"],
            "Editor|To improve the SEO ranking of this post, we strongly recommend adding internal links in your related posts that link to this post. Here are the related posts that we can link to this article, and the keywords we’ll add the links on:":
              [
                "为了提高本文的SEO排名，我们强烈建议在相关的文章中添加链接以链接到本文。以下是我们可以链接到本篇文章的相关文章，以及我们将添加链接的关键词：",
              ],
            "Editor|To improve the SEO ranking of your entire blog, we strongly recommend adding internal links between this post and your related posts. Here are the related posts we recommend linking to within this newly generated article, and the keywords we’ll add the links on:":
              [
                "为了提高你整个博客的SEO排名，我们强烈建议在本文与相关文章之间添加内部链接。以下是我们建议在这篇新生成的文章中添加链接的相关文章，以及我们将添加链接的关键词：",
              ],
            "Editor|Today's total": ["今日总价"],
            "Editor|Tone Of Voice": ["语调"],
            "Editor|Tone of Voice": ["语调"],
            "Editor|Top": ["顶部"],
            "Editor|Top & Bottom": ["顶部 & 底部"],
            "Editor|Top Bar": ["顶部栏"],
            "Editor|Top Block": ["顶部方块"],
            "Editor|Top Center": ["顶部居中"],
            "Editor|Top Left": ["顶部居左"],
            "Editor|Top Radial": ["顶部散射"],
            "Editor|Top Right": ["顶部居右"],
            "Editor|Top Space": ["上边距"],
            "Editor|Transparent": ["透明"],
            "Editor|Trigger": ["触发条件"],
            "Editor|Try First, Register Later": ["先试用，后注册"],
            "Editor|Try another keyword.": ["尝试另一个关键词。"],
            "Editor|Turn on this option to keep using your saved commands in this post.":
              ["打开这个选项，在这篇文章中继续使用你已保存的指令。"],
            "Editor|Type": ["类型"],
            "Editor|URL can only contain lowercase letters, numbers and hyphens ('-').":
              ["域名只能用小写字母、数字和短横线 ('-')。"],
            "Editor|URL cannot begin or end with a hyphen ('-').": [
              "域名不能以短横线 ('-') 开头或结尾。",
            ],
            "Editor|URL is invalid (%{invalidUrls})": [
              "URL无效（%{invalidUrls}）",
            ],
            "Editor|URL must be between 3 and 63 characters.": [
              "域名只能有3到63个字符。",
            ],
            "Editor|URL to redirect to after submission": [
              "提交表单后跳转到此网址",
            ],
            "Editor|Uh oh! Something is wrong with the audience import. Please check if any error in imported data and try again, or contact support for assistance!":
              [
                "啊哦！粉丝导入出错了。请检查导入的数据是否有误并重试，或联系技术支持寻求帮助！",
              ],
            "Editor|Uh oh! The image failed to load. Please try again, or try another image.":
              ["图片在上传中出了问题，请重试，或试其他图片"],
            "Editor|Uh-oh, your content was not saved! Blog posts have a character limit of 60,000 characters. Please reduce your post length.":
              [
                "内容保存失败！文章内容最多支持60,000字符。请适当控制文章长度。",
              ],
            "Editor|Uh-oh, your content was not saved! Blog posts have a section limit of 500. Please reduce your post length.":
              [
                "内容保存失败！文章内容最多支持500个段落板块。请适当控制文章长度。",
              ],
            "Editor|Undo": ["撤销"],
            "Editor|Unhide": ["取消隐藏"],
            "Editor|Unpublished": ["未上线"],
            "Editor|Untitled Automation": ["未命名的自动邮件"],
            "Editor|Upcoming": ["即将开始"],
            "Editor|Update": ["更新"],
            "Editor|Update Color Scheme?": ["更新配色方案？"],
            "Editor|Upgrade For More": ["升级更多精彩"],
            "Editor|Upgrade Now": ["立即升级"],
            "Editor|Upgrade Now For A Free Domain": [
              "现在升级套餐即可获得免费域名",
            ],
            "Editor|Upgrade Now for 30% Off": ["立即升级尽享7折优惠"],
            "Editor|Upgrade To Pro": ["升级到专业版"],
            "Editor|Upgrade here!": ["点击升级"],
            "Editor|Upgrade now and get [strong:30% off ] for Pro Yearly and up!":
              [
                "现在升级到专业版包年套餐及以上，即可享受[strong:7折]套餐优惠！",
              ],
            "Editor|Upgrade now and get a [strong:free domain + 30% off] for Pro Yearly and up!":
              [
                "现在升级到专业版包年套餐及以上，即可享受[strong:免费域名+7折]套餐优惠！",
              ],
            "Editor|Upgrade now to get %{var1}%% OFF!": [
              "立即升级套餐尽享 %{var1} 折优惠！",
            ],
            "Editor|Upgrade to %{plan} & unlock features": [
              "升级至%{plan}解锁网站功能",
            ],
            "Editor|Upgrade to Audience Plan to add Live Chat": [
              "升级到营销版套餐即可添加在线聊天功能",
            ],
            "Editor|Upgrade to Continue": ["升级以继续"],
            "Editor|Upgrade to Generate More": ["升级以生成更多"],
            "Editor|Upgrade to Pro & Sell more products": [
              "升级到专业版以销售更多商品",
            ],
            "Editor|Upgrade to Pro & enable Categories": [
              "升级至专业版解锁商品分类功能",
            ],
            "Editor|Upgrade to Pro & enable Membership": [
              "升级至专业版解锁网站会员功能",
            ],
            "Editor|Upgrade to Pro to add more fields": [
              "升级到专业版以添加更多字段",
            ],
            "Editor|Upgrade to Pro to add more fields to collect visitor info (e.g. dropdown select, checkbox, radio, file upload, etc).":
              [
                "升级到专业版以添加更多字段来收集访客信息（例如下拉选择，多选，单选，文件上传等等）",
              ],
            "Editor|Upgrade to Pro to connect Twitter.": [
              "升级到Pro套餐以连接Twitter。",
            ],
            "Editor|Upgrade to Pro to get": ["升级专业版套餐后即享："],
            "Editor|Upgrade to Pro to sell more products": [
              "升级到专业版以销售更多商品",
            ],
            "Editor|Upgrade to VIP & Enable Membership with multiple tiers": [
              "升级至VIP套餐解锁多个会员等级",
            ],
            "Editor|Upgrade to VIP to Add & Sell unlimited products": [
              "升级到企业版以添加和销售无限数量的商品",
            ],
            "Editor|Upgrade to VIP to sell unlimited products": [
              "升级到企业版以销售无限数量的商品",
            ],
            "Editor|Upgrade to a yearly plan or above to get a free domain for a year.":
              ["升级到包年套餐或以上，可以获得一年的免费域名。"],
            "Editor|Upgrade to pro & Enable Pop-ups": [
              "升级至专业版套餐解锁推广弹窗",
            ],
            "Editor|Upgrade to unlock Pro features for your site! All plans come with a 14-day money-back guarantee, and you can cancel any time.":
              [
                "升级套餐即可解锁更多专业版功能！所有套餐均提供14天退款承诺，我们支持14天内无理由退订。",
              ],
            "Editor|Upgrade to unlock Pro features for your site! It’s free for 14 days, and you can cancel any time.":
              [
                "升级套餐即可解锁更多专业版功能！你可以免费体验14天，我们支持14天内无理由退订。",
              ],
            "Editor|Upgrade your account for custom domain, removing branding, custom code, and more!":
              [
                "升级套餐即可使用自定义域名，移除上线了logo，添加自定义代码等功能！",
              ],
            "Editor|Upload File": ["上传文件"],
            "Editor|Upload Image": ["上传图片"],
            "Editor|Upload ZIP file": ["上传ZIP文件"],
            "Editor|Upload a logo image with transparent background. (PNG file, max filesize: %{storageSize}MB)":
              [
                "上传透明背景的Logo图片。（PNG 文件，最大文件大小：%{storageSize}MB）",
              ],
            "Editor|Upload a logo image with white or transparent background. (Max filesize: %{storageSize}MB)":
              [
                "上传白色或透明背景的Logo图片。(最大文件大小：%{storageSize}MB）",
              ],
            "Editor|Upload alternate logo": ["上传 logo"],
            "Editor|Upload alternate logo for sticky nav": [
              "上传吸顶效果时的 Logo",
            ],
            "Editor|Upload any image and we'll grab colors automatically.": [
              "上传任何图片，我们会自动抓取颜色",
            ],
            "Editor|Upload logo image": ["上传Logo图片"],
            "Editor|Upload my own logo": ["上传自己的Logo"],
            "Editor|Upload your logo or generate a new logo": [
              "上传你的Logo，或生成一个新Logo",
            ],
            "Editor|Uploaded files will be saved to your site storage.": [
              "访客上传的文件会占用你的网站存储空间。",
            ],
            "Editor|Uploading: %{fileName} (%{percent}%%)": [
              "上传中: %{fileName} (%{percent}%%)",
            ],
            "Editor|Uppercase": ["全部大写"],
            "Editor|Use Default": ["使用默认设置"],
            "Editor|Use Square instead": ["改用Square"],
            "Editor|Use Strikingly Taiwan Payments instead": [
              "改用Strikingly台湾金流",
            ],
            "Editor|Use Stripe instead": ["改用Stripe"],
            "Editor|Use a computer to edit your Mini program": [
              "使用电脑编辑你的小程序",
            ],
            "Editor|Use a computer to edit your site": ["使用电脑编辑你的网站"],
            "Editor|Use a custom domain!": ["使用自定义域名！"],
            "Editor|Use custom item URL": ["使用自定义的项目网址"],
            "Editor|Use this setting to hide this section on desktop or mobile. Hidden sections will not appear on your live site.":
              [
                "支持针对电脑端或手机端隐藏某一版块。被设为隐藏后，该版块不会显示在实际发布的网站上。",
              ],
            "Editor|Use this setting to set the text color of the main navigation menu.":
              ["可以使用这个设置来调整导航栏的字体颜色"],
            "Editor|Use this text": ["使用选中文本"],
            "Editor|User %{name} has started editing %{postTitle} and you have been automatically exited. Your edits may overwrite each other. Please instruct the user to exit the editor before you enter.":
              [
                "用户%{name}已经开始编辑《%{postTitle}》，你已被自动退出。你们的编辑可能会互相覆盖。请提醒用户退出博客编辑器后再进入。",
              ],
            "Editor|User %{name} is currently editing %{postTitle}. Your edits may overwrite each other. Please instruct the user to exit the editor before you enter.":
              [
                "用户%{name}正在编辑《%{postTitle}》，你们的编辑可能会互相覆盖。请提醒用户退出博客编辑器后再进入。",
              ],
            "Editor|VIP Subscription": ["高级会员"],
            "Editor|Verification code": ["验证码"],
            "Editor|Verification code has been sent to %{var1}.": [
              "验证码已发送到%{var1}。",
            ],
            "Editor|Verification code incorrect. Please check and try again.": [
              "验证码错误。请检查并重试。",
            ],
            "Editor|Verification code incorrect. Please check it and try again.":
              ["验证码错误。请检查并重试。"],
            "Editor|Verified and owned by Google account %{var1} and other %{var2} accounts.":
              ["已由Google帐户 %{var1} 和其他 %{var2} 个帐户验证并拥有。"],
            "Editor|Verified and owned by Google account %{var1} and other 1 account.":
              ["已由Google帐户 %{var1} 和其他 1 个帐户验证并拥有。"],
            "Editor|Verified and owned by Google account %{var1}.": [
              "已由Google帐户 %{var1}验证并拥有。",
            ],
            "Editor|Verify": ["验证"],
            "Editor|Version history": ["版本历史记录"],
            "Editor|Vertical Align": ["垂直对齐"],
            "Editor|Vertical bottom-align": ["垂直底部对齐"],
            "Editor|Vertical middle-align": ["垂直居中对齐"],
            "Editor|Vertical top-align": ["垂直顶部对齐"],
            "Editor|Video": ["视频"],
            "Editor|View & connect with your customers": [
              "查看 & 连接你的客户/顾客",
            ],
            "Editor|View Price": ["查看价格"],
            "Editor|View Pricing and Upgrade": ["查看价格并升级"],
            "Editor|View advanced layout options.": ["查看高级布局设置"],
            "Editor|View all styles": ["查看所有风格"],
            "Editor|View custom domains": ["查看自定义域名"],
            "Editor|View editor only": ["仅浏览编辑器"],
            "Editor|View history": ["查看版本历史"],
            "Editor|View orders, products, and store settings": [
              "浏览订单、商品，设置商店",
            ],
            "Editor|View, filter, and manage your site’s customers and audience.":
              ["查看、过滤和管理您网站的客户和粉丝。"],
            "Editor|Visitor Region": ["访客地区"],
            "Editor|Visitor becomes a member": ["当访客注册为会员后"],
            "Editor|Visitor completes a purchase": ["当访客下单后"],
            "Editor|Visitor subscribes to blog": ["当访客订阅博客后"],
            "Editor|Visitors who submit forms or buy items on your site will appear here.":
              ["在你的网站上提交表格或购买物品的访问者将显示在这里。"],
            "Editor|WARNING: This will keep your home page and hide all other pages. Don't worry, you can always activate Multiple Pages again to restore them.\nAre you sure you wish to continue?":
              [
                "注意：恢复至单页面网站将只会保存首页，隐藏其它页面，你可以随时再次开启多页面网站，恢复被隐藏的其它页面\n确定恢复至单页面网站？",
              ],
            "Editor|WED": ["星期三"],
            "Editor|Want more control over layouts? Arrange components yourself!":
              ["想要自定义网站布局？试试自己排版吧"],
            "Editor|We automatically resubmit the sitemap whenever pages are added or removed. You can also manually submit it again if the updates are not appearing in Google.":
              [
                "每当添加或删除页面时，我们都会自动重新提交网站地图。如果更新没有出现在Google上，你也可以手动提交。",
              ],
            'Editor|We highly recommend using a computer for editing! Please enter the URL [url: "SXL.CN"] in your browser to access the desktop editor.':
              [
                '我们强烈建议你使用电脑进行编辑！请在浏览器中输入网址 [url: "SXL.CN"] 以进入桌面编辑器。',
              ],
            "Editor|We highly recommend using a computer for editing! We can send you a shortcut to this editor via email.":
              [
                "我们强烈建议你使用电脑进行编辑！我们可以通过邮件向你发送进入编辑器的快捷方式。",
              ],
            "Editor|We now support simultaneous editing for multiple teammates on the same site! Invite your teammates and edit sites together seamlessly.":
              [
                "我们现在支持多个团队成员在同一个网站上进行同步编辑了！邀请你的团队成员，一起无缝编辑网站。",
              ],
            "Editor|We recommend entering the best comparable sites as references. These references will help the AI learn the best structure for your site.":
              [
                "我们建议输入最佳的可比较网站作为参考。这些参考将帮助AI学习你网站的最佳结构。",
              ],
            "Editor|We strongly recommend entering the best comparable sites as references. These references will help the AI learn the best structure for your site.":
              [
                "我们强烈建议输入最佳的可比较网站作为参考。这些参考将帮助AI学习你网站的最佳结构。",
              ],
            "Editor|We'll never send emails without your permission.": [
              "没有你的许可的话，我们不会发送邮件。",
            ],
            "Editor|We'll show the top 10 keywords for KD %{sentenceValue}.": [
              "我们将展示KD范围%{sentenceValue}的前10个关键词。",
            ],
            "Editor|We're checking your domain authentication status. This can take up to 48 hours, and we'll notify you of the result by email.":
              [
                "我们正在检查你的域名身份验证状态。这可能需要48小时，我们将通过邮件通知你结果。",
              ],
            "Editor|We're checking your domain connection — this may take up to 30 seconds. Please wait a moment.":
              ["我们正在检查您的域名连接 - 这可能需要30秒的时间。请稍等片刻。"],
            "Editor|We're regularly checking your domain status. This can take up to %{time} hours. Or you can click the button to check again manually.":
              [
                "我们会定期检查您的域名状态。这可能需要 %{time} 个小时。您也可以点击按钮再次手动检查。",
              ],
            "Editor|We've ensured each keyword is used repeatedly in the article for the best SEO performance. Hover on each keyword to see where it's used.":
              [
                "我们已经确保每个关键词在全文中被重复使用以获得最佳的SEO效果。将鼠标悬停在每个关键词上可以查看它们在全文中的位置。",
              ],
            "Editor|We've generated a site structure, with pages and sections. Make any changes you'd like, then continue to generate content.":
              [
                "我们已经生成了一个网站结构，包括页面和部分。你可以进行任何你想要的更改，然后继续生成内容。",
              ],
            "Editor|We've used the reference URLs you provided to set the content settings for your site. Please review and continue to generate site structure.":
              [
                "我们已使用你提供的参考 URL 为你的网站设置了内容。请检查并继续生成网站结构。",
              ],
            "Editor|We've written 5 article titles for your topic & selected keywords. Please select a title to continue writing the blog outline.":
              [
                "我们已经为你的文章主题和选定的目标关键词写了5个博客标题。请选择一个标题，继续完成博客大纲。",
              ],
            "Editor|We've written your article outline for the selected title & keywords. Please review and make any desired changes before we finish writing the full article.":
              [
                "我们已经为你所选的博客标题和关键词写好了文章大纲。在我们完成完整的文章之前，请确认大纲，并做出任何想要的更改。",
              ],
            "Editor|Welcome to AI SEO Writer": ["欢迎使用AI SEO智能写手"],
            "Editor|Welcome to Site Editor": ["欢迎进入网站编辑器"],
            "Editor|Welcome to your dashboard. We recommend taking a super quick tour to show you the ropes.":
              [
                "欢迎来到 Strikingly 的网站控制面板。在开始使用之前，先快速熟悉一下如何使用这个工具吧。",
              ],
            "Editor|We’re checking your DNS records. This may take up to %{time} seconds.":
              ["我们正在检查你的DNS记录，这可能需要%{time}秒。"],
            "Editor|We’ve upgraded the editor with more features at your fingertips! Your Mini-Program content hasn't changed. If you have any trouble, please contact support anytime.":
              [
                "我们全新升级了小程序编辑器，更多功能现在触手可及！不用担心：你的小程序内容并没有因为编辑器升级而产生变化。如果遇到问题，请随时联系我们的客服团队。",
              ],
            "Editor|We’ve upgraded the editor with more features at your fingertips! Your site content hasn't changed. If you have any trouble, please contact support anytime.":
              [
                "我们全新升级了网页编辑器，更多功能现在触手可及！不用担心：你的网站内容并没有因为编辑器升级而产生变化。如果遇到问题，请随时联系我们的客服团队。",
              ],
            "Editor|What is the goal for your site?": [
              "你的网站的目标是什么？",
            ],
            "Editor|What's your business type?": ["你经营什么业务？"],
            "Editor|When enabled, show a reCAPTCHA checkbox on the form, which provides strong protection against bots submitting spam.":
              [
                "启用后，在表单上显示人机验证复选框，这可以提供更强的保护，防止机器人提交垃圾信息。",
              ],
            "Editor|When publishing as a free site, premium features will be disabled.":
              ["作为免费版网站上线时，付费功能将会被停用。"],
            "Editor|When user has not purchased after adding to cart for": [
              "当顾客将商品加入购物车超过",
            ],
            "Editor|When you have done editing, you can click here to back to dashboard to preview your site content.":
              ["完成编辑后，你可以单击此处返回控制面板，以预览网站内容。"],
            "Editor|White Minimal": ["白色简约"],
            "Editor|Who’s editing this site:": ["谁在编辑这个网站："],
            "Editor|Why?": ["为什么？"],
            "Editor|Wide": ["全幅"],
            "Editor|Wide - 16:9": ["宽屏 - 16:9"],
            "Editor|Width": ["宽度"],
            "Editor|With images": ["有图片的"],
            "Editor|Witty": ["风趣"],
            "Editor|Word Count": ["字数"],
            "Editor|Write More": ["AI扩写"],
            "Editor|Write beautiful blog posts that open in a new page.": [
              "每一篇博客，都可以在独立网站中访问浏览",
            ],
            "Editor|Write blog posts to share your ideas.": [
              "编写博客文章分享你的想法。",
            ],
            "Editor|Write more": ["AI扩写"],
            "Editor|Write title in gallery management...": [
              "在图册管理填写标题",
            ],
            "Editor|Write with AI": ["AI 智能写手"],
            "Editor|XS": ["超小"],
            "Editor|Yes": ["有"],
            "Editor|You already have a Booking section! You can only add one Booking section on this site.":
              ["已添加了预约版块！你只能在网站上添加一个预约版块。"],
            'Editor|You already have a page called "Search". Please rename your page before enabling the search function.':
              [
                "您已经有一个名为“搜索”的页面。 启用搜索功能之前，请重新命名该页面。",
              ],
            "Editor|You are using an unauthenticated third-party domain to send emails. Sender email must be authenticated before you can send from this address. To ensure delivery, please authenticate [email:%{var}] in [strong:Email Notifications > Show advanced options.]":
              [
                "你正在使用未验证的第三方域名发送电子邮件，必须通过身份验证之后才能从这个地址发送电子邮件。为了确保发送成功，请在 [strong:邮件提醒 > 显示高级选项] 中验证[email:%{var}]。",
              ],
            "Editor|You can add up to %{maxNumber} product.": [
              "您可以添加最多%{maxNumber}件商品。",
            ],
            "Editor|You can add up to %{maxNumber} products.": [
              "您可以添加最多 %{maxNumber}件商品。",
            ],
            "Editor|You can add up to %{var1} event(s).": [
              "最多可添加%{var1}个服务",
            ],
            "Editor|You can apply the logo color to your site's color scheme, to make your site feel more consistent.":
              [
                "你可以将Logo颜色应用到网站的配色方案中，使网站的感觉更加一致。",
              ],
            "Editor|You can change the prompt to regenerate text options": [
              "修改提示可以重新生成文本选项",
            ],
            'Editor|You can choose [link: other registration method] to register a Mini Program account, and get your full version Mini Program after you get the business lisence. Note: The payment capability cannot be activated before the "WeChat authentication" is completed.':
              [
                "您可以选择【[link:其他注册方式]】注册小程序账号，待到营业执照完成办理完成在进行「微信注册」注意：在完成「微信认证」前无法开通支付能力。",
              ],
            "Editor|You can enter up to %{maxLength} reference site URLs here, to help the AI learn the best structure for your site.":
              [
                "您可以在此输入最多 %{maxLength} 个参考网站的URL，以帮助AI学习最适合您网站的结构。",
              ],
            "Editor|You can first create a trial Mini Program for mobile preview; after that, you should complete the quick & simple certification process in the desktop editor to fully publish the Mini Program online.":
              [
                "你可以先创建一个试用小程序在手机上预览效果；之后在桌面版编辑器中完成简单快捷认证，即可将该小程序正式发布到线上供所有人使用。",
              ],
            "Editor|You can have no more than %{quantity} dropdowns": [
              "你可以添加不超过%{quantity}个下拉菜单",
            ],
            "Editor|You can have no more than %{quantity} pages": [
              "网页数量不能超过%{quantity}个",
            ],
            "Editor|You can manually switch to %{var1} to process card payments instead.":
              ["你可以手动切换成%{var1}来处理银行卡收款。"],
            "Editor|You can show/hide sections only for mobile, without changing desktop view.":
              [
                "支持在手机设备上显示/隐藏特定版块，而不改变网站PC桌面端的内容布局。",
              ],
            "Editor|You can switch styles at any time here.": [
              "你可以在这里随时切换风格。",
            ],
            "Editor|You can then send emails and [link:newsletters] to your audience.":
              ["然后，你可以向你的粉丝发送一对一邮件和[link:营销邮件]。"],
            "Editor|You can try it out for now but this feature will be disabled in your published site.":
              ["你可以先试用这个功能，但是该功能将在网站上线后失效。"],
            "Editor|You can upload an alternate logo for the white background":
              ["你可以针对白色背景上传其它的 logo"],
            "Editor|You currently have different buttons for different items. Are you sure you want to set them uniformly? This will override your individual button settings!":
              [
                "你目前对于不同项目设置了不同的按钮。你确定你要统一设置所有按钮吗？这将会覆盖你单独的按钮设置！",
              ],
            "Editor|You currently have multiple editors of this site open. This may cause your edited content to be overwritten or lost.":
              ["你同时开启了多个编辑器，可能会导致你的编辑内容被覆盖或丢失。"],
            "Editor|You don't add any images yet.": ["你尚未添加任何图片。"],
            "Editor|You don't have any blog posts.": ["你当前没有博客文章。"],
            "Editor|You don't have any coupons": ["你当前没有优惠券。"],
            "Editor|You don't have any items.": ["你当前没有展示项目。"],
            "Editor|You don't have any products.": ["你当前没有商品。"],
            "Editor|You don’t have any audience entries yet.": [
              "你还没有粉丝。",
            ],
            "Editor|You have already added name field in the form. You can’t add multiple name field.":
              ["您已经在表单中添加了姓名字段。您不能添加多个姓名字段。"],
            "Editor|You have deleted the authorization in Mailchimp. Please reconnect your account if you want to re-enable.":
              [
                "你已经在Mailchimp中删除了授权。如果要重新启用，请重新绑定账号。",
              ],
            "Editor|You might need to delete some older files in this site's storage, or [link:contact support] to increase this limit.":
              [
                "你可以删除一些网站上的文件，或者[link: 联系客服]提升存储空间。",
              ],
            "Editor|You must [link:connect a custom domain] before you can use Google Search Console.":
              [
                "在使用Google Search Console之前，你必须[link:连接一个自定义域名]。",
              ],
            "Editor|You must [link:remove this site's password] before you can submit a sitemap.":
              ["在提交网站地图之前，你必须[link:移除网站密码]。"],
            "Editor|You must [link:remove this site's password] before you can use Google Search Console.":
              ["在使用Google Search Console之前，你必须[link:移除网站密码]。"],
            'Editor|You must [link:uncheck the "Hide from Search Engines"] before you can submit a sitemap.':
              ["在提交网站地图之前，你必须[link:取消勾选“屏蔽搜索引擎”]。"],
            'Editor|You must [link:uncheck the "Hide from Search Engines"] before you can use Google Search Console.':
              [
                "在使用Google Search Console之前，你必须[link:取消勾选“屏蔽搜索引擎”]。",
              ],
            "Editor|You must enter the %{var1} before sending emails.": [
              "在发送邮件之前，你必须填写%{var1}地址。",
            ],
            "Editor|You must publish your site before you can submit a sitemap.":
              ["在提交网站地图之前，你必须发布你的网站。"],
            "Editor|You must publish your site before you can use Google Search Console.":
              ["在使用Google Search Console之前，你必须发布你的网站。"],
            "Editor|You must verify your email address before sending email campaigns.":
              ["在发邮件活动之前，你必须验证你的邮件地址。"],
            "Editor|You'll be able to send emails once your domain is authenticated. Please wait until this process is complete.":
              ["域名完成验证后即可发送电子邮件，请等待完成。"],
            "Editor|You'll be redirected to Namecheap to confirm this change.":
              ["你将返回Namecheap以确认此更改。"],
            "Editor|You're being redirected to the Strikingly, please wait...":
              ["正在返回Strikingly，请等待…"],
            "Editor|You're currently building a single-page site. Add more pages if you have more content!":
              ["当前网站是单页面网站，你可添加多页面展示更多内容！"],
            "Editor|You're just a few steps away from a customized logo!": [
              "马上就可以获得你的定制Logo了！",
            ],
            "Editor|You're now connected to Google Search Console.": [
              "你现在已连接至Google Search Console。",
            ],
            "Editor|You're previewing a members-only page. Visitors must log in to see this page.":
              ["正在预览仅会员可见内容。实际网站中，非会员无法访问该页面。"],
            "Editor|You're previewing a password-protected page. Visitors must enter the password to see this page.":
              [
                "正在预览密码保护内容。实际网站中，访客必须输入密码才能正常浏览。",
              ],
            "Editor|You're previewing the unpublished version. Publish now to go live!":
              ["当前预览内容是未发布版本。点击发布即刻上线！"],
            "Editor|You've already submitted this blog post for review (%{var1}). If you submit again, we'll review your latest version.":
              [
                "你已经将该博客提交审核了。（%{var1}）如果再次提交，我们将审核你提交的最新版本。",
              ],
            "Editor|You've already submitted this site for review (%{var1}). If you submit again, we'll review your latest version.":
              [
                "你已经将该网站提交审核了。（%{var1}）如果再次提交，我们将审核你提交的最新版本。",
              ],
            "Editor|You've hit the limit for test emails. Please try again later.":
              ["你已达到测试邮件的上限，请稍后再试。"],
            "Editor|You've reached your daily limit for generating logos. Please try again tomorrow.":
              ["你已达到每日生成Logo的数量上限。请明天再试。"],
            "Editor|You've reached your daily limit for generating sites. Please try again tomorrow.":
              ["你已达到每日生成网站的数量上限。请明天再试。"],
            "Editor|You've reached your daily limit for using AI editing features in this logo. Please try again tomorrow.":
              ["你已达到在此Logo中使用AI编辑功能的每日上限。请明天再试。"],
            "Editor|You've reached your publish limit for %{var1} sites. This Pro feature is not available.":
              ["你已达到%{var1}网站发布数量上限。无法使用此专业版功能。"],
            "Editor|Your Custom Domain Name": ["你的自定义域名"],
            "Editor|Your Logo is still in progress! If you leave/refresh this page, your Logo will be saved as a draft and you can resume it from the logo list. Are you sure you want to leave this page anyway?":
              [
                "你的Logo仍在制作中！如果离开/刷新此页面，你的Logo将被保存为草稿，你可以从Logo列表中恢复。你确定要离开此页面吗？",
              ],
            "Editor|Your Mini Program expires at %{var}": [
              "有效期截止为%{var}",
            ],
            "Editor|Your Strikingly Taiwan Payments account password has been successfully changed.":
              ["你的Strikingly台湾金流账户密码已经成功修改。"],
            "Editor|Your article [strong:%{articleTitle}] has been linked from %{articlesNum} related articles.":
              [
                "你的文章[strong:%{articleTitle}]已链接至%{articlesNum}篇相关文章。",
              ],
            "Editor|Your article [strong:%{articleTitle}] has been linked from 1 related article.":
              ["你的文章[strong:%{articleTitle}]已链接至1篇相关文章。"],
            "Editor|Your article [strong:%{articleTitle}] has been linked to %{articlesNum} related articles.":
              [
                "你的文章[strong:%{articleTitle}]已链接到%{articlesNum} 篇相关文章。",
              ],
            "Editor|Your article [strong:%{articleTitle}] has been linked to 1 related article.":
              ["你的文章[strong:%{articleTitle}]已链接到1篇相关文章。"],
            "Editor|Your banner images are different sizes! You should keep all banner images the same size.":
              ["您的轮播图片尺寸不一致！请统一所有的轮播图片的尺寸。"],
            "Editor|Your blog post with custom HTML code is under review and will take effect when approved. Remember, you can add a custom domain to skip this step.":
              [
                "你的博客和HTML自定义代码正在审核中，通过后会立即生效。别忘记你可以通过绑定自定义域名来跳过审核。",
              ],
            "Editor|Your booking has been cancelled": ["你的预约已被取消"],
            "Editor|Your current nav bar does not support displaying a logo. If you wish to upload a logo in the nav bar, please change your site template.":
              [
                "你当前的导航栏不支持显示logo。如果你想在导航栏上传logo，请更换网站模板。",
              ],
            "Editor|Your current session is not valid anymore. Please retry.": [
              "你已登录超时，请重新登录。",
            ],
            "Editor|Your custom code has been saved. For security reasons, you need to connect a domain to have your custom code take effect immediately!":
              [
                "你的自定义代码已保存。出于安全性考虑，你需要绑定域名来使你的自定义代码立即生效。",
              ],
            "Editor|Your last change wasn't saved. It seems like you're offline. Please check your Internet connection before retrying.":
              [
                "你的最后一次更改未保存。你似乎已经离线，请先检查你的网络连接然后重试。",
              ],
            "Editor|Your latest versions will be stored here, Click to view what changes will be reverted.":
              ["这里有你最近的网页历史版本，点击查看可回退的版本。"],
            "Editor|Your logo package includes:": ["你的Logo文件包括："],
            "Editor|Your post is not fully generated due to some errors": [
              "发生了一些错误，你的文章还没有全部完成",
            ],
            "Editor|Your posts have been linked": ["你的文章已被链接"],
            "Editor|Your site is composed by SECTIONS. You can add, remove, rearrange and jump to your sections here.":
              [
                "你的网站将拆成不同版块为单位。你可以添加、删除、重新排序，在这里切换到不同的版块。",
              ],
            "Editor|Your site is now being cloned and translated. The process can take up to several minutes if you have a lot of content. We will notify you once it is done.":
              [
                "正在复制并翻译你的网站。如果你的网站有很多内容，这个过程可能会花费几分钟的时间。翻译完成后我们会通知你。",
              ],
            "Editor|Your teammates are still editing this site! Please make sure any teammates have quit the editor before you try to revert.":
              [
                "其他账号成员仍在编辑网站！进行恢复操作前，请确保全部账号停止编辑并退出编辑器。",
              ],
            "Editor|You’re using %{var1} to accept credit/debit card payments for physical products.":
              ["你正在使用%{var1}来接受实物类商品的银行卡付款。"],
            "Editor|You’ve exceeded the available storage space for this site.":
              ["你已超出该网站的存储空间。"],
            "Editor|You’ve updated Strikingly Taiwan Payments account information successfully.":
              ["你已成功更新了Strikingly台湾金流账户的信息。"],
            "Editor|Zoom In": ["放大"],
            "Editor|[link: Join our Affiliate Program] and get paid up to $1000 per referral.":
              [
                "[link:加入我们的联盟分销计划]即可赚取最多每单$1000美金的佣金。",
              ],
            "Editor|[link:Invite your team] to collaborate in real-time.": [
              "[link:邀请你的团队]进行实时协作",
            ],
            "Editor|[strong1:%{var1}] is currently editing. [strong2:You can view the editor content, but any changes you make will not be saved.] If you want to edit the site, please ask the user to exit the editor first.":
              [
                "[strong1:%{var1}]正在编辑中。[strong2:你可以查看编辑器的内容，但是你所做的任何修改都不会被保存。]如果你想要编辑器网站，请让用户先退出编辑器。",
              ],
            "Editor|[strong:Extra keywords] are terms related to the target keyword %{targetKeyword}. We've generated 10 extra keywords to be included in your post to get bonus traffic. [bold:Make sure to uncheck irrelevant keywords.]":
              [
                "[strong:额外关键词]是与目标关键词%{targetKeyword}相关的词语。我们已为你生成了10个额外关键词，你可以在文章中使用它们以获取额外流量。如有不相关的额外关键词，[bold:请确保取消勾选。]",
              ],
            "Editor|[strong:Note:] Email addresses from free services (Gmail, Yahoo, Hotmail, etc) cannot be authenticated and are more likely to be marked as spam or junk. We recommend using a custom domain.":
              [
                "[strong:注意：]若你使用的是免费邮箱服务（如Gmail、Yahoo、Hotmail等），将无法完成认证，也更有可能被识别为垃圾邮件。因此建议你使用自定义域名。",
              ],
            "Editor|[strong:Note:] For security reasons, since your site doesn't have a custom domain, your custom code must be reviewed by us before going live. [link:Connect a domain to skip this step.]":
              [
                "[strong:注意：] 由于网站目前没有连接自定义域名，出于网络安全考虑你的自定义代码必须先通过审核才能生效。[link:连接自定义域名即可跳过审核流程。]",
              ],
            "Editor|[strong:Note:] If all verified owners are removed, Google will still collect data for the site, but nobody can access it until someone becomes verified owner again.":
              [
                "[strong:注意：]如果所有已验证的拥有者都被移除，Google仍然会收集网站的数据，但除非有人重新成为已验证的拥有者，否则无人可以访问该数据。",
              ],
            "Editor|and create trial Mini Program in 1 minute!": [
              "1分钟即可创建试用版小程序！",
            ],
            "Editor|are editing": ["正在编辑"],
            "Editor|colors": ["颜色"],
            "Editor|connect domain to publish code": ["绑定域名来发布代码"],
            "Editor|custom code restricted": ["自定义代码需修改"],
            "Editor|custom code under review": ["自定义代码正在审核中"],
            "Editor|difficult": ["困难"],
            "Editor|e.g. \nbest pizza shop in New York \nhow to cook pizza": [
              "例如：\n纽约最好的披萨店 \n如何做披萨",
            ],
            "Editor|e.g. \ndelicious pizza \npizza sauce \npizza toppings": [
              "例如: \n美味的披萨 \n披萨酱 \n披萨配料",
            ],
            "Editor|e.g. Hal's Donuts": ["例如：美兰珠宝"],
            "Editor|e.g. Include Strikingly website builder in outline.": [
              "例如，在大纲中包括Strikingly建站工具。",
            ],
            "Editor|e.g. Mon-Fri 10am-5pm, Sat 1pm-5pm": [
              "例如：星期一至星期五 10am-5pm，星期六 1pm-5pm",
            ],
            "Editor|e.g. Satisfaction Survey": ["例如：满意度调查表"],
            "Editor|e.g. Submit": ["例如：提交"],
            "Editor|e.g. You will write compelling and engaging content for our general audience.":
              ["例如，为普通读者写出引人入胜的内容。"],
            "Editor|e.g. a pink cartoon donut": ["例如：一个粉色的卡通甜甜圈"],
            "Editor|e.g. donut shop, hair salon, consulting": [
              "例如：精品店、理发店、咨询",
            ],
            "Editor|e.g. each title should be 10~15 words.": [
              "例如，每个标题应该包含10~15个汉字。",
            ],
            "Editor|e.g. pizza recipe": ["例如：西红柿炒鸡蛋"],
            "Editor|e.g. somebody@example.com": ["例如：somebody@example.com"],
            "Editor|e.g. www.strikingly.com": ["如：www.strikingly.com"],
            "Editor|e.g. xxxxxxxxxxxxxxxxxx (18 digits)": [
              "如：xxxxxxxxxxxxxxxxxx(共18位）",
            ],
            "Editor|easy": ["容易"],
            "Editor|edit custom HTML code": ["编辑HTML自定义代码"],
            "Editor|eg. Contact Form": ["例如：联系人表单"],
            "Editor|hard": ["较困难"],
            "Editor|hour": ["小时后都没有结账"],
            "Editor|hours": ["小时后都没有结账"],
            "Editor|is editing": ["正在编辑"],
            "Editor|layout": ["布局"],
            "Editor|limited time only": ["限时优惠"],
            "Editor|logo only - %{var1}": ["仅Logo - %{var1}"],
            "Editor|n/a": ["暂无"],
            "Editor|per time slot": ["人/时间段"],
            "Editor|possible": ["略困难"],
            "Editor|submit code for review": ["提交代码审核"],
            "Editor|submit post for review": ["提交博客审核"],
            "Editor|submit site for review": ["提交网站审核"],
            "Editor|verified owner": ["已验证的拥有者"],
            "Editor|very easy": ["非常容易"],
            "Editor|very hard": ["非常困难"],
            "Editor|vip": ["vip"],
            "Editor|🎉 Store, Blog, Custom Form, Pricing Table and much more...":
              ["🎉 商店, 博客, 自定义表单, 定价表以及更多内容..."],
            "Editor|👋 Email Automation, Membership, Live Chat...": [
              "👋 邮件自动化, 会员功能, 在线聊天...",
            ],
            "Editor|📢 Coupons, Newsletter, SEO on Google...": [
              "📢 优惠券, 营销邮件, Google SEO...",
            ],
            Email: ["邮箱地址"],
            "Email Address": ["电子邮箱地址"],
            "Email Label": ["电子邮件标签"],
            "Email accounts allow you to receive emails as your own address, like david@mydomain.com":
              ["你可以将自己的地址作为接收邮件的账号，如：david@mydomain.com"],
            "Email and firstname required.": ["必须填写电子邮件和名字。"],
            "Email|%{var1} form(s) selected": ["已选中%{var1}个表单"],
            "Email|212-123-4567": ["188-8888-8888"],
            "Email|3131 Sample Road, Sample City, California, United States": [
              "上海市杨浦区示例街道100号",
            ],
            "Email|Activate": ["启用"],
            "Email|Add Product Info": ["添加商品信息"],
            "Email|Add form submission info": ["添加表单信息"],
            "Email|Add us to your address book": ["将我们添加为联系人"],
            "Email|Anyone who submits the selected form(s) will receive this email.":
              ["每位提交该表单的用户都将收到这封邮件。"],
            "Email|Are you sure you want to deactivate this email automation? Automated emails will no longer be sent for this trigger.":
              [
                "您确定想要停用这封自动化邮件吗？触发条件将被停用，直到您再次激活这封邮件。",
              ],
            "Email|Are you sure you want to delete this email automation? This action cannot be undone.":
              ["你确定要删除这封自动回复邮件吗？删除之后无法恢复。"],
            "Email|Button URL": ["按钮链接网址"],
            "Email|Cancel & Go back": ["取消并返回"],
            "Email|Code was send to %{email}. [span:Resend code]": [
              "验证码已发送 %{email}。[span:重新发送验证码]",
            ],
            "Email|Complete Order": ["完成订单"],
            "Email|Current Account Email": ["当前的账户电子邮件"],
            "Email|Current Account Password": ["当前账户密码"],
            "Email|Custom URL": ["自定义网址"],
            "Email|DKIM Authentication Incomplete": ["DKIM身份验证未完成"],
            "Email|Deactivate": ["停用"],
            "Email|Default action: Open checkout page": [
              "默认操作：打开结账页面",
            ],
            "Email|Edit Default action: Open checkout page": [
              "编辑默认操作：打开结账页面",
            ],
            "Email|Edit Email Automation": ["编辑自动回复邮件"],
            "Email|Email Verified": ["电子邮件已验证"],
            "Email|Email verification is required to proceed. Are you sure you want to cancel?":
              ["需要电子邮件验证才能继续。你确定要取消吗？"],
            "Email|Enter Code": ["输入验证码"],
            "Email|Enter verification code": ["输入验证码"],
            "Email|Hello,": ["你好"],
            "Email|Incorrect password": ["密码不正确"],
            "Email|Jane": ["杨女士"],
            "Email|Later": ["稍后发送"],
            "Email|Please enter an integer from 1 to 100.": [
              "请输入1到100之间的整数",
            ],
            "Email|Please reset a trigger": ["请重新设置触发条件"],
            "Email|Price": ["价格"],
            "Email|Product name": ["商品名称"],
            "Email|Quantity": ["数量"],
            "Email|Sample message": ["示例留言"],
            "Email|Select forms": ["选择表单"],
            "Email|Send verification code": ["发送验证码"],
            "Email|Send verification email": ["发送验证邮件"],
            "Email|Set a custom URL": ["请设置一个自定义网址"],
            "Email|Set a custom URL or check default action above.": [
              "请设置一个自定义网址或勾选上方的默认操作选项。",
            ],
            "Email|Thank you, your email has been verified! Redirecting..": [
              "谢谢你，你的电子邮件已经被验证了! 正在重定向..",
            ],
            "Email|There is an active auto-responder for this form. If you remove the email field, the auto-responder will be disabled. Are you sure you want to remove the email field?":
              [
                "这个表单有一个生效中的自动回复。如果你移除邮箱字段，自动回复会失效。确定要删除邮箱字段吗？",
              ],
            "Email|This email automation is active. If you delete it, the triggers will be disabled and the email will no longer be sent. Are you sure you want to delete this email automation? This action cannot be undone.":
              [
                "自动化邮件当前处于生效状态，删除会导致触发条件被停用且邮件将会停止发送。是否确定要进行删除？删除之后无法恢复。",
              ],
            "Email|Update Account Email": ["更新账户电子邮件"],
            "Email|Update your account email with this form. After this change is verified, you'll use your new account email to log in.":
              [
                "用这个表格更新您的账户电子邮件。此项更改被验证后，您将使用新的账户电子邮件来登录。",
              ],
            "Email|Updated Account Email": ["更新的账户电子邮件"],
            "Email|Verify Your Email": ["验证您的电子邮件"],
            "Email|Visitor abandons a shopping cart": ["当顾客弃置购物车后"],
            "Email|Visitor submits a form response": ["当访客提交表单时"],
            "Email|We just sent a verification code to [blod:%{email}]. Please enter the code here. [span:Resend code.]":
              [
                "我们刚刚发送了一个验证码到[blod:%{email}]。请在这里输入验证码。[span:重新发送验证码]。",
              ],
            "Email|We noticed you didn't finish your order. Would you like to complete it now?":
              ["我们注意到你有订单尚未完成结账，你想要现在完成吗？"],
            "Email|We've received your form submission.": [
              "我们收到了你提交的表单。",
            ],
            "Email|Welcome,": ["欢迎，"],
            "Email|Would you like to save changes to this email?": [
              "你想要保存对这封邮件的更改吗？",
            ],
            "Email|Wrong address?": ["错误的邮件地址？"],
            'Email|You are receiving this email because you opted in via <a href="%{page_url}" style="%{style}" target="_blank">our website</a>.':
              [
                '您收到此邮件是因为您订阅了 <a href="%{page_url}" style="%{style}" target="_blank">我们的网站</a>。',
              ],
            'Email|You are receiving this email because you opted in via <a href="%{page_url}" target="_blank">our website</a>.':
              [
                '您收到此邮件是因为您订阅了 <a href="%{page_url}" target="_blank">我们的网站</a>。',
              ],
            "Email|Your email address [blod:%{email}] is unverified. Please verify your email to proceed.":
              [
                "您的电子邮件地址[blod:%{email}]没有经过验证。请验证您的电子邮件以继续。",
              ],
            'Email|Your link "%{var1}" does not have a valid URL! Make sure you set a link URL before activate this automation.':
              [
                '你的链接 "%{var1}" 不是一个有效的链接！请确保在启用自动回复邮件前设置了正确的链接。',
              ],
            "Email|jane@gmail.com": ["12345678@qq.com"],
            "Embed <strong>HTML/CSS/JavaScript</strong>": [
              "嵌入<strong>HTML/CSS/JavaScript</strong>",
            ],
            "Enable Twitter Card": ["启用 Twitter 卡片"],
            Enabled: ["已激活"],
            "End trial, pay now": ["结束试用，立即支付"],
            "English Phone Support": ["英语电话咨询"],
            'Enter "#2" to link to the second section on this page.': [
              "输入“#2”可链接至此网站的第2个版块",
            ],
            'Enter "mailto:youremail@gmail.com" to link to your email.': [
              "输入“mailto:xxx@qq.com”可链接至电子邮箱",
            ],
            "Enter Embed Code": ["输入嵌入代码"],
            "Enter URL or": ["输入域名或者"],
            "Enter URL to upload from web": ["粘贴网址链接添加资源"],
            "Enter a name.": ["请输入一个名称"],
            "Enter a password here. Empty to keep your site public.": [
              "请在此处输入密码，留空则表示将你的网站设为公开",
            ],
            "Enter a phone number.": ["请输入电话号码"],
            "Enter a unique MyStrikingly.com URL. You may change this at any time.":
              ["在此设置 MySxl.cn 下的二级域名，支持随时更改。"],
            "Enter a valid email.": ["请输入有效的邮箱"],
            "Enter code": ["输入6位数短信验证码"],
            "Enter full URL (http://yourwebsite.com) to link to another website.":
              ["请输入完整的域名地址"],
            "Enter phone number": ["输入真实有效的手机号"],
            "Enter the phone number where you'd like to receive authentication codes each time you log in. You will receive a 6-digit code from your phone number.":
              [
                "输入您想要在登录时用来接收验证码的手机号码。每次登录时，您都需要使用密码和6位数短信验证码来确认您的身份。",
              ],
            "Enter your account password": ["请输入密码"],
            "Error, please try again!": ["错误，请重试"],
            "Error: Invalid email format": ["错误：电子邮箱格式无效"],
            "Error: Please enter a valid URL": ["错误： 请输入一个有效的URL"],
            "Errors|You need to upgrade your plan to use this feature.": [
              "你需要升级你的套餐来使用这个功能。",
            ],
            "Everything in the Pro plan": ["专业版的所有功能"],
            "Exceeding the bandwidth? Your site will still be visible, but we'll alert you about your traffic.":
              ["超过带宽？你的网站将仍然可见，但你会收到流量提醒。"],
            Exit: ["退出"],
            "Exit Editor": ["退出编辑器"],
            "Exit the editor": ["退出编辑器"],
            "Export All to Excel": ["导出 CSV 文件"],
            "External Links": ["外部链接"],
            FREE: ["免费版"],
            Facebook: ["Facebook 网站"],
            "Facebook Pixel ID": ["Facebook 像素 ID"],
            Fade: ["淡入"],
            "Failed to get data. Please click to retry!": [
              "糟糕，出现了一些问题。请重试。",
            ],
            Fast: ["快"],
            Favicon: ["网站图标"],
            "Feed Type": ["频道类别"],
            "File exceeds maximum allowed size of 10MB": ["文件超过了10MB限额"],
            "File type not allowed": ["文件类型不支持"],
            "Filter by source": ["筛选来源"],
            "Finalizing your page...": ["正在完成你的页面…"],
            "Finalizing your site...": ["正在完成你的网站…"],
            "Find a new domain name.": ["寻找新域名"],
            "Finding matching images...": ["正在寻找合适的图片…"],
            "First Name": ["名字"],
            "First name": ["名字"],
            Fonts: ["字体"],
            "Fonts|Are you sure you want to delete this font from your account? This will remove the font from all sites that are using it!":
              ["你确定要删除该字体？所有用到该字体的网站都将移除掉。"],
            "Fonts|Error: Maximum file size for font upload is 5MB. Please select a smaller font file.":
              ["错误：上传的字体文件不可超过5MB，请重新选择字体文件。"],
            "Fonts|Font Search": ["字体搜索"],
            "Fonts|It seems you've already uploaded this font.": [
              "似乎你已经上传过该字体。",
            ],
            "Fonts|More intricate fonts cannot be used as text font.": [
              "复杂的字体不能作为文本字体。",
            ],
            "Fonts|No fonts found.": ["未找到该字体"],
            "Fonts|Opacity": ["不透明度"],
            "Fonts|Please upgrade to Pro to use custom fonts!": [
              "请升级到专业版使用自定义字体！",
            ],
            "Fonts|Search for a Google font…": ["搜索谷歌字体"],
            "Fonts|There is a file uploading in progress.": [
              "文件正在上传中。",
            ],
            "Fonts|This font already exists in Google Fonts. We've selected it for you.":
              ["该字体已存在于 Google Fonts。我们已为你选择。"],
            "Fonts|Upload failed. Accepted file formats: ttf, otf, woff, woff2":
              ["上传失败。支持的文件格式：ttf, otf, woff, woff2"],
            "Fonts|Upload your custom font when you upgrade to Pro.": [
              "升级到专业版可上传自定义字体。",
            ],
            "Fonts|Upload your own font! Accepted files: ttf, otf, woff": [
              "上传你自己的字体吧！支持的文件格式：ttf, otf, woff",
            ],
            "Fonts|Uploaded": ["已上传"],
            'Fonts|Warning: Uploading a font larger than 500kb will slow down your site load time! Click "OK" to continue anyway.':
              [
                '请注意：你上传的字体文件超过500kb，这将会影响你的网站的访问速度，点击"OK"以继续。',
              ],
            "Fonts|Weight": ["粗细"],
            "Fonts|You can only upload up to 25 fonts on your account. Please remove some uploaded fonts to upload more.":
              [
                "你只能上传最多25种字体。如需上传更多，请先移除部分已上传的字体。",
              ],
            "Fonts|You must connect a custom domain to upload your own fonts! Please connect your domain in site settings.":
              [
                "只有自定义域名用户才可以上传自定义字体！请在网站设置里绑定自定义域名。",
              ],
            "Fonts|upload custom font": ["上传自定义字体"],
            "Footer Code": ["页脚代码"],
            "Form Fields": ["表单字段"],
            "Form Options": ["表单选项"],
            "FormResponse|From": ["来源"],
            Forms: ["表单"],
            "Form|By continuing, you agree to our [policy: Privacy Policy]": [
              "提交即表明你已经同意我们的[policy: 隐私政策]",
            ],
            "Form|By continuing, you agree to our [terms: Terms & Conditions]":
              ["提交即表明你已经同意我们的[terms: 使用条款]"],
            "Form|By continuing, you agree to our [terms: Terms & Conditions] and [policy: Privacy Policy]":
              [
                "提交即表明你已经同意我们的[terms: 使用条款]及[policy:隐私政策]",
              ],
            "Form|By registering, you agree to our [policy: Privacy Policy]": [
              "注册即视为你已阅读并同意以下[policy: 隐私政策]",
            ],
            "Form|By registering, you agree to our [terms: Terms & Conditions]":
              ["注册即视为你已阅读并同意以下[terms: 条款及条件]"],
            "Form|By registering, you agree to our [terms: Terms & Conditions] and [policy: Privacy Policy]":
              [
                "注册即视为你已阅读并同意以下[terms: 条款及条件]和[policy: 隐私政策]",
              ],
            Free: ["免费"],
            "Free domain for the first year! Choose from .com, .org, .net, and much more.":
              ["域名第一年使用免费！ 选择 .com, .org, .net, 等等。"],
            "Generate RSS feed": ["允许访客通过RSS订阅"],
            "Generate new recovery codes…": ["生成新的恢复码..."],
            "Generated: %{var2}": ["恢复码生成日期: %{var2}"],
            "Get Started. It's free!": ["立即免费使用"],
            "Get access by upgrading to Strikingly Pro!": [
              "通过更新至上线了专业版来访问",
            ],
            "Get code": ["获取验证码"],
            "Give your site a more professional look with your unique branded domain name.":
              [
                "使用自选的品牌域名可以让你的网站给访客留下更加正规专业的印象。",
              ],
            "Gmail|(You can only do this once per site.)": [
              "（每个网站只可以发送一次）",
            ],
            "Gmail|All Gmail Contacts": ["所有Gmail联系人"],
            "Gmail|Compose a short message": ["撰写一小段邮件"],
            "Gmail|Email your friends": ["发邮件给你的朋友们"],
            "Gmail|Emails successfully sent!": ["邮件已成功发送！"],
            "Gmail|Enter emails": ["输入邮箱"],
            "Gmail|Excited to launch your new site? Tell your friends to jump-start your traffic!":
              ["你的网站发布了，是否觉得很开心啊？"],
            "Gmail|Loading your contacts...": ["正在加载 Gmail 联系人..."],
            "Gmail|Send Emails": ["发送邮件"],
            "Gmail|Send To": ["发送到"],
            "Gmail|Send to all Gmail contacts?": ["发送给所有Gmail好友？"],
            "Gmail|Subject": ["主题"],
            "Gmail|You already sent to all for this site!": [
              "你已经将这个网站发送到所有Gmail好友了！",
            ],
            "Go Back": ["返回"],
            "Go back": ["返回"],
            "Google Analytics ID must be in format G-XXXXXXXXXX.": [
              "Google Analytics ID应遵循格式：G-XXXXXXXXXX。",
            ],
            "Google Analytics Tracker": ["Google Analytics 跟踪器"],
            "Got it!": ["好的"],
            "Grant membership to %{emailText} for the following site:": [
              "向 %{emailText} 授予以下网站的会员资格：",
            ],
            "HTML is invalid": ["HTML代码无效"],
            "Header Code": ["页眉代码"],
            "Here are all the images you've uploaded.": [
              "这里是你上传的所有图片。",
            ],
            "Here are some suggested alternatives.": ["以下供你选择。"],
            "Hey! You don't have any sites!": ["你还没有创建任何网站哦"],
            "Hi, there!": ["欢迎！"],
            "Hide Editor Panel": ["隐藏编辑面板"],
            "Hide Order Data": ["隐藏数据概况"],
            "Hide from Search Engines": ["屏蔽搜索引擎"],
            "Hint: Make sure your background image is big enough — around 1600x900 will do nicely.":
              ["小提示：请确保你的背景图片足够大，建议图片尺寸1600x900。"],
            "Hint: Recommended aspect ratio for product images is 4:3.": [
              "小提示：图片的推荐宽高比为4:3",
            ],
            "Hint: Upload a wide banner image — around 1600x600 will be good. Make sure all banners are the same size!":
              [
                "小提示：上传宽幅图像 - 建议图片尺寸1600x600，请确保所有图片尺寸一致！",
              ],
            "Host|Checking": ["检查中"],
            "Host|I've fixed, check again": ["已修复，再次检查"],
            "Host|Incorrect": ["错误"],
            "Host|Missing": ["缺失"],
            "Host|Name": ["主机记录"],
            "Host|Status": ["状态"],
            "Host|Type": ["记录类型"],
            "Host|Value": ["记录值"],
            "How do I verify and submit a sitemap to Google?": [
              "如何核实网站地图，并且提交至Google？",
            ],
            "Hyphens|Preview": ["预览"],
            "Hyphens|Publish": ["发布"],
            "Hyphens|Publishing": ["正在发布"],
            "Hyphens|Reviewing": ["审核中"],
            "Hyphens|Settings": ["设置"],
            "I'm happy": ["我高兴着呢"],
            IMAGE: ["图片"],
            "If this keeps happening, please email us at %{supportLink}": [
              "如果您此问题仍然存在，请发送邮件到%{supportLink}联系我们。",
            ],
            "If you generate new recovery codes, these ones will stop working.":
              ["如果您生成了更新的恢复码，以下这些恢复码将作废。"],
            "If you think your codes have fallen into the wrong hands, you can get a new set. Be sure to save the new ones because the old codes will stop working.":
              [
                "如恢复码不慎丢失，您可生成新的恢复码，同时旧恢复码作废。请妥善保存新生成的恢复码。",
              ],
            "If you're operating a business in the United States, you may be required to collect sales tax for shipment to certain states. Please consult a tax professional to comply with all applicable tax laws. [link:Learn more.]":
              [
                "如果你是在美国经营你的业务，发往个别州的货品可能会被要求征收销售税。请向税务专业人士咨询相关税法。 [link:了解更多]",
              ],
            "If you’re operating a business in Europe, you may be required to collect sales tax for shipment to certain countries. Please consult a tax professional to comply with all the applicable tax laws. [link:Learn more.]":
              [
                "如果你是在欧洲经营你的业务，发往个别国家的货品可能会被要求征收销售税。请向税务专业人士咨询相关税法。 [link:了解更多]",
              ],
            "Image Editor": ["图片编辑器"],
            "Image uploader failed to load. Click to retry.": [
              "图片上传工具加载失败，点击重试",
            ],
            "ImageEditor|Apply": ["应用"],
            "ImageEditor|Brightness": ["亮度"],
            "ImageEditor|Cancel": ["取消"],
            "ImageEditor|Contrast": ["对比度"],
            "ImageEditor|Crop": ["裁剪"],
            "ImageEditor|Custom": ["自定义"],
            "ImageEditor|Distance": ["程度"],
            "ImageEditor|Draw": ["自由标注"],
            "ImageEditor|Filter": ["滤镜"],
            "ImageEditor|Keep Aspect Ratio": ["固定比例"],
            "ImageEditor|Line": ["直线"],
            "ImageEditor|Range": ["范围"],
            "ImageEditor|Redo": ["恢复"],
            "ImageEditor|Remove White": ["去除白色"],
            "ImageEditor|Reset": ["重做"],
            "ImageEditor|Resize": ["调整尺寸"],
            "ImageEditor|Rotate": ["旋转"],
            "ImageEditor|Saturation": ["饱和度"],
            "ImageEditor|Square": ["正方形"],
            "ImageEditor|Text": ["文本"],
            "ImageEditor|Text Size": ["字号"],
            "ImageEditor|Threshold": ["阈值"],
            "ImageEditor|Undo": ["撤销"],
            "Import Images": ["上传图片"],
            "Import from CSV": ["从 CSV 文件导入"],
            "Import from your computer, then select from them here!": [
              "从电脑导入，并在此选择。",
            ],
            "Inc. country code, [placeholderBr]e.g. 1-408-555-5555": [
              "Inc. 国家代码, [placeholderBr]例如 1-408-555-5555",
            ],
            "Includes store items and blog items": ["包括商店项目和博客项目"],
            "Install Facebook Pixel": ["安装 Facebook 像素"],
            "Invalid Input": ["无效输入"],
            "Invalid phone number.": ["请输入正确格式的手机号"],
            "Invite <strong>Collaborators</strong>": [
              "邀请<strong>协作者</strong>",
            ],
            "Invite agents to create their own account and reply to live chats on your behalf →":
              ["邀请代理创建其自己的账户，并以你的名义回复在线聊天→"],
            "Invite other people to edit and manage your sites. Set their role to be editor, admin, or blogger.":
              [
                "邀请其他人来编辑和管理你的网站。你能把他们设置成编辑者、管理者和博客编辑者。",
              ],
            "Invite your friends and colleagues to help you edit and build your website.":
              ["可发送邮件邀请同事小伙伴一起编辑网站 "],
            "Invoices|Account Name": ["收款户名"],
            "Invoices|Account Number": ["收款账号"],
            "Invoices|Address": ["银行地址"],
            "Invoices|Amount": ["需支付金额"],
            "Invoices|Bank": ["开户行"],
            "Invoices|Domestic account": ["国内转账"],
            "Invoices|Domestic transfers usually take 1-5 business days and overseas transfers usually take 5-10 business days. If the order is still pending confirmation after 10 business days, please contact Happiness Officers.":
              [
                "国内转账通常需要1-5个工作日，海外转账通常需要5-10个工作日。转账付款后，若超出10个工作日订单仍是待确认状态，请联系客服。",
              ],
            "Invoices|Instructions": ["银行转账操作说明"],
            "Invoices|Offline Payment": ["银行转账支付"],
            "Invoices|Overseas account": ["境外转账"],
            "Invoices|Please do not transfer money in batches, transfer more or transfer less, otherwise it will affect your payment confirmation.":
              ["请勿分次转账、多转账或少转账，否则将会影响您的款项到账确认。"],
            "Invoices|Please make sure that the transfer amount includes the bank's handling fee to ensure that <strong>the amount to be paid is the same as the “amount” above</strong> (please consult your bank for details)":
              [
                "请确认转账金额中已包含银行手续费，以确保<strong>到账金额和需支付金额一致</strong>（具体请咨询开户行）",
              ],
            "Invoices|Please select a JPG or PNG file less than 2Mb": [
              "请选择2MB以内的 jpg 或 png 文件",
            ],
            "Invoices|Re-upload Voucher": ["重新上传凭证"],
            "Invoices|SWIFT CODE": ["SWIFT CODE"],
            "Invoices|Unpaid": ["未支付"],
            "Invoices|Upload Voucher": ["已付款，上传凭证"],
            "Invoices|Upload successfully, the page will be refreshed within 2 seconds":
              ["上传成功，页面将于2秒内刷新"],
            "Invoices|Waiting review": ["待确认"],
            "It may take a few seconds to upload images. <br/> Please wait or <a>cancel upload</a>.":
              ["上传图片需要一些时间<br/>请稍等或<a>取消上传</a>。"],
            "Keep editing!": ["继续编辑"],
            "Kickstart|%{discount}%% discount limited time only": [
              "限时%{discount} 折优惠",
            ],
            "Kickstart|%{var1} selected! Go to get my site": [
              "已选中%{var1}个！前往我的网站",
            ],
            "Kickstart|%{var1} upload failed.": ["%{var1}上传失败。"],
            "Kickstart|%{var1}/%{var1} SELECTED": ["已选中%{var1}/%{var1}"],
            "Kickstart|(PDFs, documents, etc.)": ["(pdf、文档等)"],
            "Kickstart|(logos, photos, etc.)": ["（徽标、照片等）"],
            "Kickstart|0 selected. Select references below": [
              "已选中0个，请选择下列参考网站",
            ],
            "Kickstart|1. Fast & reliable hosting": [
              "1. 高效值得信赖的托管服务",
            ],
            "Kickstart|2 years": ["两年"],
            "Kickstart|2. Drag & Drop website editor": [
              "2. 高自由度页面编辑器",
            ],
            "Kickstart|2. Free domain for the first year": [
              "2. 首年享用免费域名",
            ],
            "Kickstart|3 years": ["三年"],
            "Kickstart|3. 24/7 customer support": ["3. 24小时人工客服"],
            "Kickstart|3. Drag & Drop website editor": [
              "3. 高自由度页面编辑器",
            ],
            "Kickstart|4. 24/7 customer support": ["4. 24小时人工客服"],
            "Kickstart|48 hours delivery": ["48小时交付"],
            "Kickstart|5 years": ["五年"],
            "Kickstart|72 hours delivery": ["72小时交付"],
            "Kickstart|A subscription plan is required for Kickstart, so that you can experience all the features in your new site. You will be billed $%{discountPrice} for the plan and $%{originalPrice} per %{planTime} after that.":
              [
                "为了保证您定制的网站能够使用所有所需功能，您必须先订购一个付费套餐才能开启Kickstart服务。您将需要为该套餐支付$%{discountPrice}，之后每%{planTime}支付$%{originalPrice}。",
              ],
            "Kickstart|A subscription plan is required for Kickstart, so that you can experience all the features in your new site. You will be billed $%{originalPrice} per %{planTime} for the plan.":
              [
                "为了保证您定制的网站能够使用所有所需功能，您必须先订购一个付费套餐才能开启Kickstart服务。您将需要为该套餐每%{planTime}支付$%{originalPrice}。",
              ],
            "Kickstart|A subscription plan is required for Kickstart. You are now in a 14-day free trial. Starting %{paymentDate}, You will be billed $%{originalPrice} per %{planTime} for the plan.":
              [
                "订购一个付费套餐对Kickstart是必需的。您现已在一个为期14天的套餐试用期内。从%{paymentDate}开始，您将需要支付 $%{originalPrice}每%{planTime}.",
              ],
            "Kickstart|A subscription plan is required for Kickstart. You are now in a 14-day free trial. Starting %{paymentDate}, you will be billed $%{discountPrice} for the plan and $%{originalPrice} per %{planTime} after that.":
              [
                "订购一个付费套餐对Kickstart是必需的。您现已在一个为期14天的套餐试用期内。从%{paymentDate}开始，您将需要为该套餐支付$%{discountPrice}，之后每%{planTime}支付$%{originalPrice}。",
              ],
            "Kickstart|A subscription plan is required for hosting your website. You'll be billed $%{discountPrice} today and $%{originalPrice} per %{planTime} after. This charge is [strong:14-day full money back guaranteed.]":
              [
                "为确保你的网站上线运营，你需要购买网站托管服务。该套餐首付为$%{discountPrice}，之后每%{planTime}的费用为$%{originalPrice}。[strong:我们为此套餐提供14天无理由退款服务。]",
              ],
            "Kickstart|A subscription plan is required for hosting your website. You'll be billed $%{originalPrice} today and $%{originalPrice} per %{planTime} after. This charge is [strong:14-day full money back guaranteed.]":
              [
                "为确保你的网站上线运营，你需要购买网站托管服务。该套餐首付为$%{originalPrice}，之后每%{planTime}的费用为$%{originalPrice}。[strong:我们为此套餐提供14天无理由退款服务。]",
              ],
            "Kickstart|Accepted file types: gif, jpeg, png, bmp, ico. Single file size limit: 10MB.":
              [
                "可接受的文件类型：gif，jpeg，png，bmp，ico。单个文件大小限制：10MB。",
              ],
            "Kickstart|Accepted file types: txt, pdf, doc, xls, ppt, pages, key, numbers, wps, mp3, mp4, wav, flac, m4a, docx, xlsx, pptx, odt, odp, epub, zip, zipx, 7z, rar. Single file size limit: 10MB.":
              [
                "可接受的文件类型：txt, pdf, doc, xls, ppt, pages, key, numbers, wps, mp3, mp4, wav, flac, m4a, docx, xlsx, pptx, odt, odp, epub, zip, zipx, 7z, rar。单个文件大小限制：10MB。",
              ],
            "Kickstart|Almost done!": ["快要完成了！"],
            "Kickstart|And much more...": ["以及更多……"],
            "Kickstart|Any materials you give us would help expedite the site building process. After submitting, we’ll assign a designer to work on your site immediately.":
              [
                "您给我们的任何素材都将有助于加快网站搭建的进程。提交素材后，我们会立即指派一名设计专家搭建您的网站。",
              ],
            "Kickstart|Any materials you provide will help us build your site. Are you sure you want us to start building without any materials?":
              [
                "您提供的任何素材都将帮助我们搭建您的网站。您确定要我们不用任何素材就立即开工吗?",
              ],
            "Kickstart|Apply": ["使用"],
            "Kickstart|Apply Coupon Success!": ["使用优惠券成功！"],
            "Kickstart|Apply promo code": ["使用优惠码"],
            "Kickstart|Approve": ["确认签收"],
            "Kickstart|Approve final delivery": ["确认签收最终交付"],
            "Kickstart|Are you sure you want to change your card? This change will apply to all billing info with your account.":
              [
                "您确定要更改信用卡吗？更改后您的账号中的所有支付信息会即时更新。",
              ],
            "Kickstart|Back": ["返回"],
            "Kickstart|Billing ZIP/Postal": ["账单邮编"],
            "Kickstart|Brief description of your business (including tag lines, value proposition, etc.)":
              ["简要描述您的业务（包括品牌口号，价值主张等）。"],
            "Kickstart|Cancel": ["取消"],
            "Kickstart|Card Number": ["卡号"],
            "Kickstart|Change PayPal Account": ["更改 PayPal 账户"],
            "Kickstart|Change account email": ["修改账号邮箱"],
            "Kickstart|Change first name": ["修改名字"],
            "Kickstart|Complete": ["已完成"],
            "Kickstart|Contact Info": ["联系方式"],
            "Kickstart|Current Card": ["当前付款卡"],
            "Kickstart|DETAILS": ["详情"],
            "Kickstart|Delivered": ["已交付"],
            "Kickstart|Description": ["描述"],
            "Kickstart|Design Fee": ["设计费用"],
            "Kickstart|Due on %{paymentDate}": ["%{paymentDate}支付"],
            "Kickstart|Due today": ["今日支付"],
            "Kickstart|Edit": ["修改"],
            "Kickstart|Email": ["电子邮箱"],
            "Kickstart|Enter URLs to social media accounts for your business or project (i.e. Facebook, Twitter, Instagram, etc.).":
              [
                "请输入和您的业务/项目相关的社交媒体链接（例如Facebook, Twitter, Instagram等）。",
              ],
            "Kickstart|Features Selected": ["已选择的功能"],
            "Kickstart|Features available": ["可用功能"],
            "Kickstart|File exceeds maximum allowed size of 10MB.": [
              "文件超过了10MB限额。",
            ],
            "Kickstart|First Name": ["名字"],
            "Kickstart|Get visitors to call us": ["让访客给我们打电话"],
            "Kickstart|Get visitors to fill out a contact form": [
              "让访客填写联系表单",
            ],
            "Kickstart|Go back": ["返回"],
            "Kickstart|Go back to reselect": ["返回重新选择"],
            "Kickstart|Got everything you need? Great! Once you approve this delivery, your Kickstart site will be transferred to your account and marked as complete. You can then edit the site directly and publish it.":
              [
                "太棒了！一旦您确认签收此项交付，您的Kickstart网站将被转移到您的帐户并标记为“已完成”。之后您可以直接编辑该网站并发布它。",
              ],
            "Kickstart|Got it! In 48 to 72 hours, we'll create you...": [
              "收到！在48-72小时内，我们会为您制作…",
            ],
            "Kickstart|Have any edits or additional requirements? Please let us know.":
              ["有任何修改或附加需求吗？请告诉我们。"],
            "Kickstart|Help us understand your need, and our Kickstart Design Expert will design a perfect site just for you.":
              [
                "帮助我们更了解您的需求。我们的Kickstart设计专家将为您定制一个完美的网站。",
              ],
            "Kickstart|Help visitors to find us on a map": [
              "帮助访客在地图上找到我们",
            ],
            "Kickstart|Here's some of our past work. [strong:Select up to 5 sites for our Design Expert to reference] when building your site!":
              [
                "以下是一些我们之前的作品， [strong:请选择您喜欢的风格（最多5个）] ，以便我们的设计专家在制作您的网站时参考。",
              ],
            "Kickstart|I need edits": ["我需要修改"],
            "Kickstart|If you have any edits, please let us know within the next 7 days, and we'll be happy to complete them for you. After 7 days, your site will be transferred to your account, and you can edit it by yourself.":
              [
                "如果您有任何修改，请在接下来的7天内让我们知道，我们将很乐意为您完成。7天后，您的网站将被转移到您的帐户，您可以自己编辑它。",
              ],
            "Kickstart|In Progress": ["进行中"],
            "Kickstart|Invalid coupon code.": ["优惠券无效"],
            "Kickstart|Kickstart Expert Design Fee": ["Kickstart专家设计费"],
            "Kickstart|Last Name": ["姓"],
            "Kickstart|Last Updated on %{date}": ["最后更新于%{date}"],
            "Kickstart|Learn more": ["了解详情"],
            "Kickstart|Leaving this page will clear your Kickstart selections. Are you sure you want to leave this page?":
              ["离开此页面将丢失所有Kickstart选择。您确定要离开此页面吗?"],
            "Kickstart|Limited 2 Years": ["基础版两年套餐"],
            "Kickstart|Limited 3 Years": ["基础版三年套餐"],
            "Kickstart|Limited 5 Years": ["基础版五年套餐"],
            "Kickstart|Limited Monthly": ["基础版月付套餐"],
            "Kickstart|Limited Yearly": ["基础版年付套餐"],
            "Kickstart|MULTI-PAGE SITE": ["多页网站"],
            "Kickstart|Multi-Page Site": ["多页网站"],
            "Kickstart|My Kickstart Sites": ["我的Kickstart网站"],
            "Kickstart|Name of your site?": ["网站的名字？"],
            "Kickstart|No references selected. No worries, our design expert will come up with the best design for you.":
              ["未选择参考网站。别担心，我们的设计专家将为您做出最好的设计。"],
            "Kickstart|Once your purchase is confirmed, our Kickstart Design Expert will be in touch and we'll deliver your site within %{var1} hours.":
              [
                "在您完成付款后，我们的Kickstart设计专家将与您联系，我们将在%{var1}小时内交付您的网站。",
              ],
            "Kickstart|One Last Step: Submit Materials for Your Site": [
              "最后一步:为您的网站提交素材",
            ],
            "Kickstart|One-time, non-refundable fee.": [
              "一次性费用，不支持退款。",
            ],
            "Kickstart|Only one page": ["仅1页"],
            "Kickstart|Or use PayPal": ["或使用 PayPal"],
            "Kickstart|Or use credit card": ["或使用信用卡"],
            "Kickstart|Order a new Kickstart site": [
              "订购一个新的Kickstart网站",
            ],
            "Kickstart|Other": ["其他"],
            "Kickstart|Other past work on %{var1}...": [
              "其他我们制作过的%{var1}类型的网站……",
            ],
            "Kickstart|Payment Method": ["付款方式"],
            "Kickstart|Please confirm your first name (so we can address you properly).":
              ["请确认您的名字（这样我们才能正确称呼您）。"],
            "Kickstart|Please fill this field": ["请填写此字段"],
            "Kickstart|Please review your site and see how it works. If you're satisfied and approve it, we'll transfer the site to your account, and you'll be able to edit & publish it directly.":
              [
                "请查阅您的网站，看是否满意。如果您感到满意并确认签收，我们将会把网站转移到您的账号，您将可以直接编辑和发布它。",
              ],
            "Kickstart|Please submit any text/logos/images you want to use, any resources (PDFs, documents, video links, sample site links, etc.), or any specific instructions or notes.":
              [
                "请提交您想使用的任何文字/标志/图像，任何资源（pdf、文档、视频链接、示例网站链接等），或任何特定的说明或注释。",
              ],
            "Kickstart|Preview Link": ["预览链接"],
            "Kickstart|Pro 2 Years": ["专业版两年套餐"],
            "Kickstart|Pro 3 Years": ["专业版三年套餐"],
            "Kickstart|Pro 5 Years": ["专业版五年套餐"],
            "Kickstart|Pro Monthly": ["专业版月付套餐"],
            "Kickstart|Pro Monthly Plan Includes:": [
              "专业版月付套餐包含以下服务：",
            ],
            "Kickstart|Pro Yearly": ["专业版年付套餐"],
            "Kickstart|Pro Yearly Plan Includes:": [
              "专业版年付套餐包含以下服务：",
            ],
            "Kickstart|Promo code": ["优惠码"],
            "Kickstart|Purchase": ["购买"],
            "Kickstart|RECOMMENDED": ["推荐"],
            "Kickstart|Remove": ["删除"],
            "Kickstart|Required field": ["必填"],
            "Kickstart|SELECT": ["选择"],
            "Kickstart|SELECTED": ["已选中"],
            "Kickstart|SINGLE-PAGE SITE": ["单页网站"],
            "Kickstart|Select a Design Package": ["选择网站设计套餐"],
            "Kickstart|Select a template for our Kickstart Expert to start with":
              ["为我们的Kickstart专家选择一个模板开始。"],
            "Kickstart|Select yearly plan for an [strong:additional %{discount}%% off!]":
              ["选择专业版年付套餐享受[strong:%{discount}折优惠！]"],
            "Kickstart|Sell online": ["线上销售"],
            "Kickstart|Showcase content": ["展示内容"],
            "Kickstart|Single Page Site": ["单页网站"],
            "Kickstart|Single page is only recommended for sites with limited content, e.g. personal sites.":
              ["仅推荐内容较少的网站使用单页面，例如个人网站。"],
            "Kickstart|Site Hosting Plan": ["网站托管费用"],
            "Kickstart|Site Name": ["网站名称"],
            "Kickstart|Site Type": ["网站类型"],
            "Kickstart|Site design references": ["网站设计参考"],
            "Kickstart|Site design references:": ["网站设计参考："],
            "Kickstart|Skip & let Design Expert decide": [
              "跳过，让设计专家决定",
            ],
            "Kickstart|Social media accounts": ["社交媒体账号"],
            "Kickstart|Submit": ["提交"],
            "Kickstart|Thank you for your purchase. An invoice has been sent to your email address [strong: %{var1}.] Please send us any materials you have for your Kickstart site, so we can start building!":
              [
                "感谢您的购买。发票已发送到您的电子邮件地址[strong: %{var1}.]。请将任何您有的网站素材发送给我们，以便我们可以开始搭建!",
              ],
            "Kickstart|This helps us understand who to design for.": [
              "这有助于我们理解为谁设计。",
            ],
            "Kickstart|This kickstart site has been deleted.": [
              "Kickstart网站已被删除。",
            ],
            "Kickstart|This tells us how to design your landing page.": [
              "这将告诉我们如何设计您的登陆页面。",
            ],
            "Kickstart|Today's total": ["今日总共应付款"],
            "Kickstart|Total Price": ["总价"],
            "Kickstart|Uh-oh! There’s been an error loading templates. [span: Try loading again.]":
              ["啊哦！加载模版出错了。[span: 请再试一次。]"],
            "Kickstart|Up to 7 pages": ["多达7页"],
            "Kickstart|Update Card & Purchase": ["更新付款卡并支付"],
            "Kickstart|Upload Images": ["上传图片"],
            "Kickstart|Upload files": ["上传文件"],
            "Kickstart|Use a different card": ["使用其他银行卡支付"],
            "Kickstart|Use card on file (last four digits %{var})": [
              "使用现账户银行卡支付（尾号%{var}）",
            ],
            "Kickstart|VIP 10 Years": ["VIP版月付套餐"],
            "Kickstart|VIP 2 Years": ["VIP版两年套餐"],
            "Kickstart|VIP 3 Years": ["VIP版三年套餐"],
            "Kickstart|VIP 5 Years": ["VIP版五年套餐"],
            "Kickstart|VIP Yearly": ["VIP版年付套餐"],
            "Kickstart|View More": ["查看更多"],
            "Kickstart|View site": ["查看网站"],
            "Kickstart|We'll use this to communicate with you.": [
              "我们会用这个和您沟通。",
            ],
            "Kickstart|What do you want the site for?": [
              "您想要这个网站做什么？",
            ],
            "Kickstart|What kind of site do you need?": [
              "您想做一个什么样的网站？",
            ],
            "Kickstart|What's the main goal of your site?": [
              "网站的主要目标是什么？",
            ],
            "Kickstart|Who are your target visitors?": ["网站的目标受众是谁?"],
            "Kickstart|You are currently on Strikingly %{plan} plan": [
              "您目前的Strikingly套餐为 %{plan}",
            ],
            "Kickstart|You have an incomplete Kickstart order. [link:Continue checkout here.]":
              ["您有一个未完成的Kickstart订单。[link:点击这里继续支付。]"],
            "Kickstart|You have an incomplete Kickstart order. [link:Continue submitting materials here.]":
              ["您有一个未完成的Kickstart订单。[link:点击这里继续提交素材。]"],
            "Kickstart|Your Kickstart site [strong:%{websiteName}] is complete. You can find the site in [link:My Sites] and edit on your end!":
              [
                "您的Kickstart网站[strong:%{websiteName}]已完成。您可以在中[link:我的网站]找到该网站，并在您自己的账号上进行编辑!",
              ],
            "Kickstart|Your Kickstart site is done! Please review the site to make sure it meets your requirements.":
              ["您的Kickstart网站完成了！请检查网站，以确保它符合您的要求。"],
            "Kickstart|Your Kickstart site is now in the works. You will receive the site preview by [strong:%{date}].":
              [
                "您的Kickstart网站正在制作中。您将在[strong:%{date}]收到网站预览。",
              ],
            "Kickstart|Your card was declined. Please use a different card or contact your bank.":
              ["这张信用卡交易失败了。请使用另一张信用卡或联系银行。"],
            "Kickstart|Your materials have been submitted! Our expert designer will start building your site and get in touch with you soon.":
              [
                "您的网站素材已提交!我们的设计专家将开始搭建您的网站，并会尽快联系您。",
              ],
            "Kickstart|Your requirements have been submitted! Our expert designer will get in touch with you soon.":
              ["您的需求已提交！我们的设计专家会尽快与您联系。"],
            "Kickstart|Your site has been transferred! Now you can access your Kickstart site from Dashboard → My Sites.":
              [
                "您的网站已被转移！现在您可以从控制面板→我的网站访问您的Kickstart网站。",
              ],
            "Kickstart|You’ve made too many attempts connecting PayPal to your account. Please try again in an hour. Contact support@strikingly.com if you have any questions!":
              [
                "PayPal和账户连接次数过多。请 1 小时后再试。如果您有任何问题，请联系support@strikingly.com !",
              ],
            "Kickstart|[strong:%{var1}%% discount applied!] Offer is only valid for the initial billing period.":
              [
                "[strong:%{var1}%折优惠已生效！] 请注意该折扣仅适用于您的第一个付款周期",
              ],
            "Kickstart|[strong:GET %{discount}%%] OFF If you switch to Pro Yearly or above. Sale ends in [bold:%{remainingDays} days!]":
              [
                "如果您切换到专业版套餐包年或以上，将[strong:获得%{discount}折优惠]。距离优惠结束还剩[bold:%{remainingDays}天！]",
              ],
            "Kickstart|and much more ...": ["以及更多..."],
            "Kickstart|month": ["月"],
            "Kickstart|year": ["年"],
            "LIVE CHAT": ["在线聊天"],
            "LOGOSC|Design your logo": ["智能生成LOGO"],
            "LOGOSC|Promotion": ["活动推广"],
            "LOGOSC|Visit LOGOSC official site": ["前往LOGO神器官网"],
            "LOGOSC|and design your own logo!": ["智能生成你的专属LOGO！"],
            "Landing|24/7 Support": ["客户服务"],
            "Landing|Privacy Policy": ["法律声明"],
            "Landing|Terms of Service": ["服务条款"],
            "Last 30 Days": ["过去 30 天"],
            "Last 7 Days": ["近 7 天"],
            "Last Name": ["姓氏"],
            Layout: ["布局"],
            "Learn more": ["了解更多"],
            "Learn more.": ["了解更多。"],
            "Let viewers email you directly.": ["让访客直接向你发送邮件"],
            "Light Text": ["明亮文本"],
            "Light Text + Overlay": ["明亮文本+蒙版"],
            Limited: ["基础版"],
            "Link Name": ["链接名称"],
            "Link URL": ["链接网址"],
            LinkedIn: ["LinkedIn 应用"],
            Live: ["正常"],
            "Live Chat": ["在线聊天"],
            "LiveChat|-- Teng, Strikingly cofounder": [
              "-- Teng, Strikingly 联合创始人",
            ],
            "LiveChat|All suggestions welcome!": ["欢迎提出任何建议！"],
            "LiveChat|Contact Info Fields": ["联系信息字段"],
            "LiveChat|Contact Info Not Required": ["不需要联系方式"],
            "LiveChat|Contact Info Required": ["需要联系方式"],
            "LiveChat|Do not require the visitor to submit their info before chatting. (It may be difficult to reach out to your visitors after your conversation.)":
              [
                "不需要访客在聊天前提交联系方式（这可能会使你很难和你的访客取得进一步的联系）。",
              ],
            "LiveChat|Enter your contact info so we can follow up.": [
              "输入你的联系方式，以便我们跟进。",
            ],
            "LiveChat|Here's what the notification looks like!": [
              "这是桌面提醒示例！",
            ],
            'LiveChat|Install the latest Strikingly app on your phone (search "Strikingly" on the App Store).':
              ["在手机上安装最新Strikingly软件（在软件中心搜索“Strikingly”）"],
            "LiveChat|Live Chat Collaborators can set their own name and profile picture, and you will be able to see their chats.":
              [
                "在线聊天协作队员可设置其自己的名称及头像，你也可以看到他们的聊天记录。",
              ],
            "LiveChat|Log into the app, and make sure": ["登入软件，并确保"],
            "LiveChat|Make sure your phone allows showing notifications for our app.":
              ["确保你的手机允许我们的软件发送通知"],
            "LiveChat|Please enter your info and let's start chatting!": [
              "请输入你的联系方式，让我们开始聊天吧！",
            ],
            "LiveChat|Prompt the visitor for their contact info, but allow them to opt out and chat immediately.":
              ["提示访客填写联系方式，但允许他们跳过该步骤并直接开始聊天。"],
            "LiveChat|Require Contact Info to Chat": ["需要联系方式才能聊天"],
            "LiveChat|Require the visitor to submit their contact info before chatting.":
              ["需要访客在聊天前提交联系方式。"],
            "LiveChat|Show Strikingly Logo in Chat Window": [
              "在聊天窗口中显示Strikingly图标",
            ],
            "LiveChat|Smart Prompt (Recommended)": ["智能提示（推荐）"],
            "LiveChat|Strikingly's branding appears at the bottom of the chat window.":
              ["Strikingly图标会显示在聊天窗口的底部。"],
            "LiveChat|Thanks for activating Live Chat! What's one thing we can do to make Live Chat even better?":
              ["非常感谢使用在线聊天功能！跟我们聊聊怎么能做的更好？"],
            "LiveChat|To receive mobile notifications and reply to chats directly on your phone, please:":
              ["在手机上接收通知并直接回复客户聊天，请："],
            "LiveChat|We strongly recommend you turn this on. Greet visitors and invite them to chat when page loads.":
              ["我们强烈建议开启。访客进入网站后，将欢迎他们跟你聊聊。"],
            "LiveChat|We've just sent a test notification!": [
              "我们刚发送了一个提醒示例！",
            ],
            "LiveChat|[Live chat on mysite.com]": ["[mysite.com 的在线聊天]"],
            "Load More": ["加载更多"],
            "Loading...": ["正在加载……"],
            Location: ["地址"],
            "Login to Webmail": ["登录到邮箱账号"],
            Logos: ["图标设计"],
            "Mailchimp Embed Code": ["MailChimp 嵌入代码："],
            "Make Your Own Section!": ["自己设计你的版块吧"],
            "Make sure these settings are correct.": ["请确保以下设置无误"],
            "Make sure you edit the newsletter content before sending! Just click inside the newsletter to write your own content.":
              [
                "确保你在发送邮件前编辑过邮件的内容！直接选中邮件内容即可进行修改。",
              ],
            "Manual Entry": ["手动录入"],
            "Mark as nonspam": ["标记为非垃圾邮件"],
            "Mark as spam": ["标记为垃圾邮件"],
            "Marketing|Coupons": ["优惠券"],
            "Marketing|Newsletters": ["营销邮件"],
            "Marketing|Promotion": ["营销中心"],
            "Marketing|SEO Checklist": ["SEO 优化"],
            Membership: ["会员功能"],
            "Membership is not activated for the site which this user has accessed.":
              ["该用户访问的网站未开启会员功能。"],
            "Membership| Name Too Long!": ["用户名过长！"],
            "Membership| Name Too Short!": ["用户名过短！"],
            "Membership| Update Account Info": ["更新账户信息"],
            "Membership|%{var1} Members": ["%{var1} 位会员"],
            "Membership|%{var1} tiers selected": ["已选中 %{var1} 个会员等级"],
            "Membership|%{var1}/%{var2} %{var3} site(s) published": [
              "已发布%{var1}/%{var2} 个%{var3}网站",
            ],
            "Membership|%{var1}/month": ["%{var1}/月"],
            "Membership|%{var1}/quarter": ["%{var1}/季度"],
            "Membership|%{var1}/year": ["%{var1}/年"],
            "Membership|& more": ["及更多"],
            "Membership|(legacy)": ["（失效）"],
            "Membership|/ 3 Months": ["/ 3个月"],
            "Membership|/ Month": ["/ 月"],
            "Membership|/ Year": ["/ 年"],
            "Membership|A login URL and new password will be emailed to this user. This user will not be billed for this plan, even if you choose a paid subscription tier.":
              [
                "用户会收到一封包含登录链接和密码的邮件。即便你为该用户选择了付费的会员等级，该用户也不会付费。",
              ],
            "Membership|A new member has been registered on %{url}.": [
              "你的网站 %{url} 上有一位新注册会员。",
            ],
            "Membership|A notice for you that you've received a new member.": [
              "新会员注册成功后，你会收到的通知。",
            ],
            "Membership|A welcome message sent to your new member. You can introduce the membership, explain benefits, and list contact info.":
              [
                "新会员会收到一封来自网站的欢迎邮件，你可以在这封邮件中介绍会员资格、会员福利以及你的联系方式。",
              ],
            "Membership|Activate Paid Subscription Membership in Membership settings.":
              ["需选择会员注册方式为“付费订阅会员制”。"],
            "Membership|Active": ["进行中"],
            "Membership|Add Tier": ["添加会员等级"],
            "Membership|Add a Store to your site to attach membership to products!":
              ["为你的网站添加商店，出售会员专享商品！"],
            "Membership|Add a product to your store to use this registration method.":
              ["请在你的商城里添加一个商品以使用此注册方式。"],
            "Membership|Add free or paid membership tiers for your site. Up to 5 tiers.":
              ["为网站添加免费或付费会员等级。最多可添加5个。"],
            "Membership|All visitors": ["所有访客"],
            "Membership|Allow visitors to [strong: register an account] on your site to become your members, and allow members to see exclusive members-only content.":
              [
                "允许访客在你的网站上[strong: 注册帐户]成为会员，并为他们提供专享内容。",
              ],
            "Membership|Allow visitors to register an account on your site to become your members.":
              ["允许访客在网站上注册成为会员。"],
            "Membership|Any Product": ["任何商品"],
            "Membership|Anyone can freely sign up to become a member.": [
              "允许任何人注册成为会员。",
            ],
            "Membership|Anyone can register, no payment required.": [
              "允许任何人免费注册会员。",
            ],
            "Membership|Anyone who purchases a product from your site will receive membership. When the purchase is complete, an email will be sent to the customer with login information.":
              [
                "购买任一商品的访客都将获得会员资格。 购买完成后，系统会向他们发送一封包含会员登录信息的电子邮件。",
              ],
            "Membership|Anyone who purchases the selected product(s) will receive membership. When the purchase is complete, an email will be sent to the customer with login information.":
              [
                "购买指定商品（一件或多件）的访客都将获得会员资格。 购买完成后，系统会向他们发送一封包含会员登录信息的电子邮件。",
              ],
            "Membership|Are you absolutely sure you want to delete this tier: %{var1}?":
              ["你确定要删除这个会员等级吗：%{var1} ？"],
            "Membership|Are you absolutely sure you want to disable membership on this site? This will cancel all your existing paid members' subscriptions immediately! This action cannot be undone!":
              [
                "你确定要在这个网站上停用会员功能吗？这将会立即取消已有付费会员的订阅。此项操作不可撤销。",
              ],
            "Membership|Are you absolutely sure you want to disable membership?":
              ["你确定要停用会员功能吗？"],
            "Membership|Are you sure you want to buy <strong><strong class='extra-sites'>0</strong> extra %{var} site(s)</strong>? You will be billed an additional <strong>$</strong><strong class='extra-payment'>0</strong><strong class='per-month hidden'>/month</strong><strong class='per-year hidden'>/year</strong><strong class='per-2year hidden'>/2years</strong>":
              [
                "你确定要购买<strong class='extra-sites'>0</strong> 个额外的%{var}网站吗</strong>？系统会额外收取 <strong></strong><strong class='extra-payment'>0</strong><strong class='per-month hidden'>/月</strong><strong class='per-year hidden'>/年</strong><strong class='per-2year hidden'>/2年</strong>。",
              ],
            "Membership|Are you sure you want to cancel this member's subscription?":
              ["你确定要取消这个会员的订阅吗？"],
            "Membership|Are you sure you want to cancel your subscription?": [
              "你确定要取消这个订阅吗？",
            ],
            "Membership|Are you sure you want to change the currency?": [
              "你确定要更改货币吗？",
            ],
            "Membership|Are you sure you want to change the price of this membership to %{price}?":
              ["你确定要调整价格为 %{price} 吗？"],
            "Membership|Are you sure you want to delete this membership tier: %{var1}? This tier will no longer be available for new registrations.":
              [
                "你确定要删除这个会员等级吗：%{var1}？新用户将无法注册这个会员等级。",
              ],
            "Membership|Are you sure you want to disable paid membership and cancel all active paid memberships on this site?":
              [
                "你确定要停用付费会员系统，并取消全部还在有效期内的付费订阅吗？",
              ],
            "Membership|Are you sure you want to disable this billing period? Existing members will continue be charged with this billing period, but new customers will not see this billing period when registering.":
              [
                "你确定要停用这个付款周期吗？已订阅这个付款周期的用户将会继续按这个周期付费，但新用户在注册时将看不到这个付款周期选项。",
              ],
            "Membership|Are you sure you want to exit? Unsaved changes will be lost.":
              ["你确定要退出吗？未保存的更改将丢失。"],
            "Membership|Are you sure you want to switch to %{var1}?": [
              "你确定改用%{var1}进行收款吗？",
            ],
            "Membership|Back to home": ["返回主页"],
            "Membership|Billed every 3 months": ["每3个月收费"],
            "Membership|Buy More Sites": ["购买额外网站"],
            "Membership|Buy Product to Register": ["通过购买商品注册"],
            "Membership|Buy extra %{var} sites": ["购买额外的%{var}网站"],
            "Membership|Cancel": ["取消"],
            "Membership|Cancel subscription": ["取消订阅"],
            "Membership|Cancelled": ["已取消"],
            "Membership|Cancelled by %{email}": ["取消订阅： 由 %{email} 取消"],
            "Membership|Cancelled by payment failed": ["取消订阅: 续费失败"],
            "Membership|Cancelled paid membership [link: #%{id}] (%{price} / month)":
              ["取消订阅付费会员 [link: #%{id}] (%{price} / 月)"],
            "Membership|Cancelled paid membership [link: #%{id}] (%{price} / quarter)":
              ["取消订阅付费会员 [link: #%{id}] (%{price} / 季度)"],
            "Membership|Cancelled paid membership [link: #%{id}] (%{price} / year)":
              ["取消订阅付费会员 [link: #%{id}] (%{price} / 年)"],
            "Membership|Cheers!\n[page_name]": ["顺祝商祺！\\n[page_name]"],
            "Membership|Confirm new password (optional)": [
              "确认新密码（可选）",
            ],
            "Membership|Confirm purchase": ["确认购买"],
            "Membership|Continue To Checkout": ["继续付款"],
            "Membership|Create New Tier": ["创建新会员等级"],
            "Membership|Create a members-only page": ["创建会员专享页面"],
            "Membership|Create a password": ["创建密码"],
            "Membership|Create members-only pages that are only accessible to customers who bought specific products.":
              [
                "创建会员专享页面，只有购买了特定产品或服务的客户才能访问这些页面。",
              ],
            "Membership|Current Password Is Incorrect": ["当前密码错误"],
            "Membership|Current Plan": ["目前订阅状态"],
            "Membership|Date": ["下单日期"],
            "Membership|Dear [user name],": ["亲爱的 [user name]，"],
            "Membership|Disable Membership": ["停用会员功能"],
            "Membership|Edit Tier": ["编辑会员等级"],
            "Membership|Email Notifications": ["邮件通知"],
            "Membership|Email address": ["电子邮箱地址"],
            "Membership|Email: newmemberemail@gmail.com": [
              "电子邮箱：newmemberemail@gmail.com",
            ],
            "Membership|Enable strong anti-bot verification for member registration":
              ["为会员注册启用更强的反机器人验证"],
            "Membership|Enter current password": ["输入当前密码"],
            "Membership|Enter new password (optional)": ["输入新密码（可选）"],
            "Membership|Enter your email to reset your password.": [
              "输入邮箱地址以重置密码。",
            ],
            "Membership|Existing members will no longer be able to log into your site. Existing member information will be kept, and you can re-enable membership later.":
              [
                "现有会员将不能再登录你的网站，但他们的信息会被保存，你也可以随时重新启用会员功能。",
              ],
            "Membership|Extra %{var} sites have the same billing period as your plan. You’ll be billed immediately, pro-rated to your current billing cycle.":
              [
                "额外的%{var}网站的结算期与你的计划相同。系统会自动根据你当前的结算周期计算费用。",
              ],
            "Membership|Failed Payment for Subscription": ["订阅支付失败"],
            "Membership|Forgot Password": ["忘记密码"],
            "Membership|Forgot password": ["忘记密码"],
            "Membership|Free": ["免费"],
            "Membership|Free Membership": ["免费会员制"],
            "Membership|Got It!": ["知道了！"],
            "Membership|Grant Membership to Store Customers": [
              "购买商品后成为会员",
            ],
            "Membership|Hello there,\n\nYour subscription on [page_name] has been cancelled, and you will no longer be billed.":
              [
                "你好，\\n\\n你在网站  [page_name]  的订阅已取消，账单将不再自动续费。",
              ],
            "Membership|Hello there, \n\nThank you for your new subscription on [page_name]!":
              ["你好， \\n\\n感谢你在网站[page_name]开始了新的订阅！"],
            "Membership|Hello there, \n\nYour subscription on [page_name] has failed to renew and has been cancelled.":
              [
                "你好，\\n\\n你在网站 [page_name] 的订阅续费失败，订阅已自动取消。",
              ],
            "Membership|Hello there, \n\n[user name] failed to renew their subscription on [page_name], and the subscription has been cancelled.":
              [
                "你好，\\n\\n[user name]在网站[page_name]的订阅续费失败，订阅已自动取消。",
              ],
            "Membership|Hello there, \n\n[user name] has started a new subscription on [page_name] and completed the first payment. Their next bill date is {{next bill date}}.":
              [
                "你好！\n\n[user name] 在网站  [page_name]  付款成功并开始订阅。下个续费日期为{{next bill date}}。",
              ],
            "Membership|Hello there, \n\n[user name]'s subscription on [page_name] has been cancelled.":
              ["你好，\\n\\n[user name]在网站[page_name]的订阅已经取消。"],
            "Membership|Hi there!\n\nYou're now a member of [page_name]. Your membership details are below.":
              [
                "你好！\\n\\n你现在是网站[page_name]的会员了。你的会员信息如下。",
              ],
            "Membership|Hide legacy tiers": ["隐藏已失效会员等级"],
            "Membership|How many extra %{var} sites do you need?": [
              "你还需要几个%{var}网站？",
            ],
            "Membership|I Understand, change to paid membership": [
              "已了解，仍切换到付费会员系统",
            ],
            "Membership|I understand, confirm price change": [
              "已了解，确认价格调整",
            ],
            "Membership|I understand, delete this membership tier": [
              "我已了解，删除这个会员等级",
            ],
            "Membership|I understand, disable membership": [
              "我已了解，停用会员功能",
            ],
            "Membership|I understand, disable paid membership": [
              "已了解，停用付费会员系统",
            ],
            "Membership|If you activate Paid Subscriptions, you can let visitors subscribe here.":
              [
                "如果你启用了付费订阅会员制，你可以在这里让网站访客直接进行订阅。",
              ],
            "Membership|If you already have a Simple Store on your site, use this option to automatically grant membership to your store’s customers. (This is useful if you’re selling content from your store.)":
              [
                "如果你已经在使用商城模块，可以用这个设置让你的商城买家自动成为会员。",
              ],
            "Membership|If you cancel this subscription, this member will no longer be able to access the paid member pages.":
              ["取消会员订阅后，该会员将无法访问会员专享页面。"],
            "Membership|If you cancel your subscription, you will no longer have access to members-only content.":
              ["取消会员订阅后，你将无法访问会员专享页面。"],
            "Membership|Includes all free members, paid members, and members with cancelled subscriptions.":
              ["全部免费会员、订阅中的付费会员、以及已取消订阅的付费会员。"],
            "Membership|Incorrect email or password.": ["邮箱或密码错误。"],
            "Membership|Initial Password: 5%hgjWf4v-8": [
              "初始密码：5%hgjWf4v-8",
            ],
            "Membership|Initial payment received": ["首次付款成功"],
            "Membership|Invalid Current password.": ["当前密码无效。"],
            "Membership|Invalid email address.": ["无效邮箱。"],
            "Membership|Invalid name.": ["用户名无效。"],
            "Membership|Invalid password confirmation.": ["确认密码操作无效。"],
            "Membership|Invalid password.": ["无效的密码。"],
            "Membership|Items": ["商品"],
            "Membership|Keep my subscription": ["继续订阅"],
            "Membership|Log In": ["登录"],
            "Membership|Log Out": ["退出"],
            "Membership|Login": ["登录"],
            "Membership|Login URL": ["登录链接"],
            "Membership|Login URL: ": ["登录链接："],
            "Membership|Login to your Strikingly account to view more details.":
              ["立即登录 Strikingly 账户，查看更多详细信息。"],
            "Membership|Logout": ["退出"],
            "Membership|MY ORDERS": ["我的订单"],
            "Membership|Manage Account": ["管理账户"],
            "Membership|Manage members-only pages": ["管理会员专享页面"],
            "Membership|Member #1": ["会员 #1"],
            "Membership|Member Email: newmemberemail@gmail.com": [
              "会员邮箱：newmemberemail@gmail.com",
            ],
            "Membership|Member Login": ["会员登录"],
            "Membership|Member Registration": ["会员注册"],
            "Membership|Member login": ["会员登陆"],
            "Membership|Member registration": ["会员注册"],
            "Membership|Member since %{createdAt}": [
              "会员开始时间 %{createdAt}",
            ],
            "Membership|Members only": ["仅限注册会员"],
            "Membership|Members-Only Pages": ["会员专享页面"],
            "Membership|Membership Tier": ["会员等级"],
            "Membership|Membership granted. Email sent.": [
              "授予会员资格邮件已发送。",
            ],
            "Membership|Membership password reset. Email sent.": [
              "重置会员密码邮件已发送。",
            ],
            "Membership|Membership payment has failed. You're still registered as a free member. Please try again.":
              [
                "会员付费失败了。已为您注册免费会员账号，请再次尝试付费订阅以成为付费会员。",
              ],
            "Membership|Membership was deleted": ["已取消会员资格"],
            "Membership|Membership was suspended": ["已暂停会员资格"],
            "Membership|Membership was unsuspended": ["已开启会员资格"],
            "Membership|Memberships payments recur forever until cancelled. [link: Learn more]":
              [
                "订阅会员将持续自动续月费，除非其主动取消订阅。[link: 了解更多]",
              ],
            "Membership|Multiple Membership Tiers": ["多个会员等级"],
            "Membership|My Account": ["我的账户"],
            "Membership|Name": ["会员名"],
            "Membership|New Membership! newmemberemail@gmail.com": [
              "新会员！newmemberemail@gmail.com",
            ],
            "Membership|New member": ["新会员"],
            "Membership|New paid subscription": ["新订阅"],
            "Membership|New subscription #%{number}": ["新订阅 #%{number}"],
            "Membership|Next": ["下一步"],
            "Membership|Next Bill Date": ["下次扣款时间"],
            "Membership|Next bill on %{date}": ["自动续费时间 %{date}"],
            "Membership|No, go back": ["不，返回"],
            "Membership|Note About Membership Tier": ["会员等级注意事项"],
            "Membership|Note about free members": ["免费会员注意事项"],
            "Membership|Note about paid members": ["付费会员注意事项"],
            "Membership|Notifications sent to member": ["发送给会员的通知"],
            "Membership|Notifications sent to you": ["发送给你的通知"],
            "Membership|Only includes paid members with an active paid subscription.":
              ["仅包含订阅中的付费会员。"],
            "Membership|Only registered members who purchased a specific product":
              ["仅限购买指定商品的注册会员"],
            "Membership|Order History": ["历史订单"],
            "Membership|Order ID": ["订单编号"],
            "Membership|Paid Membership": ["付费会员等级"],
            "Membership|Paid Subscription Membership": ["付费订阅会员制"],
            "Membership|Paid members only": ["仅限付费会员"],
            "Membership|Paid memberships are currently disabled. The subscriptions below have been cancelled. [link: Upgrade to PRO or VIP] to re-enable paid memberships.":
              [
                "付费会员功能已停用，下方的相关订阅已全部自动取消。[link: 升级至专业版Pro或以上]后可重启付费会员功能。",
              ],
            "Membership|Paid memberships with subscription billing. Subscription payment is required to become a member.":
              ["付费订阅会员将需要每月支付订阅费。"],
            "Membership|Password": ["密码"],
            "Membership|Password Too Short!": ["密码过短！"],
            "Membership|Password:": ["密码："],
            "Membership|Passwords must match.": ["密码必须匹配。"],
            "Membership|Payment Failed": ["续费失败"],
            "Membership|Payment received": ["续费成功"],
            "Membership|Please email us at [user_email] if you have any questions.\n\nCheers!\n[page_name]":
              [
                "如果你有任何问题，请邮件联系我们 [user_email]，\\n\\n顺祝商祺！\\n[page_name]",
              ],
            "Membership|Price": ["价格"],
            "Membership|Recurring payments are collected on the same day of the month (Monthly) or same date in next year (Yearly). [link: Learn more]":
              ["续费会在下个月或者明年的同一天进行。[link:了解更多]"],
            "Membership|Register": ["注册"],
            "Membership|Register Account": ["注册账户"],
            "Membership|Register new account": ["注册新账户"],
            "Membership|Registered": ["已注册"],
            "Membership|Registered as member": ["注册成为会员"],
            "Membership|Registered as member via store purchase": [
              "购买商品即可注册成为会员",
            ],
            "Membership|Registration Method": ["注册方式"],
            "Membership|Registration URL": ["登录链接"],
            "Membership|Registration failed.": ["注册失败。"],
            "Membership|Registration failed. Email already exists.": [
              "注册失败 - 该邮箱地址已存在",
            ],
            "Membership|Registrations are closed at this time.": [
              "注册已关闭。",
            ],
            "Membership|Requires Store": ["仅适用于商城模块"],
            "Membership|Save %{var1}%%": ["节省 %{var1}%%"],
            "Membership|Save members’ shipping info for faster repeat purchases.":
              ["保存会员的配送信息，方便会员复购。"],
            "Membership|Select Membership Tier": ["选择会员等级"],
            "Membership|Select Product(s)": ["选择商品"],
            "Membership|Select Registration Method": ["选择会员注册方式"],
            "Membership|Select all": ["全选"],
            "Membership|Select none": ["取消全部"],
            "Membership|Sent when a member starts a paid subscription": [
              "订阅付款后发送邮件通知",
            ],
            "Membership|Sent when a member's payment fails on renewal": [
              "续费扣款失败后发送邮件通知",
            ],
            "Membership|Sent when a subscription is cancelled, by you or the customer":
              ["你或会员取消订阅后发送邮件通知"],
            "Membership|Set different tiers (including recurring paid membership) for your site, each accessing different pages.":
              [
                "你现在可以为你的网站设置不同的会员等级，其中也包含自动续费会员，不同的会员等级可以设置不同的页面权限。",
              ],
            "Membership|Set up payments.": ["设置支付"],
            "Membership|Setting a password will remove the members-only setting. Anyone with the password will be able to access this page. Are you sure you want to set a password?":
              [
                "设置密码会移除会员专享页面的相关设置。 任何拥有密码的人都可以访问此页面。 你确定要设置密码吗？",
              ],
            "Membership|Setting this page as members-only will remove the old password (%{password}). Are you sure you want to set this page as members-only?":
              [
                "将此页面设置为会员专用页面会删除旧密码（%{password}）。你确定要将此页面设置为会员专用吗？",
              ],
            "Membership|Show Login / Register Buttons in Main Navigation for Non-Members":
              ["在非会员页面的导航栏中，显示登录/注册按钮"],
            "Membership|Since %{date}": ["开始时间 %{date}"],
            "Membership|Sorry, activating Paid Membership with Square is only supported for sites with HTTPS enabled. Please contact support to resolve this.":
              [
                "抱歉，只有启用了 HTTPS 的网站才支持使用 Square 开启付费会员订阅。 请联系客服解决此问题。",
              ],
            "Membership|Specific Product": ["指定商品"],
            "Membership|Specific tiers": ["仅限指定会员等级"],
            "Membership|Start Date": ["开始时间"],
            "Membership|Submit": ["提交"],
            "Membership|Subscribe": ["订阅"],
            "Membership|Subscribed to paid membership [link: #%{id}] (%{price} / month)":
              ["订阅付费会员 [link: #%{id}] (%{price} / 月)"],
            "Membership|Subscribed to paid membership [link: #%{id}] (%{price} / quarter)":
              ["订阅付费会员 [link: #%{id}] (%{price} / 季度)"],
            "Membership|Subscribed to paid membership [link: #%{id}] (%{price} / year)":
              ["订阅付费会员 [link: #%{id}] (%{price} / 年)"],
            "Membership|Subscription": ["订阅"],
            "Membership|Subscription No.": ["订阅号."],
            "Membership|Subscription Price Change": ["会员订阅价格调整"],
            "Membership|Subscription cancelled": ["订阅取消"],
            "Membership|Subscription renewal failed": ["订阅续费失败"],
            "Membership|Subscription renewal failed #Subscription No.": [
              "订阅续费失败 #订单号。",
            ],
            "Membership|TOTAL": ["累计收款金额"],
            "Membership|TOTAL RECEIVED": ["累计收款金额"],
            "Membership|Take recurring payments! Allow visitors to subscribe to be a member.":
              ["收取订阅月费！访客可以付费注册成为订阅会员。"],
            "Membership|Test account:": ["测试账户："],
            "Membership|Test tier": ["测试会员等级"],
            "Membership|Thank you for your subscription!": ["感谢你的订阅！"],
            "Membership|The currency change will only apply to your new membership tiers. (e.g. If your existing membership tier is set to USD $10/month and you change currency to EUR,  subscriptions on this tier will continue to renew at USD $10.)":
              [
                "收款货币的更改仅适用于新的会员等级。例如，若你当前的会员等级设定为每月10美元，当收款货币更改为欧元后，这一会员等级将仍按每月10美元续费。",
              ],
            "Membership|The price change will only affect the future subscribers. [hint: (e.g. If a member subscribed for $10/month and you change the price to $15/month, this customer's subscription will continue to renew at $10.)]":
              [
                "价格调整只影响新的付费订阅会员，不影响老会员订阅价格[hint:（譬如老会员现在订阅费为 $10/月，而价格被修改为$15/月，该老会员会仍然以$10/月的价格自动续费）]。",
              ],
            "Membership|The price must be greater than or equal to 1.": [
              "价格必须大于等于1",
            ],
            "Membership|These members' subscriptions will be cancelled when their current billing period ends. After that, they will not be billed any more, but they will still be able to log in and access pages as free members.":
              [
                "这些会员的订阅将会持续到他们当前账单周期结束。周期结束后他们将不再付费，但仍然可以作为免费会员访问你的网站。",
              ],
            "Membership|This button will open the Log In & Registration screen for this site's members. (If already logged in, this button will go to the default member's page.)":
              [
                "你的访客点击这个按钮将会打开本网站的会员登录注册页面。（如果用户已经登录会员，则点击按钮将直接跳转到默认会员页面。）",
              ],
            "Membership|This link will open the Log In & Registration screen for this site's members. (If already logged in, this link will go to the default member's page.)":
              [
                "你的访客点击这个链接将会打开本网站的会员登录注册页面。（如果用户已经登录会员，则点击链接将直接跳转到默认会员页面。）",
              ],
            "Membership|This setting can be changed later.": [
              "以上选项后期可以进行修改。",
            ],
            "Membership|This site has %{var1} paid members with a recurring paid subscription. Paid members' subscriptions will expire immediately, and will no longer be billed, and they will be converted to free members.":
              [
                "这个网站有 %{var1} 个付费会员订阅了自动续费的会员。付费会员的订阅会立刻过期，他们也不会再付费，同时，他们会变为免费会员。",
              ],
            "Membership|This will be shown at member registration. Describe this tier and why members should join.":
              [
                "请描述你的会员等级详情以及吸引会员加入的理由，这段信息将会在会员注册页面显示。",
              ],
            "Membership|Tier Description (Optional)": ["会员等级描述（选填）"],
            "Membership|Tier Name": ["会员等级名称"],
            "Membership|Tier Name is required": ["请输入会员等级名称"],
            "Membership|To change subscription, please cancel your current subscription.":
              ["要更换订阅，请先取消当前订阅。"],
            "Membership|To reset a new price for all subscribers, you will need to cancel the subscriptions first.":
              [
                "如需调整现有订阅会员的月费费用，你需要先取消这些会员的订阅，并让他们重新付费订阅。",
              ],
            "Membership|To subscribe again, please [link: visit our site].": [
              "重新订阅，请[link: 访问我的网站]",
            ],
            "Membership|Total": ["总额"],
            "Membership|UPDATE": ["更新"],
            "Membership|UPDATE ACCOUNT INFO": ["更新账户信息"],
            "Membership|Update account information successfully.": [
              "账户信息更新成功。",
            ],
            "Membership|Upgrade to Pro": ["升级至专业版"],
            "Membership|Upgrade to VIP to add multiple tiers": [
              "升级到VIP开启更多会员等级",
            ],
            "Membership|Upon deletion, this tier will no longer be available for new registrations. Existing members will become legacy members, and will still be able to log in and access members-only pages.":
              [
                "一旦删除，新用户将无法注册这个会员等级，已订阅这个会员等级的用户将会变成已失效会员，而且他们仍然有权限登录以及访问「仅限会员」的页面。",
              ],
            "Membership|Use this URL in buttons and links to guide users to register.":
              ["在按钮和链接中使用这个URL来引导用户注册。"],
            "Membership|View Customer Detail": ["查看客户详情"],
            "Membership|View Order History": ["查看历史订单"],
            "Membership|View all subscription": ["查看所有订阅"],
            "Membership|View legacy tiers": ["显示已失效会员等级"],
            "Membership|View my account": ["查看我的账户"],
            "Membership|View payment setup...": ["查看收款设置"],
            "Membership|View subscription details.": ["查看订阅详情"],
            "Membership|View subscriptions": ["查看订阅"],
            "Membership|Welcome, New Member!": ["欢迎，新会员！"],
            "Membership|When enabled, show a reCAPTCHA checkbox on the registration form, which provides strong protection against bots/spammers.":
              [
                "启用后，在注册表单上显示人机验证复选框，这可以提供更强的保护，防止机器人提交垃圾信息。",
              ],
            "Membership|When this option is checked, an account management menu will be shown in your site's main menu for easy access. If unchecked, only logged-in members will see this menu.":
              [
                "勾选此项后，帐户管理菜单将显示在网站导航栏中，便于会员快速访问。 如不勾选，则只有已登录会员才能看到账户管理菜单。",
              ],
            "Membership|Yes, purchase": ["是，购买"],
            'Membership|You can only add one "Buy Product to Register" tier. Please select a different method.':
              [
                "你只可以添加一个「通过购买商品注册」的会员等级，请选择别的注册方式。",
              ],
            "Membership|You can only add one Free Membership tier. Please select a different method.":
              ["你只可以添加一个免费会员等级，请选择别的注册方式。"],
            "Membership|You can update page access settings in the pages manager.":
              [
                "如果需要调整免费会员的访问权限，你可以在会员页面的配置上进行调整。",
              ],
            "Membership|You currently have %{var1} members on this tier: %{var2}!":
              ["你现在有 %{var1} 个会员正在订阅这个会员等级：%{var2}！"],
            "Membership|You currently have %{var1} members with ongoing subscriptions on this tier: %{var2}!":
              ["你现在有 %{var1} 个会员正在订阅这个会员等级：%{var2}！"],
            "Membership|You have %{var1} paid membership subscriptions managed by %{var2}! Before you can disconnect %{var2}, you must either cancel all these %{var1} subscriptions in Orders > Subscription list or delete current membership tiers in Membership settings.":
              [
                "你有%{var1}位会员的付费订阅通过%{var2}收款。如果想要解绑%{var2}，必须先在订单-订阅列表中取消这%{var1}个付费订阅，或者在会员设置中删除当前已有的会员等级。",
              ],
            "Membership|You have %{var1} paid membership subscriptions managed by %{var2}. The new payment gateway will only apply for future subscribers.":
              [
                "当前你有%{var1}位会员的付费订阅通过%{var2}收款。收款方式的变动仅适用于未来的付费订阅者。",
              ],
            "Membership|You have no more %{var} sites to publish!": [
              "你没有%{var}网站可以发布了！",
            ],
            "Membership|You have subscribed and become a member. Subscription details will be emailed to you shortly.":
              ["你已经订阅成为会员。订阅信息将很快发到你的邮箱。"],
            "Membership|You have successfully cancelled this subscription.": [
              "你已成功取消该订阅。",
            ],
            "Membership|You have successfully subscribed!": ["你已订阅成功！"],
            "Membership|You must activate at least one pricing period.": [
              "请确保至少有一个付款周期是可用的",
            ],
            "Membership|You must enable Stripe or Square to accept subscription payments.":
              ["付费订阅功能需先开启Stripe或Square收款方式。"],
            "Membership|You're switching your Membership Registration Method to [strong: Free Membership Only].":
              ["你将把会员注册方式切换为[strong: 任何人免费注册]。"],
            "Membership|You're switching your Membership Registration Method to [strong: Paid Subscription Membership], but you have existing free members registered. Those free members will still be able to log in and access pages available to free members.":
              [
                "你将把会员注册方式切换为[strong: 仅限付费会员]，但你现在还有一些免费会员拥有登录权限。这些会员的权限会被持续保留，他们还能继续登录访问你的会员页面。",
              ],
            "Membership|You've just added a new Members-Only page! Customize it however you'd like. You can remove this page in the page manager.":
              [
                "新的会员专属页面创建成功！你可以自由编辑此页面。在页面管理器中可以将它删除。",
              ],
            "Membership|Your subscription has been cancelled due to failed payment on %{date}. Please check your billing info and subscribe again.":
              [
                "由于续费扣款失败，会员订阅已于%{date}取消。请检查付款账户设置后重新订阅。",
              ],
            "Membership|You’re purchasing <strong><strong class='extra-sites'>0</strong> extra %{var} sites(s)</strong> for an additional <strong>$</strong><strong class='extra-payment'>0</strong><strong class='per-month hidden'>/month</strong><strong class='per-year hidden'>/year</strong><strong class='per-2year hidden'>/2years</strong>":
              [
                "你正在购买 <strong><strong class='extra-sites'>0</strong>个额外的%{var}网站</strong>并花费<strong>$</strong><strong class='extra-payment'>0</strong><strong class='per-month hidden'>/月</strong><strong class='per-year hidden'>/年</strong><strong class='per-2year hidden'>/2年</strong>。",
              ],
            "Membership|You’ve published %{var1} %{var2} site(s) out of a maximum of %{var3}":
              ["你已经发布了%{var1}个%{var2}网站（最多%{var3}个）"],
            "Membership|[link: Activate Multiple Pages] to create members-only pages.":
              ["[link: 开启多页面功能]以创建会员专享页面。"],
            "Membership|[strong: You currently have %{number} members with active paid subscriptions!] If you disable membership, these existing subscriptions will be cancelled immediately, and will not be billed anymore. Any existing members will no longer be able to log into your site.":
              [
                "[strong: 目前有 %{number} 个正在订阅中的付费会员！]如果停用会员功能，目前仍在有效期内的所有付费订阅将被立即取消，不再续费扣款。你网站所有的会员将无法登录、无法访问会员专享页面",
              ],
            "Membership|[strong: You currently have %{number} members with active paid subscriptions!] These current subscriptions will be cancelled immediately, and will not be billed anymore. These members will still be able to log in and access pages as free members.":
              [
                "[strong: 目前有 %{number} 个付费订阅会员！]这些目前正在付费的订阅会员会被立即转为免费会员，不再续费扣款。这些会员在转为免费会员之后仍能登录并访问相关会员页面。",
              ],
            "Membership|[var1] is not a member yet. Are you sure you wish to manually grant membership to this user on [var2]?":
              [
                "[var1] 还不是会员，你确定要在 [var2] 上手动为这个用户添加会员等级吗？",
              ],
            "Membership|e.g. Standard Membership": ["例如：普通会员"],
            "Membership|products selected": ["个商品已选定"],
            "Membetship|Please check your email for a link to reset your password.":
              ["请检查您的电子邮箱，以获取重置密码的链接。"],
            Message: ["留言"],
            "Message Label": ["消息标签"],
            "Mobile screens have their own sliding navigation menu.": [
              "访客在手机上可以跳转至不同版块",
            ],
            "Mobile|Add Image": ["添加图片"],
            "Mobile|Add Item": [" 添加项目"],
            "Mobile|App store is not yet editable on the mobile app.": [
              "应用商店及HTML代码版块暂时不支持移动端编辑，请前往桌面端编辑。",
            ],
            "Mobile|Banner Image Slider section is not yet editable on the mobile app.":
              ["轮播图版块暂时无法在手机APP上编辑。"],
            "Mobile|Donation is not yet editable on the mobile app.": [
              "筹款版块暂时不支持移动端编辑，请前往桌面端编辑。",
            ],
            "Mobile|Done": ["完成"],
            "Mobile|Grid section is not yet editable on the mobile app.": [
              "网格版块暂时不支持移动端编辑，请前往桌面端完成。",
            ],
            "Mobile|Make your own section is not yet editable on the mobile app.":
              ["自定义版块暂时不支持移动端编辑，请前往桌面端编辑。"],
            "Mobile|Manage items": ["管理项目"],
            "Mobile|No content.": ["还未添加内容"],
            "Mobile|Portfolio is not yet editable on the mobile app.": [
              "产品展示版块暂时不支持移动端编辑，请前往桌面端完成。",
            ],
            "Mobile|Simple Store is not yet editable on the mobile app.": [
              "简易商店版块暂时不支持移动端编辑，请前往桌面端编辑。",
            ],
            "Mobile|Social feed is not yet editable on the mobile app.": [
              "社交内容版块暂时不支持移动端编辑，请前往桌面端编辑。",
            ],
            "Mobile|Social media is not yet editable on the mobile app.": [
              "社交媒体版块暂时不支持移动端编辑，请前往桌面端编辑。",
            ],
            "Mobile|Text + Button Slider section is not yet editable on the mobile app.":
              ["滑块版块暂时无法在手机APP上编辑"],
            "Mobile|Video is not yet editable on the mobile app.": [
              "视频暂时不支持移动端编辑，请前往桌面端编辑。",
            ],
            Monthly: ["包月"],
            More: ["更多"],
            "More Icons": ["更多图标"],
            "More Options": ["更多选项"],
            "MultiLang|About": ["关于"],
            "MultiLang|Activate Language Switcher": ["启用语言切换器"],
            "MultiLang|Add New Redirect": ["添加新的跳转规则"],
            "MultiLang|Add a Language Switcher to your site’s navigation menu, that links to sites of different languages.":
              [
                "在你的网站导航中添加一个语言切换器，让网站访客能够切换不同语言访问。",
              ],
            "MultiLang|Are you sure you want to remove this redirect rule?": [
              "你确定要删除这个跳转规则吗？",
            ],
            "MultiLang|Are you sure you wish to apply these settings? All sites in this list will show the same Language Switcher!":
              [
                "你确定你想要应用这些设置吗？在这个列表中的所有网站都会显示相同的语言切换！",
              ],
            "MultiLang|Are you sure you wish to disable the Language Switcher? This will be removed from all sites in this list.":
              [
                "确定要停用语言切换器吗？停用后语言切换器会从所有此处列出的网站上消失。",
              ],
            "MultiLang|Are you sure you wish to remove this site from the Language Switcher?":
              ["确定要把这个网站从语言切换器中移除掉吗？"],
            "MultiLang|Contact": ["联系我们"],
            "MultiLang|Disable Language Switcher": ["停用语言切换器"],
            "MultiLang|Go to dashboard to clone this site...": [
              "前往控制面板复制本网站...",
            ],
            "MultiLang|Home": ["首页"],
            "MultiLang|Icon": ["图标"],
            "MultiLang|Language Label": ["语言名称"],
            "MultiLang|Language Switcher": ["语言切换器"],
            "MultiLang|Language/Region Redirect": ["语言/地区页面跳转"],
            "MultiLang|Preview": ["预览"],
            "MultiLang|Redirect To": ["跳转至"],
            "MultiLang|Redirect visitors to a different URL depending on the visitor's location or browser language.":
              ["根据访客的位置或浏览器语言，将访客跳转到不同的网址。"],
            "MultiLang|Remove icon": ["不显示图标"],
            "MultiLang|Target URL": ["目标网址"],
            "MultiLang|This function only links together multiple sites in your account. You'll have to create each language’s site separately. This also means that the separate sites will not share the store, orders list, blog, or audience list.":
              [
                "语言切换器功能仅将你账户下多个网站以不同语言版本的形式关联起来，也就是说每一个语言版本的网站，都需要另外创建一个新的网站。所以虽然内容上是不同语言的同一个网站，商城、订单、博客、客户列表这些数据都会因为是不同网站的而需要分开进行管理。",
              ],
            "MultiLang|Visitor Language/Region": ["访客语言/地区"],
            "MultiLang|You'll need to clone this site and translate it before you can link multiple sites together!":
              ["请先复制你的网站并翻译完成后，再进行多语言关联操作。"],
            "MultiLang|e.g. www.example.com": ["例：www.example.com"],
            "My Email Accounts": ["我的邮箱账号"],
            "My Sites": ["我的网站"],
            "My sites": ["我的网站"],
            Name: ["姓名"],
            "Name Label": ["名称标签"],
            "Namecheap|%{domain} (connected)": ["%{domain}（已连接）"],
            "Need help?": ["需要帮助？"],
            Neon: ["青紫"],
            "Network is not available. Please check your connection and click here to retry.":
              ["网络连接不可用，请检查您的网络连接并点击此处重试。"],
            "Network timeout. Please retry.": ["网络超时，请重试。"],
            Newest: ["最新"],
            Newsletters: ["邮件"],
            "Newsletter|Name": ["名称"],
            Next: ["下一页"],
            "Next Step: Add a Custom Domain": ["下一步：添加自定义域名"],
            "Next Step: Add a Domain": ["下一步：添加域名"],
            "No Billing Info Provided": ["无支付信息"],
            "No Data": ["暂无"],
            "No Recipient": ["没有收件人"],
            "No Spam": ["无垃圾信息"],
            "No content.": ["无内容"],
            "No responses.": ["无回复。"],
            'No result for "%{searchKey}".': ['没有关于"%{searchKey}"的结果'],
            'No results for "%{searchKey}".': ['没有"%{searchKey}"的相关结果'],
            "No thanks.": ["不用，谢谢"],
            None: ["无"],
            "Note:": ["注意："],
            "Note: If you cancel your plan within the 14-day money-back guarantee, the price of the domain will not be refunded.":
              [
                "注意：如果你在14天退款承诺期内取消套餐，域名的费用将不会被退还。",
              ],
            "Note: Preview your site to see all animations!": [
              "注意：预览你的网站查看所有动画！",
            ],
            "Note: Some fonts do not support all Latin characters.": [
              "注意：某些字体不支持全部拉丁字符。",
            ],
            "Note: You can only add one video per product.": [
              "注意：每个商品可添加1个视频。点击查看视频网站的链接提取方法",
            ],
            "Note: [placeholderStrong: You'll be billed $%{price} immediately for your domain.] If you cancel your plan within the 14-day money-back guarantee, the price of the domain will not be refunded.":
              [
                "注意：[placeholderStrong: 你将立即为你的域名支付 $%{price}。] 如果你在14天退款承诺期内取消套餐，域名的费用将不会被退还。",
              ],
            Notes: ["备注"],
            Notifications: ["通知"],
            OK: ["确认"],
            OR: ["或者"],
            Ok: ["好的"],
            Oldest: ["最早"],
            "Once you've fulfilled or shipped this order, click this button to send your customer an email notification.":
              [
                "在完成这个订单或发货后，请点击这个按钮给你的买家发送邮件通知。",
              ],
            "One Click Online Resume": ["一键生成个人网站"],
            "Oops, a network issue occurred, please refresh and try again.": [
              "网络出现问题，请刷新并重试。",
            ],
            "Oops, something went wrong. Refresh the page and try again; if the error keeps happening please contact support!":
              [
                "哎呀，出错了。请刷新页面后再尝试，如果连续报错请联系客服解决。",
              ],
            "Oops, something went wrong. try again; if the error keeps happening, please contact support!":
              [
                "哎呀，发生了点小故障。请重试；若持续发生，请联系我们的客服团队！",
              ],
            "Open DNS Manager": ["打开 DNS 管理界面"],
            "Open Site Analytics": ["查看网站数据"],
            "Open Site Audience": ["打开客户页面"],
            "Open in new tab?": ["在新标签页中打开"],
            "Open membership registration form on submit?": [
              "提交时打开会员注册表单？",
            ],
            "Optimizely A/B Testing": ["Optimizely A/B 测试"],
            "Optimizely Experiment ID": ["Optimizely 实验 ID"],
            "Optimizely Project ID": ["Optimizely 项目 ID"],
            Options: ["选项"],
            "Or pay with PayPal": ["或使用PayPal付款"],
            "Or search more domains...": ["或搜索更多域名..."],
            "Or use PayPal": ["或者使用 PayPal"],
            "Or use credit card": ["或使用信用卡"],
            "Order completed": ["订单完成"],
            "Order confirmed": ["订单已确认"],
            Other: ["其它"],
            "Other folks' sites that you can edit & manage.": [
              "可以进行编辑和管理的其他人的网站",
            ],
            "Our Happiness Officers are available only from Monday to Friday, 9:00AM to 9:00PM.":
              ["我们的客服在线时间为：每天上午 8:00 至 晚上 22:00。"],
            "Our image hosting service is experiencing temporary downtime. We're working with them to resolve the issue - hold tight! <a href='%{link}' target='_blank'>Check our Twitter for updates.</a>":
              [
                "我们的图片服务提供商暂时出了些问题，导致现在无法访问，我们正在和他们一起奋战修复！给我们一些时间<a href='%{link}' target='_blank'>查看我们的微博了解实时状态。</a>",
              ],
            PREMIUM: ["高级模版"],
            PRO: ["专业版"],
            PUBLISH: ["上线"],
            "Page %{pageIndex}/%{totalPage}": [
              "第 %{pageIndex}/%{totalPage} 页",
            ],
            "Page Posts": ["博文"],
            "PageGroup|Name": ["名称"],
            Pageviews: ["访问量"],
            "Password Protection": ["密码保护"],
            "Password protection is only available for Pro users.": [
              "开启密码保护，访客需要输入密码才能打开网站",
            ],
            "Paste the meta tag from Google Search Console.": [
              "粘贴取自 Google Search Console 工具的元标签",
            ],
            "Paste your pixel ID from Facebook. We'll automatically set up tracking for your Facebook ads.":
              [
                "将你的 Facebook 像素ID粘贴在下方，我们会自动设置 Facebook 广告追踪。",
              ],
            Persona: ["水绿"],
            Phone: ["电话"],
            "Phone Number": ["电话号码"],
            "Phone Number Label": ["电话号码标签"],
            "Phone number": ["手机号"],
            "Phone verification": ["手机验证"],
            "Please contact the site owner to unlock this feature.": [
              "请联系网站管理员解锁此功能。",
            ],
            "Please contact your account manager to upgrade.": [
              "请联系你的代理商进行升级。",
            ],
            "Please drag 1 image at a time.": ["一次只能拖动一张图片"],
            "Please drag no more than 30 images at a time.": [
              "每次拖动图片请勿超过30个。",
            ],
            "Please enter HTML tag verification code provided by Baidu, such as NQ53KRpuNy":
              ["请填入百度提供的HTML标签验证码(例如NQ53KRpuNy)"],
            "Please enter a valid Email address": ["请输入有效的邮箱"],
            "Please enter a valid email": ["请输入有效的邮箱"],
            "Please enter the URL.": ["输入域名"],
            "Please modify your code to remove restricted content, or contact us if you have any questions.":
              [
                "请修改你的代码，删除不合规的内容。如果你有任何疑问，请联系我们。",
              ],
            "Please select a category": ["选择一个类别"],
            "Please show you're not a robot": [
              "您的操作过于频繁，请完成安全验证后继续操作",
            ],
            "Please upgrade to an [boldText: Audience Plan] to enable Live Chat. Audience Plans come with a 7-day free trial.":
              [
                "请升级到[boldText: 营销套餐]以启用在线聊天功能。营销套餐包含7天免费试用。",
              ],
            "Please wait a bit... Your site will be published soon.": [
              "内容较多，请耐心等待片刻…",
            ],
            "Please wait until the page is fully generated.": [
              "请等待页面加载完成。",
            ],
            "Portfolio|%{num} products": ["%{num} 个产品"],
            "Portfolio|%{num} products selected": ["已选中 %{num} 个产品"],
            "Portfolio|(Price varies)": ["(价格不等)"],
            "Portfolio|Add More Products": ["添加更多产品"],
            "Portfolio|Add New Category": ["添加分类"],
            "Portfolio|Add Product": ["添加产品"],
            "Portfolio|Add Variant": ["添加规格"],
            "Portfolio|Add categories (optional).": ["添加分类（可选）"],
            "Portfolio|Add product description. Keep it short and sweet! (Optional)":
              ["添加产品描述，尽量使用简短而有趣的句子（可选）"],
            "Portfolio|Add, rename, reorder, and delete product categories. You can tag products under categories when you edit products.":
              [
                "添加新的产品分类， 对产品分类排序，删除产品分类。你可以在编辑产品时添加产品分类。",
              ],
            "Portfolio|Add-on Options": ["选配项目"],
            "Portfolio|Adding Multiple Items is a Pro feature": [
              "添加多个项目是专业版功能",
            ],
            "Portfolio|All Categories": ["所有分类"],
            "Portfolio|Are you absolutely sure you want to delete %{num} selected products? This action cannot be undone!":
              ["确定要删除已选中的 %{num} 个产品？此操作无法撤回。"],
            "Portfolio|Are you sure you want to cancel? These items will not be imported!":
              ["确定要取消导入吗？这些项目将不会被导入！"],
            "Portfolio|Are you sure you want to import these items?": [
              "你确定要导入这些项目吗？",
            ],
            "Portfolio|As a VIP user, you can add unlimited items.": [
              "作为企业版用户，你可以添加无限数量的项目。",
            ],
            "Portfolio|Be careful! Deleting this category is a permanent and irreversible action! It will be deleted from all products under this category. Are you sure you still want to delete this category?":
              [
                "注意！删除此产品分类是一个永久的不可逆转的操作！删除后这个分类标签将从该分类下的所有产品中移除。仍然确定删除该分类吗？",
              ],
            "Portfolio|Button URL": ["按钮链接网址"],
            "Portfolio|Button URL is not valid.": ["按钮链接网址无效"],
            "Portfolio|Button text": ["按钮名称"],
            "Portfolio|Categories": ["分类"],
            "Portfolio|Categories can only contain letters, numbers, spaces and dashes.":
              ["类别名称中只能包含字母，数字，空格和破折号。"],
            "Portfolio|Click here to add products or projects!": [
              "点击这里添加产品或项目！",
            ],
            "Portfolio|Color, Size, etc.": ["颜色，尺寸，等等。"],
            "Portfolio|Contact Us": ["联系我们"],
            "Portfolio|Display other items as add-ons for customers to select. A total price will be calculated and shown.":
              ["展示其他项目作为选配项目供客户选择。将计算并显示总价格。"],
            "Portfolio|Download failed. This might be caused by too many items or an internal error. Please try again or ask customer service for export.":
              [
                "下载失败。或因项目数量过多或其他原因导致。请再次尝试或联系在线客服导出。",
              ],
            "Portfolio|E.g. Negotiable": ["例：面议"],
            "Portfolio|Edit Product": ["编辑产品"],
            "Portfolio|Export Items": ["导出展示项目"],
            "Portfolio|Import Items": ["导入展示项目"],
            "Portfolio|Invalid Price": ["无效的显示价格"],
            "Portfolio|It seems you have a large number of items! Please [link:contact support] and we'll help you add more items.":
              [
                "看起来你有大量的项目！请[link: 联系客服]，我们会帮你添加更多项目。",
              ],
            "Portfolio|It seems you have a large number of products! Please contact support and we'll help you add more products.":
              ["看起来你有大量的产品！请联系客服，我们会帮你添加更多产品。"],
            "Portfolio|It seems you have a lot of items, so it may take a long time to export. We'll email you a download link when the export is completed. Please enter your email address.":
              [
                "你的项目较多，可能需要较长时间导出。我们会在导出完成后通过邮件给你发送CSV文件的下载链接。请输入你的邮箱。",
              ],
            "Portfolio|It seems you have a lot of items, so it may take a long time to import. We will notify you by email when the import is completed. Please enter your email address.":
              [
                "你的项目较多，可能需要较长时间导入。我们会在导入完成后通过邮件通知你。请输入你的邮箱。",
              ],
            "Portfolio|It seems you have a lot of items, so it may take a long time to import. You can close this dialog and continue working, or even close the editor. We'll send you an email when the import is complete!":
              [
                "你的项目较多，可能需要较长时间导入。你可以关闭本窗口，甚至关闭编辑器，无需等待。导入完成后，我们会给你发送邮件通知！",
              ],
            "Portfolio|Item": ["项目"],
            "Portfolio|Item Categories": ["项目分类"],
            "Portfolio|Item ID": ["项目ID"],
            "Portfolio|Item Name": ["项目名称"],
            "Portfolio|Item detail page": ["项目详情页面"],
            "Portfolio|Items": ["项目"],
            "Portfolio|Manage Categories": ["分类管理"],
            "Portfolio|Manage Product": ["产品管理"],
            "Portfolio|Manage Products": ["产品管理"],
            "Portfolio|Max %{var1} image only per Item option": [
              "每个项目规格最多添加%{var1}张图",
            ],
            "Portfolio|Max %{var1} images only per Item": [
              "每个项目最多添加%{var1}张图片",
            ],
            "Portfolio|Max %{var1} options per item": [
              "每个项目最多支持%{var1}种规格名称",
            ],
            "Portfolio|No items": ["当前没有项目可被添加为选配项目"],
            "Portfolio|No products": ["目前还没有任何产品"],
            "Portfolio|No products in this product showcase now!": [
              "这个产品展示版块中目前没有产品！",
            ],
            "Portfolio|Only visitors who fill out the form will be able to view the item details or price.":
              ["只有填写了表单的访客可以看到项目详情或价格。"],
            "Portfolio|Please add portfolio items first.": [
              "请先添加产品项目。",
            ],
            "Portfolio|Please fill in your contact information to view item details.":
              ["请填写你的联系方式以查看项目详情。"],
            "Portfolio|Please fill in your contact information to view price and item details.":
              ["请填写你的联系方式以查看价格和项目详情。"],
            "Portfolio|Please select a variant first.": ["请先选择一个规格"],
            "Portfolio|Please upload a CSV file with at least 1 item.": [
              "CSV文件中应至少包含1个项目。",
            ],
            "Portfolio|Portfolio": ["产品展示"],
            "Portfolio|Portfolio Settings": ["产品展示设置"],
            "Portfolio|Price": ["价格"],
            "Portfolio|Price cannot be empty": ["显示价格不能为空"],
            "Portfolio|Product": ["产品"],
            "Portfolio|Product Categories": ["产品分类"],
            "Portfolio|Product Limit": ["产品数量超出限制"],
            "Portfolio|Products": ["产品"],
            "Portfolio|Require Contact Info to View Item Information": [
              "需要联系方式以查看项目信息",
            ],
            "Portfolio|Select a category": ["选择一个分类"],
            "Portfolio|Select a category for this section.": [
              "为当前版块选择一个分类下的产品。",
            ],
            "Portfolio|Select a variant to view price.": [
              "选择一个规格以查看价格",
            ],
            "Portfolio|Select an additional add-on...": [
              "选择一个额外的选配项目...",
            ],
            "Portfolio|Show Add-on Description": ["显示选配项目的描述"],
            "Portfolio|Show Add-on Images": ["显示选配项目的图像"],
            "Portfolio|Show button": ["显示按钮"],
            "Portfolio|Show detailed description": ["显示产品描述详情"],
            "Portfolio|Show different prices for visitors from different regions. We use geolocation to determine where each site visitor is visiting from, and then apply changes to your portfolio depending on the location.":
              [
                "为来自不同地区的访客显示不同的价格。我们使用地理定位来确定每个站点访问者从哪里访问，然后根据位置变化产品的价格。",
              ],
            "Portfolio|Show price": ["显示价格"],
            "Portfolio|Sort Items": ["项目排序"],
            "Portfolio|Successfully imported %{var1} items!": [
              "成功导入%{var1}个项目！",
            ],
            "Portfolio|Switch to price": ["切换到价格"],
            "Portfolio|Switch to text": ["切换到文字"],
            "Portfolio|There are no items under this category yet.": [
              "还没有为此分类添加任何项目。",
            ],
            "Portfolio|This category has already been added to this product.": [
              "该分类下已存在此产品",
            ],
            "Portfolio|This includes [strong: %{var1} items] that already exist, and will be replaced!":
              [
                "其中包括已创建的[strong: %{var1}个项目]，系统将覆盖更新它们的信息。",
              ],
            "Portfolio|This is an existing category.": ["该分类已经存在。"],
            "Portfolio|This item has region rules configured. Adding variants for this item will remove those region rules, and you'll need to reconfigure the region rules for this item. Are you sure you want to add variants for this item?":
              [
                "这个项目已经配置了区域规则。为该物品添加规格将删除这些区域规则，您需要为该物品重新配置区域规则。你确定你要为这个项目添加规格吗？",
              ],
            "Portfolio|This item is currently selected as an add-on for other items. Adding variants to this item will remove this add-on from other items, and you'll need to re-add this item as an add-on for other items. Are you sure you want to add variants for this item?":
              [
                "此项目目前被选为其他项目的附加项。为该物品添加规格将从其他物品中移除该附加项，您需要重新将该物品作为其他物品的附加项。你确定你要为这个项目添加规格吗？",
              ],
            "Portfolio|This product is not available anymore.": [
              "该产品已经下线",
            ],
            "Portfolio|Total Price": ["总价"],
            "Portfolio|Upgrade to add categories": [
              "升级至企业版以添加产品分类",
            ],
            "Portfolio|Upgrade to add more items": ["升级套餐以添加更多项目"],
            "Portfolio|Upgrade to add more products": [
              "升级套餐以添加更多产品",
            ],
            "Portfolio|Use this tool to export all your current items to a CSV file. You can then edit the CSV and re-import them, to easily update many items at once.":
              [
                "此功能可以导出展示项目为CSV文件。你可以修改CSV文件中的展示项目信息，然后上传此CSV文件进行展示项目导入，以实现快速批量编辑。",
              ],
            "Portfolio|Useful if you have a lot of Items.": [
              "可以使您的访客更方便的找到所需项目。",
            ],
            "Portfolio|Variant": ["规格"],
            "Portfolio|Variant Name": ["规格名称"],
            "Portfolio|Variant name": ["规格名称"],
            "Portfolio|Variant names can’t be the same.": [
              "规格名称不能相同！",
            ],
            "Portfolio|Variant price": ["规格价格"],
            "Portfolio|View all items": ["查看所有项目"],
            "Portfolio|You can add a maximum of 10 images.": [
              "您只能添加最多10张图片",
            ],
            "Portfolio|You can add up to %{var1} variants in an item.": [
              "您可以在一个商品中最多添加%{var1}个规格。",
            ],
            "Portfolio|You can tag up to 5 categories for this product.": [
              "您最多可以为该产品添加5种项目分类。",
            ],
            "Portfolio|You can use this tool to add or update multiple items at once. You’ll need to upload a CSV file, which must be in a specific format.":
              [
                "此功能可以帮你批量添加、修改展示项目。请使用我们提供的CSV模板，按格式录入展示项目信息，然后上传此CSV文件进行导入。",
              ],
            "Portfolio|You don’t have any items yet. You can add more items to your portfolio first, then add them as add-on options here.":
              [
                "您还没有任何项目。您可以先将更多项目添加到您的项目展示中，然后再将它们添加为附加选项。",
              ],
            "Portfolio|You will be importing [strong: %{var1} items] with a total of [strong1: %{var2} options].":
              [
                "即将导入[strong: %{var1}个项目]，共[strong1: %{var2}个项目规格]。",
              ],
            "Portfolio|Your current plan only allows for %{var1} items. Please upgrade or chat with customer support for more.":
              [
                "当前套餐仅支持添加%{var1}个项目。请升级套餐或咨询在线客服以增加项目数额上限。",
              ],
            "Portfolio|You’ve reached your product limit! Please upgrade your plan to add more items.":
              ["你的产品展示已经到达项目上限了。请升级套餐以增加更多的项目。"],
            'Portfolio|clicks "View Price" button': ["点击“查看价格”按钮"],
            "Portfolio|clicks request quote button": ["点击询盘按钮"],
            "Portfolio|opens item detail page": ["打开项目详情页"],
            Posts: ["文章"],
            "Posts on timeline": ["时间线上的文章"],
            "Preparing image uploader. Please wait...": [
              "图片上传工具正在加载中，请稍后",
            ],
            "Preparing your homepage...": ["正在准备你的主页…"],
            Preview: ["预览"],
            "Preview This Site": ["预览该网站"],
            "Preview map.": ["预览地图。"],
            "Preview your site across screen sizes": [
              "查看在不同设备上的呈现效果",
            ],
            Previewing: ["预览中"],
            "Previewing %{name}": ["正在预览%{name}"],
            "Preview|Confirm style & go to editor": ["确认样式并进入编辑器"],
            "Preview|Continue to Select Style": ["继续选择样式"],
            "Preview|Pending": ["待处理"],
            "Preview|Regenerate %{var1} new styles...": [
              "重新生成 %{var1} 种新样式...",
            ],
            "Preview|Save & Go Back": ["保存并返回"],
            "Preview|Save Your Site": ["保存你的网站"],
            "Preview|Select a style to edit & publish!": [
              "选择要编辑和发布的样式！",
            ],
            "Preview|Site in progress. Select a style to edit this site.": [
              "网站仍待处理。选择一个样式以编辑此网站。",
            ],
            "Preview|The current site will be saved to your site list. You can find it again in Dashboard - My Sites.":
              [
                "当前网站会被保存到你的网站列表。你可以在控制面板 - 我的网站中找到它。",
              ],
            "Preview|You have already confirmed the style of this site.": [
              "你已经确认了此网站的样式。",
            ],
            Price: ["价格"],
            "Pricing|%{var1} Active Contacts": ["%{var1} 个有效联系人"],
            "Pricing|%{var1} Advanced sites": ["%{var1} 个进阶版网站"],
            "Pricing|%{var1} GB bandwidth": ["%{var1} GB 网站流量"],
            "Pricing|%{var1} GB storage per site": [
              "每个网站 %{var1} GB 存储空间",
            ],
            "Pricing|%{var1} Limited sites": ["%{var1} 个基础版网站"],
            "Pricing|%{var1} Pro sites": ["%{var1} 个专业版网站"],
            "Pricing|%{var1} Unicorn sites": ["%{var1} 个独角兽版网站"],
            "Pricing|%{var1} VIP sites": ["%{var1} 个企业版网站"],
            "Pricing|%{var1} transaction fee": ["%{var1} 交易手续费"],
            "Pricing|%{var1} transaction fees apply": [
              "平台将收取 %{var1} 交易手续费",
            ],
            "Pricing|(Payment gateway fees still apply.)": [
              "（支付通道手续费另收）",
            ],
            "Pricing|(This is in addition to payment gateway fees.)": [
              "（这是在支付网关费用之外的额外手续费用。）",
            ],
            "Pricing|0% additional transaction fees": ["0% 额外交易手续费"],
            "Pricing|24/7 chat support": ["24/7 在线实时聊天真人客服"],
            "Pricing|Access our full font library of hundreds of fonts, or upload your own custom fonts.":
              ["获取我们的字体库，超过上百种字体。或者上传你自己的字体。"],
            "Pricing|Active Contacts include your site’s members, Live Chat conversations, and newsletter recipients.":
              ["有效联系人包括网站会员功能、在线聊天联系人、营销邮件收件人"],
            "Pricing|Add a Live Chat function on your site to get leads and boost conversion. Get notified of new Live Chats on the Strikingly mobile app, so you can reply from anywhere.":
              [
                "在你的网站上添加在线聊天功能来高效获取潜在客户、提高转化率。并且你可以在 Strikingly 手机 app上实时获得新的在线聊天通知推送，在任何地方回复你的网站访客。",
              ],
            "Pricing|Advanced": ["进阶版"],
            "Pricing|Allow visitors to search all pages, blog posts, and products.":
              ["允许访问者在网站内搜索所有页面，博客文章和产品。"],
            "Pricing|Call us during active hours for phone support in English.":
              ["可在正常工作时间内拨打我们的电话客服（仅限英文）。"],
            "Pricing|Connect custom domain": ["连接自定义域名"],
            "Pricing|Connect to PayPal": ["连接到 Paypal"],
            "Pricing|Create a custom form with any fields you want, and easily view all form responses.":
              ["你可以自定义表单，高度定制化你的表单内容。"],
            "Pricing|Create multilingual versions of your site in minutes.": [
              "在几分钟内创建你的多语言版本的网站。",
            ],
            "Pricing|Create multiple paid membership tiers for your site, with each tier able to access different pages. Set membership fees to be billed monthly, quarterly, or yearly.":
              [
                "为你的网站创建多个付费会员等级，每个等级可以访问不同的页面。按月度、季度或年度进行会员订阅收费。",
              ],
            "Pricing|Custom Font Upload": ["上传自定义字体"],
            "Pricing|Custom font upload": ["上传自定义字体"],
            "Pricing|Dedicated account manager": ["专属客户经理"],
            "Pricing|Efficiency at scale": ["放大你的规模效应"],
            "Pricing|Embed custom code": ["嵌入自定义代码"],
            "Pricing|Enable member registrations and create a members-only section of your site! Members count as Active Contacts. Includes %{var1} Active Contacts, with more available with the Audience Plan add-on.":
              [
                "启用会员注册功能来在你的网站上创建一个会员专属区吧！每个会员都会被算作一个有效联系人。当前套餐包含存储最多 %{var1} 个有效联系人，可购买升级营销套餐来增加有效联系人上限。",
              ],
            "Pricing|Everything in the Advanced plan": ["进阶版的所有功能"],
            "Pricing|Everything you need to launch & grow!": [
              "帮助你扩张增长的全套功能！",
            ],
            "Pricing|Extra %{var1}%% off": ["限时 %{var1} 折优惠"],
            "Pricing|Features": ["功能列表"],
            "Pricing|Free SSL for custom domain": ["域名均提供免费 SSL 证书"],
            "Pricing|Free domain for a year!": ["尽享一年免费域名！"],
            "Pricing|Initial promo price, USD, billed every %{var1} years": [
              "首年优惠价（%{var1}年付），价格为美金",
            ],
            "Pricing|Initial promo price, USD, billed yearly": [
              "首年优惠价（年付），价格为美金",
            ],
            "Pricing|Just starting with a custom domain": ["只需要自定义域名"],
            "Pricing|Live Chat widget": ["在线聊天插件"],
            "Pricing|Most Popular": ["最畅销"],
            "Pricing|Multi-Language & Auto-Translation": ["多语言自动翻译"],
            "Pricing|No additional fee will be charged for your site's store transactions, for any non-recurring payment.":
              [
                "你网站的商城交易（非自动续费形式付款）将不会产生任何平台交易手续费。",
              ],
            "Pricing|No additional fee will be charged for your site's transactions.":
              ["你网站的任何交易都不会产生任何平台交易手续费。"],
            "Pricing|Our powerful enterprise-level hosting scales with your traffic.":
              ["我们强大的企业级主机可根据你的网站流量进行弹性扩容。"],
            "Pricing|Paid subscription memberships": ["付费订阅会员功能"],
            "Pricing|Paid subscription memberships will have a %{var1} transaction fee. (This is in addition to payment gateway fees.)":
              [
                "订阅会员的付费将被收取 %{var1} 的交易手续费（这是在支付网关费用之外的额外手续费用）。",
              ],
            "Pricing|Phone support (English)": ["电话客服（仅限英文）"],
            "Pricing|Power features for businesses & membership sites": [
              "更精细化的电商、会员功能",
            ],
            "Pricing|Priority customer service": ["优先客服"],
            "Pricing|Publish up to %{var1} sites with %{var2} features.": [
              "最多可发布 %{var1} 个带有 %{var2} 功能的网站。",
            ],
            "Pricing|Remove Strikingly branding": ["移除 Strikingly 品牌标识"],
            "Pricing|Restore a previous version of your entire site from the last 20 saved  versions.":
              ["你可以选择将你的网站恢复到最近保存的20个历史版本中的一个。"],
            "Pricing|Restore historical version": ["恢复历史版本"],
            "Pricing|Select and filter recipients, compose a custom email, and send a newsletter directly to your Audience. Great for increasing retention and repeat customers.":
              [
                "选择与过滤收件人、编写自定义邮件、并直接向你的粉丝发送新闻简报，大大增加客户的留存率与复购率！",
              ],
            "Pricing|Sell a single product": ["最多可上架 1 件商品"],
            "Pricing|Sell a single product. Add product variations, coupons, shipping regions, pre-orders, and much more.":
              [
                "最多可上架售卖 1 件商品！还可以添加商品种类、优惠券、送货地区、预售发货等功能。",
              ],
            "Pricing|Sell unlimited products": ["上架售卖无限量的商品"],
            "Pricing|Sell unlimited products! Add product variations, coupons, shipping regions, pre-orders, and much more.":
              [
                "上架售卖无限量的商品！还可以添加商品种类、优惠券、送货地区、预售发货等功能。",
              ],
            "Pricing|Sell up to %{var1} products": [
              "最多可上架 %{var1} 件商品",
            ],
            "Pricing|Sell up to %{var1} products! Add product variations, coupons, shipping regions, pre-orders, and much more.":
              [
                "最多可上架售卖 %{var1} 件商品噢！还可以添加商品种类、优惠券、送货地区、预售发货等功能。",
              ],
            "Pricing|Send newsletters": ["发送营销邮件"],
            "Pricing|Site Search": ["站内搜索"],
            "Pricing|Site memberships": ["网站会员系统"],
            "Pricing|Site search": ["站内搜索"],
            "Pricing|Storage includes any files, images, and documents uploaded to your site.":
              ["存储空间会计算所有上传到你的网站的文件、文档、图像。"],
            "Pricing|Store Product Reviews": ["商品评价"],
            "Pricing|Take monthly, quarterly, or yearly recurring payments from your members! We'll handle all the billing for you.":
              [
                "向你的会员收取月度、季度或年度的定期定额付款！我们会帮你处理好所有扣款、入账等支付相关事宜。",
              ],
            "Pricing|Talk to a human being anytime. Happiness officers are here to help!":
              ["有问题就和我们沟通吧，我们随时为你提供帮助！"],
            "Pricing|This fee will be charged for your site's store transactions, for any non-recurring payment. (This is in addition to payment gateway fees.)":
              [
                "此费用将针对你的网站的所有商城交易（非自动续费形式付款）而收取（这是在支付网关费用之外的额外手续费用）。",
              ],
            "Pricing|This published site uses Unicorn feature and counts towards your Unicorn sites publish limit!":
              [
                "此已发布网站使用了独角兽版功能，将算入账户的独角兽版网站发布限额！",
              ],
            "Pricing|Transaction fees apply": ["平台将收取交易手续费"],
            "Pricing|Unicorn": ["独角兽版"],
            "Pricing|Unlimited bandwidth": ["无限量网站流量"],
            "Pricing|Unlimited free sites": ["无限个免费版网站"],
            "Pricing|Upgrade To VIP": ["升级到企业版"],
            "Pricing|Upgrade to %{var1} for lower fees.": [
              "升级至%{var1}套餐来降低手续费。",
            ],
            "Pricing|VIP": ["企业版"],
            "Pricing|We keep your site secure! HTTPS/SSL is automatically applied when you connect any custom domain.":
              [
                "我们会为你的网站安全保驾护航！一旦连接任意自定义域名，HTTPS/SSL协议证书会自动在你网站上生效。",
              ],
            "Pricing|You're currently on the %{var1} plan, which has a %{var2} fee for store transactions.":
              ["你目前套餐版本为%{var1}，商城交易手续费为 %{var2}。"],
            "Pricing|Your very own Happiness Officer will take care of you!": [
              "你的专属客户经理会为你提供无微不至的服务！",
            ],
            Print: ["打印"],
            "Priority Customer Service": ["客户优先服务"],
            "Private pages can not be previewed. Please publish to see the effect.":
              ["加密页面不能预览，请发布后查看效果。"],
            Pro: ["专业版"],
            Publish: ["上线"],
            "Publish Now": ["立即上线"],
            "Publish now.": ["立即上线"],
            "Publish this site": ["上线"],
            "Publish to go live": ["发布上线"],
            Published: ["已上线"],
            "Publishing will unleash your site to the world!": [
              "网站上线即可展示给全世界",
            ],
            "Publishing...": ["正在上线..."],
            "RSS Feed": ["RSS 订阅"],
            "Read the instructions here.": ["点击阅读说明"],
            "Ready to go live?": ["上线就差一步啦"],
            "Receive an SMS/text message with an authentication code that you need to enter when you log in.":
              ["登录时，您需要输入手机收到的验证码。"],
            "Recovery Codes": ["恢复码"],
            "Recovery codes provide a way to log in if you lose your phone (or don't have it with you).":
              ["手机不可用时，可使用恢复码进行验证登录。"],
            "Redeem your FREE Custom Domain": [
              "你有一个免费的自定义域名待兑换",
            ],
            "Redeem your FREE Domain": ["兑换你的免费域名"],
            "Redirect URL": ["重定向网址"],
            Redo: ["重做"],
            Refresh: ["刷新"],
            "Register Domain": ["注册域名"],
            "Register New Domain": ["注册新域名"],
            "Registered on": ["注册于"],
            "Registration Info": ["注册信息"],
            "Reload Editor": ["刷新编辑器页面"],
            "Reload editor": ["刷新编辑器页面"],
            "Remember that your latest changes won't be visible until you publish!":
              ["注意：上线后才能看到你最新的更改"],
            "Remember to click PUBLISH once you're ready to go live! Any changes you make won't be visible to the world until you click this button.":
              ['网站完成后，请记得点击"上线"，访客才能看到你的网站'],
            Remove: ["移除"],
            "Remove <strong>Strikingly Branding</strong>": [
              "去除 <strong>上线了商标</strong>",
            ],
            "Remove Image": ["移除图片"],
            "Remove the Strikingly logo at the bottom of the page?": [
              "去除网站底部的上线了商标",
            ],
            "Remove this item": ["删除此项"],
            Replace: ["替换"],
            "Reply to All": ["回复全部"],
            "Reselelr|Add New Client": ["新增客户"],
            "Reselelr|Add Reseller Partner": ["添加二级分销账号"],
            "Reselelr|Create New Reseller Account": ["创建新的代理商帐户"],
            "Reselelr|Edit Partner Info": ["编辑二级分销账户信息"],
            "Reseller|%{contact} active contacts - $%{price}/year": [
              "%{contact} 个有效联系人 - $%{price}/年",
            ],
            "Reseller|%{currencySymbol}%{totalPrice} will immediately be deducted from your balance. Your next renewal date is %{date}.":
              [
                "确认后将从您的余额中扣除 %{currencySymbol}%{totalPrice}，付款后下次续费时间为 %{date}。",
              ],
            "Reseller|%{membership}": ["%{membership}"],
            "Reseller|%{name}'s account": ["%{name}的账号"],
            "Reseller|%{num} Audience Plan": ["%{num} 营销套餐"],
            "Reseller|(PNG, white logo with transparent background)": [
              "(PNG格式，白色logo，透明背景)",
            ],
            "Reseller|Actions": ["设置"],
            "Reseller|Add Audience Plan": ["添加营销套餐"],
            "Reseller|Add Credit": ["充值"],
            "Reseller|Add Credit To Balance": ["增加账户余额"],
            "Reseller|Add new reseller partner": ["添加新的二级分销账户"],
            "Reseller|Address": ["地址"],
            "Reseller|After payment, $%{amount} will be added to your account balance immediately":
              ["付款成功后，您的账户余额将立即增加$%{amount}"],
            "Reseller|Agent: %{superiorName}, phone number: %{phoneNumber}": [
              "上级代理商: %{superiorName}, 电话号码: %{phoneNumber}",
            ],
            "Reseller|All time": ["所有时间"],
            "Reseller|Amount": ["总共消费金额"],
            "Reseller|Amount To Add": ["充值金额"],
            "Reseller|Amount must be a integer.": ["金额必须为整数"],
            "Reseller|Amount of Credit to Add": ["充值金额"],
            "Reseller|Are you absolutely sure you want to move this site to %{targetClientEmail}? %{currentClientEmail} will lose access.":
              [
                "你确定要把网站移到 %{targetClientEmail}下吗? 移动后，%{currentClientEmail} 将不能编辑这个网站。",
              ],
            "Reseller|Are you absolutely sure you want to transfer %{currencySympol}%{amount} to %{partnerName}? This action cannot be undone!":
              [
                "你确定要转 %{currencySympol}%{amount}给%{partnerName}吗？转账后不能撤消！",
              ],
            "Reseller|Are you sure you want to clone this site? The cloned site will be added to the same client, and will start a free trial of the same plan. (Form responses will not be cloned.)":
              [
                "代理商|您确定要复制此网站吗？ 复制的网站将被添加到同一个客户端，并将开始免费试用相同的套餐。（表单回复不会被克隆。）",
              ],
            "Reseller|Are you sure you want to clone this site? The cloned site will start a free trial of the same plan. (Form responses will not be cloned.)":
              [
                "代理商|您确定要复制此网站吗？ 克隆的网站将开始免费试用相同的套餐。 （表单回复不会被克隆。）",
              ],
            "Reseller|Are you sure you want to downgrade this site?": [
              "你确定要降级套餐吗？",
            ],
            'Reseller|Are you sure you wish to unpublish? This will make your site go into "Under Construction" mode.':
              ["网站下线后将显示“正在创建中”，你确定下线该网站吗？"],
            "Reseller|Are you sure you wish to upgrade this subscription? The additional amount for the new plan will be billed.":
              ["你确定要升级这个订单吗？升级所需的费用会从你的账户中扣除。"],
            "Reseller|Are you sure you'd like to add $%{amount} to your account balance?":
              ["您确定要为帐户充值%{amount}吗？"],
            "Reseller|Audience Plan expired!": ["营销套餐已过期！"],
            "Reseller|Audience Plan: %{num} contacts": [
              "营销套餐：%{num} 个有效联系人",
            ],
            "Reseller|Awaiting Approval": ["等待审核"],
            "Reseller|Be careful! Deleting this client (%{clientName}) is a permanent and irreversible action!":
              [
                "输入客户姓名以确认删除。请注意！此客户 (%{clientName}) 删除后将无法恢复！",
              ],
            "Reseller|Be careful! Deleting this subscription (Deadline: %{endsAt}) is a permanent and irreversible action!":
              [
                "注意！你将永久的删除这个订单（过期时间：%{endsAt}），这个操作将是不可逆的。",
              ],
            "Reseller|Billing": ["账单"],
            "Reseller|Billing ZIP/Postal": ["帐单邮政编码"],
            "Reseller|Biz + mini program": ["企业版 ＋ 小程序"],
            "Reseller|Booking mini program - %{currencySymbol}%{price}/year": [
              "服务预定小程序 - %{currencySymbol}%{price}／年",
            ],
            "Reseller|Booking mini program plus Business site - %{currencySymbol}%{price}/year":
              ["服务预定小程序 + 企业版网站 - %{currencySymbol}%{price}／年"],
            "Reseller|Business": ["企业版"],
            "Reseller|Business + mini program": ["企业版 ＋ 小程序"],
            "Reseller|Business - %{currencySymbol}%{price}/month": [
              "企业版 - %{currencySymbol}%{price} / 月",
            ],
            "Reseller|Business - %{currencySymbol}%{price}/year": [
              "企业版 - %{currencySymbol}%{price} / 年",
            ],
            "Reseller|CLIENT LOGIN HAS BEEN CREATED": ["客户登录信息已创建"],
            "Reseller|Cancel": ["取消"],
            "Reseller|Card Number": ["卡号"],
            "Reseller|Channel manager": ["渠道经理"],
            "Reseller|City": ["城市"],
            "Reseller|Client Management": ["客户管理"],
            "Reseller|Client Name": ["姓名"],
            "Reseller|Client accounts": ["客户账户"],
            "Reseller|Client login link: [Link: %{userLoginUrl}]": [
              "客户登录链接：[Link: %{userLoginUrl}]",
            ],
            "Reseller|Clone Site": ["复制网站"],
            "Reseller|Clone an existing site": ["复制已经存在的网站"],
            "Reseller|Clone this site": ["复制这个网站"],
            "Reseller|Company": ["公司名称"],
            "Reseller|Company Name (Optional)": ["公司名称 (选填)"],
            "Reseller|Confirm": ["确认"],
            "Reseller|Confirm Add $%{amount} credit": ["确认充值 $%{amount}"],
            "Reseller|Confirm Transfer": ["确认转账"],
            "Reseller|Confirm plan": ["确认套餐"],
            "Reseller|Copied!": ["已复制到剪贴板"],
            "Reseller|Copy Link": ["复制链接"],
            "Reseller|Copy failed!": ["复制到剪贴板失败"],
            "Reseller|Country": ["国家"],
            "Reseller|Create": ["创建"],
            "Reseller|Create New Client": ["新增客户"],
            "Reseller|Create New Mini Program": ["创建小程序套餐"],
            "Reseller|Create New Site": ["创建新网站"],
            "Reseller|Create new reseller": ["创建新的代理商"],
            "Reseller|Create new site": ["创建新网站"],
            "Reseller|Created at": ["创建于"],
            "Reseller|Credit Added": ["充值记录"],
            "Reseller|Credit Remaining": ["剩余金额"],
            "Reseller|Credit Usage": ["余额使用情况"],
            "Reseller|Credit Used": ["已用金额"],
            "Reseller|Credit used": ["已使用"],
            "Reseller|Credit used %": ["已使用%"],
            "Reseller|Credits have been successfully added. In addition, your account manager may add bonus credits soon.":
              ["充值成功，渠道经理稍后为您的账户增加额外奖励金。"],
            "Reseller|Current Audience Plan": ["当前营销套餐"],
            "Reseller|Date": ["日期"],
            "Reseller|Deadline": ["过期时间"],
            "Reseller|Delete": ["删除"],
            "Reseller|Delete Client": ["删除客户"],
            "Reseller|Delete Subscription": ["删除订单"],
            "Reseller|Delete subscription": ["删除订单"],
            "Reseller|Discover": ["发现"],
            "Reseller|Downgrade": ["降级"],
            "Reseller|Downgrade Site": ["降级网站"],
            "Reseller|Downgrading this site will cause all %{plan} features on the site to be removed.":
              ["降级网站会导致网站内使用的%{plan}套餐的特性被移除掉。"],
            "Reseller|Download": ["下载"],
            "Reseller|Edit Mini Program": ["编辑小程序"],
            "Reseller|Edit info": ["编辑客户信息"],
            "Reseller|Edit partner info": ["编辑二级代理账户信息"],
            "Reseller|Email": ["电子邮箱"],
            "Reseller|Email: %{email}": ["邮箱：%{email}"],
            "Reseller|Expiration Date": ["到期时间"],
            "Reseller|Expired - Please purchase before %{date} to continue service":
              ["已到期，请在%{date}前付费以保证正常使用"],
            "Reseller|Expired - Please purchase to resume service": [
              "已到期 - 付费后可恢复正常使用",
            ],
            "Reseller|Expires on %{date}, please renew before this date": [
              "到期时间为%{date}，请在此之前续费。",
            ],
            "Reseller|Expires on %{date}.": ["过期时间为 %{date}。"],
            "Reseller|First Name": ["名字"],
            "Reseller|Free": ["免费版"],
            "Reseller|Free - %{currencySymbol}%{price}/year": [
              "免费版 - %{currencySymbol}%{price} / 年",
            ],
            "Reseller|Hotel mini program - %{currencySymbol}%{price}/year": [
              "酒店小程序 - %{currencySymbol}%{price}／年",
            ],
            "Reseller|Hotel mini program plus Business site - %{currencySymbol}%{price}/year":
              ["酒店小程序 + 企业版网站 - %{currencySymbol}%{price}／年"],
            "Reseller|Incorrect client name!": ["错误的客户姓名"],
            "Reseller|Incorrect deadline!": ["错误的过期时间"],
            "Reseller|Initial payment amount": ["原始付款金额"],
            "Reseller|Insufficient balance, please contact your agent to transfer credit to your account.":
              ["您的余额不足，请联系一级代理商充值。"],
            "Reseller|Insufficient balance, please contact your channel manager to add credit to your account.":
              ["您的余额不足，请先联系渠道经理充值。"],
            "Reseller|Insufficient plan.": ["无效的套餐。"],
            "Reseller|Invoices": ["账单详情"],
            "Reseller|Last Name": ["姓氏"],
            "Reseller|Login email": ["登录邮箱"],
            "Reseller|Login link has been sent to %{email}.": [
              "登录链接已经发送到 %{email}。",
            ],
            "Reseller|Logout": ["登出"],
            "Reseller|Manage Sites": ["网站管理"],
            "Reseller|Mini Program Name": ["小程序名称"],
            "Reseller|Minimum Sites to Add is 10.": ["至少需要添加10个网站"],
            "Reseller|Minimum amount is $480.": ["最低充值金额为 $480。"],
            "Reseller|Month to date": ["最近一个月内"],
            "Reseller|Most recent signin date": ["最近登录日期"],
            "Reseller|Move site": ["移动网站"],
            "Reseller|Move site to another client": ["移动网站到另一个客户"],
            "Reseller|Move this site": ["移动网站"],
            "Reseller|My Account": ["我的账户"],
            "Reseller|NOTE: After you submit this form, this reseller must be approved before their account is activated.":
              ["注意：提交此表单后，代理商必须在其帐户激活之前获得批准。"],
            "Reseller|Name": ["姓名"],
            "Reseller|No clients found": ["没有匹配的客户"],
            "Reseller|No clients found, [link: view all clients].": [
              "未找到相关客户，[link: 查看所有客户]",
            ],
            "Reseller|No sites found": ["没有搜索到的网站"],
            "Reseller|Number of Sites to Add": ["添加网站的数量"],
            "Reseller|OK": ["知道了"],
            "Reseller|OK, got it!": ["好的，知道了！"],
            "Reseller|On trial - Please purchase before %{date}": [
              "试用中，请于 %{date} 前付费",
            ],
            "Reseller|Or": ["或者"],
            "Reseller|Paid subscriptions": ["付费网站"],
            "Reseller|Partner Name": ["二级分销账户的名字"],
            "Reseller|Password reset link has been sent to %{email}.": [
              "重置密码链接已经发送到%{email}！",
            ],
            "Reseller|Phone": ["联系电话"],
            "Reseller|Phone Number": ["联系电话"],
            "Reseller|Phone Number (Optional)": ["联系电话 (选填)"],
            "Reseller|Please contact us at [link: support@strikingly.com] if you need to change this Audience Plan.":
              [
                "如果你需要更改营销套餐，请联系 [link: support@strikingly.com]。",
              ],
            "Reseller|Please contact your agent %{name} (%{phoneNumber}) to transfer credit to your balance.":
              ["请联系您的一级代理商%{name} (%{phoneNumber})充值。"],
            "Reseller|Please contact your channel manager %{name} (%{phoneNumber}) to add credit to your balance.":
              ["请联系您的渠道经理%{name} (%{phoneNumber})充值。"],
            "Reseller|Please enter a client name.": ["请输入客户姓名"],
            "Reseller|Please enter a name.": ["请输入一个名称"],
            "Reseller|Please enter a partner name.": [
              "请输入二级分销账户的名字。",
            ],
            "Reseller|Please enter a plan.": ["请选择一个套餐"],
            "Reseller|Please enter a site name.": ["请输入网站名称"],
            "Reseller|Please enter a valid amount.": ["请输入有效金额。"],
            "Reseller|Please enter a valid card number": ["请输入有效的卡号"],
            "Reseller|Please enter a valid email.": ["请输入有效的邮箱"],
            "Reseller|Please enter a valid expiration": ["请输入有效期"],
            "Reseller|Please enter a valid name.": ["请输入有效的名称。"],
            "Reseller|Please enter a valid phone number.": [
              "请输入有效的电话号码",
            ],
            "Reseller|Please enter a valid security code": [
              "请输入有效的安全码",
            ],
            "Reseller|Please input transfer amount!": ["请输入转账数量！"],
            "Reseller|Please send the following link to your client to reset their password.":
              ["请发送下面的重置密码链接给你的客户。"],
            "Reseller|Please send the following link to your client to set up their password.":
              ["请发送下面的登录链接给你的客户以设置密码"],
            "Reseller|Please send the following link to your partner to reset their password.":
              ["请发送下面的链接给你的二级分销账户去重置密码。"],
            "Reseller|Preview": ["预览"],
            "Reseller|Price/Site/Year": ["价格/网站/年"],
            "Reseller|Pro": ["专业版"],
            "Reseller|Pro - %{currencySymbol}%{price}/month": [
              "专业版 - %{currencySymbol}%{price} / 月",
            ],
            "Reseller|Pro - %{currencySymbol}%{price}/year": [
              "专业版 - %{currencySymbol}%{price} / 年",
            ],
            "Reseller|Provider": ["来源"],
            "Reseller|Publish": ["网站上线"],
            "Reseller|Purchase": ["付费"],
            "Reseller|Purchase Audience Plan": ["购买营销套餐"],
            "Reseller|Purchase Subscription": ["订单付费"],
            "Reseller|Recently updated": ["按网站最近更新时间排列"],
            "Reseller|Recharge Date": ["充值时间"],
            "Reseller|Remaining Balance": ["账户余额"],
            "Reseller|Remaining Balance: %{currencySymbol}%{credit}": [
              "账户余额: %{currencySymbol}%{credit}",
            ],
            "Reseller|Renew": ["续费"],
            "Reseller|Renew Audience Plan": ["营销套餐续费"],
            "Reseller|Renew Subscription": ["订单续费"],
            "Reseller|Reseller Partners": ["二级代理管理"],
            "Reseller|Reseller partners have an account like yours, and you can transfer credits from your account to their account.":
              [
                "你的二级代理账户和你的账户类似，你可以转账给你的二级代理账户。",
              ],
            "Reseller|Reseller partners have an account like yours. You can transfer your credits to their account, but you cannot transfer their credits back to your account!":
              [
                "二级代理账户和你的账户类似，但是你可以转账给二级代理账户，二级代理账户不能转账给你！",
              ],
            "Reseller|Resellers": ["代理商"],
            "Reseller|Reset partner password": ["重置二级代理账户密码"],
            "Reseller|Restaurant mini program - %{currencySymbol}%{price}/year":
              ["点餐小程序 - %{currencySymbol}%{price}／年"],
            "Reseller|Restaurant mini program plus Business site - %{currencySymbol}%{price}/year":
              ["点餐小程序 + 企业版网站 - %{currencySymbol}%{price}／年"],
            "Reseller|Restaurant mini program with ten storefronts - %{currencySymbol}%{price}/year":
              ["点餐小程序(10门店) - %{currencySymbol}%{price} / 年"],
            "Reseller|Restaurant mini program with ten storefronts plus Business site - %{currencySymbol}%{price}/year":
              [
                "点餐小程序(10门店) + 企业版网站 - %{currencySymbol}%{price} / 年",
              ],
            "Reseller|Restaurant mini program with thirty storefronts - %{currencySymbol}%{price}/year":
              ["点餐小程序(30门店) - %{currencySymbol}%{price} / 年"],
            "Reseller|Restaurant mini program with thirty storefronts plus Business site - %{currencySymbol}%{price}/year":
              [
                "点餐小程序(30门店) + 企业版网站 - %{currencySymbol}%{price} / 年",
              ],
            "Reseller|Return to dashboard": ["返回控制面板"],
            "Reseller|Sales Stats": ["销售统计"],
            "Reseller|Search and select an existing client...": [
              "搜索并选择已存在的客户...",
            ],
            "Reseller|Search and select an existing site...": [
              "搜索并选择一个存在的网站",
            ],
            "Reseller|Search by name/email/company/phone/site name/site domain":
              ["输入姓名/邮箱/公司名称/联系电话/网站名字/域名"],
            "Reseller|Select Template": ["选择模板"],
            "Reseller|Select an existing site": ["选择一个已经存在的网站"],
            "Reseller|Select plan for new subscription": ["选择新的套餐"],
            "Reseller|Select template to get started": ["请选择一个模板"],
            "Reseller|Selected client": ["选中的客户"],
            "Reseller|Selected site": ["选择的网站"],
            "Reseller|Send Email": ["发送邮件"],
            "Reseller|Send login": ["发送登陆链接"],
            "Reseller|Send us your feedback!": [
              "欢迎将您的问题或意见发送给我们！",
            ],
            "Reseller|Site Name": ["网站名称"],
            "Reseller|Sites": ["网站个数"],
            "Reseller|Sites Billed This Week": ["本周付款网站数"],
            "Reseller|Sites Built": ["创建网站数"],
            "Reseller|Sites Purchased": ["购买网站数"],
            "Reseller|Soon expiring": ["即将到期"],
            "Reseller|Sort by most recent": ["时间由近到远"],
            "Reseller|Sort by oldest": ["时间由远及近"],
            "Reseller|Standard - %{currencySymbol}%{price}/month": [
              "基础版 - %{currencySymbol}%{price} / 月",
            ],
            "Reseller|Standard - %{currencySymbol}%{price}/year": [
              "基础版 - %{currencySymbol}%{price} / 年",
            ],
            "Reseller|Start from a new template": ["从一个新模版开始"],
            "Reseller|State/Province": ["州/省"],
            "Reseller|Stats for %{name}": ["%{name}的统计资料"],
            "Reseller|Store mini program - %{currencySymbol}%{price}/year": [
              "电商小程序 - %{currencySymbol}%{price}／年",
            ],
            "Reseller|Store mini program plus Business site - %{currencySymbol}%{price}/year":
              ["电商小程序 + 企业版网站 - %{currencySymbol}%{price}／年"],
            "Reseller|Submit": ["提交"],
            "Reseller|Success!": ["成功！"],
            "Reseller|Successfully Purchased!": ["购买成功！"],
            "Reseller|Successfully Renewed!": ["续费成功！"],
            "Reseller|Successfully added $%{amount} credit to account balance":
              ["成功为账户充值$%{amount}"],
            "Reseller|Support Phone (displayed to this reseller's client)": [
              "客服电话（显示给代理商的客户）",
            ],
            "Reseller|Support email (displayed to this reseller's client)": [
              "客服邮箱（显示给代理商的客户）",
            ],
            "Reseller|The link will expire in 24 hours.": [
              "链接有效时间为24小时。",
            ],
            "Reseller|The site plan will not be changed.": [
              "网站的套餐不会受到影响。",
            ],
            "Reseller|There is less than %{currencySymbol}%{CREDIT_THRESHOLD} in your account, Please contact your agent to transfer credit to your balance as soon as possible.":
              [
                "您的账户余额已不足 %{currencySymbol}%{CREDIT_THRESHOLD}，请及时联系一级代理商充值。",
              ],
            "Reseller|There is less than %{currencySymbol}%{CREDIT_THRESHOLD} in your account, Please contact your channel manager to add credit to your balance as soon as possible.":
              [
                "您的账户余额少于%{currencySymbol}%{CREDIT_THRESHOLD}，请联系您的渠道经理及时为账户充值。",
              ],
            "Reseller|This client's current plan allows for %{contact} active contacts. Upgrade their Audience Plan to allow more, and to unlock Live Chat for their sites.":
              [
                "该客户当前所在的套餐仅允许 %{contact} 个有效联系人。升级客户的营销套餐以增加有效联系人上限以及解锁网页在线聊天功能。",
              ],
            "Reseller|This email is used by another client": [
              "该邮箱已存在，请重新输入",
            ],
            "Reseller|This email is used by another partner": [
              "该邮箱已存在，请重新输入",
            ],
            "Reseller|This field is required.": ["此项为必填项"],
            "Reseller|This field must be a integer.": ["该字段必须是整数"],
            "Reseller|This free trial will end in %{trialDays} days. Please purchase this site before %{date} so the site can be published successfully.":
              [
                "该网站免费试用 %{trialDays} 天, 请于 %{date} 前在网站列表中点击“购买”进行付款，以保证网站能够正常上线。",
              ],
            "Reseller|This free trial will end in %{trialDays} days. Please purchase this subscription before %{date} so the subscription can be published successfully.":
              [
                "该订单免费试用 %{trialDays} 天, 请于 %{date} 前在订单列表中点击“购买”进行付款，以保证其能够正常上线／发布。",
              ],
            "Reseller|This reseller account has successfully been created, but they still need to set up their password and log in.":
              ["二级分销账户已经创建成功，但是他还需要设置密码并登陆。"],
            "Reseller|This reseller account has successfully been created, but they still need to set up their password and log in. To complete the process, you can send an email or send them the link yourself.":
              [
                "代理商账户已经创建成功，但是他还需要设置密码并登陆。请通过email或者其他方式发送登录链接给代理商。",
              ],
            "Reseller|This reseller partner account must be approved before you can continue.":
              ["这个二级分销账户需要通过审核才能进行后续操作。"],
            "Reseller|This site is still in the trial period, so you may downgrade the plan.":
              ["网站还在试用期，你可以降级网站。"],
            "Reseller|This subscription is expired and has been unpublished. To edit and republish, please renew this subscription.":
              ["这个订单已到期并且被下线。想要编辑和上线，请先续费。"],
            "Reseller|This subscription is expired but is currently in the grace period. If you do not renew by %{date}, this subscription will be unpublished.":
              [
                "这个订单已到期但是处于宽限期。如果你未在%{date}前续费，这个订单会被下线。",
              ],
            "Reseller|This subscription is not allowed to update, please contact your channel manager.":
              ["这个网站不允许升级，请联系你的渠道经理。"],
            "Reseller|This username is used by another partner": [
              "该用户名已存在，请重新输入",
            ],
            "Reseller|This will make your site visible to the world!": [
              "确认后网站将立即上线",
            ],
            "Reseller|To complete the process, you can send an email or send them the link yourself.":
              ["请通过email或者其他方式发送登录链接给二级分销账户。"],
            "Reseller|Top payments": ["最高付款"],
            "Reseller|Top resellers by credit usage": ["销售金额最多的代理商"],
            "Reseller|Total Amount Billed This Week": ["本周消费金额"],
            "Reseller|Total credit loaded": ["总金额"],
            "Reseller|Total payments by all resellers": ["所有代理商的总付款"],
            "Reseller|Total recharge credit": ["充值总金额"],
            "Reseller|Transfer Amount": ["转账数量"],
            "Reseller|Transfer Credit": ["转账"],
            "Reseller|Transfer amount can not be 0!": ["转账数量不能为0！"],
            "Reseller|Transfer amount must be an integer!": [
              "转账数量必须为整数！",
            ],
            "Reseller|Transfer credit": ["转账"],
            "Reseller|Transfer to": ["转账至"],
            "Reseller|Trial subscriptions": ["试用网站"],
            "Reseller|Unpublish": ["网站下线"],
            "Reseller|Update Reseller Info": ["更新代理商信息"],
            "Reseller|Update logo": ["更新logo"],
            "Reseller|Updated %{date}": ["更新于 %{date}"],
            "Reseller|Upgrade": ["升级"],
            "Reseller|Upgrade Site": ["升级网站"],
            "Reseller|Upgrade Subscription": ["升级"],
            "Reseller|Upgrade subscription": ["升级"],
            "Reseller|Upload logo": ["上传logo"],
            "Reseller|Upload proof of payment": ["上传付款凭证"],
            "Reseller|Upload reseller logo (Optional, white logo with transparent background, PNG)":
              ["上传代理商logo（可选，透明背景的白色logo, PNG）"],
            "Reseller|Upload reseller's photo ID": [
              "上传公司营业执照/个人身份证",
            ],
            "Reseller|Upload signed contract": ["上传签约合同"],
            "Reseller|Upon approval, an email will be sent to this address to allow the reseller to set up their account.":
              [
                "批准后，电子邮件会发送到代理商的邮箱，代理商可以登录和设置帐户。",
              ],
            "Reseller|Use exsiting card %{card}": ["使用现有的银行卡%{card}"],
            "Reseller|View All Sites": ["查看所有网站"],
            "Reseller|View more": ["查看更多网站"],
            "Reseller|Week": ["日期"],
            "Reseller|Year to date": ["最近一年内"],
            "Reseller|You don't have any billings yet.": ["您还没有销售记录。"],
            "Reseller|You don't have any clients yet.": ["您还没有添加客户。"],
            "Reseller|You don't have any partners yet.": [
              "您还没有添加任何二级分销账户。",
            ],
            "Reseller|You don't have enough credit!": ["您的余额不足！"],
            "Reseller|You need to purchase the site first to get the mini program!":
              ["你需要购买这个网站才能获取小程序！"],
            "Reseller|You will not be billed during this trial period.": [
              "在试用期间，你不会被扣除费用。",
            ],
            "Reseller|Your Audience Plan has expired. Please ask your site administrator to re-enable the Audience Plan for membership, live chats, and email recipients.":
              [
                "你的营销套餐已过期。请联系你的网站管理员以重新启用营销套餐来重新激活网站会员功能、在线聊天对话、邮件收件人等功能。",
              ],
            "Reseller|Your Credit Available": ["你的可用余额"],
            "Reseller|Your Reseller Partners": ["你的二级分销账户"],
            "Reseller|Your remaining credit is %{currencySymbol}%{credit}.": [
              "您的余额为 %{currencySymbol}%{credit}.",
            ],
            "Reseller|You’ve hit the limit for active contacts. Please ask your site administrator to enable more contacts for membership, live chats, and email recipients.":
              [
                "你已达到当前套餐所允许的有效联系人上限了。请联系你的网站管理员来获得更多有效联系人的额度（有效联系人包括网站会员功能、在线聊天对话、邮件收件人）。",
              ],
            "Reseller|[span: You will be billed %{currencySymbol}%{upgradingPrice} immediately,] pro-rated to your current billing period + first-year fee (%{currencySymbol}%{oneTimeFee}).":
              [
                "[span: 你的账户会被立即扣除%{currencySymbol}%{upgradingPrice}，] 根据你套餐剩余时间按比例计算的差价 + 第一年费用 (%{currencySymbol}%{oneTimeFee})。",
              ],
            "Reseller|[span: You will be billed %{currencySymbol}%{upgradingPrice} immediately,] pro-rated to your current billing period.":
              [
                "[span: 你的账户会被立即扣除 %{currencySymbol}%{upgradingPrice}，] 根据你套餐剩余时间按比例计算的差价。",
              ],
            "Reseller|client login link": ["创建客户登录信息"],
            "Reseller|declined": ["申请被拒绝"],
            "Reseller|edit client info": ["编辑客户信息"],
            "Reseller|reapply": ["重新申请"],
            "Reseller|reset client password": ["重置账户密码"],
            "Reseller|send login info": ["发送登录信息"],
            "Reseller|standard": ["基础版"],
            "Reseller|upload proof of payment": ["上传付款凭证"],
            "Resend after %{var1}s": ["%{var1}秒后重发"],
            Reset: ["重置"],
            "Reset Password": ["重设密码"],
            "Return To Dashboard": ["返回控制面板"],
            "Return to Dashboard": ["回到控制面板"],
            "Return to blog manager": ["返回博客管理"],
            "Review form responses, contact visitors via email, and send newsletters.":
              ["通过邮箱地址、发送营销邮件来查看表单，联系访客。"],
            "Review forms, contact visitors directly via email, and send newsletters.":
              ["通过邮箱地址、发送营销邮件来查看表单，联系访客。"],
            Reward: ["奖励"],
            SELECT: ["选择"],
            "SHARED WITH ME": ["与我分享"],
            "SMS Number": ["短信号码"],
            "STRIKINGLY LIBRARY": ["上线了图库"],
            Save: ["保存"],
            "Save [price]": ["节省 [price]"],
            "Save [price] on Pro": ["专业版节省 [price]"],
            "Save as Draft": ["保存为草稿"],
            "Save recovery codes": ["保存恢复码"],
            Saved: ["已保存"],
            "Saved!": ["已保存"],
            Saving: ["保存中"],
            "Saving...": ["正在保存……"],
            Section: ["版块"],
            Sections: ["版块"],
            "Sections|$1.5M": ["一百万元"],
            "Sections|20M": ["两千万"],
            "Sections|30min": ["30min"],
            "Sections|<br/><p>How to Build a Website Like a Professional</p>": [
              "<br/><p>如何专业地搭建网站</p>",
            ],
            "Sections|<div>Add and rearrange any components you want.</div>": [
              "<div>添加网站元素或自定义排版</div>",
            ],
            "Sections|<div>Become a Member Today</div>": [
              "<div>立即订阅成为会员！</div>",
            ],
            "Sections|<div>Check out my latest updates!</div>": [
              "<div>查看最新资讯</div>",
            ],
            "Sections|<div>Contact Us</div>": ["<div>联系我们</div>"],
            "Sections|<div>Create unique form!</div>": [
              "<div>创建独一无二的表单！</div>",
            ],
            "Sections|<div>Custom Form</div>": ["<div>自定义表单</div>"],
            "Sections|<div>Don't be afraid to reach out. You + us = awesome.</div>":
              ["<div>赶紧联系我们吧。和我们一起，激发无限创造力</div>"],
            "Sections|<div>Download Now</div>": ["<div>立即下载</div>"],
            "Sections|<div>Embed an App</div>": ["<div>添加一个应用工具</div>"],
            "Sections|<div>Join us for these amazing benefits.</div>": [
              "<div>加入即可享受精彩权益。</div>",
            ],
            "Sections|<div>Make Your Own Section!</div>": [
              "<div>创建自己的版块</div>",
            ],
            "Sections|<div>Or write your own HTML code! (HTML is Pro only)</div>":
              ["<div>或者你可以输入 HTML 代码（专业版以上功能）</div>"],
            "Sections|<div>Sign Up</div>": ["<div>报名</div>"],
            "Sections|<div>Social Feed</div>": ["<div>社交内容</div>"],
            "Sections|<div>The Blog</div>": ["<div>博客</div>"],
            "Sections|<div>Thoughts, musings, and ruminations.</div>": [
              "<div>你的想法，值得被传递</div>",
            ],
            "Sections|<div>We'll get in touch with you soon.</div>": [
              "<div>我们会尽快联系你</div>",
            ],
            "Sections|<div>You can add any link or even upload a file to this button!</div>":
              ["<div>你可以在按钮上添加任何链接</div>"],
            "Sections|<em>Add a subtitle here.</em>": ["<em>添加副标题</em>"],
            "Sections|<p><br/>You’ve read all your free member-only stories.</p><p>Become a member to get unlimited access and support the voices you want to hear more from.</p>":
              [
                "<p><br/>你已阅读完免费会员所属的全部内容。</p><p>成为付费会员可畅享无限制阅读，并支持你所喜爱的内容创作。</p>",
              ],
            "Sections|<p><strong>About Us</strong></p><p>Our Mission</p><p>We&#39;re Hiring!</p>":
              [
                "<p><strong>关于我们</strong></p><p>我们的使命</p><p>正在招聘！</p>",
              ],
            "Sections|<p><strong>Contact Us</strong></p><p>321-555-5555</p><p>info@company.com</p>":
              [
                "<p><strong>联系我们</strong></p><p>321-555-5555</p><p>info@company.com</p>",
              ],
            "Sections|<p><strong>Resources</strong></p><p>Tutorials</p><p>Brand Assets</p>":
              ["<p><strong>资源</strong></p><p>教程</p><p>品牌资料</p>"],
            "Sections|<p><strong>Subscribe to Our Newsletter</p></strong>": [
              "<p><strong>订阅我们的最新资讯</p></strong>",
            ],
            "Sections|<p>A sentence or two describing this item. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.</p>":
              [
                "<p>简介你的项目或成员。夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。</p>",
              ],
            "Sections|<p>A sentence or two describing this item.</p>": [
              "<p>简介你的产品、功能或项目</p>",
            ],
            "Sections|<p>About Me</p>": ["<p>关于我</p>"],
            "Sections|<p>Advanced course unlocked</p><p>Live chat support</p><p>Video guides</p>":
              ["<p>进阶课程教程</p><p>在线实时客服支持</p><p>含视频教程</p>"],
            "Sections|<p>Basic course unlocked</p><p>Email support</p><p>No video guides</p>":
              ["<p>基础课程教程</p><p>邮件客服支持</p><p>无视频教程</p>"],
            "Sections|<p>Everything in Pro, plus:</p><p>One-on-one coaching</p><p>Bonus care package!</p>":
              ["<p>专业版权益外加</p><p>一对一培训</p><p>神秘礼包特权!</p>"],
            "Sections|<p>Gallery</p>": ["<p>相册</p>"],
            "Sections|<p>How to Build a Website Like a Professional</p>": [
              "<p>如何专业地搭建网站</p>",
            ],
            "Sections|<p>Just say hi or send inquiries</p>": [
              "和我们打个招呼吧",
            ],
            "Sections|<p>Photos &amp; Videos</p>": ["<p>照片和视频</p>"],
            "Sections|<p>Photos &amp; videos from our travels.</p>": [
              "<p>旅途中的照片和视频</p>",
            ],
            "Sections|<p>Stay in Touch</p>": ["<p>联系我们</p>"],
            "Sections|<p>Take a look and enjoy!</p>": ["<p>试试吧</p>"],
            "Sections|<p>Title Text</p>": ["<p>标题文本</p>"],
            "Sections|<p>Use a text section to describe your values, show more info, summarize a topic, or tell a story. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore. Nullam accumsan diam libero, non iaculis ante mattis vitae.</p>":
              [
                "<p>简介你的项目和产品，或者展示你的品牌文化。夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。</p>",
              ],
            "Sections|<p>You’ve read all your free member-only stories.</p><p>Become a member to get unlimited access and support the voices you want to hear more from.</p>":
              [
                "<p>你已阅读完免费会员所属的全部内容。</p><p>成为付费会员可畅享无限制阅读，并支持你所喜爱的内容创作。</p>",
              ],
            "Sections|A Heroic Section": ["头条版块"],
            "Sections|A big background with a title and tagline.": [
              "带有标题和宣传语的背景大图。",
            ],
            "Sections|A big call-to-action. Supports an external link or a file download!":
              [
                "你可以给按钮添加链接，访客点击后即可跳转至指定链接或下载文件！",
              ],
            "Sections|A bold cover image, with colorful backgrounds throughout. Great for startups!":
              [
                "一张让人印象深刻的背景图片，让访客知道你在做什么，非常适合创业公司",
              ],
            "Sections|A classy, modern profile.": ["经典简历模板"],
            "Sections|A clean, simple template with your choice of color. Great for businesses and startups.":
              [
                "简单而又兼富设计感的模板，搭配上你选择的颜色，让你的网站更专业",
              ],
            "Sections|A list of small icons. Good for social media.": [
              "添加一排社交媒体图标。",
            ],
            "Sections|A magazine-style template with bold, beautiful fullscreen tiles. Great for showcases and portfolios.":
              ["杂志般的模版，醒目，美观，全屏，适用于产品展示或作品集"],
            "Sections|A numbered list of steps. Explain how your service works!":
              ["用带编号的步骤，向用户解释你的服务流程！"],
            "Sections|A sentence or two describing this item.": [
              "简介你的产品、功能或项目",
            ],
            "Sections|A sentence or two describing this item. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.":
              [
                "一行简单的描述文字。夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。",
              ],
            "Sections|A small tagline": ["一行小标语"],
            "Sections|A small, simple template.": ["精致简约的模板"],
            "Sections|A very sleek theme": ["现代感十足的模板"],
            "Sections|Accordion / FAQ": ["可折叠文本/常见问答"],
            "Sections|Add a button": ["添加按钮"],
            "Sections|Add a fully customizable form with any fields you want.":
              ["添加自定义表单，灵活配置不同表单字段。"],
            "Sections|Add details and descriptions to each product.": [
              "为每个产品添加详情和描述。",
            ],
            "Sections|Add subtitle": ["添加副标题"],
            "Sections|Add text here": ["添加文字"],
            "Sections|All Categories": ["所有分类"],
            "Sections|An advanced business portfolio. Each product or item opens in its own page, where you can add a price, gallery, and detailed description.":
              [
                "进阶产品展示板块，每个产品有自己独立的产品页，可以添加图片、价格以及详细描述。",
              ],
            "Sections|App Store": ["应用商店"],
            "Sections|App Store & HTML": ["应用商店及 HTML 代码"],
            "Sections|August 30": ["8月30日"],
            "Sections|BOOK NOW": ["立即预约"],
            "Sections|Banner": ["轮播图"],
            "Sections|Banner Image Slider": ["轮播图"],
            "Sections|Become a member to get unlimited access and support the voices you want to hear more from.":
              ["成为付费会员可畅享无限制阅读，并支持你所喜爱的内容创作。"],
            "Sections|Big Media": ["大尺寸媒体"],
            "Sections|Big and clear content. Great for startups and pitch decks.":
              ["内容醒目，清晰，适合创业公司或活动分享"],
            "Sections|Big cover images for every section! Great for personal sites, events, and businesses.":
              [
                "大尺寸的清晰图片，可以更好地展示个人网站、活动及商业产品的品牌",
              ],
            "Sections|Bio": ["简介"],
            "Sections|Blog": ["博客"],
            "Sections|Blog Post Title A": ["博客标题 A"],
            "Sections|Blog Post Title B": ["博客标题 B"],
            "Sections|Blog Post Title C": ["博客标题 C"],
            "Sections|Booking": ["服务预约"],
            "Sections|Business Workshop": ["商业学习交流"],
            "Sections|Button": ["按钮"],
            "Sections|Buy Now": ["立即购买"],
            "Sections|Check out our products.": ["查看我们的产品"],
            "Sections|Clients served": ["客户"],
            "Sections|Columns": ["列表"],
            "Sections|Connect": ["联系"],
            "Sections|Connect With Us": ["联系我们"],
            "Sections|Contact": ["联系方式"],
            "Sections|Contact Form": ["留言表单"],
            "Sections|Contact Us": ["联系方式"],
            "Sections|Content in Columns": ["纵向布局"],
            "Sections|Content in Rows": ["横向布局"],
            "Sections|Custom Form": ["自定义表单"],
            "Sections|DOWNLOAD": ["下载"],
            "Sections|Date & Time": ["日期 & 时间"],
            "Sections|Deliver": ["发货"],
            "Sections|Display your latest social media posts beautifully.": [
              "完整展示你的最新社交媒体博文",
            ],
            "Sections|Donate Now": ["支持一下"],
            "Sections|Donation": ["筹款"],
            "Sections|Email": ["邮箱"],
            "Sections|Embed a map, a calendar, a document, a form or any HTML code!":
              ["嵌入地图、日历、文件、表單、或任意 HTML 代码！"],
            "Sections|Enter your address and pay with credit, debit, or PayPal. We ship anywhere.":
              ["输入收货地址，可使用信用卡，借记卡或PayPal付款。"],
            "Sections|FAQs": ["常见问题解答"],
            "Sections|Fall": ["秋"],
            "Sections|Feature 1": ["特点 1"],
            "Sections|Feature 2": ["特点 2"],
            "Sections|Feature 3": ["特点 3"],
            "Sections|Feature Listing": ["功能展示"],
            "Sections|Freedom": ["自由"],
            "Sections|Funding raised": ["融资金额"],
            "Sections|Gallery": ["相册"],
            "Sections|Gallery (Legacy)": ["图册（旧版）"],
            "Sections|Get in Touch with Nadia!": ["快来联系Nadia吧！"],
            "Sections|Great for the top of a page. Add images, a button, or even a sign-up form.":
              ["适合用于网站首屏，可以添加图片，按钮，甚至报名表单"],
            "Sections|Grid": ["网格"],
            "Sections|Hello & Welcome!": ["你好世界"],
            "Sections|Hero": ["头条"],
            "Sections|How It Works": ["流程"],
            "Sections|How do I create a website?": ["我要怎么创建一个网站？"],
            "Sections|How to Build a Website Like a Professional": [
              "如何专业地搭建网站",
            ],
            "Sections|Image and video thumbnails that open in a full view.": [
              "可以全屏浏览的图片和视频缩略图。",
            ],
            "Sections|Independence": ["独立"],
            "Sections|Info": ["信息"],
            "Sections|Info Boxes": ["信息框"],
            "Sections|Intro": ["简介"],
            "Sections|Introduce your product or service!": [
              "介绍你的产品和服务",
            ],
            "Sections|Just paragraphs of text with titles.": [
              "带有标题的文本段落。",
            ],
            "Sections|Lessons Learned from Starting Up": [
              "在创业公司工作的收获",
            ],
            "Sections|Let viewers drop their name, email, and message. Show a map and business info.":
              [
                "用于让访客填写姓名、电子邮件和评论的留言表，同时显示地图和其他信息。",
              ],
            "Sections|Let visitors sign up for a newsletter or a service.": [
              "让访客注册预约最新通讯或服务。",
            ],
            "Sections|Linkable panels of images & text. Customize layout, size, and spacing. A very visual way to display categories, testimonials, or features!":
              [
                "这是一个可链接的图文版块，用来展示分类、客户评价或功能列表。你可自定义内容布局、大小和间距。",
              ],
            "Sections|List experiences, schools, projects, or anything!": [
              "展示经历、学校、作品或任何事！",
            ],
            "Sections|List your features, projects, team members, or anything!":
              ["列举你的业务特点、项目优势、核心团队或其他"],
            "Sections|List your projects, clients, features, team, or anything!":
              [
                "展示你的项目、客户、功能、团队以及任何你想要告诉这个世界的事情！",
              ],
            "Sections|Lorem ipsum": ["夏天的飞鸟"],
            "Sections|Lorem ipsum dolor sit amet, consectetuer adipiscing elit":
              [
                "夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，只叹息一声，飞落在那里。",
              ],
            "Sections|Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.":
              [
                "夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。",
              ],
            "Sections|Make Your Own": ["自定义"],
            "Sections|Make Your Own Section": ["自定义版块"],
            "Sections|Make sure to add links to the icons!": [
              "试试在图标上添加链接",
            ],
            "Sections|Message": ["留言"],
            "Sections|Name": ["名字"],
            "Sections|New Blog Feature!": ["新的博客功能"],
            "Sections|Only show posts from a certain category.": [
              "只显示当前博客分类下的文章",
            ],
            "Sections|Option 1": ["多选 1"],
            "Sections|Option 2": ["多选 2"],
            "Sections|Our Blog": ["我们的博客"],
            "Sections|Our Commitment to Service": ["我们对服务的承诺"],
            "Sections|Passion": ["热情"],
            "Sections|Pay Online": ["在线支付"],
            "Sections|People reached": ["用户"],
            "Sections|Phone": ["电话"],
            "Sections|Photos & Videos": ["照片和视频"],
            "Sections|Pick your favorites from our high-quality collections, and add to your cart.":
              ["从高品质的系列中挑选你喜欢的，并添加到购物车"],
            "Sections|Plain Text": ["纯文本"],
            "Sections|Portfolio": ["作品集"],
            "Sections|Present yourself beautifully. Great for resumes and personal sites.":
              ["展现你自己，适合个人简历或个人网站"],
            "Sections|Pricing Table": ["定价表"],
            "Sections|Process": ["流程"],
            "Sections|Product Showcase": ["产品展示"],
            "Sections|Profiles": ["个人资料"],
            "Sections|Projects": ["项目"],
            "Sections|Purchase": ["购买"],
            "Sections|Purple": ["浅紫"],
            "Sections|Radio 1": ["单选 1"],
            "Sections|Radio 2": ["单选 2"],
            "Sections|Read More": ["查看更多"],
            "Sections|Receive donations right on your site!": [
              "立即在你的网站上创建一个筹款！",
            ],
            "Sections|Recommendations": ["推荐"],
            "Sections|Resume": ["简历"],
            "Sections|SELECT": ["选择"],
            "Sections|SXL is a store & site builder that allows anyone to create a beautiful website and start selling products within minutes.":
              [
                "上线了是一个建设网站和商店的平台，让任何人都可以在几分钟内快速创建出一个漂亮的网站并且销售产品。",
              ],
            "Sections|Schedule your service, training, concerts, meetings, or any event so visitors can book appointments!":
              ["适用于服务预订、课程培训、音乐会、会议等任意预约类场景！"],
            "Sections|Select a category for this section.": [
              "为当前简易博客版块选择显示一个博客分类下的文章",
            ],
            "Sections|Select a date and time to book.": ["选择预约日期和时间"],
            "Sections|Sell products right on your site! Manage orders, payments, and more.":
              ["在你的网站上随心交易！轻松管理订单、收款及更多。"],
            "Sections|September 12": ["9月12日"],
            "Sections|September 17": ["9月17日"],
            "Sections|Set your booking information, availability, and start taking appointments.":
              ["配置服务类型和可预约时间，开启你的预约服务。"],
            "Sections|Shop Now": ["立即购买"],
            "Sections|Show a big video or image. Or add many of them.": [
              "显示大尺寸视频或图片。或者多添加几个。",
            ],
            "Sections|Show boxes of steps, stats, or tidbits.": [
              "用流程框的形式展示步骤、数据、功能或其他信息。",
            ],
            "Sections|Show off your projects, features, or clients in this section.":
              ["在这里展示你的项目，功能或客户"],
            "Sections|Show skills, stats, or tidbits.": [
              "展示技能、数据或者花絮",
            ],
            "Sections|Show text content in an accordion format. Each item can be expanded to show the full text.":
              ["通过可折叠的形式显示文本内容，每个项目都可以展开以显示全文。"],
            "Sections|Show the world your fresh new ideas.": [
              "告诉世界你的新奇创意",
            ],
            "Sections|Show your plans, prices, and benefits in an elegant grid, with clear calls-to-action.":
              [
                "用定价表来清晰地呈现你的业务、定价、核心卖点，吸引客户点击购买。",
              ],
            "Sections|Showcase": ["展示"],
            "Sections|Sign Up": ["报名"],
            "Sections|Sign up for a creative consultation": ["注册创意咨询"],
            "Sections|Sign-Up Form": ["注册功能"],
            "Sections|Simple Blog": ["简易博客"],
            "Sections|Simple Blog 1": ["简易博客 1"],
            "Sections|Simple Blog 3": ["简易博客 3"],
            "Sections|Simple Store": ["简易商店"],
            "Sections|Skills": ["技能"],
            "Sections|Slider": ["滑块"],
            "Sections|Smart Light Bulbs": ["智能灯泡"],
            "Sections|Social Feed": ["社交内容"],
            "Sections|Some caption here": ["输入标题"],
            "Sections|Spring": ["春"],
            "Sections|Stay in Touch": ["联系我们"],
            "Sections|Store": ["商店"],
            "Sections|Strikingly is a store & site builder that allows anyone to create a beautiful website and start selling products within minutes.":
              [
                "Strikingly是一个建设网站和商店的平台，让任何人都可以在几分钟内快速创建出一个漂亮的网站并且销售产品。",
              ],
            "Sections|Submit": ["提交"],
            "Sections|Subscribe": ["订阅"],
            "Sections|Subtitle Text": ["副标题"],
            "Sections|Summer": ["夏"],
            "Sections|Super clean and spacey, with a handy left-hand navigation.":
              ["模板简介清新，网站侧边的菜单栏也极富设计感"],
            "Sections|Swipeable and linkable image slider. Great for promos and heavy graphical content.":
              ["可滑动和可添加链接的轮播图，尤其适合促销活动。"],
            "Sections|Swipeable slider with text, button, and image/video. Background image optional.":
              ["滑块版块可添加文本，按钮，图片/视频。可选择是否添加背景图片。"],
            "Sections|Text + Button Slider": ["滑块"],
            "Sections|Thanks for your submission!": ["感谢提交"],
            "Sections|The FAQ section lets you show expandable content. Enter questions and answers, or more detailed information for anything you want!":
              [
                "常见问答版块能让你以可折叠的形式展示文本内容。你可以输入问题与答案，或任何你想展示的更详细的信息！",
              ],
            "Sections|Title": ["标题"],
            "Sections|Title Text": ["标题文本"],
            "Sections|Use a text section to describe your values, or show more info, or summarize a topic, or tell a story. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore.":
              [
                "简介你的项目和产品，或者展示你的品牌文化。夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。",
              ],
            "Sections|Use a text section to describe your values, show more info, summarize a topic, or tell a story.":
              [
                "简介你的项目和产品，或者展示你的品牌文化。夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。",
              ],
            "Sections|Use a text section to describe your values, show more info, summarize a topic, or tell a story. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore.":
              [
                "简介你的项目和产品，或者展示你的品牌文化。夏天的飞鸟，飞到我的窗前唱歌，又飞去了。秋天的黄叶，它们没有什么可唱，只叹息一声，飞落在那里。",
              ],
            "Sections|View All": ["查看全部"],
            "Sections|Want more control over layouts? Arrange components yourself!":
              ["想要自定义网站布局？试试自己排版吧"],
            "Sections|We'll deliver your goods within 5 business days. Ask us any questions!":
              ["我们将在5个工作日内发货， 有任何问题可以与我们联系！"],
            "Sections|We've got a top notch team!": ["我们拥有最专业的团队"],
            "Sections|What We Do": ["我们在做什么"],
            "Sections|What is SXL?": ["什么是“上线了”？"],
            "Sections|What is Strikingly?": ["什么是“Strikingly”？"],
            "Sections|What is the FAQ section?": ["什么是常见问答版块？"],
            "Sections|While you might not need all...": [
              "点亮生活，从这里开始",
            ],
            "Sections|Winter": ["冬"],
            "Sections|With SXL, it's incredibly easy to create a website. Just pick a template, add sections, change the content, and click Publish. Thousands of sites have already been created -- yours is next!":
              [
                "在上线了，创建一个网站非常容易。你只要选择一个模板，添加版块，修改内容，然后点击上线。已经有成千上万的网站在这里被创建起来了——你的就是下一个！",
              ],
            "Sections|With Strikingly, it's incredibly easy to create a website. Just pick a template, add sections, change the content, and click Publish. Millions of sites have already been created -- yours is next!":
              [
                "在Strikingly，创建一个网站非常容易。你只要选择一个模板，添加版块，修改内容，然后点击发布。已经有上千万的网站在这里被创建起来了——你的就是下一个！",
              ],
            "Sections|Write a blurb about yourself.": ["简单宣传下你自己。"],
            "Sections|Write beautiful blog posts that open in a new page.": [
              "每一篇博客，都可以在独立页面中访问浏览",
            ],
            "Sections|You already have a %{section} on this site.": [
              "你的网站已经有一个%{section}版块",
            ],
            "Sections|You already have a blog section! Note: Pro users can add multiple blog sections for different categories.":
              [
                "网站上已经添加过简易博客版块了! 小贴士：企业版用户可以添加多个简易博客版块以显示不同博客分类下的文章。",
              ],
            "Sections|You already have a blog section! Note: You can add multiple blog sections if you have different blog categories.":
              [
                "网站上已经添加过简易博客版块了! 小贴士：先在博客文章中添加博客分类，然后再添加多个博客版块以显示不同博客分类中的文章。",
              ],
            "Sections|You already have a product showcase section! Note: Pro users can add multiple product showcase sections for different categories.":
              [
                "您已经有一个产品展示版块！ 注意：企业版用户可以添加包含不同分类的多个产品展示版块。",
              ],
            "Sections|You already have a product showcase section! Note: You can add multiple product showcase sections if you have different product categories.":
              [
                "网站上已经添加过产品展示版块了! 小贴士：先为产品添加分类，然后再添加多个产品展示版块以显示不同产品分类。",
              ],
            "Sections|You already have a store section! Note: Pro users can add multiple store sections for different categories.":
              [
                "网站上已经添加过简易商店版块了! 小贴士：企业版用户可以添加多个简易商店版块以显示不同的商品分类。",
              ],
            "Sections|You already have a store section! Note: You can add multiple store sections if you have different product categories.":
              [
                "网站上已经添加过简易商店版块了! 小贴士：先为商品添加商品分类，然后再添加多个简易商店版块以显示不同商品分类。",
              ],
            "Sections|You can add multiple blog sections with categories to the site.":
              ["您可以添加多个简易博客版块来显示不同的博客分类。"],
            "Sections|You can add multiple product showcase sections with categories to the site.":
              ["您可以在网站上添加包含不同分类的产品展示版块。"],
            "Sections|You can add multiple store sections with categories to the site.":
              ["你可以添加多个简易商店板块来显示不同的商品分类。"],
            "Sections|Your name here!": ["你的名字"],
            "Section|Add Section": ["添加板块"],
            "Section|Advanced": ["高级"],
            "Section|All Categories": ["所有分类"],
            "Section|Banner Slider": ["轮播图滑块"],
            "Section|Blank": ["空白"],
            "Section|Blog": ["博客"],
            "Section|Blog & Portfolio": ["博客 & 产品展示"],
            "Section|Call to Action": ["图文引导"],
            "Section|Commerce": ["业务模块"],
            "Section|Contact & Forms": ["联系表单"],
            "Section|Embed & HTML": ["插件嵌入 & HTML"],
            "Section|Feature List": ["列表"],
            "Section|Image & Media": ["图片媒体"],
            "Section|Infographic": ["信息图"],
            "Section|Let viewers drop their name, email, and message. Add a fully customizable form with any fields you want.":
              [
                "让访客留下姓名、邮箱和留言。或添加1个自定义表单，包含想要的各种各样字段。",
              ],
            "Section|Panels of images & text. Customize layout, size, and spacing. A very visual way to show categories, testimonials, or features.":
              [
                "网格图文组合。支持自定义布局、大小和间距，用直观的方式展示各种类别、推荐或功能。",
              ],
            "Section|Paragraphs of text with titles.": ["文字段落，包含标题。"],
            "Section|Pricing": ["定价"],
            "Section|Show a big video or image, or add many of them.": [
              "展示单一视频或图片，或多个视频图片组合。",
            ],
            "Section|Show boxes of steps, stats, tidbits and a numbered list of steps. Explain how your service works!":
              ["显示方框、数据或带编号的步骤图，以解释你的业务如何运作。"],
            "Section|Submit": ["提交"],
            "Section|Text": ["文本"],
            Select: ["选择"],
            "Select a Template": ["选择一个模板"],
            "Select a domain from your Namecheap account to publish this site to.":
              ["从你的Namecheap帐户中选择一个域名来发布此网站。"],
            "Select a template to get started!": ["请选择一个模板"],
            "Select all": ["全选"],
            "Select an existing address": ["选择一个现有地址"],
            "Select another site": ["选择其它网站"],
            "Selecting colors and fonts...": ["正在选择颜色和字体…"],
            "Sell a single product! Add product variations, payment gateways, shipping fees, pre-orders, and more. Strikingly never charges a transaction fee.":
              [
                "卖一件商品！你可添加商品种类，收款方式（包括支付宝），运费，预订等设置。上线了不征收任何交易佣金",
              ],
            "Sell products right on your site! Manage orders, payments, and more.":
              ["在你的网站上轻松销售商品、管理订单以及收款。"],
            "Sell up to %{num_products} products! Add product variations, payment gateways, shipping fees, pre-orders, and more. Strikingly never charges a transaction fee.":
              [
                "可以卖%{num_products}件商品！添加商品种类，收款方式，运费，预订等设置。上线了不征收任何交易佣金。",
              ],
            "Send A Newsletter": ["发送邮件"],
            "Send Invites": ["发送邀请"],
            "Send a message ...": ["发送消息"],
            "Send code": ["获取短信验证码"],
            "Send newsletter preview to this address: ": [
              "发送邮件预览到该地址：",
            ],
            "Send test desktop notification": ["发送桌面通知测试"],
            "Send to Gmail Contacts": ["发送到你的Gmail 联系人"],
            "Session timeout!": ["登录超时"],
            "Set a Favicon": ["设置网站图标"],
            "Set a category": ["设置类别"],
            "Set a flat tax rate to apply to all of your store's orders. If you need to set a sales tax, please consult a tax professional to comply with all applicable tax laws. [link:Learn more.]":
              [
                "设置一个适用于你商店的所有订单的统一税率。如果你需要设置销售税，请先向税务专业人士咨询相关税法。[link:了解更多]",
              ],
            "Set a meta description": ["设置网站描述"],
            "Set a social share image": ["设置分享图片"],
            "Set a title for your site": ["为你的网站设置一个标题"],
            "Setting a category helps users find your site.": [
              "设置一个类别，以便用户找到你的网站。",
            ],
            Settings: ["设置"],
            "Share on Facebook": ["在 Facebook 上分享"],
            "Share on Twitter": ["在 Twitter 上分享"],
            "Share on Wechat": ["分享至微信"],
            "Share on Weibo": ["分享至微博"],
            "Share your site": ["分享你的网站"],
            "Shipping|Edit": ["修改"],
            "Shipping|Grant [strong: free shipping] to orders of at least a certain amount (before tax)":
              ["[strong: 满包邮]（下单满一定金额后免运费，按折后金额计算）"],
            "Show Desktop Notifications Upon Receiving a Chat": [
              "收到新消息时发送桌面提醒",
            ],
            "Show Editor Panel": ["显示编辑面板"],
            "Show Order Data": ["显示数据概况"],
            "Show Strikingly logo on the page?": ["在网站中显示上线了图标"],
            "Sign Up": ["注册"],
            "Sign up with Facebook": ["使用脸书账号注册"],
            "Simple Store - %{num_products} products per site": [
              "简易商店 - 每个网站%{num_products}件商品",
            ],
            "Simple Store - 1 product per site": ["简易商店 - 每个网站1件商品"],
            "Site Audience": ["客户列表"],
            "Site Description": ["网站描述"],
            "Site Keywords": ["网站关键词"],
            "Site Membership": ["网站会员功能"],
            "Site Sections": ["网站部件"],
            "Site Title": ["网站标题"],
            "Site has over %{var1} pages": ["现已超过%{var1}页"],
            "Site saved!": ["网站已保存"],
            "SiteSearch|Search": ["搜索"],
            "SiteSearch|Search is disabled in editor. View your live site or preview your site to try search!":
              [
                "站内搜索功能无法在编辑器中使用，请在上线后的网站或是网站预览页面尝试搜索功能。",
              ],
            Sitemap: ["网站地图"],
            "Site|%{var1} spots left": ["剩余%{var1} 个"],
            "Site|Accept all": ["全部接受"],
            "Site|Analytics Cookies": ["分析性Cookies"],
            "Site|Booking Confirmed": ["预约已确认"],
            "Site|By entering this website, you agree that you are age 21 or above.":
              ["继续浏览网站即代表你已年满 21 岁或以上。"],
            "Site|Check out our latest offers and pick up some amazing deals.":
              ["快来看看我们近期的优惠活动，挑选你喜爱的商品吧。"],
            "Site|Cookie Settings": ["Cookie设置"],
            "Site|Decline All": ["全部拒绝"],
            "Site|Email for booking confirmation": ["接收确认信息的邮箱地址"],
            "Site|Email is required": ["邮箱地址必填"],
            "Site|Enter": ["进入"],
            "Site|Event": ["服务"],
            "Site|Exit": ["退出"],
            "Site|Feel free to contact us": ["欢迎联系我们"],
            "Site|File removed.": ["下载文件已移除"],
            "Site|File upload unavailable": ["上传文件不可用"],
            "Site|Get notified whenever we release new products or offers.": [
              "第一时间知晓我们的新品上市、优惠活动。",
            ],
            "Site|I got it. Thanks": ["了解了，谢谢"],
            "Site|Login is currently disabled.": ["暂时不可以登录"],
            "Site|Name is required": ["姓名必填"],
            "Site|Necessary Cookies": ["必要的Cookies"],
            "Site|No spot left": ["没有剩余"],
            "Site|Oops! This time slot have been scheduled. Please try another time.":
              ["哎呀！此时间段已经被预约了，请试试其他时间段。"],
            "Site|Please complete verification.": ["请完成验证。"],
            "Site|Please leave your mobile phone number here and we'll get in touch with you as soon as we can.":
              ["请留下你的联系方式，我们将第一时间联系你！"],
            "Site|Preferences Cookies": ["首选项Cookies"],
            "Site|Prevent minors from accessing this site": [
              "阻止未成年人浏览当前网站",
            ],
            "Site|Published": ["最近发布"],
            "Site|Registration Currently Disabled": ["暂时不可以注册"],
            "Site|Select date and time": ["选择日期与时间"],
            "Site|Settings": ["设置"],
            "Site|Sign up to receive updates!": ["注册获取新鲜资讯！"],
            "Site|Special Offers!": ["特惠活动！"],
            "Site|Thank you for your booking! The confirmation will be sent to your email address: [email]":
              ["感谢你的预约！确认邮件将发送到以下邮箱: [email]"],
            "Site|Thanks for your submission!": ["感谢注册！"],
            "Site|These cookies allow the website to remember choices you've made to provide enhanced functionality and personalization.":
              [
                "这些cookies允许网站记住你的选择，以提供更好的功能和个性化支持。",
              ],
            "Site|These cookies enable core functionality such as security, network management, and accessibility. These cookies can’t be switched off.":
              [
                "这些cookies支持诸如安全性、网络管理和可访问性等核心功能。这些cookies无法关闭。",
              ],
            "Site|These cookies help us better understand how visitors interact with our website and help us discover errors.":
              [
                "这些cookies帮助我们更好地了解访问者与我们网站的互动情况，并帮助我们发现错误。",
              ],
            "Site|Up to %{var1} MB": ["最大可上传 %{var1} MB"],
            "Site|Upload Failed": ["上传失败"],
            'Site|Upon exiting, the visitor will see a "content restricted" page.':
              ["退出后，访客将会看到一个 “内容受限” 的提示页面。"],
            "Site|View Bookings": ["查看预约"],
            "Site|We use cookies to ensure a smooth browsing experience. By accepting, you agree the use of cookies.":
              [
                "我们使用cookies来确保流畅的浏览体验。若接受，即表示你同意使用cookies。",
              ],
            "Site|You don’t have any bookings yet!": ["你还没有预约！"],
            "Site|You must be 21 or over to enter.": [
              "你必须年满 21 岁或以上才能继续浏览。",
            ],
            "Site|Your Name": ["您的姓名"],
            Slide: ["滑动"],
            Slider: ["滑块"],
            Slow: ["慢"],
            "Social Media": ["社交媒体"],
            "Social Platform": ["社交平台"],
            "Social Share Image": ["分享图片"],
            "Social feed manager": ["社交内容管理"],
            "SocialFeed|View more...": ["查看更多..."],
            "SocialMedia|Add New Link": ["添加新的链接"],
            "SocialMedia|Add social media buttons": ["添加社交媒体链接"],
            "SocialMedia|Add social media buttons.": ["添加社交媒体按钮"],
            "SocialMedia|Bilibili URL": ["哔哩哔哩网址"],
            "SocialMedia|Buttons": ["按钮"],
            "SocialMedia|Customize Tweet": ["改写默认Tweet"],
            "SocialMedia|Customize URL": ["改写默认URL"],
            "SocialMedia|Default Tweet": ["默认Tweet"],
            "SocialMedia|Delete image": ["删除图片"],
            "SocialMedia|Douyin QR code": ["抖音二维码"],
            "SocialMedia|Enter your email address": ["输入你的邮件地址"],
            "SocialMedia|Enter your phone number": ["输入你的电话号码"],
            "SocialMedia|Enter your social media profile links.": [
              "输入你的社交媒体个人信息链接。",
            ],
            "SocialMedia|Facebook URL": ["Facebook网址"],
            "SocialMedia|Get followers! Take visitors to your social media profiles.":
              ["让访客看看你的社交媒体信息！"],
            "SocialMedia|Get shares! Let visitors like & share this site.": [
              "让访客多多分享你的网站！",
            ],
            "SocialMedia|Google+ URL": ["Google+网址"],
            "SocialMedia|Icons": ["图标"],
            "SocialMedia|Instagram URL": ["Instagram网址"],
            "SocialMedia|LinkedIn URL": ["领英网址"],
            "SocialMedia|Links": ["链接"],
            "SocialMedia|Pinterest URL": ["Pinterest网址"],
            "SocialMedia|Please enter a valid %{type} URL.": [
              "请输入有效的 %{type} 网址",
            ],
            "SocialMedia|Share": ["分享"],
            "SocialMedia|Sharing": ["分享"],
            "SocialMedia|Social media links": ["社交媒体链接"],
            "SocialMedia|Sync across header & footer": ["同步页眉和页脚的按钮"],
            "SocialMedia|Tencent Video URL": ["腾讯视频网址"],
            "SocialMedia|The icon will automatically change to the logo of any supported social networks based on the URL.":
              ["图标将根据网址，自动适配系统自带的社交媒体商标。"],
            "SocialMedia|Tieba URL": ["百度贴吧网址"],
            "SocialMedia|Twitter URL": ["Twitter网址"],
            "SocialMedia|URL to +1": ["+1的URL"],
            "SocialMedia|URL to Like": ["点赞的网址"],
            "SocialMedia|URL to share": ["分享的网址"],
            "SocialMedia|Update image": ["上传图片"],
            "SocialMedia|View": ["查看"],
            "SocialMedia|WeChat QR code": ["微信公众号二维码"],
            "SocialMedia|YouTube URL": ["YouTube 链接"],
            "SocialMedia|Youku URL": ["优酷视频网址"],
            "SocialMedia|e.g. %{URL}": ["例：%{URL}"],
            "Sorry! [placeholderStrong: %{domain}] is unavailable for transfer.":
              ["抱歉！[placeholderStrong: %{domain}] 无法转入。"],
            "Sorry! [placeholderStrong: %{domain}] is unavailable for transfer. Invalid domain name. Please check the domain name and try again.":
              [
                "抱歉！ [placeholderStrong: %{domain}]无法转入。该域名无效，请检查后重新输入。",
              ],
            "Sorry, there are no related articles": [
              "抱歉，未能检索到相关帮助文章",
            ],
            Sources: ["来源"],
            Spam: ["垃圾信息"],
            "Start %{free_period_string} Free!": [
              "%{free_period_string} 免费试用期开始！",
            ],
            "Start Editing": ["开始编辑"],
            "Start Free Trial": ["立即免费试用"],
            'Start writing now, add different kinds of content, and make sure to click "Publish" once you\'re done.':
              ["你可以在这里尽情写作，添加不同内容，完成后记得点击“上线”"],
            "Start writing!": ["开始写作吧"],
            "State/Province": ["州/省"],
            Stats: ["数据"],
            Status: ["数据"],
            "Status updated!": ["状态已更新！"],
            "Storage|Include images and files total storage.": [
              "总存储空间包括图片、文件。",
            ],
            Store: ["商店"],
            Stretch: ["拉伸"],
            "Strikingly App Store": ["上线了应用商店"],
            "Strikingly Logo": ["上线了 logo"],
            "Strikingly Team": ["上线了 团队"],
            "Strikingly recovery codes": ["Strikingly 恢复码"],
            "Strikingly's branding appears at the bottom of the page and after form submission.":
              ["上线了图标显示于网站上以及表单提交后"],
            Styles: ["风格"],
            Submit: ["提交"],
            "Submit Label": ["提交标签"],
            Success: ["成功"],
            "Success Message": ["成功提示"],
            "Successfully purchased <strong class='last-extra-sites'>0</strong> extra %{type} site(s).":
              [
                "成功购买了<strong class='last-extra-sites'>0</strong>额外的%{type}网站。",
              ],
            "SupportWidget|ASK ANOTHER QUESTION": ["再问一个问题"],
            "SupportWidget|Angry": ["愤怒"],
            "SupportWidget|Are these helpful?": ["这些有帮助吗？"],
            "SupportWidget|Ask a question or let us know your feedback here.": [
              "请详细描述遇到的问题或对产品的反馈",
            ],
            "SupportWidget|Attach a screenshot or file": ["附加截图或文件"],
            "SupportWidget|Attached file should be bigger than 10KB and smaller than 3MB.":
              ["附件应大于10KB而小于3MB"],
            "SupportWidget|Awesome!": ["太棒了"],
            "SupportWidget|Before you cancel your plan, is there anything we can help with?":
              ["在您取消订阅套餐之前，有什么需要我们能帮上忙的吗？"],
            "SupportWidget|CHAT WITH US": ["与我们交谈"],
            "SupportWidget|Chat with Strikingly": ["与 Strikingly 联系"],
            "SupportWidget|Ecstatic!": ["非常兴奋"],
            "SupportWidget|Email not set": ["未绑定邮箱，无法收到回复"],
            "SupportWidget|Excited": ["兴奋"],
            "SupportWidget|Frustrated": ["失望"],
            "SupportWidget|Go to Help Center": ["前往知识库"],
            "SupportWidget|Go to Help Center & Idea Forum": ["前往客服中心"],
            "SupportWidget|Got questions? Need help with anything? Just talk to us!":
              ["有疑问？需要帮助吗？来聊聊吧！"],
            "SupportWidget|Happy": ["高兴"],
            "SupportWidget|How can we help?": ["有什么可以帮到你？"],
            "SupportWidget|How do you feel right now?": ["你现在的心情如何？"],
            "SupportWidget|Invalid email address": ["无效邮箱"],
            "SupportWidget|Is this helpful?": ["这有帮助吗？"],
            "SupportWidget|LEAVE A MESSAGE": ["留言"],
            "SupportWidget|Leave a message": ["发送留言"],
            "SupportWidget|Live chat available!": ["和我们在线沟通"],
            "SupportWidget|Loading...": ["正在加载…"],
            "SupportWidget|Message sent!": ["留言成功！"],
            "SupportWidget|NEXT": ["下一步"],
            "SupportWidget|Name field can’t be empty": ["名字字段不可为空"],
            "SupportWidget|Need any help with your new site? Happiness Officers available!":
              ["建站需要帮助吗？找我们在线客服聊聊吧！"],
            "SupportWidget|Need help picking the right plan? Ask us anything!":
              ["拿不定主意？跟我们聊聊，为你推荐合适的套餐！"],
            "SupportWidget|Not sure what you need? Chat with us to get the best template!":
              ["拿不定主意？跟我们聊聊，为你推荐合适的模板！"],
            "SupportWidget|Oops!": ["糟糕"],
            "SupportWidget|Our Happiness Officers are available only from Monday to Friday, 9:00AM to 9:00PM.":
              ["我们的客服在线时间为：每天上午 8:00 至 晚上 22:00。"],
            "SupportWidget|Our happiness team will get back to you at": [
              "我们将在 24 小时内回复至你的邮箱",
            ],
            "SupportWidget|Processing...": ["正在处理…"],
            "SupportWidget|Question field can't be empty": ["问题字段不可为空"],
            "SupportWidget|Related articles:": ["相关文章"],
            "SupportWidget|SEND MESSAGE": ["发送留言"],
            "SupportWidget|SKIP AND LEAVE A MESSAGE": ["直接发送留言"],
            "SupportWidget|START THE CHAT": ["开始交谈"],
            "SupportWidget|Something went wrong! Please try again later,": [
              "客服插件出了问题。请稍后再试，",
            ],
            "SupportWidget|Sorry for the inconvenience.": [
              "我们对此深表歉意！",
            ],
            "SupportWidget|THIS ANSWERS MY QUESTION": ["这回答了我的问题"],
            "SupportWidget|Thank you for upgrading! Need help connecting your custom domain? Just talk to us!":
              ["感谢升级！需要绑定自定义域名吗？请联系我们！"],
            "SupportWidget|View original article": ["查看原文"],
            "SupportWidget|Watch Video Guides": ["查看视频教程"],
            "SupportWidget|We can’t wait to talk to you! Before starting the chat, please fill in the short form below.":
              ["真期待和你交流！在我们开始之前，请提供以下信息。"],
            "SupportWidget|We need email to contact with you, please make sure you have set your email address, click":
              [
                "我们会通过回复邮件来解答你的问题，帮助你更好地使用上线了，点击",
              ],
            "SupportWidget|We'd love to check how we can help with anything.": [
              "我们很乐意帮助你。",
            ],
            "SupportWidget|Worried": ["担心"],
            "SupportWidget|Your email address (example@email.com)": [
              "你的邮箱地址 (example@email.com)",
            ],
            "SupportWidget|here": ["此处"],
            "SupportWidget|or email us at support@strikingly.com.": [
              "或发送邮件至 hi@sxl.cn。",
            ],
            "SupportWidget|to set your email.": ["来绑定你的邮箱"],
            "Sure?": ["确定？"],
            "Switch to desktop view": ["切换至桌面端编辑"],
            "Switch to mobile view": ["切换至手机端编辑"],
            "Take Control": ["继续编辑"],
            "Take Tour": ["新手指南"],
            "Take me back!": ["返回"],
            "Take the tour!": ["好的，开始吧"],
            "Team|(Recommended size: 400*400, smaller than 2MB. Supported format: .jpg, .png)":
              ["(推荐尺寸400*400，大小2M内，支持 jpg, png)"],
            "Team|ATTENTION: After the role change %{salesName} will no longer be able to follow up on the customers. To ensure your customers' experience, you must designate another teammate to take over %{salesName}'s accounts. %{salesName}'s SuperCard info will be replaced with this designated teammate's.":
              [
                "注意：操作完成后%{salesName}将无法继续跟进现在客户！为保证客户的体验，在切换角色前你必须设置另一位团队成员负责接管%{salesName}的客户。%{salesName}的名片信息将被替换为该成员。",
              ],
            "Team|Active": ["使用中"],
            "Team|Add teammate": ["添加团队成员"],
            "Team|Admin": ["管理员"],
            "Team|Administrator": ["管理员"],
            "Team|Agent": ["客服"],
            "Team|Are you sure you want to disable access for this teammate? You can re-enable access later.":
              [
                "你确定想要撤销该团队成员的操作权限吗？撤销后随时可以再次启用。",
              ],
            "Team|Are you sure you want to remove this teammate? They will no longer have access to this site.":
              [
                "你确定想要删除该团队成员吗？移除后，他们将无法再继续登录当前网站。",
              ],
            "Team|Blogger": ["博客作者"],
            "Team|Can edit Mini Program content, styles": [
              "可编辑小程序内容、风格设计",
            ],
            "Team|Can edit everything in this Mini Program": [
              "可编辑当前小程序的所有内容",
            ],
            "Team|Can edit everything in this site": [
              "可以编辑当前网站的所有内容",
            ],
            "Team|Can edit products and process orders": [
              "可编辑商品、处理订单",
            ],
            "Team|Can edit sections, styles, and blog": [
              "可以编辑当前网站的内容板块，风格，博客",
            ],
            "Team|Can manage Audience and Live Chat": [
              "可以管理粉丝运营与在线聊天",
            ],
            "Team|Can manage audience, reply message, write follow-up reports":
              ["可管理粉丝、在线聊天、写日志"],
            "Team|Can publish Mini Program": ["可以发布小程序"],
            "Team|Can publish blog posts": ["可以发布文章"],
            "Team|Can publish new products": ["可以发布新建商店商品"],
            "Team|Can publish site": ["可以发布网站"],
            "Team|Can receive real-time activity reports via WeChat push notifications":
              ["可在微信里接收客户动态、数据报表等重要信息"],
            "Team|Can view, manage audience": ["可查看、管理粉丝的范围"],
            "Team|Can write blog posts, edit blog settings": [
              "可以编辑文章、修改文章设置",
            ],
            "Team|Cancel": ["取消"],
            "Team|Click to connect account": ["点击绑定"],
            "Team|Collaborate with your team!": ["与你的团队共同协作！"],
            "Team|Copied!": ["链接已复制！"],
            "Team|Copy": ["复制链接"],
            "Team|Customer takeover": ["客户接管"],
            "Team|Delete": ["删除"],
            "Team|Delete teammate": ["删除团队成员"],
            "Team|Director belongs to all groups": ["总监归属于所有组"],
            "Team|Disable": ["停用"],
            "Team|Disable teammate": ["停用团队成员账号"],
            "Team|Disabled": ["已停用"],
            "Team|Disconnect": ["解绑"],
            "Team|Edit teammate": ["编辑团队成员"],
            "Team|Editor": ["编辑者"],
            "Team|Email": ["邮箱"],
            "Team|Enable": ["启用"],
            "Team|Enable Super Assistant notification": ["绑定超级云助理推送"],
            "Team|Everyone (suitable for Director-level)": [
              "所有成员（适合总监级别管理者）",
            ],
            "Team|Failed to delete, Please try again.": ["删除失败，请重试"],
            "Team|First Name": ["名字"],
            "Team|Generate WMP code and WeChat Official Account path": [
              "获取小程序码，公众号路径地址",
            ],
            "Team|Got it": ["我知道了"],
            "Team|Group": ["所属团队"],
            "Team|If unchecked, this teammate can only save Mini Program as draft":
              ["若取消勾选，该团队成员编辑小程序后只能保存为草稿状态"],
            "Team|If unchecked, this teammate can only save blog posts as draft":
              ["若取消勾选，此成员只能编辑文章后存为草稿状态"],
            "Team|If unchecked, this teammate can only save new products as draft":
              ["若取消勾选，该团队成员创建商品后只能将其保存为草稿"],
            "Team|If unchecked, this teammate can only save site as draft": [
              "若取消勾选，此成员只能编辑网站后存为草稿状态",
            ],
            "Team|Introducing new team feature, now you can invite more teammate's roles to join collaboration, see what's new here!":
              [
                "团队功能现已焕然一新，可邀请更多成员共同协作，快速了解下有哪些新变化吧！",
              ],
            "Team|Invitation sent to teammate's phone number. Please remind them to join!":
              ["加入邀请已发送至团队成员的手机号，请提醒他及时完成验证。"],
            "Team|Learn more.": ["了解更多"],
            "Team|Mini Program Management Tool": ["小程序端后台"],
            "Team|Name": ["姓名"],
            "Team|Non-sales teammates do not count against your SuperCard seats.":
              ["非销售团队成员不占用云名片套餐团队人数"],
            "Team|Note: The editor can only be used by one person at a time.": [
              "请注意: 同一时刻只能一位团队成员登录编辑器。",
            ],
            "Team|OK": ["确定"],
            "Team|Operation failed, Please try again.": ["操作失败，请重试"],
            "Team|Owned only (For normal sales)": [
              "仅限自己（适合一线销售员）",
            ],
            "Team|Pending": ["待验证"],
            "Team|Phone Number": ["手机号"],
            "Team|Please designate a teammate to take over the customers": [
              "请选择负责接管的成员",
            ],
            "Team|Please enter a correct email": ["请输入一个正确的邮箱"],
            "Team|Please enter an email.": ["请输入一个邮箱地址。"],
            "Team|Please send this invitation QR code to your teammates to let them log into the Mini Program Management Tool, where they can manage audience, reply to messages, write follow-up reports, and more!":
              [
                "请将该验证二维码发送给团队成员，登录后即可使用小程序端管理后台管理粉丝、在线聊天、写日志等！",
              ],
            "Team|Please verify the teammate first before promoting.": [
              "请先验证成员，完成后即可进行推广。",
            ],
            "Team|Profile Picture": ["头像"],
            "Team|Reinvite": ["重新邀请"],
            "Team|Role": ["角色"],
            "Team|Sales": ["销售"],
            "Team|Sales (Director)": ["销售（总监）"],
            "Team|Sales (Manager)": ["销售（主管）"],
            "Team|Sales team only (For Sales Supervisor)": [
              "同组成员（适合主管级别管理者）",
            ],
            "Team|Salespeople can manage audience, reply to messages, and write follow-up reports":
              ["销售可在小程序端管理粉丝、回复聊天、写跟进等"],
            "Team|Save QR code": ["保存二维码"],
            "Team|Search teammates…": ["搜索团队成员"],
            "Team|Select a Role": ["选择角色"],
            "Team|Select a group": ["选择分组"],
            "Team|Send invitation": ["发送邀请"],
            "Team|Shared with %{teammateNumber} teammate(s)": [
              "已与 %{teammateNumber} 个团队成员共同协作",
            ],
            "Team|Site Owner": ["网站所有者"],
            "Team|Status": ["状态"],
            "Team|Store Manager": ["商店管理员"],
            "Team|Switch to the new editor to add & manage collaborators and teammates!":
              [
                "切换到新版编辑器后可使用“我的团队”功能来添加、管理协作者与团队成员！",
              ],
            "Team|Team": ["我的团队"],
            "Team|Teammate invitation failed to send, Please try again.": [
              "团队邀请发送失败，请重试.",
            ],
            "Team|Teammate invitation sent to %{teammateEmail}!": [
              "团队邀请已发送至 %{teammateEmail} ！",
            ],
            "Team|This email address will set as teammate's login account": [
              "该邮箱地址将作为该成员的登录账号。",
            ],
            "Team|This is a Pro feature! Please ask the site owner to upgrade to Pro to unlock this feature.":
              [
                "这是一个专业版功能！请联系网站所有者将网站升级到专业版或以上来解锁本功能。",
              ],
            "Team|This phone number will be set as this teammate's login account":
              ["手机号将作为该团队成员的登录账号。"],
            "Team|Title": ["职称"],
            "Team|Upload image": ["上传图片"],
            "Team|View QR code": ["查看二维码"],
            "Team|WeChat connected": ["已绑定微信"],
            "Team|You aren’t able to switch to the old editor because you have invited Teammates, and the old editor does not support Teammates.":
              [
                "因为你已经在团队模块中添加了团队成员，因此无法切换回旧编辑器了（旧编辑器不支持团队功能）。",
              ],
            "Team|You can also send this invitation link. This link is valid for 72 hours.":
              ["你也可以复制链接发送给他，链接有效期为 72 个小时。"],
            "Team|You don’t have any teammates yet. Invite friends and colleagues to co-edit and manage this site together. Everyone can see edits in real-time!":
              [
                "你还没有团队成员。邀请你的朋友和同事们共同编辑和管理这个网站，每个人都可以实时看到编辑内容！",
              ],
            "Team|You don’t have any teammates yet. Invite friends and colleagues to help edit and manage this Mini Program!":
              [
                "你还没有团队成员。邀请你的朋友和同事们一起协作编辑管理这个小程序吧！",
              ],
            "Team|You don’t have any teammates yet. Invite friends and colleagues to help edit and manage this site!":
              [
                "你还没有团队成员。邀请你的朋友和同事们一起协作编辑管理这个网站吧！",
              ],
            "Team|You will stop receiving real-time activity reports via WeChat push notifications if you disconnect this account. Are you sure you want to disconnect?":
              [
                "解绑后将无法实时在微信内接收客户行为、数据报表等。你确定要解绑吗？",
              ],
            "Team|You've already invited this person before!": [
              "你之前已邀请过该成员！",
            ],
            "Team|Your role: %{roleName}": ["你的身份: %{roleName}"],
            "Team|Your teammate": ["你的团队成员"],
            "Templates|%{var1} Templates": ["%{var1}模版"],
            "Templates|All templates support e-commerce, blog, memberships, forms, live chat, and more. Switch anytime.":
              [
                "所有的模版都支持电商、博客、会员系统、表单、在线聊天等各种高级功能，而且你可以随时更改模版。",
              ],
            "Templates|Can’t find what you need? Send us your suggestions!": [
              "找不到你想要的分类？请告诉我们你的建议！",
            ],
            "Templates|Let's find the best starting point for you. You can always add to your site later.":
              [
                "我们来帮你选择一个最好基础来建站。你可以在模版的基础上添加各种功能。",
              ],
            "Templates|More": ["更多"],
            "Templates|More…": ["显示更多..."],
            "Templates|One page only": ["只看单页面模版"],
            "Templates|Other %{var1} templates you might like...": [
              "你可能还喜欢的其他%{var1}模版……",
            ],
            "Templates|Pick a template to start!": ["选个模版，立刻开始！"],
            "Templates|Popular:": ["人气模版："],
            "Templates|Reset filter and view all templates": [
              "重置筛选并浏览全部模版",
            ],
            "Templates|Show less…": ["显示更少..."],
            "Templates|Skip & view all templates": ["跳过，浏览全部模版"],
            "Templates|Start with a single-page template. You can always add more pages anytime.":
              ["从单页模版开始。你可以随时增添更多页面。"],
            "Templates|Tell us more details about your suggestions. e.g. Links to sites or styles you want, or styles you like.":
              [
                "请提供更多细节和建议给我们以方便我们为您创建合适的网站模板, 例如您喜欢的网站风格，或者您喜欢的网站链接等。",
              ],
            "Templates|Topic": ["细分类目"],
            "Templates|Uh-oh! There’s been an error loading templates. [span: Try loading again.]":
              ["啊哦！加载模版出错了。[span: 请再试一次。]"],
            "Templates|What category of site are you looking for?": [
              "您在寻找什么类型/行业的网站模板？",
            ],
            "Templates|What kind of site do you need?": [
              "你想做一个什么样的网站？",
            ],
            "Template|Start from scratch": ["从零开始<br/>挥洒你的网站创意"],
            "Template|Thumbnail Gallery": ["缩略图库"],
            Text: ["文本"],
            "The favicon is the tiny icon that represents your site in the browser's tab.":
              [
                "这个网站图标是一个小图标，它会显示在在浏览器的标签中，代表你的网站。",
              ],
            "The footer contains some social media buttons and a textbox for some fine print. A nice way to end your page.":
              [
                "包含一些社交媒体按钮和用于显示网站相关信息（如备案号）的文本框",
              ],
            "The icon for your site in the browser’s tab. Upload PNG files only, optimal size is 16x16.":
              ["浏览器标签上的页面图标。仅接受 PNG 文件，最佳尺寸为 16x16。"],
            "The icon used when your page is shared on social media. Size must be at least 200x200.":
              [
                "网站分享到社交媒体（微信、微博等）所显示的图标。不小于 200x200。",
              ],
            "The meta description appears in search engine results.": [
              "这个网站描述会出现在搜索引擎的搜索结果中。",
            ],
            "The navigation menu is a fixed menu that lets viewers immediately jump to a section.":
              ["访客在电脑和平板上可以跳转至不同版块"],
            "The page has an invalid domain.": ["域名无效"],
            "The recovery codes are now copied.": ["已复制恢复码。"],
            "There has been an error. Our engineers are looking into it now. Please retry!":
              ["糟糕，出现了一些问题。我们的工程师正在检修，请重试。"],
            'There seems to be multiple editors open in different tabs or devices. Make sure other editors are closed, then click "Take Control" to activate this editor!':
              [
                "检测到该网站在不同设备上的编辑器同时打开。请先确保关闭其他设备上的编辑器，然后点击下面的按钮重新激活当前编辑器。",
              ],
            "This blog is being edited!": ["其他用户正在编辑博客"],
            "This blog is currently being edited": ["其他用户正在编辑博客。"],
            "This field is required.": ["此项为必填项"],
            "This form lets you change the card used to bill recurring subscriptions.":
              ["你可以通过此表单更改用于收取循环订购费用的卡号。"],
            "This page is empty.": ["本页面没有内容。"],
            'This page will automatically update when you have finished successfully. To cancel, click "Cancel and return to Strikingly" in the PayPal tab or popup window.':
              [
                "成功后此网站会自动更新。若想取消，点击 PayPal 网站或弹窗上的“取消并返回上线了”按钮。",
              ],
            "This published site uses Limited features and counts towards your Limited sites publish limit!":
              ["此网站使用的基础版功能将算入账户的基础版网站发布上限"],
            "This published site uses Pro feature and counts towards your Pro sites publish limit!":
              [
                "该网站发布时使用了一些专业版的功能，将会计入账户的专业版网站发布数量上限。",
              ],
            "This site is being edited!": ["注意：其他用户正在编辑网站"],
            "This site is empty.": ["本网站没有内容。"],
            "This site is hidden from search engines.": [
              "网站开启屏蔽搜索引擎",
            ],
            "This site is password-protected.": ["网站已开启密码保护"],
            "This site's images": ["本网站中的图片"],
            "This user is not a member yet. Are you sure you wish to manually grant membership to this user on your membership-enabled site? A login URL and new password will be emailed to this user.":
              [
                "该用户尚无会员资格。 你确定要手动授予其会员资格吗？ 授予会员资格后，登录链接和新密码将会通过电子邮件发送给该用户。",
              ],
            "This website is built with Strikingly.": [
              "此网站通过 Strikingly 创建.",
            ],
            Tile: ["平铺"],
            "Time|1 Hour": ["1小时"],
            "Time|15 Minutes": ["15分钟"],
            "Time|30 Minutes": ["30分钟"],
            "Time|All times displayed in %{var1}": ["时区为%{var1}"],
            "Time|DD/MM/YYYY": ["DD/MM/YYYY"],
            "Time|Date": ["日期"],
            "Time|Date Format": ["日期格式"],
            "Time|Earliest Available Time": ["最早可选时间"],
            "Time|Latest Available Time": ["最晚可选时间"],
            "Time|MM/DD/YYYY": ["MM/DD/YYYY"],
            "Time|Select a date": ["选择一个日期"],
            "Time|Select a time": ["选择一个时间"],
            "Time|This time zone will be displayed to visitors.": [
              "访客将看到时区提示信息。",
            ],
            "Time|Time": ["时间"],
            "Time|Time Interval": ["时间间隔"],
            "Time|User will select one of  %{var1}": [
              "访客看到的选项为%{var1}",
            ],
            "Time|YYYY/MM/DD": ["YYYY/MM/DD"],
            "Time|Your time zone:": ["你的时区："],
            Title: ["标题"],
            'To ensure fast speed and reliable access for visitors in mainland China, <a target="_blank" href="%{url}">click here to learn about SXL.cn.</a>':
              [
                '为了确保中国大陆地区的访客能够快速、稳定地访问你的网站，<a target="_blank" href="%{url}">请点击这里了解SXL.cn。</a>',
              ],
            "Transfer Domain": ["转入域名"],
            "Transfer Domain to Strikingly": ["将域名转移到Strikingly"],
            Transferring: ["正在转移。"],
            Transition: ["切换效果"],
            Translating: ["翻译进行中"],
            "Try different styles or change your template.": [
              "更换网站样式或模板",
            ],
            Tweets: ["推文"],
            Type: ["类别"],
            "Type the text": ["输入图片验证码"],
            UNPUBLISH: ["下线"],
            "UPLOAD NEW FILE": ["上传新文件"],
            "UPLOAD NEW IMAGE": ["上传新图片"],
            "UPLOADED FILES": ["已上传文件"],
            "UPLOADED IMAGES": ["已上传的图片"],
            URL: ["URL 地址"],
            "URL to redirect to after a visitor submits the form.": [
              "访问者提交表单后重定向到的URL。",
            ],
            "Uh oh! This error wasn't supposed to happen. Our engineers are working on it":
              ["出了一个奇怪的问题。不用担心 - 我们的工程师已经在进行修复了。"],
            "Uh oh. Your site is blocked or Your account is blocked. Please contact customer service":
              ["糟糕，你的网站或账户处于被封锁状态。请联系在线客服处理。"],
            "Uh-oh! Something went wrong...": ["哎呀！好像出了点小问题……"],
            Underline: ["加下划线"],
            Undo: ["撤消"],
            Unknown: ["未知"],
            Unpublish: ["下线"],
            "Unpublish a site below or remove excess products": [
              "以下一个网站下线或删除多余的商品",
            ],
            "Unpublish this site": ["下线本网站"],
            Unpublished: ["未上线"],
            Unverified: ["未验证"],
            "Up to %{var1} pages per site": ["单个网站页面数高达%{var1}页"],
            Update: ["更新"],
            "Update your site to the latest version of the editor.": [
              "更新网站到最新版本的编辑器。",
            ],
            Updated: ["更新于"],
            Upgrade: ["升级"],
            "Upgrade Plan": ["升级套餐"],
            "Upgrade for more.": ["升级套餐获取更多功能   "],
            "Upgrade to %{membership} %{period}": [
              "升级至 %{membership} %{period}",
            ],
            "Upgrade to Pro": ["升级到企业版"],
            "Upgrade to Pro & Unlock Pages": ["升级到专业版来解锁更多页面"],
            "Upgrade to Pro to add up to %{var1} pages per site.": [
              "升级到专业版，单个网站可添加%{var1}个页面。",
            ],
            "Upgrade to Pro to add up to %{var1} pages.": [
              "升级到专业版可添加页面数增加到%{var1}个。",
            ],
            "Upgrade to VIP to unlock": ["升级至企业版套餐解锁"],
            "Upgrade to send more": ["升级套餐以发送更多"],
            "Upgrade your account to Pro to access this feature!": [
              "企业版用户可使用这个功能",
            ],
            "Upgrade your account to Pro to remove it!": [
              "升级账户至专业或企业版可移除商标",
            ],
            Upload: ["上传"],
            "Upload CSV File": ["上传 CSV 文件"],
            "Upload Image": ["上传图片"],
            "Upload a doc for viewers to download.": ["上传文档供访客下载。"],
            "Upload an image": ["请上传图片"],
            "Upload failed due to network issue. Please try again.": [
              "上传失败，请重新尝试。",
            ],
            "Upload failed. Only gif, jpg, jpeg, png, bmp, ico files are allowed. Please check your image type and retry.":
              [
                "上传失败。 仅支持上传 gif，jpg，jpeg，png，bmp，ico 格式的图片。请检查后重试。",
              ],
            "Upload failed. Only gif,jpg,jpeg,png,bmp,ico files are allowed. Please check your image type and retry.":
              [
                "上传失败。支持的图片文件类型为 gif,jpg,jpeg,png,bmp,ico 。请选择合适的文件类型并重新上传",
              ],
            "Upload new image": ["上传新图片"],
            "Uploading...": ["正在上传..."],
            "Use Mailchimp to collect emails and send newsletters to your blog visitors.":
              [
                "用 MailChimp 收集订阅用户的邮箱地址，并向订阅用户定期推送最新博客。点击这里了解更多。",
              ],
            "Use theme color": ["使用网站的配色方案"],
            "Use these recovery codes to log in if you lose access to your phone. Each code can only be used once. Save these and keep them somewhere safe.":
              [
                "手机不可用时，可使用恢复码进行验证登录。每个代码只能使用一次。请妥善保存。",
              ],
            "Used in the title bar and search results. Should be no longer than 70 characters!":
              ["在标题栏和搜索结果中使用，不超过70个字符。"],
            "User agrees to the Terms and Privacy Policy": [
              "用户同意使用条款和隐私政策",
            ],
            "User does not agree to be contacted using the provided information":
              ["用户不同意以提供的信息被联系"],
            "UserProfile|Profile picture": ["头像"],
            "User|Connect email": ["绑定邮箱"],
            "User|Name": ["姓名"],
            "User|Name is required": ["名字不能为空"],
            "User|Please enter your email to receive product updates as soon as possible.":
              ["请输入你的邮箱地址，第一时间接收产品更新动态。"],
            "User|Please enter your email to receive the latest product updates.":
              ["请输入你的邮箱地址以接收最新产品动态。"],
            "User|Thank you for your comment! We will keep improving our product.":
              ["感谢你的评价！我们会继续提升我们的产品质量和服务。"],
            VIDEO: ["视频"],
            VIP: ["VIP套餐"],
            Value: ["值"],
            "Variation|Amethyst": ["青莲"],
            "Variation|Berry": ["樱桃红"],
            "Variation|Black": ["黑色"],
            "Variation|Blue": ["天蓝"],
            "Variation|Bright": ["杏黄"],
            "Variation|Coffee": ["驼色"],
            "Variation|Dark": ["深色"],
            "Variation|Dark + Blue": ["深色+蓝"],
            "Variation|Dark + Purple": ["深色+紫"],
            "Variation|Dark + Rose": ["深色+红"],
            "Variation|Dark Transparent": ["深色透明"],
            "Variation|Earth": ["棕褐色"],
            "Variation|Emerald": ["翠绿"],
            "Variation|Fresh": ["墨色"],
            "Variation|Green": ["草绿"],
            "Variation|Ice": ["艾绿"],
            "Variation|Ink": ["水墨"],
            "Variation|Light": ["明亮"],
            "Variation|Light Transparent": ["明亮透明"],
            "Variation|Meadow": ["苔色"],
            "Variation|Navy": ["海军蓝"],
            "Variation|Olive": ["橄榄"],
            "Variation|Orange": ["蜜柑"],
            "Variation|Pink": ["玫红"],
            "Variation|Purple": ["浅紫"],
            "Variation|Red": ["红色"],
            "Variation|Ruby": ["朱红"],
            "Variation|Rustic": ["象牙白"],
            "Variation|Sapphire": ["湖蓝"],
            "Variation|Sky": ["天蓝"],
            "Variation|Teal": ["水色"],
            "Variation|Turquoise": ["石青"],
            "Variation|Violet": ["紫罗兰"],
            "Variation|White + Blue": ["明亮+蓝"],
            "Variation|Yellow": ["柠黄"],
            "Verification Code": ["验证码"],
            Verify: ["验证"],
            "Verify Google Search Console": ["验证 Google Search Console"],
            "Verify Logins By Phone (SMS)": ["使用手机短信验证登录"],
            "Video Library": ["视频库"],
            "Video|Embed Video": ["嵌入视频"],
            "Video|Enter Youtube/Vimeo URL": ["输入视频网址（腾讯、优酷）"],
            "Video|Enter video URL (YouTube, Vimeo, etc)": [
              "输入视频网址（腾讯、优酷、爱奇艺、哔哩哔哩）",
            ],
            "Video|Learn more.": ["了解更多"],
            "Video|More": ["更多"],
            "Video|Note: Video backgrounds won't play on phones or tablets. A thumbnail will be shown instead.":
              [
                "注意：视频背景将无法在手机或平板设备上播放。用户将只能看到该视频的缩略图。",
              ],
            "Video|Remove": ["移除"],
            "Video|Upload": ["上传"],
            "Video|Use Youtube/Vimeo Video": ["输入视频网址（腾讯、优酷）"],
            "Video|Video URL is invalid.": ["视频网址无效。"],
            "Video|Video format is not supported. Please use Youtube/Vimeo full URL only.":
              ["我们只支持YouTube, Vimeo的视频网站。"],
            "Video|We support video embeds from YouTube, Vimeo, and more!": [
              "支持腾讯、优酷、爱奇艺、哔哩哔哩",
            ],
            "View All Responses": ["查看所有回复"],
            "View Example": ["查看示例"],
            "View Post": ["查看文章"],
            "View Stats": ["查看数据"],
            "View [strong: %{count} current members] on this site": [
              "查看该网站现有的[strong: %{count}位会员]",
            ],
            "View codes": ["查看恢复码"],
            "View format sample.": ["查看格式示例"],
            "View live site": ["查看上线后的网站"],
            "View site audience and send newsletters!": [
              "查看客户列表和发送营销邮件！",
            ],
            Views: ["访问量"],
            "Visitors can click on buttons to move to the next/previous section.":
              ["访客可以点击按钮跳转至网站的下/上一个版块"],
            "Visitors must agree to this before form submission.": [
              "访客必须在提交表格前同意这一点。",
            ],
            "WRITE NEW POST": ["撰写新博文"],
            "Want to get started quickly? Convert your LinkedIn profile into a beautiful personal website in just one click!":
              [
                "想要快速上手？一键点击即可将你的 LinkedIn 个人资料转化为美观的个人网站！",
              ],
            "We strongly recommend that you turn this on. You’ll receive desktop notifications as long as your browser is open (even if it’s not on Strikingly.com). Click the notification to open a chat window and reply instantly.":
              [
                "我们强烈建议你开启这个功能。只要你的浏览器开启，你就会收到桌面通知（即便你没有在浏览Strikingly.com）。点击通知来开启聊天窗口并立即回复信息。",
              ],
            "We strongly recommend uploading a headshot to increase engagement.":
              ["我们强烈建议你上传头像，可提升与访客的互动效果。"],
            "We're sorry, but you've sent too many requests. Please try again later.":
              ["获取过于频繁，喝杯咖啡再来吧"],
            "We've just added some updates to our editor. Click the button below to get the latest changes!":
              ["我们对编辑器进行了一些更新。点击下方按钮获取最新更改"],
            Web: ["域名"],
            "Welcome to the Strikingly Blog Editor": [
              "欢迎使用上线了博客编辑器",
            ],
            "We’ll bill this purchase from your Paypal account.": [
              "我们将从您的Paypal帐户中为此次购买扣款。",
            ],
            "White + Purple": ["明亮+紫"],
            "White + Rose": ["明亮+红"],
            "Writing unique content...": ["正在撰写独特内容…"],
            "Wrong code. Please try again.": ["验证码错误，请重新输入。"],
            "Wrong password. Please try again.": ["密码错误，请重新输入。"],
            "Wrong text, please try again.": ["图形验证码不正确"],
            Year: ["年"],
            Yearly: ["包年"],
            Years: ["年"],
            "You can [link] to continue.": ["请将[link]以继续。"],
            "You can change your plan any time by contacting us at support@strikingly.com.":
              [
                "你可以随时更改套餐，有任何问题都可以发送电子邮件至 hi@sxl.cn 联系我们。",
              ],
            "You can connect your own domain to your Strikingly site. See the FAQ below for more details.":
              ["你可以将已有域名连接到你的上线了网站。"],
            "You can embed any HTML/CSS/JavaScript code directly into your site.":
              ["你可以在网站中直接嵌入任何 HTML/CSS/JavaScript 代码。"],
            "You can import more and select from this list!": [
              "你可以上传更多图片，然后从列表中选择",
            ],
            "You can publish as many sites as you want with free features.": [
              "你能让任意个带免费版功能的网站上线。",
            ],
            "You can publish up to 2 sites with Limited features.": [
              "你能有2个带有基础版功能的网站上线。",
            ],
            "You can publish up to 3 sites with Pro features.": [
              "你能有3个带有专业版功能的网站上线。",
            ],
            "You can publish up to 5 sites with Pro features.": [
              "你最多可以发布5个带有专业版功能的网站。",
            ],
            "You can remove SMS authentication and log in with your password alone. Verify your password to continue removing SMS authentication.":
              [
                "关闭短信验证后，将只使用密码登录。如确定要关闭，请输入密码继续。",
              ],
            'You can remove the Strikingly logo from the bottom of your site, and remove "on Strikingly" from the site title.':
              [
                "你可以去除站点底部的上线了商标，并去除网站标题中的“上线了”字样。",
              ],
            "You can upload images and files to your site.": [
              "你可以上传图片和文件至网站。",
            ],
            "You can use recovery codes to log in if you lose access to your mobile device or security key. Each code can only be used once.":
              [
                "手机不可用时，可使用恢复码进行验证登录。每个代码只能使用一次。",
              ],
            "You cannot downgrade your plan at this time. Please contact us at support@strikingly.com to continue.":
              ["你目前不能降级套餐。请联系 support@strikingly.com。"],
            'You have exceeded the file limit (%{limit}), <a href="%{upgradeUrl}" target="_blank">upgrade</a> to get more space.':
              [
                '存储空间已达到上限（%{limit}），<a href="%{upgradeUrl}" target="_blank">立即升级</a>获取更多空间',
              ],
            'You have exceeded the storage limit (%{limit}). <a href="%{upgradeUrl}" target="_blank">Upgrade to get more space</a>':
              [
                '网站容量已达最大值（%{limit}）。<a href="%{upgradeUrl}" target="_blank">升级套餐获得更多存储空间</a>',
              ],
            "You have exceeded your limit for memberships! Please [strong: upgrade your Audience Plan] to allow more registrations.":
              [
                "网站会员名额超过上限啦！ 请[strong：升级营销套餐]以增加会员名额。",
              ],
            "You have exceeded your limit for memberships! Please upgrade your Audience Plan to allow more registrations.":
              ["网站会员名额已超过上限啦！ 请升级营销套餐以增加会员名额。"],
            "You have no audience yet! Build an audience to start sending newsletters. Build an audience from your website's forms, or from manual import.":
              [
                "你还没有客户！创建一个客户后开始发送邮件。从网站的表单中创建一个客户或手动导入。",
              ],
            "You have unpublished changes. Click to go live!": [
              "网站有未发布的更改，点击上线吧",
            ],
            "You haven't uploaded any images yet.": ["你还未上传任何图片"],
            "You must disable Privacy Protection on this domain": [
              "您必须禁用此域名的隐私保护。",
            ],
            "You need a domain before you can add email accounts.          [linkRegister: Register a new domain name] or           [linkTransfer: transfer an existing domain to Strikingly].":
              [
                "需要一个域名才能添加邮箱账号。[linkRegister: 注册一个新域名] 或 [linkTransfer: 转移一个已有的域名到 Strikingly]。",
              ],
            "You will be billed $%{price} for this domain transfer and the domain ownership will be extended by %{duration}.":
              [
                "转移此域名将向您收取 $%{price} 的费用，域名所有权将按 %{duration} 延长。",
              ],
            "You will need access to this email to confirm the transfer!": [
              "您需要打开此电子邮件以确认转移！",
            ],
            "You'll need to create an Optimizely account at [link: optimizely.com]. Next, follow the instructions on their website to set up your project and experiment, and enter your project ID and experiment ID below. Then you're ready to test. Note: You must set Activation Mode to 'Manual' within your Optimizely experiment settings.":
              [
                "你需要在[link: optimizely.com]上创建一个优化帐户。接下来，按照网站上的说明设置项目和实验，并在下面输入你的项目ID和实验ID。然后你准备好测试。注意：你必须在优化实验设置中将激活模式设置为“手动”。",
              ],
            "You'll receive an email at this address when a visitor submits a message.":
              ["当访客提交留言后，你的这个邮箱会收到提醒邮件。"],
            "You're using Limited features [link] but you've hit your publish limit for Limited sites or products quantity limit.":
              [
                "你正在使用基础版的功能[link]，但是你已经用完基础版的网站数量限额或产品数量限额。",
              ],
            "You're using Pro features [link] but you've hit your publish limit for Pro sites or products quantity limit.":
              [
                "你正在使用专业版的功能[link]，但是你已经用完专业版的网站数量限额或产品数量限额。",
              ],
            "You've published %{var1} site(s).": [
              "你已经发布了%{var1}个网站。",
            ],
            "You've reached the limit of %{var1} pages per site!": [
              "你已到达页面数 %{var1} 上限！",
            ],
            "You've reached the page limit for this site. To add more pages to this site, please unpublish another %{var1} site, or buy extra %{var1} sites.":
              [
                "你已达到此网站的页面数量上限。如果要在这个网站添加更多页面，请取消发布另一个%{var1}网站，或购买更多%{var1}网站。",
              ],
            "Your account allows for up to %{quota} members. [link: Upgrade your Audience Plan] to increase this limit.":
              [
                "你的账户最多可以注册 %{quota} 个会员。[link: 升级营销套餐]可以增加会员上限。",
              ],
            "Your card was declined. Please use a different card or contact your bank.":
              ["这张信用卡交易失败了。请使用另一张信用卡或联系银行。"],
            "Your changes are saved but not published.": [
              "网页的编辑已被保存，但还未上线。",
            ],
            "Your custom code is currently active in your site.": [
              "你的自定义代码已生效。",
            ],
            "Your custom code is under review and will take effect when approved. Remember, you can add a custom domain to skip this step.":
              [
                "你的自定义代码正在审核中，通过后会立即生效。别忘记你可以通过绑定自定义域名来跳过此步骤。",
              ],
            "Your feedback and requests are prioritized in our queue. Get a response in minutes from our Happiness Officers!":
              [
                "你的反馈和请求会在我们的客服队列中优先处理。在几分钟内就能得到我们世界级客服团队的回复!",
              ],
            "Your latest change didn't get saved!": ["你的最新更改尚未保存"],
            'Your link "%{linkName}" does not have a valid URL! Make sure you set a link URL before sending this newsletter.':
              [
                '你的链接 "%{linkName}" 不是一个有效的链接！请确保在发送邮件设置了正确的链接。',
              ],
            "Your site has more than %{var1} pages. Since you're on the %{var2} plan, only the first %{var3} pages will be published.":
              [
                "你单个网站的页面数已超过%{var1}页。由于您是%{var2}套餐，只有前%{var3}个页面可以上线哦。",
              ],
            "Your site is currently in single-page mode. Activate multiple pages and add up to %{var1} pages per site.":
              [
                "你的网站现在处于单页面模式。激活多页面模式，可以单个网站添加%{var1}个页面哦。",
              ],
            "Your site is not yet published. It won't be viewable until you publish.":
              ["你的网站还没上线，在这之前访客是看不到的"],
            "Your site is using an older version of Google Analytics (UA tracker), which will stop working on July 1, 2023. To maintain your Google Analytics tracking, [link:please create a new Google Analytics 4 (GA4) property on Google Analytics] and set it up on your site.":
              [
                "你的网站正在使用Google Analytics的旧版本（UA跟踪器），该版本将于2023年7月1日停止服务。为了能够正常使用Google Analytics功能，[link:请在Google Analytics上创建一个新版跟踪器（GA4）]，并将其设置在你的网站上。",
              ],
            "Your yearly plan comes with a free domain for a year. Redeem yours now!":
              [
                "你的年度套餐附送一个有效期为一年的免费域名。快来兑换你自己的域名吧！",
              ],
            "You’ve blocked notifications in this browser. View how to unblock":
              ["你已关闭了浏览器消息通知。了解如何开启。"],
            "[boldText: Reach your visitors in real time,] collect their emails, and give a personal touch. Live Chat turns visitors into valuable leads for your business.":
              [
                "[boldText: 随时与访客沟通,] 获得访客的邮箱地址，与他们进行互动，在线聊天帮助你获得更多客户。",
              ],
            "[link] to continue.": ["[link]以继续。"],
            "[placeholderStrong1:You'll be billed $25 immediately] for your email but [placeholderStrong2: will be credited $25] for the first payment of your Strikingly plan.":
              [
                "[placeholderStrong1: 您将会被立即扣款邮箱费用 $25]，但[placeholderStrong2: 会获得 $25 的抵扣金]，用于 Strikingly 套餐的首年费用。",
              ],
            "[strong: Note:] On the %{var1} plan, you can add up to %{var2} pages on a site.":
              [
                "[strong: 注意:]现在是%{var1}套餐，你在单个网站上最多可以添加%{var2}个页面。",
              ],
            "[strong: Note:] You've reached your publish limit for %{plan} sites. You can clone more sites, but you won’t be able to publish them if they're using %{plan} features. Are you sure you want to continue?":
              [
                "您已经达到了发布%{plan}网站的限制。如需要发布具有企业版功能的新网站，您需要购买额外的%{plan}网站，或取消现有已发布的网站。",
              ],
            active: ["已生效"],
            "active contacts this month": ["个有效联系人（本月）"],
            "but you can chat with us, or leave a message!": [
              "你可以直接联系我们或给我们留言",
            ],
            "connect custom domain": ["绑定自定义域名"],
            "custom domain": ["自定义域名"],
            "dashboard|Reactivate": ["续费"],
            day: ["日"],
            "day later": ["天后"],
            "days later": ["天后"],
            "e.g.": ["例如"],
            "e.g. G-XXXXXXXXXX.": ["例如：G-XXXXXXXXXX。"],
            "e.g. www.mydomain.com": ["例如：www.abc.com"],
            "ecommerce|Please renew your plan to publish. If you have any questions, please contact customer service.":
              ["续费后可继续使用小程序。如果有任何疑问，请联系在线客服处理。"],
            "ecommerce|Reactivate": ["前往续费"],
            "ecommerce|Renew your plan to reactivate your Mini-Program": [
              "前往续费重新激活套餐",
            ],
            "ecommerce|Your plan is expired. Please reactivate.": [
              "套餐已到期。前往续费",
            ],
            forever: ["永久"],
            from: ["从"],
            immediately: ["立即"],
            "is available!": ["可用！"],
            "last 7 days": ["过去 7 天"],
            month: ["月"],
            "password can't be empty": ["密码不能为空"],
            "pricing|Start 14-day Trial": ["开始14天试用"],
            "product image": ["产品图片"],
            restricted: ["需修改"],
            retweeted: ["转发"],
            "s4|No, Thanks": ["不用，谢谢"],
            save: ["保存"],
            "select an existing site": ["选择已生成的网站"],
            "start now": ["开始创建"],
            "switch view": ["切换视图"],
            "the app is open or is running in the background.": [
              "软件已打开，或正在后台运行。",
            ],
            "under review": ["审核中"],
            "unpublish a site below or remove excess products": [
              "以下一个网站下线或删除多余的商品",
            ],
            year: ["年"],
          },
        },
      };
    },
  },
]);
