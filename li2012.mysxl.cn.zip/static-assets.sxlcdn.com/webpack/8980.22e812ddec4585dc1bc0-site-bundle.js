/*! For license information please see 8980.22e812ddec4585dc1bc0-site-bundle.js.LICENSE.txt */
(self.webpackChunkbobcat_monorepo =
  self.webpackChunkbobcat_monorepo || []).push([
  [8980],
  {
    304393: function (e, t, o) {
      var i = {
        "./": 653549,
        "./Blog": 26889,
        "./Blog.es6": 26889,
        "./Ecommerce": 589145,
        "./Ecommerce.es6": 589145,
        "./FAQ": 502676,
        "./FAQ.es6": 502676,
        "./Slider": 396392,
        "./Slider.es6": 396392,
        "./index": 653549,
        "./index.es6": 653549,
      };
      function n(e) {
        var t = r(e);
        return o(t);
      }
      function r(e) {
        if (!o.o(i, e)) {
          var t = new Error("Cannot find module '" + e + "'");
          throw ((t.code = "MODULE_NOT_FOUND"), t);
        }
        return i[e];
      }
      (n.keys = function () {
        return Object.keys(i);
      }),
        (n.resolve = r),
        (e.exports = n),
        (n.id = 304393);
    },
    584987: function (e, t, o) {
      "use strict";
      o.r(t),
        o.d(t, {
          ErrorBoundary: function () {
            return x;
          },
          default: function () {
            return b;
          },
        });
      var i = o(501068),
        n = o.n(i),
        r = o(573126),
        a = o(863056),
        s = o(468420),
        l = o(327344),
        d = o(484441),
        c = o(103020),
        p = o(803362),
        g = (o(974916), o(323123), o(2991), o(25843), o(366757)),
        m = o(595386),
        u = o(353147);
      function h(e) {
        var t = (function () {
          if ("undefined" == typeof Reflect || !n()) return !1;
          if (n().sham) return !1;
          if ("function" == typeof Proxy) return !0;
          try {
            return (
              Boolean.prototype.valueOf.call(n()(Boolean, [], function () {})),
              !0
            );
          } catch (e) {
            return !1;
          }
        })();
        return function () {
          var o,
            i = (0, p.Z)(e);
          if (t) {
            var r = (0, p.Z)(this).constructor;
            o = n()(i, arguments, r);
          } else o = i.apply(this, arguments);
          return (0, c.Z)(this, o);
        };
      }
      var f = g.memo(
          (0, m.default)("div", { target: "css-7sps990" })(
            "text-align:center;padding:100px 20px;font-size:14px;> div{display:inline-block;zoom:1;background:#eee;padding:18px 30px;border-radius:3px;color:#777;border-bottom:1px solid #ddd;text-shadow:none;}"
          )
        ),
        x = (function (e) {
          (0, d.Z)(o, e);
          var t = h(o);
          function o(e) {
            var i;
            return (
              (0, s.Z)(this, o),
              ((i = t.call(this, e)).state = {
                currentError: null,
                errorInfo: null,
              }),
              i
            );
          }
          return (
            (0, l.Z)(o, [
              {
                key: "componentDidCatch",
                value: function (e, t) {
                  this.setState({ currentError: e, errorInfo: t });
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this.state.currentError;
                  return e
                    ? (console.log(e.stack),
                      this.props.hide
                        ? null
                        : (0, a.Z)(
                            f,
                            {},
                            void 0,
                            (0, a.Z)(
                              "div",
                              {},
                              void 0,
                              u(
                                "Oops, something went wrong. Refresh the page and try again; if the error keeps happening please contact support!"
                              )
                            )
                          ))
                    : this.props.children;
                },
              },
            ]),
            o
          );
        })(g.Component);
      function b(e) {
        return (function (t) {
          (0, d.Z)(i, t);
          var o = h(i);
          function i() {
            return (0, s.Z)(this, i), o.apply(this, arguments);
          }
          return (
            (0, l.Z)(i, [
              {
                key: "render",
                value: function () {
                  return (0, a.Z)(
                    x,
                    {},
                    void 0,
                    g.createElement(e, (0, r.Z)({}, this.props, this.state))
                  );
                },
              },
            ]),
            i
          );
        })(g.Component);
      }
    },
    9769: function (e, t, o) {
      "use strict";
      o.r(t),
        o.d(t, {
          default: function () {
            return C;
          },
          getShapeHeight: function () {
            return E;
          },
        });
      var i,
        n,
        r = o(501068),
        a = o.n(r),
        s = o(841266),
        l = o(468420),
        d = o(327344),
        c = o(505281),
        p = o(484441),
        g = o(103020),
        m = o(803362),
        u = o(844845),
        h = o(863056),
        f = o(977766),
        x = o.n(f),
        b = o(294184),
        w = o.n(b),
        v = o(366757),
        y = o(223336),
        k = o(496486),
        S = o(7904),
        z = o(318592),
        _ = o(818166),
        T = o.n(_),
        N = ["firstSectionShape"];
      var O = function (e) {
          var t,
            o,
            i,
            n,
            r,
            a,
            s,
            l,
            d,
            c,
            p,
            g,
            m,
            u,
            h,
            f,
            b,
            w,
            v,
            y,
            k,
            S,
            z,
            _,
            T,
            N;
          return x()(
            (t = x()(
              (o = x()(
                (i = x()(
                  (n = x()(
                    (r = x()(
                      (a = x()(
                        (s = x()(
                          (l = x()(
                            (d = x()(
                              (c = x()(
                                (p = x()(
                                  (g = x()(
                                    (m = x()(
                                      (u = x()(
                                        (h = x()(
                                          (f = x()(
                                            (b = x()(
                                              (w = x()(
                                                (v = x()(
                                                  (y = x()(
                                                    (k = x()(
                                                      (S = x()(
                                                        (z = x()(
                                                          (_ = x()(
                                                            (T = x()(
                                                              (N =
                                                                ".s-section-shape {\n    &.s-first-section-round {\n      position: absolute;\n      left: 50%;\n      ".concat(
                                                                  e.putArrowOnTopOfSecondSection
                                                                    ? "top: 100%;height: 1px;"
                                                                    : "top: 0;height: 100%;",
                                                                  "\n      & .shape1,\n      .shape2 {\n        display: block;\n        position: absolute;\n        width: 100vw;\n        left: -50vw;\n        "
                                                                ))
                                                            ).call(
                                                              N,
                                                              "height: 100%;",
                                                              "\n      }\n      svg.s-first-section-svg {\n        position: absolute;\n        left: -50vw;\n        width: 100vw;\n        bottom: 0;\n        z-index: "
                                                            ))
                                                          ).call(
                                                            T,
                                                            2,
                                                            ";\n      }\n      &:not(._on-top-of-second-section) {\n        /* round shape is made of .s-section */\n        & .shape1,\n        .shape2 {\n          bottom: 0;\n          z-index: "
                                                          ))
                                                        ).call(
                                                          _,
                                                          -1,
                                                          ";\n        }\n        & .shape2 {\n          clip-path: circle(250vw at 50% calc(99% - 250vw));\n        }\n      }\n      &._on-top-of-second-section {\n        /* round shape is made of .shape1 */\n        & .shape1 {\n          z-index: "
                                                        ))
                                                      ).call(
                                                        z,
                                                        3,
                                                        ";\n          clip-path: circle(250vw at 50% calc(99% - 250vw));\n        }\n      }\n    }\n\n    &.s-section-shape.s-first-section-round {\n      & .shape1,\n      .shape2 {\n        background-color: "
                                                      ))
                                                    ).call(
                                                      S,
                                                      e.firstSectionArrowColor,
                                                      ";\n      }\n      &:not(._on-top-of-second-section) {\n        & .shape2 {\n          "
                                                    ))
                                                  ).call(
                                                    k,
                                                    e.firstSectionHasBackgroundImage
                                                      ? ""
                                                      : "background-color: ".concat(
                                                          e.firstSectionBgColor,
                                                          " !important; /* in some case, section(e.g slider) bg is transparent */"
                                                        ),
                                                    "\n        }\n      }\n    }\n\n    &.s-first-section-slant {\n      position: absolute;\n      left: 50%;\n      top: 100%;\n      z-index: "
                                                  ))
                                                ).call(
                                                  y,
                                                  2,
                                                  ";\n      & .shape1 {\n        display: block;\n        position: absolute;\n        left: -50vw;\n      }\n      &:not(._on-top-of-second-section) {\n        & .shape1 {\n          bottom: -100%;\n          border-top: "
                                                ))
                                              ).call(
                                                v,
                                                E("slant"),
                                                " solid transparent;\n          border-right: 100vw solid "
                                              ))
                                            ).call(
                                              w,
                                              e.firstSectionArrowColor,
                                              ";\n        }\n      }\n      &._on-top-of-second-section {\n        & .shape1 {\n          border-bottom: 8vw solid transparent;\n          border-right: 100vw solid "
                                            ))
                                          ).call(
                                            b,
                                            e.firstSectionArrowColor,
                                            ";\n        }\n      }\n    }\n\n    &.s-first-section-big-arrow {\n      &:not(._on-top-of-second-section) {\n        position: absolute;\n        left: 50%;\n        top: 100%;\n        & .shape1,\n        .shape2 {\n          content: ' ';\n          display: block;\n          position: absolute;\n        }\n      }\n      &._on-top-of-second-section {\n        position: absolute;\n        left: 50%;\n        border-left: 50vw solid transparent;\n        border-right: 50vw solid transparent;\n        margin-left: -50vw;\n      }\n    }\n\n    &.s-first-section-big-arrow {\n      &:not(._on-top-of-second-section) {\n        & .shape1,\n        .shape2 {\n          bottom: -150px;\n          left: -1500px;\n          width: 3000px;\n          height: 150px;\n          transform: rotate(-7deg);\n          background-color: "
                                          ))
                                        ).call(
                                          f,
                                          e.firstSectionArrowColor,
                                          ";\n        }\n        & .shape2 {\n          transform: rotate(7deg);\n        }\n      }\n      &._on-top-of-second-section {\n        z-index: "
                                        ))
                                      ).call(h, 100, ";\n        border-top: "))
                                    ).call(u, E("bigArrow"), " solid "))
                                  ).call(
                                    m,
                                    e.firstSectionArrowColor,
                                    ";\n      }\n    }\n\n    &.s-first-section-arrow {\n      &:not(._on-top-of-second-section) {\n        position: absolute;\n        bottom: 0;\n        width: 100%;\n        left: 0;\n        & .shape1,\n        .shape2 {\n          position: absolute;\n          bottom: 0;\n          width: 50%;\n          height: 0;\n          box-sizing: border-box;\n        }\n        & .shape1 {\n          left: 0;\n          border-right-color: transparent !important;\n        }\n        & .shape2 {\n          right: 0;\n          border-left-color: transparent !important;\n        }\n      }\n      &._on-top-of-second-section {\n        position: absolute;\n        left: 50%;\n      }\n    }\n\n    &.s-first-section-arrow {\n      &:not(._on-top-of-second-section) {\n        height: "
                                  ))
                                ).call(
                                  g,
                                  E("arrow"),
                                  ";\n        width: 100%;\n        z-index: "
                                ))
                              ).call(
                                p,
                                100,
                                ";\n        & .shape1,\n        .shape2 {\n          border-width: 0 "
                              ))
                            ).call(c, E("arrow"), " "))
                          ).call(d, E("arrow"), "\n            "))
                        ).call(l, E("arrow"), ";\n          border-color: "))
                      ).call(
                        s,
                        e.firstSectionArrowColor,
                        ";\n          border-style: solid;\n\n        }\n      }\n      &._on-top-of-second-section {\n        margin-left: -"
                      ))
                    ).call(a, E("arrow"), ";\n        z-index: "))
                  ).call(r, 100, ";\n        border-left: "))
                ).call(
                  n,
                  E("arrow"),
                  " solid transparent;\n        border-right: "
                ))
              ).call(
                i,
                E("arrow"),
                " solid transparent;\n        border-top: "
              ))
            ).call(o, E("arrow"), " solid "))
          ).call(t, e.firstSectionArrowColor, ";\n      }\n    }\n   }\n");
        },
        C = (function (e) {
          (0, p.Z)(f, e);
          var t,
            o,
            r =
              ((t = f),
              (o = (function () {
                if ("undefined" == typeof Reflect || !a()) return !1;
                if (a().sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                  return (
                    Boolean.prototype.valueOf.call(
                      a()(Boolean, [], function () {})
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              })()),
              function () {
                var e,
                  i = (0, m.Z)(t);
                if (o) {
                  var n = (0, m.Z)(this).constructor;
                  e = a()(i, arguments, n);
                } else e = i.apply(this, arguments);
                return (0, g.Z)(this, e);
              });
          function f(e) {
            var t;
            return (
              (0, l.Z)(this, f),
              (t = r.call(this, e)),
              (0, u.Z)((0, c.Z)(t), "updateShape", function () {
                return t.forceUpdate();
              }),
              (t.state = { useStaticCss: !0 }),
              (t.updateShape = (0, k.debounce)(t.updateShape, 200)),
              t
            );
          }
          return (
            (0, d.Z)(f, [
              {
                key: "componentWillMount",
                value: function () {
                  (0, S.staticStyle)(O(this.props)),
                    T().getInitPageUID() !== T().getCurrentPageUID() &&
                      this.setState({ useStaticCss: !1 });
                },
              },
              {
                key: "componentDidMount",
                value: function () {
                  y(window).on("resize", this.updateShape);
                },
              },
              {
                key: "componentWillUnmount",
                value: function () {
                  y(window).off("resize", this.updateShape);
                },
              },
              {
                key: "render",
                value: function () {
                  var e,
                    t,
                    o,
                    r,
                    a,
                    l,
                    d,
                    c = this.props;
                  return (
                    (e = c.firstSectionShape),
                    (t = (0, s.Z)(c, N)),
                    (o = this.state.useStaticCss),
                    (d = {
                      arrow: "s-first-section-arrow",
                      bigArrow: "s-first-section-big-arrow",
                      slant: "s-first-section-slant",
                      round: "s-first-section-round",
                    }[e])
                      ? (0, h.Z)(
                          "div",
                          {
                            className: w()(
                              "".concat(d, " s-section-shape"),
                              !o && (0, z.css)("&", O(t)),
                              t.putArrowOnTopOfSecondSection &&
                                (0, z.css)(
                                  "&",
                                  ((r = e),
                                  "round" === r &&
                                    x()(
                                      (a = x()(
                                        (l =
                                          ".s-section-shape {\n    &.s-first-section-round {\n      svg.s-first-section-svg {\n        height: ".concat(
                                            E("round"),
                                            ";\n      }\n      &:not(._on-top-of-second-section) {\n        & .shape1,\n        .shape2 {\n          height: "
                                          ))
                                      ).call(
                                        l,
                                        E("round"),
                                        ";\n        }\n      }\n      &._on-top-of-second-section {\n        & .shape1 {\n          height: "
                                      ))
                                    ).call(
                                      a,
                                      E("round"),
                                      ";\n        }\n      }\n    }\n  }"
                                    ))
                                ),
                              {
                                "_on-top-of-second-section":
                                  t.putArrowOnTopOfSecondSection,
                              }
                            ),
                          },
                          void 0,
                          i || (i = (0, h.Z)("div", { className: "shape1" })),
                          n || (n = (0, h.Z)("div", { className: "shape2" })),
                          !1
                        )
                      : null
                  );
                },
              },
            ]),
            f
          );
        })(v.Component);
      function E(e) {
        var t = 20;
        return (
          "undefined" != typeof window &&
            (t = window && window.innerWidth / 100),
          {
            arrow: "25px",
            bigArrow: "calc(".concat(Math.tan((7 * Math.PI) / 180), " * 50vw)"),
            slant: "calc(40px + 4vw)",
            round: "".concat(
              250 * t - Math.sqrt(250 * t * 250 * t - 50 * t * 50 * t),
              "px"
            ),
            none: "0px",
          }[e] || "0px"
        );
      }
    },
    500987: function (e, t, o) {
      "use strict";
      o.r(t);
      var i = o(501068),
        n = o.n(i),
        r = o(863056),
        a = o(468420),
        s = o(327344),
        l = o(484441),
        d = o(103020),
        c = o(803362),
        p = o(366757),
        g = o(171725);
      var m = (function (e) {
        (0, l.Z)(p, e);
        var t,
          o,
          i =
            ((t = p),
            (o = (function () {
              if ("undefined" == typeof Reflect || !n()) return !1;
              if (n().sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    n()(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (e) {
                return !1;
              }
            })()),
            function () {
              var e,
                i = (0, c.Z)(t);
              if (o) {
                var r = (0, c.Z)(this).constructor;
                e = n()(i, arguments, r);
              } else e = i.apply(this, arguments);
              return (0, d.Z)(this, e);
            });
        function p() {
          return (0, a.Z)(this, p), i.apply(this, arguments);
        }
        return (
          (0, s.Z)(p, [
            {
              key: "render",
              value: function () {
                var e = this.props,
                  t = e.title,
                  o = e.subTitle,
                  i = e.btnText,
                  n = e.closeDialog;
                return (0, r.Z)(
                  "div",
                  { className: "reminder-dialog-wrapper" },
                  void 0,
                  (0, r.Z)("p", { className: "dialog-title" }, void 0, t),
                  o &&
                    (0, r.Z)("p", { className: "dialog-subtitle" }, void 0, o),
                  i &&
                    (0, r.Z)(
                      "div",
                      { className: "dialog-btns-wrap" },
                      void 0,
                      (0, r.Z)(
                        g.Z,
                        { className: "small no-margin", onClick: n },
                        void 0,
                        i
                      )
                    )
                );
              },
            },
          ]),
          p
        );
      })(p.PureComponent);
      t.default = m;
    },
    598980: function (e, t, o) {
      "use strict";
      var i = o(353147),
        n = o(686902),
        r = o(14310),
        a = o(620116),
        s = o(834074),
        l = o(778914),
        d = o(239649),
        c = o(820368),
        p = o(663978),
        g = o(60530)(o(60530));
      p(t, "__esModule", { value: !0 });
      var m,
        u = o(812077),
        h = (0, g.default)(u),
        f = o(487672),
        x = (0, g.default)(f);
      o(974916), o(323123), o(569600);
      var b = o(51942),
        w = (0, g.default)(b),
        v = o(933032),
        y = ((0, g.default)(v), o(678580)),
        k = (0, g.default)(y),
        S = o(620116),
        z = (0, g.default)(S),
        _ = o(981643),
        T = (0, g.default)(_),
        N = o(277149),
        O = ((0, g.default)(N), o(54103)),
        C = ((0, g.default)(O), o(366757)),
        E = (0, g.default)(C),
        Z = o(45697),
        I = (0, g.default)(Z),
        D = o(973935),
        M = (0, g.default)(D),
        A = o(223336),
        P = (0, g.default)(A),
        H = o(496486),
        B = ((0, g.default)(H), o(294184)),
        F = ((0, g.default)(B), o(399069)),
        L = (0, g.default)(F),
        R = o(234584),
        q = (0, g.default)(R),
        W = o(141655),
        j = ((0, g.default)(W), o(183123)),
        U = (0, g.default)(j),
        Y = o(818166),
        Q = (0, g.default)(Y),
        G = o(399402),
        V = ((0, g.default)(G), o(217136)),
        J = o(704991),
        K = (0, g.default)(J),
        X = o(584987),
        $ = o(851172),
        ee = o(9769),
        te = (0, g.default)(ee),
        oe = o(718711),
        ie = (0, g.default)(oe),
        ne = o(548273),
        re = ((0, g.default)(ne), o(143393)),
        ae = ((0, g.default)(re), o(43138)),
        se = (0, g.default)(ae),
        le = o(104802),
        de = o(500987),
        ce = ((0, g.default)(de), o(653549)),
        pe = (o(178498), o(359019)),
        ge = o(881701);
      function me(e, t) {
        var o = n(e);
        if (r) {
          var i = r(e);
          t &&
            (i = a(i).call(i, function (t) {
              return s(e, t).enumerable;
            })),
            o.push.apply(o, i);
        }
        return o;
      }
      function ue(e) {
        for (var t = 1; t < arguments.length; t++) {
          var o,
            i = null != arguments[t] ? arguments[t] : {};
          if (t % 2)
            l((o = me(Object(i), !0))).call(o, function (t) {
              (0, x.default)(e, t, i[t]);
            });
          else if (d) c(e, d(i));
          else {
            var n;
            l((n = me(Object(i)))).call(n, function (t) {
              p(e, t, s(i, t));
            });
          }
        }
        return e;
      }
      var he = ["s5-theme", "bright", "glow", "zine"],
        fe = L.default.create({
          displayName: "Section",
          propTypes: {
            indexType: I.default.oneOf(["first", "middle", "last"]).isRequired,
            isFirstNoHiddenSection: I.default.bool,
            eagerLoad: I.default.bool.isRequired,
            waypointHandler: I.default.func,
            binding: I.default.object.isRequired,
            index: I.default.number,
            isOnlyOneSection: I.default.bool,
            inSectionSelector: I.default.bool,
            templateDummyData: I.default.any,
          },
          contextTypes: { theme: I.default.object },
          _showFirstSectionShape: function () {
            var e = this.props.firstSectionShape;
            return "s5-theme" === q.default.getThemeName() &&
              0 === this.props.index &&
              "none" !== e
              ? E.default.createElement(te.default, this.props)
              : null;
          },
          getShowReminderDialog: function () {
            var e = "first" === this.props.indexType;
            return (
              !q.default.hideNavTextColorReminderDialog() &&
              "s5-theme" === q.default.getThemeName() &&
              e
            );
          },
          getSectionbackgroundId: function () {
            return this.getDefaultBinding().get([
              "components",
              "background1",
              "id",
            ]);
          },
          componentDidMount: function () {
            var e = this;
            try {
              var t = "first" === this.props.indexType;
              window.edit_page.Event.publish("Slide.afterAdd", {
                target: (0, P.default)(M.default.findDOMNode(this)),
              }),
                t &&
                  window.edit_page.Event.subscribe(
                    "Editor.navbarUpdated",
                    function () {
                      e.forceUpdate();
                    }
                  );
            } catch (e) {
              console.log(e);
            }
          },
          componentWillMount: function () {
            if (
              (this.setState({ isShowReminderDialog: !1 }),
              U.default.getHasAdvancedSectionLayoutSetting())
            ) {
              var e = this.props,
                t = e.sectionPadding,
                o = e.contentAlignment,
                i = e.contentWidth,
                n = e.topNavSpace,
                r = e.navTheme,
                a = q.default.getThemeName(),
                s = null == r ? void 0 : r.get("layout"),
                l = (0, pe.getNavHeight)(s, a),
                d = {
                  sectionPadding: t,
                  contentAlignment: o,
                  contentWidth: i,
                  topNavSpace: n,
                },
                c = this._getSectionLayoutClass(d, l);
              this.sectionLayoutClass = c;
            }
          },
          componentWillUnmount: function () {
            var e, t;
            null === (e = window.edit_page) ||
              void 0 === e ||
              null === (t = e.Event) ||
              void 0 === t ||
              t.publish("Slide.afterDelete");
          },
          mapStateToProps: function (e) {
            var t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              o = {
                sectionIdOnDragMode: null,
                navIsTransparent: (0, le.getNavIsTransparent)(e),
                navTheme: (0, le.getNavTheme)(e),
                isPreviewMode: !1,
                isMobileView: !1,
              };
            if ("s5-theme" === q.default.getThemeName()) {
              var i = {};
              if (t.useOutProps) {
                var n = e.mergeDeep(t.themeSiteState);
                i = ue(
                  ue(
                    {
                      navTheme: (0, le.getNavTheme)(n),
                      navIsTransparent: (0, le.getNavIsTransparent)(n),
                    },
                    (0, $.getFirstSectionShapeProps)(n)
                  ),
                  (0, $.getSectionClassProps)(n)
                );
              }
              return (0, w.default)(
                {},
                (0, $.getSectionClassProps)(e),
                (0, $.getFirstSectionShapeProps)(e),
                o,
                i
              );
            }
            return (0, w.default)({}, o);
          },
          _onClickShowSection: function () {},
          _onClickSectionDragMode: function (e) {},
          closeReminderDialog: function () {
            this.setState({ isShowReminderDialog: !1 });
          },
          _resetSection: function () {},
          _getEditorWidgetClass: function () {
            return "";
          },
          _getSectionLayoutClass: function (e, t) {
            var o = this.props,
              i = o.indexType,
              n = o.navIsTransparent,
              r = o.navTheme,
              a = o.showFooter,
              s = o.showLogo,
              l = o.isOnlyOneSection,
              d = q.default.getThemeName(),
              c = "first" === i,
              p = "last" === i,
              g = this.getDefaultBinding(),
              m = "s6" === g.get("template_version"),
              u = g.get(["components", "slideSettings", "layout_config"]);
            if (!m || !u || 0 === u.size) return "";
            var h = l && Q.default.getIsFullScreenOnlyOneSection(),
              f = u.get("width"),
              x = u.get("height"),
              b = h && "full" !== x ? "minimum" : x,
              w = u.get("content_align"),
              v = e.topNavSpace || 0,
              y = null == r ? void 0 : r.get("isSticky"),
              S = null == r ? void 0 : r.get("layout"),
              _ = (se.default.isMobile(), pe.SECTION_WIDTH_STYLE);
            "profile" === d && (_ = pe.SECTION_WIDTH_STYLE_PERCENTAGE);
            var N,
              O = 0;
            c && y && !(0, k.default)(he).call(he, d) && (O = t),
              "ion" === d &&
                (O =
                  ((null === (N = (0, P.default)(".s-section-1").offset()) ||
                  void 0 === N
                    ? void 0
                    : N.top) || 0) + 120),
              "full" === b && (O = 0);
            var C = (0, pe.SECTION_ALIGN_STYLE)(f, b, w, v, c, n, S, d);
            if (p && !a && s) {
              var E = C.split(";");
              C = (0, z.default)(E)
                .call(E, function (e) {
                  return (
                    e && -1 === (0, T.default)(e).call(e, "padding-bottom")
                  );
                })
                .join(";");
            }
            return (0, ge.css)(
              "&{",
              !1,
              "\n\n        .s-section:not(.s-slider-section):not(.s-grid-section):not(.s-new-gallery-section):not(.s-blog-section):not(.s-store-section):not(.s-new-media-section):not(.s-accordion-section){display:flex;",
              C,
              "\n\n          ",
              "full" === b &&
                "padding-top: 0px !important;\n          min-height: calc(100vh - ".concat(
                  v + O,
                  "px) !important;\n          box-sizing: content-box;"
                ),
              "\n\n          .container{margin:0 3%;max-width:94%;box-sizing:border-box;",
              _[f],
              "}}}"
            );
          },
          getSectionHiddenTips: function () {
            if (!U.default.getCanUseNewMobileEditorFeature())
              return i("Editor|This section is hidden.");
            var e = this.getDefaultBinding(),
              t = e.get("components.slideSettings.hidden_section"),
              o = (0, V.getIsHiddenMobileSection)(e);
            return t && o
              ? i("Editor|This section is hidden for desktop & mobile view.")
              : t && !o
              ? i(
                  "Editor|This section is only visible in mobile view and is hidden on desktop view."
                )
              : !t && o
              ? i(
                  "Editor|This section is only visible in desktop view and is hidden on mobile view."
                )
              : void 0;
          },
          render: function () {
            var e,
              t,
              o = this.props,
              i =
                (o.indexType,
                o.isFirstNoHiddenSection,
                o.navIsTransparent,
                o.navTheme),
              n = o.showFooter,
              r = o.showLogo,
              a = o.inSectionSelector,
              s = (o.templateDummyData, o.isPreviewMode, o.isMobileView),
              l = o.useOutProps,
              d = (this.state.isShowReminderDialog, this.getDefaultBinding());
            this.observeBinding(d);
            var c = q.default.getThemeName(),
              p = null == i ? void 0 : i.get("layout"),
              g = (0, pe.getNavHeight)(p, c),
              u = this.props,
              f = {
                sectionPadding: u.sectionPadding,
                contentAlignment: u.contentAlignment,
                contentWidth: u.contentWidth,
                topNavSpace: u.topNavSpace,
              },
              x = d.get("template_name"),
              b = "s6" === d.get("template_version"),
              v = (this.context.theme || this.props.manualTheme).getSection(
                x,
                b
              );
            1 !== this.props.index ||
              "round" !== this.props.firstSectionShape ||
              this.props.putArrowOnTopOfSecondSection ||
              (t = !0),
              (e =
                !!/lazyLoading=0/.test(window.location.href) ||
                this.props.eagerLoad);
            var y = function (e) {
                switch (e) {
                  case "first":
                    return -1;
                  case "last-bottom":
                    return "102%";
                  default:
                    return "50%";
                }
              },
              S = "section-".concat(d.get("id")),
              z = (0, V.isSectionHidden)(d, s),
              _ = "slide s-section-".concat(this.props.index + 1);
            if (
              (n ||
                "last" !== this.props.indexType ||
                ((_ += " s-last-section-no-footer"),
                (_ += r ? " s-show-strikingly-logo" : ""),
                (_ += q.default.hasNewMobileActions()
                  ? " s-has-new-mobile-actions"
                  : "")),
              z && (_ += " s-hidden-section"),
              U.default.getCanUseNewMobileEditorFeature() &&
                (d.get("components.slideSettings.hidden_section") &&
                  (_ += " s-new-hidden-pc-section"),
                (0, V.getIsHiddenMobileSection)(d) &&
                  (_ += " s-new-hidden-mobile-section")),
              "first" === this.props.indexType &&
                (_ += " s-first-visible-section"),
              "s5-theme" === q.default.getThemeName())
            ) {
              var T,
                N = this.props.firstSectionHeight;
              _ += " ".concat(
                (0, K.default)(
                  (0, w.default)(
                    {
                      sectionIndex: this.props.index,
                      bottomPaddingImportant:
                        0 === this.props.index &&
                        (0, k.default)((T = ["large", "full"])).call(T, N)
                          ? "!important"
                          : "",
                      navHeight: g,
                    },
                    this.props
                  )
                )
              );
            }
            (b || "s6_common_section" === x) && (_ += " s-s6-wrapper"),
              U.default.getHasAdvancedSectionLayoutSetting() &&
                (_ += " ".concat(this.sectionLayoutClass));
            var O = d.get("id");
            return (
              Boolean(O === this.props.sectionIdOnDragMode),
              "booking" === x && (_ += " s-booking-section-wrapper"),
              this.props.isOnlyOneSection &&
                Q.default.getIsFullScreenOnlyOneSection() &&
                (_ += " s-only-one-section"),
              (0, h.default)(
                "li",
                { className: _, id: S },
                "section-".concat(S),
                !a &&
                  (0, h.default)(ie.default, {
                    handler: this.props.waypointHandler,
                    offset: y(this.props.indexType),
                    group: "sections",
                    containerId: S,
                  }),
                !a &&
                  (m ||
                    (m = (0, h.default)("div", {
                      className: "section-anchor",
                    }))),
                !b && !a && void 0,
                !1,
                !z &&
                  (0, h.default)(
                    X.ErrorBoundary,
                    { hide: !0 },
                    void 0,
                    (0, h.default)(ce.SectionWithStyles, {
                      component: v.component,
                      themeName: c,
                      hackRoundShapeFlag: t,
                      binding: d,
                      eagerLoad: e,
                      indexType: this.props.indexType,
                      index: this.props.index,
                      s5ClassProps: f,
                      isOnlyOneSection: this.props.isOnlyOneSection,
                    })
                  ),
                (!a || l) && this._showFirstSectionShape(),
                "last" === this.props.indexType &&
                  !a &&
                  (0, h.default)(ie.default, {
                    handler: this.props.waypointHandler,
                    offset: y("last-bottom"),
                    group: "sections",
                    containerId: S,
                  })
              )
            );
          },
        });
      (t.default = fe), (e.exports = t.default);
    },
    26889: function (e, t, o) {
      "use strict";
      var i = o(663978),
        n = o(60530)(o(60530));
      i(t, "__esModule", { value: !0 });
      var r = o(366757),
        a = ((0, n.default)(r), o(595386)),
        s = (0, n.default)(a),
        l = o(370917);
      (t.default = (0, s.default)("div", { target: "css-1vhlegm0" })(
        ".s-blog{clear:both;}// new mobile layout\n  @media only screen and (max-width:727px){.s-blog-section.s-new-mobile-layout{.s-blog-wrapper\n        .s-blog-col-placeholder\n        .s-blog-col-body\n        .s-blog-posts\n        .s-blog-entry.s-layout-columns{&.mobile-one-columns{width:98%;}&.mobile-two-columns{width:48%;}&.mobile-three-columns{width:31.33%;}&.mobile-four-columns{width:23%;}}}}.s-blog-wrapper{.s-blog-col-placeholder{min-height:116px;position:relative;font-family:inherit;font-weight:inherit;font-size:16px;position:relative;.s-blog-row{margin-bottom:6px;}.s-link-color(@color){}.s-blog-link{.s-no-bg &{color:#007fff;&:hover{color:darken(#007fff,10%);}}&.s-blog-prev-link,&.s-blog-next-link,&.s-blog-pagination-page{.s-no-bg &{color:#777;&:hover{color:darken(#777,10%);}}}}ul.s-blog-pagination{display:inline;li{display:inline;}li a.s-blog-pagination-page{&.active{text-decoration:underline;}}}.s-blog-col-body{min-height:100px;&.s-blog-no-posts{display:block;}.s-blog-left &{margin:0;width:100%;}.s-blog-posts{.s-blog-entry{line-height:1.5;text-align:left;.s-blog-entry-inner{overflow:hidden;.s-blog-entry-left{vertical-align:top;.sample-tag{position:absolute;left:10px;top:10px;z-index:2;}.s-blog-avatar{background-size:cover;background-position:center;background-repeat:no-repeat;&.s-blog-whole-avatar{background-size:contain;}}.s-blog-default-avatar{background:#ddd;text-align:center;font-size:40px;.s-no-bg &{color:#aaa;}.entypo-bookmark{position:relative;top:-4px;color:#aaa;}}}.s-blog-entry-right{vertical-align:middle;.s-blog-details{.s-blog-title{font-size:26px;margin-bottom:5px;line-height:1.2;a{color:inherit;font-weight:inherit;vertical-align:middle;}@media only screen and (max-width:479px){font-size:20px;}}.s-blog-info{font-size:83%;.s-bg-light-text &{color:#fff;}.s-bg-dark-text &{color:#000;}}.s-blog-details-blurb{margin-top:5px;word-break:break-word;@media only screen and (max-width:500px){display:none;}}}.sample-tag{display:none;vertical-align:middle;margin-left:10px;}}}&.s-layout-row{&.s-avatar-none{.s-blog-entry-inner{padding:15px 0;.s-blog-entry-left{display:none;}.s-blog-entry-right{.sample-tag{display:inline-block;}}}}&.s-avatar-circle,&.s-avatar-square{.s-blog-entry-inner{padding:15px 0;.s-blog-entry-left,.s-blog-entry-right{display:table-cell;}.s-blog-avatar{width:80px;height:80px;margin-right:20px;overflow:hidden;@media only screen and (max-width:479px){width:65px;height:65px;}video{position:relative;top:-15px;left:-80px;width:228px;}}}}&.s-avatar-circle{.s-blog-avatar{border-radius:50%;}}&.s-avatar-square{.s-blog-avatar{border-radius:3px;}}}&.s-layout-columns{margin-right:2%;display:inline-block;vertical-align:top;&.one{width:98%;}&.two{width:48%;}&.three{width:31.33%;}&.four{width:23%;}}}.tiled-columns{display:inline-block;@media only screen and (max-width:727px){&.s-blog-entry.s-layout-columns{width:48%;}}.s-blog-entry.s-layout-columns{width:100%;}.s-blog-entry-right{text-align:center;}}}.s-blog-read-more-link{text-decoration:underline;color:inherit;}}.s-blog-col-foot{margin-top:28px;padding-bottom:20px;text-align:inherit;.s-blog-left &{text-align:left;}.s-more-blog-posts-button{padding:8px 16px;font-size:100%;}}.s-loading{position:absolute;top:50%;left:50%;padding:16px;margin:-32px 0 0 -19px;border-radius:99px;border:3px solid white;}.no-posts-error{margin:30px auto;}}}",
        function (e) {
          var t = e.themeName;
          return "glow" === t
            ? (0, l.css)(
                ".s-blog-wrapper{.s-blog-col-placeholder{.s-blog-col-body.s-layout-g{.s-blog-posts{text-align:center;.s-blog-entry{display:inline-block;float:none;}}}.s-blog-details{.s-blog-title{font-size:24px;margin-bottom:5px;line-height:1.2;a{color:inherit;}@media only screen and (max-width:1023px){font-size:20px;}}}}}"
              )
            : "ion" === t
            ? (0, l.css)(
                ".s-blog-wrapper{.s-blog-col-placeholder{.s-blog-col-body{margin:0;width:100%;&.s-layout-f .s-blog-entry-left{margin-bottom:10px;}}}}.s-blog-avatar{border-radius:3px;}"
              )
            : "bright" === t
            ? (0, l.css)(
                ".s-blog-wrapper .s-blog-col-placeholder .s-blog-details .s-blog-title{font-weight:bold;}"
              )
            : "onyx_new" === t
            ? (0, l.css)(
                ".s-blog-wrapper{.s-blog-col-placeholder{.s-blog-col-body{margin:0;width:100%;}}}"
              )
            : (0, l.css)();
        }
      )),
        (e.exports = t.default);
    },
    589145: function (e, t, o) {
      "use strict";
      var i = o(663978),
        n = o(60530)(o(60530));
      i(t, "__esModule", { value: !0 });
      var r = o(366757),
        a = ((0, n.default)(r), o(595386)),
        s = (0, n.default)(a),
        l = o(370917);
      (t.default = (0, s.default)("div", { target: "css-1kcvu530" })(
        ".s-store-section{@media screen and (max-width:727px){padding-top:60px;}&.s-bg-gray{.product-filter-container{.list .option .item.price-slider .s-kit-slider{.s-kit-slider-rail,.s-kit-slider-track{color:#c6c9cd;background:#c6c9cd;}}}}&.s-bg-dark{.product-filter-container{.title,.reset,.list .option .item.price-slider .s-kit-slider .price-slider-marks,.option .label{color:rgba(255,255,255,0.8);}.top-bar,.option{border-bottom:1px solid rgba(255,255,255,0.2);}.list .option .item.price-slider .s-kit-slider{.s-kit-slider-rail,.s-kit-slider-track{color:rgba(255,255,255,0.2);background:rgba(255,255,255,0.2);}.s-kit-slider-handle{border:1px solid #c6c9cd;}}}}&.s-bg-video,&.s-bg-image{.product-filter-container{background:#fff;}}}.s-ecommerce{clear:both;hyphens:auto;.s-ecommerce-content{position:relative;text-align:left;clear:both;.small-symbol{font-size:0.8em;}.s-ecommerce-products-wrapper{clear:both;position:relative;&.loading-wrapper{opacity:0.6;}.product-section-wrapper{position:relative;}@media screen and (min-width:727px){&.has-filter{display:inline-block;width:calc(100% - 250px);}}.s-component-overlay{border-radius:2px;position:absolute;width:100%;height:100%;z-index:90;cursor:pointer;background:rgba(255,255,255,0.4);border:1px solid #bbb;border:1px solid rgba(0,0,0,0.25);opacity:0;transition:opacity 0.05s;&:hover,&.visible{opacity:1;}}.s-ecommerce-card-view-wrapper{width:100%;position:relative;left:0;transition:left 0.3s;.s-ecommerce-card-view-cards-wrapper{width:100%;overflow:hidden;.s-ecommerce-card-view-cards{overflow:hidden;clear:both;display:flex;flex-wrap:wrap;margin-bottom:-50px;@media screen and (max-width:727px){margin-bottom:-30px;}.s-ecommerce-card-view-card{margin-bottom:50px;text-align:center;float:none;display:inline-block;vertical-align:top;cursor:pointer;box-sizing:border-box;&.card{background:white;}@media screen and (max-width:727px){width:48%;box-sizing:content-box;margin:0 0 30px;&:nth-child(odd){margin-right:4%;}&:only-child{width:100%;margin-right:0%;margin-left:0%;}}@media screen and (min-width:728px){&.sixteen.columns{margin-left:2.5%;margin-right:2.5%;width:95%;}&.eight.columns{margin-left:2.5%;margin-right:2.5%;width:45%;}}a.external-link{color:initial;}.s-ecommerce-card-view-card-image{width:100%;overflow:hidden;position:relative;img{width:100%;position:relative;}.sample-tag{position:absolute;left:10px;top:10px;z-index:1;}&.landscape,&.landscape-4-3{height:0;padding-bottom:75%;}&.square{height:0;padding-bottom:100%;}&.landscape-16-9{height:0;padding-bottom:56.25%;}&.portrait-4-5{height:0;padding-bottom:125%;}&.portrait{height:0;padding-bottom:125%;}&.auto{height:auto;padding-bottom:inherit;}.s-ecommerce-card-view-card-image-overlay,.s-ecommerce-card-view-card-image-button{position:absolute;opacity:0;transition:opacity 0.6s;}.s-ecommerce-card-view-card-image-overlay{top:0;left:0;width:100%;height:100%;background:#fff;cursor:pointer;}.s-ecommerce-card-view-card-image-button{top:42%;left:0;width:100%;text-align:center;text-transform:uppercase;.s-common-button{font-size:16px;padding:12px 20px;transform:translateY(10px);transition:transform 0.6s;}}@media screen and (min-width:727px){&.in-stock:hover{.s-ecommerce-card-view-card-image-overlay{opacity:0.8;}.s-ecommerce-card-view-card-image-button{opacity:1;.s-common-button{transform:translateY(0);}}}&.out-of-stock:hover{.s-ecommerce-card-view-card-image-overlay{opacity:0.3;}}}}.s-ecommerce-card-view-card-stock-warning{position:absolute;top:0;left:0;min-width:20%;padding:3px 8px;font-size:15px;}.s-ecommerce-card-view-card-description{line-height:1.25;margin-bottom:12px;&.card{padding:0 10px;}}.s-ecommerce-card-view-card-name{font-size:16px;margin-top:15px;word-break:break-word;}.s-ecommerce-card-view-card-price-wrapper{display:flex;align-items:baseline;flex-flow:wrap;margin-top:5px;gap:10px;&.left-align{justify-content:start;}&.center-align{justify-content:center;}&.right-align{justify-content:end;}.s-ecommerce-card-view-card-price{margin-top:0;}}.s-ecommerce-card-view-card-link{.s-ecommerce-card-view-card-name{line-height:1.45;}}.s-ecommerce-card-view-card-price{margin-top:5px;font-size:18px;line-height:1.25;font-weight:600;word-break:break-word;}.s-ecommerce-card-view-card-original-price{line-height:1.25;}.s-ecommerce-card-view-card-original-price{text-decoration:line-through;color:#93989c;}}}.s-ecommerce-card-view-pagination{text-align:right;.prev-page-btn,.next-page-btn{cursor:pointer;color:#4b5056;&:hover{color:#636972;}}.page-index{padding:0 5px;color:#4b5056;&.normal{cursor:pointer;&:hover{color:#999;}}}}}.s-ecommerce-card-view-detail{width:40%;float:left;.s-ecommerce-card-view-detail-header{margin-bottom:30px;overflow:hidden;-webkit-touch-callout:none;user-select:none;.right{float:right;.prev-product-btn,.next-product-btn{display:inline-block;margin-left:20px;}}&.bottom{margin-top:-10px;}@media screen and (max-width:500px){&.bottom{display:flex;flex-direction:column-reverse;margin:0 0 20px 0;}margin-bottom:10px;.right{float:none;margin-top:20px;.prev-product-btn,.next-product-btn{margin:0;}.prev-product-btn{float:left;}.next-product-btn{float:right;}}}}}}.s-ecommerce-row-view-product{width:100%;display:inline-block;position:relative;margin-bottom:40px;padding:0;&:last-child{margin-bottom:0;}.slider-wrapper{display:none;position:relative;.slide-thumb{width:100%;position:relative;}.slider-dot-wrapper{margin:8px 0;width:100%;text-align:center;.slider-dot{display:inline-block;margin:0 5px;width:10px;height:10px;border-radius:6px;}}}&.booking-event-item{&.center-item{display:flex;align-items:center;justify-content:center;}&.left-item{.s-ecommerce-row-view-product-detail-panel{padding-left:0;}}}.half-offset-right{width:100%;}.s-ecommerce-row-view-product-image-wrapper{position:relative;overflow:hidden;box-sizing:border-box;cursor:pointer;font-size:0;transition:height 0.3s;@media screen and (max-width:727px){margin-bottom:15px;}&.square{height:0;padding-bottom:100%;}&.landscape-16-9{height:0;padding-bottom:56.25%;}&.landscape-4-3{height:0;padding-bottom:75%;}&.portrait-4-5{height:0;padding-bottom:125%;}&.portrait{height:0;padding-bottom:125%;}&.auto{height:auto;padding-bottom:inherit;}&.square,&.landscape-16-9,&.landscape-4-3,&.portrait-4-5,&.portrait{img{position:absolute;}}img{width:100%;}.sample-tag{position:absolute;left:10px;top:10px;z-index:1;}.s-ecommerce-row-view-product-image-gallery-button{position:absolute;right:10px;bottom:10px;width:34px;height:34px;text-align:center;line-height:34px;background:#f6f7f8;border:1px solid #d2d2d2;border-radius:3px;cursor:pointer;.entypo-picture{font-size:18px;color:#636972;}.fa{font-size:20px;color:#636972;vertical-align:middle;}@media screen and (max-width:560px){width:40px;height:40px;line-height:40px;.entypo-picture{font-size:20px;}}}.s-ecommerce-row-view-product-image-overlay-wrapper{position:absolute;top:0;left:0;width:100%;height:100%;.s-ecommerce-row-view-product-image-overlay,.s-ecommerce-row-view-product-image-overlay-icon{position:absolute;opacity:0;transition:opacity 0.5s;}.s-ecommerce-row-view-product-image-overlay{top:0;left:0;width:100%;height:100%;background:#fff;}.s-ecommerce-row-view-product-image-overlay-icon{bottom:15px;right:15px;font-size:0;transition:opacity 0.5s;.fa{font-size:16px;color:#888;transform:translateY(15px);transition:transform 0.5s;}}}&:hover{.s-ecommerce-row-view-product-image-overlay{opacity:0.7;}.s-ecommerce-row-view-product-image-overlay-icon{opacity:1;.fa{transform:translateY(0);}}}}.s-ecommerce-row-view-product-thumbnail-list{width:100%;overflow:hidden;ul{position:relative;left:0;display:flex;margin-top:10px;width:200%;transition:left 0.3s,right 0.3s;li{position:relative;width:6.5%;height:0;padding-bottom:6.5%;margin-right:0.75%;text-align:center;overflow:hidden;cursor:pointer;opacity:0.4;&:hover{opacity:1;}&.current{opacity:1;box-sizing:border-box;top:-2px;}img{width:200%;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);}}}}.s-ecommerce-row-view-product-detail-panel{box-sizing:border-box;padding-left:10px;.s-ecommerce-row-view-product-name{margin-bottom:15px;font-size:20px;font-weight:600;line-height:1.1;h1{font-size:inherit !important;}.title-name{display:inline-block;vertical-align:middle;}.sample-tag{vertical-align:middle;margin-left:10px;}}.s-ecommerce-row-view-product-pricing{font-size:18px;font-weight:600;margin-bottom:5px;display:inline-block;&.need-select-variation{color:rgba(0,0,0,0.3);}}.s-ecommerce-after-pay-message{display:flex;align-item:center;margin-bottom:15px;color:#636972;font-size:13px;.payment-icon{position:relative;top:4px;margin:0 2px;height:14px;}.hint-icon{position:relative;top:2px;margin:0 4px;font-size:13px;cursor:pointer;}}.s-ecommerce-row-view-product-original-pricing{display:inline-block;margin-left:10px;text-decoration:line-through;color:#93989c;}.s-ecommerce-row-view-product-pricing,.s-ecommerce-row-view-product-original-pricing{margin-bottom:10px;}.statistics-wrapper{cursor:pointer;margin-bottom:10px;text-decoration:underline;.ant-rate{margin-right:10px;}}.s-ecommerce-row-view-product-desc{margin:0px 0 20px;word-wrap:break-word;line-height:1.5;@media screen and (max-width:727px){margin:0px 0 10px;}.view-detail-btn{color:#29aad8;display:inline-block;margin-top:10px;cursor:pointer;}}.s-ecommerce-row-view-product-add-options{margin:20px 0px;> p{margin-bottom:15px;font-weight:700;}.total{display:flex;justify-content:space-between;margin-top:10px;span{font-weight:700;font-size:17px;line-height:1.5;&:first-child{color:rgba(80,85,92,1);}&:last-child{color:rgba(226,51,51,1);}}}.options{border:1px solid rgba(198,201,205,1);border-radius:6px;.option-item{display:flex;align-items:start;border-bottom:1px solid rgba(198,201,205,1);padding:15px;&:last-child{border-bottom:0;}input{width:20px;height:20px;margin-right:10px;border:1px solid rgba(99,105,114,1);border-radius:2px;margin-top:2px;}img{width:80px;height:50px;margin-right:10px;}.fa.fa-camera{color:#a9aeb2;font-size:40px;padding:5px 20px;margin-right:10px;}.item-info{max-width:calc(100% - 120px);p{line-height:1.5;display:flex;align-items:center;}p:not(.price){font-size:17px;&:first-child{font-weight:700;margin-bottom:5px;}}p.desc{overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;max-width:350px;}.price{span{font-weight:700;font-size:17px;}.currency-tag{padding:1px 3px 1px;color:rgb(169,174,178,1);border:1px solid rgb(169,174,178,1);font-size:14px;font-weight:bold;line-height:1.5;border-radius:3px;text-transform:uppercase;font-style:normal;vertical-align:middle;margin-right:5px;}}}}}}.s-ecommerce-row-view-product-select{width:100%;margin-bottom:16px;select,input{&:focus{outline:none;}}select{white-space:nowrap;}.select-label{font-weight:400;font-size:16px;}.select-variation,.select-number{border-bottom:1px solid #a9aeb2;padding-bottom:10px;}.select-variation{margin-bottom:15px;position:relative;select{font-size:16px;position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;}.select-title{width:90%;text-overflow:ellipsis;display:inline-block;overflow:hidden;white-space:nowrap;}.select-arrow{float:right;display:inline-block;margin-right:1px;height:14px;width:14px;border:1px solid #919394;border-width:0 2px 2px 0;transform:rotate(45deg);}select{option:first{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;}}}.select-number{-webkit-touch-callout:none;user-select:none;display:flex;justify-content:space-between;align-items:center;.select-label{flex:0 0 auto;}.number-input-wrapper{text-align:right;flex-grow:1;flex-shrink:1;flex-basis:0%;font-size:22px;}.minus-icon,.plus-icon{display:inline-block;vertical-align:middle;padding:0 10px;margin:-10px 0;font-size:30px;cursor:pointer;color:#a9aeb2;&.disable{color:#e2e4e7;cursor:not-allowed;}}.plus-icon{padding-right:0;margin-right:-5px;}input{width:60px;vertical-align:middle;text-align:center;background:transparent;color:inherit;}}}.s-ecommerce-row-view-product-error-text{margin:10px 0;font-weight:normal;color:#fb7d2b;}.s-ecommerce-row-view-product-order-btn{text-align:center;margin:0;width:100%;max-width:100%;padding:12px;font-size:18px;box-sizing:border-box;&.s-view-preview-btn{margin-bottom:20px;}&.disable{cursor:not-allowed;color:#ccc;border-color:#ccc;background:#f6f6f6;box-shadow:none;text-shadow:none;}&.disabled-quote{cursor:not-allowed;}}.s-ecommerce-buy-prompt{text-align:center;color:#a9aeb2;margin-top:10px;i{margin-right:5px;}}}&.from-product-page{@media screen and (max-width:727px){.slider-wrapper{display:block;}.image-wrapper,.s-ecommerce-row-view-product-thumbnail-list{display:none;}.s-ecommerce-row-view-product-image-wrapper{height:auto !important;padding-bottom:0 !important;}}}}.s-booking-row-view-description{margin-bottom:5px;word-wrap:break-word;white-space:pre-wrap;display:flex;align-items:flex-start;.booking-icon{margin-right:10px;&.location{margin-top:3px;}&.quote{margin-top:6px;}}}.time-zone-view{flex-wrap:wrap;margin-bottom:10px;.time-zone{&.label{margin-right:6px;}}}.s-booking-date-picker{display:flex;font-size:14px;align-items:center;margin:15px 0 5px;padding:10px;border-radius:4px;color:#c6c9cd;border:1px solid #c6c9cd;.calendar{width:16px;margin-right:4px;}}.s-kit-date-time-picker-wrapper{position:relative;margin:15px 0 5px;.s-kit-date-picker-wrapper{width:100%;cursor:pointer;.ant-picker{width:100%;padding:10px;input{cursor:pointer;}}}.s-booking-time-picker{position:absolute;left:280px;top:48px;width:180px;height:307px;z-index:2000;background-color:#fff;box-shadow:6px 6px 10px rgba(0,0,0,8%);.s-kit-step-time-list{height:306px;overflow-y:auto;border:1px solid #f4f6f8;.s-kit-time-item{font-size:14px;color:#4b5056;padding:10px 0 10px 15px;&:hover{cursor:pointer;color:#518bff;background-color:rgba(240,246,255,1);}&.disabled{cursor:not-allowed;color:#c6c9cd;}.spots-left-text{font-size:12px;color:#c6c9cd;}}.loading-panel{width:100%;margin-top:125px;text-align:center;color:#4b5056;}}}@media screen and (max-width:727px){.s-booking-time-picker{left:153px;}}}.s-booking-form-field{margin-bottom:10px;&.email{margin-bottom:15px;}input[type='text']{width:100%;padding:10px;border-radius:4px;box-sizing:border-box;border:1px solid #c6c9cd;&:focus{outline:none;}}.field-error{color:#e64751;font-size:12px;margin-top:5px;}}.select-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.45);z-index:310;pointer-events:none;opacity:0;transition:opacity 0.4s;&.show{pointer-events:initial;opacity:1;}}.mobile-select{position:fixed;bottom:0;left:0;font-size:16px;width:100%;z-index:310;pointer-events:none;display:none;.container{padding:0;border:none;overflow:hidden;&:after,&:before{display:none !important;}}.select-panel{background:#fff;transform:translateY(0);transition:transform 0.4s;pointer-events:all;position:absolute;top:0;left:0;width:100%;&.show{transform:translateY(-100%);}.error-text{color:#fb7d2b;}}.select-label{flex:0 0 auto;color:#919394;padding:8px 0;}.price,.variations{border-bottom:1px solid #e2e4e7;}.price,.quantity{.columns{display:flex;justify-content:space-between;align-items:center;}.minus-icon,.plus-icon{font-size:30px;display:inline-block;vertical-align:middle;padding:0 15px;margin:-10px 0;cursor:pointer;color:#a9aeb2;&.disable{color:#e2e4e7;}}.plus-icon{padding-right:0;margin-right:-5px;}.quantity-number{display:inline-block;width:60px;vertical-align:middle;text-align:center;}}.variations-list{max-height:360px;overflow:scroll;}.variation-item{display:inline-block;margin:0 5px 5px 0;padding:6px 8px;line-height:1;border:1px solid #cdd1d4;border-radius:4px;color:#636972;}.add-btn{color:#fff;width:100%;padding:10px 0;font-size:20px;text-align:center;text-transform:uppercase;position:relative;pointer-events:all;&.disabled{pointer-events:none;cursor:not-allowed;color:#ccc;border:1px solid #ccc;background:#f6f6f6;box-shadow:none;text-shadow:none;}}}@media screen and (max-width:727px){.s-page-product &{.s-ecommerce-row-view-product-select,.s-ecommerce-row-view-product-order-btn{display:none;}.mobile-select{display:block;}}}}.s-ecommerce-empty-box{position:relative;height:150px;width:100%;border-radius:4px;box-sizing:border-box;margin:0;.tags{position:absolute;top:0;left:0;width:100%;line-height:150px;text-align:center;z-index:1;color:#e2e4e7;display:flex;align-items:center;justify-content:center;height:100%;width:100%;.fa,.entypo-bag{display:inline-block;font-size:70px;width:30%;}}.text{width:100%;position:absolute;top:50%;left:0;transform:translateY(-50%);padding:0 30px;box-sizing:border-box;z-index:2;line-height:1.5;text-align:center;color:#636972;text-transform:uppercase;}}.s-ecommerce-pagination{text-align:center;margin-top:20px;.s-ecommerce-pagination-item{padding:0 5px;cursor:pointer;text-decoration:none;color:inherit;&.selected{text-decoration:underline;}}}.s-ecommerce-wrapper{width:100%;.s-product-filter-wrapper{position:relative;display:inline-block;vertical-align:top;width:250px;.s-component-overlay{max-height:1200px;}.s-product-filter-btn{display:none;}}.s-product-filter-skeleton-wrapper{width:225px;padding:0 10px 15px 14px;box-sizing:border-box;.skeleton-border-line{width:100%;border-bottom:1px solid #e2e4e7;margin:15px 0;}.skeleton-line:first-child{width:40%;height:30px;}.skeleton-line:last-child{width:100%;height:60px;}}.reset-filter{text-align:center;font-size:14px;width:calc(100% - 250px);display:inline-block;span{cursor:pointer;text-decoration:underline;}}}@media screen and (max-width:726px){.s-ecommerce-wrapper{display:block;.s-product-filter-wrapper{text-align:center;width:100%;display:inline-block;.s-product-filter{display:none;}.s-product-filter-btn{display:block;}.s-kit-btn{margin:auto;margin-bottom:25px;}}.s-product-filter-skeleton-wrapper{width:100%;padding:0;.skeleton-line:first-child{margin:0 auto 25px;width:150px;height:40px;}.skeleton-line:last-child,.skeleton-border-line{display:none;}}}}}}.s-ecommerce-container{clear:both;}@media screen and (min-width:728px){.s-store-section:not(.s-bg-light-text){.s-ecommerce-card-view-card.card{border:1px solid rgba(0,0,0,0.25);}}}",
        function (e) {
          var t = e.themeName;
          return "perspective" === t
            ? (0, l.css)(
                "@media screen and (max-width:1127px){.s-ecommerce-row-view-product-image-wrapper{margin-bottom:15px;}}"
              )
            : "profile" === t || "spectre" === t || "zine" === t
            ? (0, l.css)(
                "@media screen and (max-width:727px){.s-ecommerce\n            .s-ecommerce-content\n            .s-ecommerce-products-wrapper\n            .s-ecommerce-card-view-wrapper\n            .s-ecommerce-card-view-detail\n            .s-ecommerce-card-view-detail-header{margin-bottom:5px;.right{float:none;margin-top:12px;.prev-product-btn{margin-left:0;}}}}"
              )
            : (0, l.css)();
        }
      )),
        (e.exports = t.default);
    },
    502676: function (e, t, o) {
      "use strict";
      var i = o(663978),
        n = o(60530)(o(60530));
      i(t, "__esModule", { value: !0 });
      var r = o(366757),
        a = ((0, n.default)(r), o(595386)),
        s = (0, n.default)(a);
      (t.default = (0, s.default)("div", { target: "css-neub100" })(
        ".s-repeatable-item{.s-kit-collapse-item{height:auto;.s-kit-collapse-header{white-space:normal;width:100%;display:flex;.arrow{position:absolute;height:15px;top:0;bottom:0;right:15px;left:unset;margin:auto;}.s-component.s-text{margin:20px;font-size:20px;min-height:29px;flex:1;word-break:break-word;}.s-accordion-question-text{width:99%;&,> *{font-weight:bold;}}}.s-kit-collapse-content{> .s-kit-collapse-content-box{padding:0px;}.s-component.s-text{font-size:14px;color:#8d949c;}}}}"
      )),
        (e.exports = t.default);
    },
    396392: function (e, t, o) {
      "use strict";
      var i = o(663978),
        n = o(60530)(o(60530));
      i(t, "__esModule", { value: !0 });
      var r = o(366757),
        a = ((0, n.default)(r), o(595386)),
        s = (0, n.default)(a),
        l = o(370917);
      (t.default = (0, s.default)("div", { target: "css-xhe5lr0" })(
        "@media screen and (min-width:728px){.right,.left{.s-title-group,.cta-button-wrapper{text-align:left;}.cta-button-wrapper{&.center-align{text-align:center;}&.left-align{text-align:left;}&.right-align{text-align:right;}}}}@media screen and (max-width:727px){.s-component.s-media{max-width:80%;margin:0 auto;margin-bottom:15px;}}.noImage{text-align:center;.s-title{text-align:center;}}.slider-container{.slide-selectors{transition:opacity 0.4s;}.prev-button,.next-button{transition:padding 0.6s ease-in-out,background 0.2s,opacity 0.2s;}}.slider-container.loading{.slider .item{display:none;&:first-of-type{display:block;padding-top:80px;padding-bottom:80px;}}.slide-selectors,.prev-button,.next-button{opacity:0;}}",
        function (e) {
          var t = e.themeName;
          return "ion" === t
            ? (0, l.css)(
                ".iosslider{box-shadow:inset 0 0 1px black;border-radius:3px;}.prev-button{display:none;}.next-button{height:12px;border-radius:12px;font-size:20px;float:left;cursor:pointer;font-weight:bold;color:@gray;text-shadow:0 1px @gray;line-height:12px;vertical-align:middle;margin-right:6px;margin-top:4px;}.slide-selectors{float:left;margin-left:1px;.slide-selectors-inner .selector-wrapper{float:left;.selector{width:12px;height:12px;cursor:pointer;border-radius:12px;background:#666;margin-right:6px;margin-top:6px;&.selected,&:hover{background:#999;}&:before{content:' ';position:absolute;}}}}"
              )
            : "minimal" === t || "pitch_new" === t
            ? (0, l.css)(
                ".s-common-button{font-size:18px;padding:16px 30px;text-transform:uppercase;}.container{.cta-button-wrapper{margin-top:36px;.cta-button{margin-bottom:10px;display:inline-block;}}.media-outer{&.recede{position:absolute;width:80px;top:0;right:0;z-index:99;.media-wrapper{min-width:220px;}@media only screen and (max-width:1024px){right:100px;}}@media only screen and (max-width:727px){float:none;}}.slider-desc{display:inline-block;zoom:1;&.middle{vertical-align:middle;}.center-mixin{}&.center{text-align:center;float:none;.cta-button-wrapper.left{text-align:center;}.half-offset-right{padding-right:0;}}@media only screen and (max-width:727px){margin-top:0 !important;margin-bottom:0 !important;text-align:center;float:none;.cta-button-wrapper.left{text-align:center;}.half-offset-right{padding-right:0;}}}.media-wrapper{margin-bottom:0;@media only screen and (max-width:727px){margin-bottom:22px;}}.cta-button .s-common-button{padding:16px 60px;}}"
              )
            : "sleek" === t
            ? (0, l.css)(
                ".item .inner{width:100%;box-sizing:border-box;padding:80px 80px;}.cta-button-wrapper{margin-top:30px;.s-common-button{padding:15px 25px;font-size:120%;}}.noImage .s-title-group{text-align:center;}"
              )
            : (0, l.css)();
        }
      )),
        (e.exports = t.default);
    },
    653549: function (e, t, o) {
      "use strict";
      var i = o(663978),
        n = o(60530)(o(60530));
      i(t, "__esModule", { value: !0 }), (t.SectionWithStyles = void 0);
      var r = o(812077),
        a = (0, n.default)(r);
      o(974916), o(115306);
      var s = o(366757),
        l = (0, n.default)(s),
        d = o(329756),
        c = {
          blog: "Blog",
          ecommerce: "Ecommerce",
          portfolio: "Ecommerce",
          booking: "Ecommerce",
          donation: "Ecommerce",
          faq: "FAQ",
          slider: "Slider",
        };
      t.SectionWithStyles = function (e) {
        if (!e) return null;
        var t = e.binding,
          i = e.component,
          n = e.themeName,
          r = i,
          s =
            e.sectionName ||
            t.get("template_name").replace(d.RegexConstants.ZERO_TO_NINE, ""),
          p = c[s];
        if (!p) return l.default.createElement(r, e, e.children);
        var g = o(304393)("./".concat(p));
        return (0, a.default)(
          g,
          { themeName: n },
          void 0,
          l.default.createElement(r, e, e.children)
        );
      };
    },
    704991: function (e, t, o) {
      "use strict";
      var i = o(663978),
        n = o(60530)(o(60530));
      i(t, "__esModule", { value: !0 }),
        (t.default = function (e) {
          var t = e.sectionPadding,
            o = e.sectionIndex,
            i = e.bottomPaddingImportant,
            n = e.firstSectionHeight,
            r = e.topNavSpace,
            s = e.firstSectionShape,
            c = e.putArrowOnTopOfSecondSection,
            g = e.navIsTransparent,
            u = e.navHeight,
            h = (0, m.getShapeHeight)(s),
            f = r || 0;
          function x(e) {
            var t,
              i = e,
              n = h;
            if (g && 0 === o && !p.default.isMobile()) {
              var r = (0, l.default)(".s-navbar-desktop-fixed").outerHeight();
              (i += r), (n += r);
            }
            return 1 === o && c && n
              ? (0, a.default)((t = "calc(".concat(n, " + "))).call(t, i, "px)")
              : "".concat(i, "px");
          }
          return (0, d.css)(
            ".s-top-padding-half{&.s-section:not(.s-slider-section):not(.s-grid-section),&.s-grid-section:not(._wide),&.s-new-grid-section{",
            "small" === t && (0, d.css)("padding-top:", x(20), ";"),
            ";",
            "normal" === t && (0, d.css)("padding-top:", x(40), ";"),
            ";",
            "large" === t && (0, d.css)("padding-top:", x(55), ";"),
            ";}}.s-bottom-padding-half{&.s-section:not(.s-slider-section):not(.s-grid-section),&.s-grid-section:not(._wide),&.s-new-grid-section{",
            "small" === t && (0, d.css)("padding-bottom:20px ", i, ";"),
            ";",
            "normal" === t && (0, d.css)("padding-bottom:40px ", i, ";"),
            ";",
            "large" === t && (0, d.css)("padding-bottom:55px ", i, ";"),
            ";}}.s-top-padding-none{&.s-section:not(.s-slider-section):not(.s-grid-section),&.s-grid-section:not(._wide),&.s-new-grid-section{padding-top:",
            x(0),
            ";}}.s-bottom-padding-none{&.s-section:not(.s-slider-section):not(.s-grid-section),&.s-grid-section:not(._wide),&.s-new-grid-section{padding-bottom:0 ",
            i,
            ";}}& .s-section:not(.s-slider-section):not(.s-grid-section),& .s-grid-section:not(._wide),& .s-new-grid-section{",
            "small" === t &&
              (0, d.css)(
                "padding-top:",
                x(40),
                ";padding-bottom:40px ",
                i,
                ";"
              ),
            ";",
            "normal" === t &&
              (0, d.css)(
                "padding-top:",
                x(75),
                ";padding-bottom:75px ",
                i,
                ";"
              ),
            ";",
            "large" === t &&
              (0, d.css)(
                "padding-top:",
                x(110),
                ";padding-bottom:110px ",
                i,
                ";"
              ),
            ";",
            0 === o &&
              "large" === n &&
              (0, d.css)(
                "box-sizing:border-box;min-height:calc(80vh - ",
                f,
                "px);"
              ),
            ";",
            0 === o &&
              "full" === n &&
              (0, d.css)(
                "box-sizing:border-box;min-height:calc(100vh - ",
                f,
                "px);"
              ),
            ";}",
            "round" === s &&
              (0, d.css)(
                "& .s-section{",
                0 === o &&
                  !c &&
                  (0, d.css)(
                    "clip-path:circle(200vw at 50% calc(99% - 200vw));@media screen and (max-width:727px){clip-path:circle(200vh at 50% calc(99% - 200vh));}"
                  ),
                ";",
                1 === o &&
                  !c &&
                  (0, d.css)(
                    "/* transform:scale(1);*/\n          /* If ths 1st & 2nd sections bg are solid color,the second section bg styles maybe ignored unexpectedly in some case(at least happens in Chrome). Transform can fix this weird problem,but it's useless in class. So we add this style on .s-section element directly. */"
                  ),
                ";}"
              ),
            ";",
            0 === o &&
              (0, d.css)(
                ".s-section.s-grid-section._wide:not(.s-new-grid-section){padding-top:",
                u,
                "px;}"
              )
          );
        });
      var r = o(977766),
        a = (0, n.default)(r),
        s = o(223336),
        l = (0, n.default)(s),
        d = o(881701),
        c = o(43138),
        p = (0, n.default)(c),
        g = o(234584),
        m = ((0, n.default)(g), o(9769));
      e.exports = t.default;
    },
    399402: function (e, t, o) {
      "use strict";
      o(663978)(t, "__esModule", { value: !0 });
      var i = o(834243),
        n = {
          shouldFreeForMYO: function () {
            return i.getData() && i.getData().created_timestamp < 1495778878;
          },
        };
      (t.default = n), (e.exports = t.default);
    },
  },
]);
